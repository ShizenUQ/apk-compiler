package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import java.util.Calendar
import kotlin.math.max
import kotlin.math.sin

/** One thing Nova says: the text, the quick replies under it, and how long it stays when nobody answers. */
class NovaChip(val id: String, val label: String)

class NovaTalk(val text: String, val chips: List<NovaChip>, val holdMs: Long = 2600L)

/** What Nova knows about the moment when she talks. */
class NovaCtx(
    val game: String,
    val freedMb: Long,
    val boosted: Boolean,
    val minutes: Int,
    val fps: Int,
    val bat: Int,
    val temp: Int
)

/**
 * Nova's voice. Every line is built from small parts (opener, body, question, mood, joke), so the same game opened
 * ten times still sounds different, and she remembers what was said lately so she does not repeat herself. It all
 * runs on the phone, no internet.
 */
object NovaBrain {
    private val rnd = java.util.Random()

    private fun recent(c: Context): MutableList<String> =
        Prefs.str(c, "nova_recent", "").split("|").filter { it.isNotEmpty() }.toMutableList()

    /** Picks one option that was not used in the last few lines. */
    private fun pick(c: Context, tag: String, opts: List<String>): String {
        val r = recent(c)
        val fresh = opts.filter { (tag + opts.indexOf(it)) !in r }
        val i = opts.indexOf((if (fresh.isEmpty()) opts else fresh)[rnd.nextInt(if (fresh.isEmpty()) opts.size else fresh.size)])
        r.add(tag + i)
        while (r.size > 14) r.removeAt(0)
        Prefs.putStr(c, "nova_recent", r.joinToString("|"))
        return opts[i]
    }

    private fun fill(s: String, x: NovaCtx): String =
        s.replace("{g}", x.game).replace("{mb}", x.freedMb.toString()).replace("{min}", x.minutes.toString())
            .replace("{fps}", x.fps.toString()).replace("{bat}", x.bat.toString()).replace("{t}", x.temp.toString())

    private fun bucket(): Int {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (h) { in 5..11 -> 0; in 12..17 -> 1; in 18..22 -> 2; else -> 3 }
    }

    private val openers = listOf(
        listOf("Good morning, handsome.", "Morning, handsome. Gaming before breakfast?", "Rise and shine, handsome.", "Handsome, early start today.", "Morning, handsome. Coffee first, then glory.", "Hey handsome, fresh day, fresh match."),
        listOf("Hey handsome.", "Good afternoon, handsome.", "Handsome, you're back.", "Afternoon, handsome. Ready to play?", "There you are, handsome.", "Hi handsome, perfect time for a match."),
        listOf("Good evening, handsome.", "Evening, handsome. Prime time.", "Handsome, the night is yours.", "Hey handsome, the evening squad is here.", "Welcome back, handsome.", "Evening, handsome. Let's make it count."),
        listOf("It's late, handsome.", "Midnight session, handsome?", "Handsome, you should be asleep. But fine.", "Late night, handsome. I'll keep you company.", "Night owl mode, handsome.", "Handsome, the world is asleep. We're not.")
    )

    private val bodyFreed = listOf(
        "I cleared {mb} MB for {g}.", "{g} just got {mb} MB of breathing room.", "Boost done, {mb} MB freed.",
        "I swept out {mb} MB so {g} runs smooth.", "{mb} MB cleaned. {g} is all yours.", "Everything's tuned and {mb} MB lighter."
    )
    private val bodyClean = listOf(
        "Your RAM was already spotless.", "Nothing to clear, you keep things tidy.", "{g} is boosted and ready.",
        "Everything's tuned, nothing was in the way.", "Boost done, the phone was already in top shape."
    )
    private val bodyPlain = listOf(
        "{g} is open and I'm watching the numbers.", "I'm tracking {g} for you.", "Status is up, {g} is running.",
        "All set on my side.", "I've got your back in {g}."
    )
    private val asks = listOf(
        "Ready to play?", "Want some music while we play?", "What's the plan?", "Shall we drop in?", "Need anything before we start?",
        "Any requests?", "How are we feeling today?", "Say the word and I'll help."
    )

    fun greeting(c: Context, x: NovaCtx): NovaTalk {
        val op = pick(c, "o" + bucket(), openers[bucket()])
        val body = fill(
            if (x.boosted && x.freedMb > 0) pick(c, "bf", bodyFreed)
            else if (x.boosted) pick(c, "bc", bodyClean)
            else pick(c, "bp", bodyPlain), x
        )
        val ask = pick(c, "a", asks)
        val list = ArrayList<NovaChip>()
        val musicNo = Prefs.int(c, "nova_music_no", 0)
        val musicYes = Prefs.int(c, "nova_music_yes", 0)
        if (musicNo < musicYes + 3) list.add(NovaChip("music", "Play music"))
        list.add(listOf(NovaChip("go", "Let's go"), NovaChip("how", "How am I doing?"), NovaChip("joke", "Tell me something")).random())
        list.add(NovaChip("bye", "Not now"))
        return NovaTalk(fill("$op $body $ask", x), list)
    }

    fun reply(c: Context, id: String, x: NovaCtx): NovaTalk {
        when (id) {
            "go" -> return NovaTalk(fill(pick(c, "go", listOf(
                "That's the spirit, handsome. Go get them.", "Locked in. I'll keep watch.", "Show them what you've got, handsome.",
                "Good luck out there, I'm right here.", "Go be legendary, handsome.", "On your signal, champ. I'll stay quiet."
            )), x), emptyList())
            "bye" -> {
                Prefs.putInt(c, "nova_music_no", Prefs.int(c, "nova_music_no", 0) + 1)
                return NovaTalk(fill(pick(c, "by", listOf(
                    "No problem, handsome. I'll be here.", "Okay, I'll stay out of your way.", "Understood. Shout if you need me.",
                    "Quiet mode on. Have fun.", "Sure thing. I'm still watching your stats."
                )), x), emptyList(), 1800L)
            }
            "thanks" -> return NovaTalk(fill(pick(c, "th", listOf(
                "Anytime, handsome.", "That's what I'm here for.", "Always, handsome.", "My pleasure. Now go win.", "Happy to help."
            )), x), emptyList(), 1800L)
            "how" -> {
                val fpsLine = if (x.fps <= 0) "" else pick(c, "hf", listOf(
                    " You're holding {fps} FPS.", " {fps} FPS right now, steady.", " The frame counter says {fps}.", " Running at {fps} FPS."
                ))
                val time = pick(c, "hm", listOf(
                    "You've been in {g} for {min} min.", "{min} minutes in so far.", "That's {min} minutes of {g} already.", "{min} min on the clock."
                ))
                val bt = pick(c, "hb", listOf(
                    " Battery is at {bat}%, {t}°C.", " Battery {bat}%, temperature {t}°C.", " Phone is at {t}°C with {bat}% left.", " {bat}% battery and {t}°C."
                ))
                return NovaTalk(fill(time + fpsLine + bt, x), listOf(NovaChip("music", "Play music"), NovaChip("thanks", "Thanks")))
            }
            "joke" -> {
                val a = pick(c, "j1", listOf(
                    "Fun fact: you've opened {g} more than your fridge today.", "I don't blink, so I never miss a frame.", "My favourite number is 90, you know why.",
                    "If lag was a person, I'd politely escort it out.", "I've counted your frames. You're doing great.", "Somewhere a battery is quietly rooting for you.",
                    "Tip: hydrate. Even legends need water.", "I was going to tell a joke about RAM but I forgot it.", "They say gamers never sleep. I say we don't need to.",
                    "Thermal check: you're the coolest thing here."
                ))
                val b = pick(c, "j2", listOf(" Anyway.", " Just saying.", " Don't tell the others.", " Okay, back to work.", " Carry on, handsome.", ""))
                return NovaTalk(fill(a + b, x), listOf(NovaChip("joke", "Another"), NovaChip("music", "Play music"), NovaChip("thanks", "Thanks")))
            }
        }
        return NovaTalk("Anything else, handsome?", listOf(NovaChip("bye", "That's all")))
    }

    fun noPlaylist(c: Context, x: NovaCtx) = NovaTalk(fill(pick(c, "np", listOf(
        "You don't have a playlist yet, handsome. Make one in Frameline > Music.", "No playlists found. Create one in the Music tab and I'll play it.",
        "I'd love to, but there's no playlist. Add one in Frameline > Music."
    )), x), emptyList(), 3200L)

    fun askPlaylist(c: Context, names: List<Pair<String, String>>, x: NovaCtx): NovaTalk {
        val chips = names.take(4).map { NovaChip("pl:" + it.first, it.second) } + NovaChip("bye", "Not now")
        return NovaTalk(fill(pick(c, "ap", listOf(
            "Which playlist, handsome?", "Pick a playlist and I'll start it.", "What are we in the mood for?", "Choose your soundtrack.", "Which one should I play?"
        )), x), chips, 30_000L)
    }

    fun musicStart(c: Context, name: String): String = pick(c, "ms", listOf(
        "On it, handsome.", "Tuning in to $name.", "Coming right up.", "Sound check for $name.", "Let me set the mood."
    ))

    fun musicDone(c: Context, name: String, x: NovaCtx): NovaTalk = NovaTalk(pick(c, "md", listOf(
        "Now playing $name. Enjoy, handsome.", "$name is on. Turn it up.", "Your soundtrack is live: $name.", "Done. $name is playing.", "$name, as ordered."
    )), listOf(NovaChip("skip", "Next song"), NovaChip("thanks", "Thanks")), 8000L)
}

/**
 * Nova's speech bubble. It is a small cyber card that sits against the status overlay (a little pointer shows where it
 * is attached), types its line out, shows quick-reply chips, and can turn into a short "working" panel while she does
 * something for you.
 */
class NovaView(ctx: Context) : View(ctx) {
    var onChip: ((String) -> Unit)? = null
    var onExpire: (() -> Unit)? = null
    var onActionDone: (() -> Unit)? = null

    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val path = Path()
    private var talk: NovaTalk? = null
    private var layout: StaticLayout? = null
    private var chipRects: List<RectF> = emptyList()
    private var typedAt = 0L
    private var doneAt = 0L
    private var expired = false
    private var pressedChip = -1
    private var running = false

    var compact = false
        set(v) { field = v; relayout() }
    var side = 0          // where the status overlay is: 0 above the bubble, 1 below, 2 left, 3 right
        set(v) { field = v; relayout() }
    var ptr = 0f          // how far along that edge the pointer sits (px)

    private val pt get() = 7 * d
    private val cardW get() = (if (compact) 200 else 236) * d
    private val charMs = 24L

    // action mode
    private var actKind = ""
    private var actTitle = ""
    private var actSteps: List<String> = emptyList()
    private var actAt = 0L
    private var actDone = false
    private val stepMs = 560L

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    fun say(t: NovaTalk) {
        talk = t
        actKind = ""
        typedAt = System.currentTimeMillis()
        doneAt = 0L
        expired = false
        pressedChip = -1
        relayout()
    }

    fun startAction(kind: String, title: String, steps: List<String>) {
        actKind = kind
        actTitle = title
        actSteps = steps
        actAt = System.currentTimeMillis()
        actDone = false
    }

    private fun textSize() = (if (compact) 12f else 12.5f) * d

    private fun cardInnerW(s: Int = side): Float = cardW - (if (s >= 2) pt else 0f)

    private fun buildLayout(s: Int): StaticLayout? {
        val t = talk ?: return null
        tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tp.textSize = textSize()
        val w = (cardInnerW(s) - 26 * d).toInt().coerceAtLeast(40)
        return StaticLayout.Builder.obtain(t.text, 0, t.text.length, tp, w)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(2f * d, 1f).build()
    }

    private fun chipRows(s: Int): List<List<Int>> {
        val t = talk ?: return emptyList()
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 11f * d
        val maxW = cardInnerW(s) - 26 * d
        val rows = ArrayList<MutableList<Int>>()
        var cur = ArrayList<Int>()
        var used = 0f
        for (i in t.chips.indices) {
            val w = p.measureText(t.chips[i].label) + 22 * d
            if (cur.isNotEmpty() && used + w > maxW) { rows.add(cur); cur = ArrayList(); used = 0f }
            cur.add(i); used += w + 6 * d
        }
        if (cur.isNotEmpty()) rows.add(cur)
        return rows
    }

    /** Size of the window for a given side, in px: width, height. */
    fun measure(s: Int): IntArray {
        val w = cardW.toInt()
        if (actKind.isNotEmpty()) return intArrayOf(w, (112 * d + (if (s < 2) pt else 0f)).toInt())
        val lay = buildLayout(s) ?: return intArrayOf(w, (60 * d).toInt())
        val rows = chipRows(s).size
        val chipsH = if (rows == 0) 0f else rows * 28 * d + 4 * d
        val h = 12 * d + 14 * d + 6 * d + lay.height + chipsH + 12 * d + (if (s < 2) pt else 0f)
        return intArrayOf(w, h.toInt())
    }

    private fun relayout() {
        layout = buildLayout(side)
        requestLayout()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val busy = actKind.isNotEmpty()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { pressedChip = if (busy) -1 else hit(e.x, e.y); invalidate() }
            MotionEvent.ACTION_UP -> {
                val h = if (busy) -1 else hit(e.x, e.y)
                val t = talk
                pressedChip = -1
                invalidate()
                if (h >= 0 && t != null && h < t.chips.size && doneAt != 0L) onChip?.invoke(t.chips[h].id)
            }
            MotionEvent.ACTION_CANCEL -> { pressedChip = -1; invalidate() }
        }
        return true
    }

    private fun hit(x: Float, y: Float): Int {
        for (i in chipRects.indices) if (chipRects[i].contains(x, y)) return i
        return -1
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = System.currentTimeMillis()
        val tt = (now - typedAt) / 1000f
        val pulse = 0.55f + 0.45f * sin(Neon.now() * 4f)

        // card area (leave room for the pointer on the side facing the status)
        val l = if (side == 2) pt else 0f
        val r = if (side == 3) w - pt else w
        val t = if (side == 0) pt else 0f
        val b = if (side == 1) h - pt else h
        rr.set(l + d, t + d, r - d, b - d)
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = 0xF00B1118.toInt()
        CyUi.drawCut(c, p, rr, 12 * d)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Cy.a(Neon.CYAN, 0.35f + 0.35f * pulse)
        CyUi.drawCut(c, p, rr, 12 * d)
        p.strokeWidth = 2.2f * d
        p.color = Cy.PINK
        c.drawLine(l + 2 * d, t + 16 * d, l + 2 * d, t + 3 * d, p); c.drawLine(l + 2 * d, t + 3 * d, l + 26 * d, t + 3 * d, p)

        // pointer toward the status overlay
        p.style = Paint.Style.FILL
        p.color = Cy.a(Neon.CYAN, 0.5f + 0.4f * pulse)
        path.reset()
        val q = ptr.coerceIn(18 * d, (if (side < 2) w else h) - 18 * d)
        when (side) {
            0 -> { path.moveTo(q - 7 * d, t + d); path.lineTo(q, 0f); path.lineTo(q + 7 * d, t + d) }
            1 -> { path.moveTo(q - 7 * d, b - d); path.lineTo(q, h); path.lineTo(q + 7 * d, b - d) }
            2 -> { path.moveTo(l + d, q - 7 * d); path.lineTo(0f, q); path.lineTo(l + d, q + 7 * d) }
            else -> { path.moveTo(r - d, q - 7 * d); path.lineTo(w, q); path.lineTo(r - d, q + 7 * d) }
        }
        path.close()
        c.drawPath(path, p)

        // header: avatar + name
        val hx = l + 14 * d
        val hy = t + 18 * d
        p.color = Cy.a(Neon.CYAN, 0.25f * pulse)
        c.drawCircle(hx + 5 * d, hy - 4 * d, 8 * d, p)
        p.color = Neon.CYAN
        path.reset()
        path.moveTo(hx + 5 * d, hy - 9 * d); path.lineTo(hx + 10 * d, hy - 4 * d); path.lineTo(hx + 5 * d, hy + d); path.lineTo(hx, hy - 4 * d); path.close()
        c.drawPath(path, p)
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 9.5f * d
        p.letterSpacing = 0.22f
        p.color = Neon.CYAN
        c.drawText(if (actKind.isEmpty()) "NOVA" else "NOVA  /  " + actTitle.uppercase(), hx + 18 * d, hy, p)
        p.letterSpacing = 0f

        if (actKind.isNotEmpty()) { drawAction(c, l, r, t, b, now); return }

        // typed text
        val lay = layout ?: return
        val tk = talk ?: return
        val typed = (((now - typedAt) / charMs).toInt()).coerceAtMost(tk.text.length)
        val ox = l + 14 * d
        val oy = t + 30 * d
        tp.color = 0xFFFFFFFF.toInt()
        for (i in 0 until lay.lineCount) {
            val s = lay.getLineStart(i)
            val e = lay.getLineEnd(i)
            if (typed <= s) break
            val to = if (typed < e) typed else e
            c.drawText(tk.text, s, to, ox, oy + lay.getLineBaseline(i), tp)
        }
        val finished = typed >= tk.text.length
        if (finished && doneAt == 0L) doneAt = now
        if (!finished && (now / 300) % 2 == 0L) {
            var li = 0
            while (li < lay.lineCount - 1 && lay.getLineEnd(li) <= typed) li++
            val cx = ox + tp.measureText(tk.text, lay.getLineStart(li), typed.coerceAtLeast(lay.getLineStart(li)))
            val by = oy + lay.getLineBaseline(li)
            p.style = Paint.Style.FILL
            p.color = Neon.CYAN
            c.drawRect(cx + 1 * d, by - 10 * d, cx + 4 * d, by + 2 * d, p)
        }

        // chips
        val rows = chipRows(side)
        val rects = ArrayList<RectF>()
        if (rows.isNotEmpty() && doneAt != 0L) {
            val k = ((now - doneAt) / 260f).coerceIn(0f, 1f)
            var y = oy + lay.height + 6 * d
            for (row in rows) {
                var x = ox
                for (i in row) {
                    val label = tk.chips[i].label
                    p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                    p.textSize = 11f * d
                    val cw = p.measureText(label) + 22 * d
                    val cr = RectF(x, y + (1f - k) * 6 * d, x + cw, y + 24 * d + (1f - k) * 6 * d)
                    while (rects.size < i) rects.add(RectF())
                    rects.add(cr)
                    val warm = tk.chips[i].id == "bye"
                    val col = if (warm) 0xFF9AA7B4.toInt() else Neon.CYAN
                    p.style = Paint.Style.FILL
                    p.color = Cy.a(col, (if (pressedChip == i) 0.35f else 0.12f) * k)
                    CyUi.drawCut(c, p, cr, 6 * d)
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 1f * d
                    p.color = Cy.a(col, 0.7f * k)
                    CyUi.drawCut(c, p, cr, 6 * d)
                    p.style = Paint.Style.FILL
                    p.textAlign = Paint.Align.CENTER
                    p.color = Cy.a(if (warm) 0xFFCFD8E0.toInt() else 0xFFFFFFFF.toInt(), k)
                    c.drawText(label, cr.centerX(), cr.centerY() + 4 * d, p)
                    x += cw + 6 * d
                }
                y += 28 * d
            }
        }
        chipRects = rects

        // nobody answered: let the bubble go by itself
        if (doneAt != 0L && !expired) {
            val hold = if (tk.chips.isEmpty()) tk.holdMs else (if (tk.holdMs < 20_000L) 20_000L else tk.holdMs)
            if (now - doneAt > hold) { expired = true; post { onExpire?.invoke() } }
        }
    }

    private fun drawAction(c: Canvas, l: Float, r: Float, t: Float, b: Float, now: Long) {
        val el = now - actAt
        val n = max(1, actSteps.size)
        val total = n * stepMs + 500L
        val prog = (el.toFloat() / total).coerceIn(0f, 1f)
        val ox = l + 14 * d
        // steps
        p.textAlign = Paint.Align.LEFT
        for (i in actSteps.indices) {
            val y = t + 38 * d + i * 15 * d
            val doneStep = el > (i + 1) * stepMs
            val active = !doneStep && el > i * stepMs
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.textSize = 11f * d
            p.color = if (doneStep) Neon.GREEN else if (active) 0xFFFFFFFF.toInt() else 0xFF5C6773.toInt()
            c.drawText((if (doneStep) "OK  " else if (active) ">>  " else "..  ") + actSteps[i], ox, y, p)
        }
        // progress bar
        val by = b - 18 * d
        val bl = ox
        val br = r - 14 * d
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3f * d
        p.color = Cy.a(Neon.CYAN, 0.18f)
        c.drawLine(bl, by, br, by, p)
        p.color = Neon.CYAN
        c.drawLine(bl, by, bl + (br - bl) * prog, by, p)
        // kind specific animation, right side
        val ax = r - 38 * d
        val ay = t + 44 * d
        if (actKind == "music") {
            p.style = Paint.Style.FILL
            for (i in 0 until 5) {
                val hh = (6 + 16 * (0.5f + 0.5f * sin(now / 140f + i * 1.3f))) * d * (0.3f + 0.7f * prog)
                p.color = if (i % 2 == 0) Neon.CYAN else Cy.PINK
                c.drawRect(ax - 12 * d + i * 6 * d, ay + 12 * d - hh, ax - 8 * d + i * 6 * d, ay + 12 * d, p)
            }
        } else {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.4f * d
            p.color = Cy.a(Neon.CYAN, 0.25f)
            c.drawCircle(ax, ay, 13 * d, p)
            p.color = Neon.CYAN
            rr.set(ax - 13 * d, ay - 13 * d, ax + 13 * d, ay + 13 * d)
            c.drawArc(rr, -90f + now / 4f % 360f, 90f, false, p)
        }
        if (prog >= 1f && !actDone) { actDone = true; post { onActionDone?.invoke() } }
    }
}

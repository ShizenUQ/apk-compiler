package com.xio.bulwark

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.sin

class MainActivity : Activity() {

    private class PermRow(val status: TextView, val btn: PButton, val box: LinearLayout)

    private val main = Handler(Looper.getMainLooper())
    private val t0 = SystemClock.elapsedRealtime()
    private var tick = 0

    private lateinit var preview: HudRoot
    private lateinit var nav: NavBar
    private lateinit var startBar: LinearLayout
    private lateinit var startBtn: PButton
    private lateinit var statePill: TextView
    private lateinit var banner: LinearLayout
    private lateinit var bannerText: TextView
    private lateinit var pageLive: ScrollView
    private lateinit var pageSettings: ScrollView
    private val liveCards = ArrayList<View>()
    private val settingsCards = ArrayList<View>()
    private var curPage = 0
    private lateinit var diagText: TextView
    private lateinit var pageMusic: ScrollView
    private lateinit var pageGames: ScrollView
    private val gamesCards = ArrayList<View>()
    private lateinit var pageBoost: ScrollView
    private val boostCards = ArrayList<View>()
    private lateinit var boostCore: BoostCore
    private lateinit var boostLog: TextView
    private lateinit var turbo: TurboCore
    private lateinit var hangar: LinearLayout
    private lateinit var weekChart: WeekChart
    private lateinit var rankBox: LinearLayout
    private lateinit var sessBox: LinearLayout
    private lateinit var usageCard: View
    private lateinit var segRemind: Segmented
    private val musicCards = ArrayList<View>()
    private var pickingFiles = false

    private val designCards = ArrayList<DesignCard>()
    private lateinit var segSize: Segmented
    private lateinit var segTarget: Segmented
    private lateinit var slOpacity: PSlider
    private lateinit var slScale: PSlider
    private lateinit var tvOpacity: TextView
    private lateinit var tvScale: TextView
    private lateinit var swGraph: PSwitch
    private lateinit var swBars: PSwitch
    private lateinit var swFooter: PSwitch
    private lateinit var swFx: PSwitch
    private lateinit var swLock: PSwitch
    private lateinit var swSound: PSwitch
    private lateinit var swBoot: PSwitch
    private lateinit var swAuto: PSwitch
    private lateinit var swOvIcon: PSwitch
    private lateinit var autoUsage: PermRow
    private lateinit var autoAcc: PermRow
    private var bgView: CyberBg? = null
    private lateinit var bgPick: PButton
    private lateinit var bgClear: PButton
    private lateinit var pageGallery: ScrollView
    private val galCards = ArrayList<View>()
    private lateinit var pagePlayer: android.widget.ScrollView
    private val plrCards = ArrayList<View>()
    private lateinit var playerTab: PlayerTab
    private lateinit var galTitle: CyTitle
    private lateinit var vList: LinearLayout
    private lateinit var iGrid: LinearLayout
    private val vCards = ArrayList<VideoCard>()
    private var inForeground = false
    private lateinit var rowOverlay: PermRow
    private lateinit var rowShizuku: PermRow
    private lateinit var rowBattery: PermRow
    private lateinit var rowNotif: PermRow

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    // ---------------- small builders ----------------

    private fun dp(v: Float) = Ui.dpi(this, v)

    private fun tv(s: String, size: Float, color: Int, face: Int = Typeface.NORMAL): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        t.typeface = Typeface.create("sans-serif-medium", face)
        return t
    }

    private fun card(title: String, into: ViewGroup, list: ArrayList<View>): LinearLayout {
        val c = NeonCard(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(12f)
        c.layoutParams = lp
        c.addView(CyTitle(this, title.uppercase(), "", Cy.CYAN))
        into.addView(c)
        list.add(c)
        return c
    }

    private fun row(title: String, sub: String?, ctl: View, ctlW: Int = ViewGroup.LayoutParams.WRAP_CONTENT): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(9f), 0, dp(9f))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, 15f, P.TEXT))
        if (sub != null) col.addView(tv(sub, 11.5f, P.DIM))
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(ctl, LinearLayout.LayoutParams(ctlW, -2))
        return r
    }

    private fun label(s: String): TextView {
        val t = tv(s, 12f, P.DIM)
        t.setPadding(0, dp(12f), 0, dp(4f))
        return t
    }

    private fun sw(key: String, def: Boolean): PSwitch {
        val s = PSwitch(this)
        s.setChecked(Prefs.bool(this, key, def))
        s.onChange = { v -> Prefs.putBool(this, key, v); pushPreview() }
        return s
    }

    private fun permRow(title: String, into: LinearLayout): PermRow {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(0, dp(9f), 0, dp(9f))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, 15f, P.TEXT))
        val st = tv("", 12f, P.DIM)
        col.addView(st)
        box.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        val b = PButton(this, "Open", 1, 38f)
        box.addView(b, LinearLayout.LayoutParams(dp(118f), -2))
        into.addView(box)
        return PermRow(st, b, box)
    }

    // ---------------- screen ----------------

    override fun onCreate(savedInstanceState: Bundle?) {
        ExitLog.install(this)
        super.onCreate(savedInstanceState)
        val frame = FrameLayout(this)
        bgView = CyberBg(this)
        frame.addView(bgView, FrameLayout.LayoutParams(-1, -1))
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        frame.addView(root, FrameLayout.LayoutParams(-1, -1))

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(20f), dp(14f), dp(20f), dp(6f))
        val logo = BoltLogo(this)
        head.addView(logo, LinearLayout.LayoutParams(dp(46f), dp(46f)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(8f), 0, 0, 0)
        titles.addView(GlitchTitle(this, "FRAMELINE"))
        titles.addView(tv("performance overlay", 11f, P.DIM))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        statePill = tv("", 10.5f, P.DIM)
        statePill.letterSpacing = 0.12f
        statePill.setPadding(dp(12f), dp(6f), dp(12f), dp(6f))
        head.addView(statePill)
        root.addView(head)

        // pages
        val pages = FrameLayout(this)
        pageLive = ScrollView(this)
        pageSettings = ScrollView(this)
        pageLive.isVerticalScrollBarEnabled = false
        pageSettings.isVerticalScrollBarEnabled = false
        pages.addView(pageLive, FrameLayout.LayoutParams(-1, -1))
        pages.addView(pageSettings, FrameLayout.LayoutParams(-1, -1))
        pageSettings.visibility = View.GONE
        pageMusic = ScrollView(this)
        pageMusic.isVerticalScrollBarEnabled = false
        pages.addView(pageMusic, FrameLayout.LayoutParams(-1, -1))
        pageMusic.visibility = View.GONE
        pageGames = ScrollView(this)
        pageGames.isVerticalScrollBarEnabled = false
        pages.addView(pageGames, FrameLayout.LayoutParams(-1, -1))
        pageGames.visibility = View.GONE
        pageBoost = ScrollView(this)
        pageBoost.isVerticalScrollBarEnabled = false
        pages.addView(pageBoost, FrameLayout.LayoutParams(-1, -1))
        pageBoost.visibility = View.GONE
        pageGallery = ScrollView(this)
        pageGallery.isVerticalScrollBarEnabled = false
        pages.addView(pageGallery, FrameLayout.LayoutParams(-1, -1))
        pageGallery.visibility = View.GONE
        pagePlayer = ScrollView(this)
        pagePlayer.isVerticalScrollBarEnabled = false
        pages.addView(pagePlayer, FrameLayout.LayoutParams(-1, -1))
        pagePlayer.visibility = View.GONE
        root.addView(pages, LinearLayout.LayoutParams(-1, 0, 1f))

        buildLive()
        buildSettings()
        buildMusic()
        buildGames()
        buildBoost()
        buildGallery()
        playerTab = PlayerTab(this, pagePlayer, plrCards)
        playerTab.build()

        // start bar + tabs
        startBar = LinearLayout(this)
        startBar.orientation = LinearLayout.VERTICAL
        startBar.setPadding(dp(16f), dp(8f), dp(16f), dp(10f))
        startBar.setBackgroundColor(0xF0070B10.toInt())
        startBtn = PButton(this, "START OVERLAY", 0, 52f)
        startBtn.onClick = { startStop() }
        startBar.addView(startBtn, LinearLayout.LayoutParams(-1, -2))
        root.addView(startBar)

        nav = NavBar(this, listOf("Live", "Music", "Player", "Games", "Boost", "Gallery", "Settings"), listOf(true, true, true, true, true, true, true))
        nav.onSelect = { i -> showPage(when (i) { 0 -> 0; 1 -> 2; 2 -> 6; 3 -> 3; 4 -> 4; 5 -> 5; else -> 1 }) }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))

        setContentView(frame)
        Ui.enter(liveCards, 150L)
    }

    private fun buildLive() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        pageLive.addView(col, FrameLayout.LayoutParams(-1, -2))

        // setup banner
        banner = LinearLayout(this)
        banner.orientation = LinearLayout.HORIZONTAL
        banner.gravity = Gravity.CENTER_VERTICAL
        banner.background = CutDrawable(0x26FFC24B, 0x66FFC24B, dp(1f).toFloat(), dp(12f).toFloat())
        banner.setPadding(dp(14f), dp(10f), dp(10f), dp(10f))
        bannerText = tv("", 12.5f, P.MID)
        banner.addView(bannerText, LinearLayout.LayoutParams(0, -2, 1f))
        val bbtn = PButton(this, "Fix", 1, 34f)
        bbtn.onClick = { showPage(1); nav.select(6) }
        banner.addView(bbtn, LinearLayout.LayoutParams(dp(70f), -2))
        val blp = LinearLayout.LayoutParams(-1, -2)
        blp.topMargin = dp(8f)
        col.addView(banner, blp)
        liveCards.add(banner)

        // lock first
        val cl = card("Lock", col, liveCards)
        swLock = sw(Prefs.LOCKED, false)
        cl.addView(row("Lock in place", "Touches pass through to the game. Unlock with the lock icon.", swLock))

        // live preview (scrolls with the page, only on this tab)
        val pbox = PreviewBox(this)
        pbox.minimumHeight = dp(120f)
        pbox.setPadding(0, dp(30f), 0, dp(16f))
        preview = HudRoot(this)
        preview.interactive = false
        pbox.addView(preview, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        val plp = LinearLayout.LayoutParams(-1, -2)
        plp.topMargin = dp(12f)
        col.addView(pbox, plp)
        liveCards.add(pbox)

        // design
        val c1 = card("Design", col, liveCards)
        val dr = LinearLayout(this)
        dr.orientation = LinearLayout.HORIZONTAL
        val names = listOf("Glass", "Gauge", "Pill")
        for (i in 0..2) {
            val d = DesignCard(this, i, names[i])
            d.onPick = {
                Prefs.putInt(this, Prefs.STYLE, i)
                refreshControls()
                pushPreview()
            }
            val lp = LinearLayout.LayoutParams(0, -2, 1f)
            lp.setMargins(dp(3f), dp(10f), dp(3f), 0)
            dr.addView(d, lp)
            designCards.add(d)
        }
        c1.addView(dr)
        c1.addView(label("Size"))
        segSize = Segmented(this, listOf("Full", "Compact", "Dot"))
        segSize.onSelect = { i -> Prefs.putInt(this, Prefs.MODE, i); pushPreview() }
        c1.addView(segSize, LinearLayout.LayoutParams(-1, -2))
        c1.addView(label("Target FPS"))
        segTarget = Segmented(this, listOf("30", "60", "90", "120"))
        segTarget.onSelect = { i -> Prefs.putInt(this, Prefs.TARGET, intArrayOf(30, 60, 90, 120)[i]); pushPreview() }
        c1.addView(segTarget, LinearLayout.LayoutParams(-1, -2))

        // look
        val c2 = card("Look", col, liveCards)
        tvOpacity = label("Opacity")
        c2.addView(tvOpacity)
        slOpacity = PSlider(this, 40, 100)
        slOpacity.onValue = { v -> Prefs.putInt(this, Prefs.OPACITY, v); tvOpacity.text = "Opacity  $v%"; pushPreview() }
        c2.addView(slOpacity, LinearLayout.LayoutParams(-1, -2))
        tvScale = label("Size")
        c2.addView(tvScale)
        slScale = PSlider(this, 70, 140)
        slScale.onValue = { v -> Prefs.putInt(this, Prefs.SCALE, v); tvScale.text = "Scale  $v%"; pushPreview() }
        c2.addView(slScale, LinearLayout.LayoutParams(-1, -2))

        // show
        swFx = sw(Prefs.EFFECTS, true)
        c2.addView(row("Animated effects", "Sparks, glitch and sweeps. Turn off to save battery in games.", swFx))

        val c3 = card("Show", col, liveCards)
        swGraph = sw(Prefs.GRAPH, true)
        c3.addView(row("Frame-time graph", null, swGraph))
        swBars = sw(Prefs.BARS, true)
        c3.addView(row("CPU and RAM", null, swBars))
        swFooter = sw(Prefs.FOOTER, true)
        c3.addView(row("Clock and battery", "Only when Nyx is off", swFooter))
        c3.addView(row("Nyx companion", "Chats in the bottom bar (Glass, Full). Tap the bar to poke her", sw(Prefs.NYX, true)))
        val segNyx = Segmented(this, listOf("Quiet", "Normal", "Chatty"))
        segNyx.select(Prefs.int(this, Prefs.NYX_FREQ, 1).coerceIn(0, 2), false)
        segNyx.onSelect = { i -> Prefs.putInt(this, Prefs.NYX_FREQ, i); pushPreview() }
        c3.addView(segNyx, lp(-1, dp(42f), dp(6f)))

    }

    // ---------------- gallery ----------------

    /** Opens the phone's photo picker (the Photos / Gallery grid) instead of the Files browser. */
    /** One picture from the photo picker (photos and albums, not the file manager). */
    private fun pickOneImage(code: Int) {
        pickingFiles = true
        try {
            val i: Intent
            if (Build.VERSION.SDK_INT >= 33) {
                i = Intent(android.provider.MediaStore.ACTION_PICK_IMAGES)
            } else {
                i = Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            }
            i.type = "image/*"
            startActivityForResult(i, code)
        } catch (t: Throwable) {
            try {
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "image/*"
                startActivityForResult(i, code)
            } catch (t2: Throwable) {
                pickingFiles = false
                Toast.makeText(this, "No picture picker found", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun pickMedia(mime: String, code: Int) {
        try {
            val i: Intent
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                i = Intent(android.provider.MediaStore.ACTION_PICK_IMAGES)
                i.putExtra(android.provider.MediaStore.EXTRA_PICK_IMAGES_MAX, android.provider.MediaStore.getPickImagesMaxLimit())
            } else {
                i = Intent(Intent.ACTION_GET_CONTENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
            i.type = mime
            startActivityForResult(i, code)
        } catch (t: Throwable) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = mime
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            startActivityForResult(i, code)
        }
    }

    private fun buildGallery() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        pageGallery.addView(col, FrameLayout.LayoutParams(-1, -2))
        pageGallery.overScrollMode = View.OVER_SCROLL_NEVER
        // starting / stopping players while the list is moving is what made it jerky: wait until it settles
        pageGallery.setOnScrollChangeListener { _, _, _, _, _ ->
            pageGallery.removeCallbacks(playIdle)
            pageGallery.postDelayed(playIdle, 220)
        }

        galTitle = CyTitle(this, "GALLERY", "", Cy.PINK)
        col.addView(galTitle, lp(-1, -2, dp(4f)))
        galCards.add(galTitle)

        val vp = CyPanel(this)
        vp.setPadding(dp(14f), dp(12f), dp(14f), dp(14f))
        vp.addView(CyTitle(this, "VIDEO SCREEN", "TOP RIGHT", Cy.CYAN))
        vp.addView(tv("Tap a clip to add it to the status loop, tap again to take it out. Selected clips play one after another.", 12f, P.DIM), lp(-1, -2, dp(6f)))
        val showV = PSwitch(this)
        showV.setChecked(Gallery.showVideo(this))
        showV.onChange = { v -> Prefs.putBool(this, Gallery.SHOW_V, v); Gallery.bump(this); pushPreview() }
        vp.addView(row("Show video screen", "Off hides it without deleting anything", showV), lp(-1, -2, dp(8f)))
        val addV = CyBtn(this, "+ ADD VIDEOS", Cy.CYAN)
        addV.onClick = { pickMedia("video/*", 34) }
        vp.addView(addV, lp(-1, -2, dp(12f)))
        vList = LinearLayout(this)
        vList.orientation = LinearLayout.VERTICAL
        vp.addView(vList, lp(-1, -2, dp(12f)))
        swSound = sw(Prefs.SOUND, false)
        vp.addView(row("Clip sound", "Off plays silent copies, so recordings stay quiet", swSound))
        col.addView(vp, lp(-1, -2, dp(12f)))
        galCards.add(vp)

        val ipn = CyPanel(this)
        ipn.setPadding(dp(14f), dp(12f), dp(14f), dp(14f))
        ipn.addView(CyTitle(this, "IMAGE SCREEN", "LOOP", Cy.PINK))
        ipn.addView(tv("Pictures swap one after another on the image screen under the video.", 12f, P.DIM), lp(-1, -2, dp(6f)))
        val showI = PSwitch(this)
        showI.setChecked(Gallery.showImage(this))
        showI.onChange = { v -> Prefs.putBool(this, Gallery.SHOW_I, v); Gallery.bump(this); pushPreview() }
        ipn.addView(row("Show image screen", "Off hides it without deleting anything", showI), lp(-1, -2, dp(8f)))
        val addI = CyBtn(this, "+ ADD IMAGES", Cy.PINK)
        addI.onClick = { pickMedia("image/*", 33) }
        ipn.addView(addI, lp(-1, -2, dp(12f)))
        val slides = listOf(3000, 4000, 6000, 10000)
        val seg = CySeg(this, listOf("3 S", "4 S", "6 S", "10 S"), Cy.PINK)
        seg.select(slides.indexOf(Prefs.int(this, Gallery.SLIDE, 4000)).coerceAtLeast(1))
        seg.onSelect = { i -> Prefs.putInt(this, Gallery.SLIDE, slides[i]); pushPreview() }
        ipn.addView(tv("Time per image", 13f, P.TEXT), lp(-1, -2, dp(14f)))
        ipn.addView(seg, lp(-1, -2, dp(6f)))
        ipn.addView(row("Shuffle", "Random order", sw(Gallery.SHUF, false)))
        iGrid = LinearLayout(this)
        iGrid.orientation = LinearLayout.VERTICAL
        ipn.addView(iGrid, lp(-1, -2, dp(8f)))
        col.addView(ipn, lp(-1, -2, dp(12f)))
        galCards.add(ipn)
    }

    private fun addToGallery(uris: List<Uri>) {
        if (uris.isEmpty()) return
        Toast.makeText(this, "Adding " + uris.size + "...", Toast.LENGTH_SHORT).show()
        Thread {
            var ok = 0
            var why = ""
            for (u in uris) {
                val r = Gallery.add(this, u)
                if (r == null) { ok++; runOnUiThread { refreshGallery(); pushPreview() } } else why = r
            }
            runOnUiThread {
                val msg = if (ok == uris.size) "Added $ok" else "Added $ok of ${uris.size}: $why"
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                refreshGallery()
                pushPreview()
            }
        }.start()
    }

    /** Plays the videos that are on screen (2 at a time, all muted) and pauses the rest. */
    private val playIdle = Runnable { updateVideoPlay() }

    private fun updateVideoPlay() {
        if (curPage != 5 || !inForeground) { for (c in vCards) c.stop(); return }
        var n = 0
        val r = android.graphics.Rect()
        for (c in vCards) {
            val vis = c.isShown && c.getGlobalVisibleRect(r) && r.height() > c.height * 0.45f
            if (vis && n < 2) { c.play(); n++ } else c.stop()
        }
    }

    private fun openViewer(kind: Int, i: Int) {
        for (c in vCards) c.stop()
        startActivity(Intent(this, ViewerActivity::class.java).putExtra("idx", i).putExtra("kind", kind))
        overridePendingTransition(android.R.anim.fade_in, 0)
    }

    private fun refreshGallery() {
        val vids = Gallery.videos(this)
        val imgs = Gallery.images(this)
        galTitle.setTagText(String.format("%.1f MB", Gallery.totalBytes(this) / 1048576f))

        for (c in vCards) c.stop()
        vCards.clear()
        vList.removeAllViews()
        val selIds = Gallery.enabledVideos(this).map { it.id }.toSet()
        if (vids.isEmpty()) vList.addView(tv("No videos yet.", 12.5f, P.DIM))
        for ((i, v) in vids.withIndex()) {
            val card = VideoCard(this, v, i)
            card.onStatus = v.id in selIds
            card.onOpen = { openViewer(0, i) }
            card.onPick = {
                Gallery.setOn(this, v.id, !(v.id in Gallery.enabledVideos(this).map { it.id }.toSet() && v.on))
                val ids = Gallery.enabledVideos(this).map { it.id }.toSet()
                for (o in vCards) o.onStatus = o.item.id in ids
                pushPreview()
            }
            card.onHold = { galMenu(v, 0) }
            vList.addView(card, lp(-1, -2, if (i == 0) 0 else dp(12f)))
            vCards.add(card)
        }

        iGrid.removeAllViews()
        val tiles = ArrayList<GalTile>()
        if (imgs.isEmpty()) iGrid.addView(tv("No images yet.", 12.5f, P.DIM))
        val cols = 3
        var rowL: LinearLayout? = null
        for ((i, im) in imgs.withIndex()) {
            if (i % cols == 0) {
                rowL = LinearLayout(this)
                rowL.orientation = LinearLayout.HORIZONTAL
                iGrid.addView(rowL, LinearLayout.LayoutParams(-1, -2))
            }
            val t = GalTile(this, im, i)
            t.onTap = { openViewer(1, i) }
            t.onHold = { galMenu(im, 1) }
            val tl = LinearLayout.LayoutParams(0, -2, 1f)
            tl.setMargins(dp(3f), dp(3f), dp(3f), dp(3f))
            rowL!!.addView(t, tl)
            tiles.add(t)
        }
        if (imgs.isNotEmpty()) {
            val rest = (cols - imgs.size % cols) % cols
            for (q in 0 until rest) rowL!!.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).also { lpp -> lpp.setMargins(dp(3f), 0, dp(3f), 0) })
            iGrid.addView(tv("Hold an image for options.", 11.5f, P.DIM).also { tvv -> tvv.setPadding(dp(3f), dp(8f), 0, 0) })
        }
        val vc = ArrayList(vCards)
        Thread {
            for (c in vc) { val b = Gallery.thumb(this, c.item); runOnUiThread { c.setThumb(b) } }
            for (t in tiles) { val b = Gallery.thumb(this, t.item); runOnUiThread { t.setBmp(b) } }
        }.start()
        pageGallery.post { updateVideoPlay() }
    }

    private fun galMenu(g: GItem, kind: Int) {
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18f), dp(16f), dp(18f), dp(14f))
        box.background = CutDrawable(0xFF0B1118.toInt(), Neon.a(Neon.CYAN, 150), dp(1f).toFloat(), dp(14f).toFloat())
        box.addView(CyTitle(this, if (kind == 0) "VIDEO" else "IMAGE", "", Cy.CYAN))
        fun act(label: String, col: Int, f: () -> Unit) {
            val b = CyBtn(this, label, col)
            b.onClick = { dlg.dismiss(); f() }
            box.addView(b, lp(-1, -2, dp(8f)))
        }
        if (kind == 0) {
            act(if (g.on) "TAKE OUT OF LOOP" else "ADD TO LOOP", Cy.CYAN) { Gallery.setOn(this, g.id, !g.on); refreshGallery(); pushPreview() }
        } else {
            act(if (g.on) "HIDE FROM LOOP" else "SHOW IN LOOP", Cy.CYAN) { Gallery.setOn(this, g.id, !g.on); refreshGallery(); pushPreview() }
            act("MOVE EARLIER", Cy.CYAN) { Gallery.moveKind(this, g.id, -1); refreshGallery(); pushPreview() }
            act("MOVE LATER", Cy.CYAN) { Gallery.moveKind(this, g.id, 1); refreshGallery(); pushPreview() }
        }
        act("REMOVE", Cy.PINK) { Gallery.remove(this, g.id); refreshGallery(); pushPreview() }
        dlg.setContentView(box)
        dlg.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0))
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.84f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        dlg.show()
    }

    private fun buildSettings() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        pageSettings.addView(col, FrameLayout.LayoutParams(-1, -2))

        val c1 = card("Permissions", col, settingsCards)
        rowOverlay = permRow("Display over other apps", c1)
        rowOverlay.btn.onClick = {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        rowShizuku = permRow("Shizuku (reads FPS)", c1)
        rowShizuku.btn.onClick = { shizukuAction() }
        rowBattery = permRow("Run in background", c1)
        rowBattery.btn.onClick = {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (t: Throwable) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        rowNotif = permRow("Notifications", c1)
        rowNotif.btn.onClick = {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }

        val cbg = card("Background", col, settingsCards)
        cbg.addView(tv("Put your own picture behind the whole app. It is copied into Frameline, so it stays even if you delete the original.", 12f, P.DIM))
        bgPick = PButton(this, if (Backdrop.has(this)) "Change image" else "Choose image", 1, 42f)
        bgPick.onClick = { pickOneImage(62) }
        val bplp = LinearLayout.LayoutParams(-1, -2)
        bplp.topMargin = dp(10f)
        cbg.addView(bgPick, bplp)
        val dimLabel = tv("Darkness", 13f, P.TEXT)
        val dlp = LinearLayout.LayoutParams(-1, -2)
        dlp.topMargin = dp(14f)
        cbg.addView(dimLabel, dlp)
        val segDim = Segmented(this, listOf("Light", "Medium", "Dark"))
        val dimNow = Backdrop.dim(this)
        segDim.select(if (dimNow < 45) 0 else if (dimNow < 66) 1 else 2, false)
        segDim.onSelect = { i ->
            Backdrop.setDim(this, intArrayOf(30, 55, 75)[i.coerceIn(0, 2)])
            repaintAll()
        }
        val sdlp = LinearLayout.LayoutParams(-1, -2)
        sdlp.topMargin = dp(6f)
        cbg.addView(segDim, sdlp)
        bgClear = PButton(this, "Remove image", 2, 40f)
        bgClear.onClick = {
            Backdrop.clear(this)
            bgPick.set("Choose image", 1)
            bgClear.visibility = View.GONE
            repaintAll()
        }
        bgClear.visibility = if (Backdrop.has(this)) View.VISIBLE else View.GONE
        val bclp = LinearLayout.LayoutParams(-1, -2)
        bclp.topMargin = dp(10f)
        cbg.addView(bgClear, bclp)

        val ca = card("Auto mode", col, settingsCards)
        ca.addView(tv("Open a game from your list and Frameline boosts it and shows the status over it, even when this app is closed. Frameline sees the game open through an Accessibility service, which reacts the instant it opens. It only gets \"window changed\" events and cannot read your screen. On Android 13+ you may first need App info > ⋮ > Allow restricted settings.", 12f, P.DIM))
        swAuto = PSwitch(this)
        swAuto.setChecked(Prefs.bool(this, Prefs.AUTO, false))
        swAuto.onChange = { v -> setAutoMode(v) }
        ca.addView(row("Auto mode", "Boost and show the status when a game opens", swAuto))
        autoAcc = permRow("Accessibility (sees the game open instantly)", ca)
        autoAcc.btn.onClick = { try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (t: Throwable) { } }
        autoUsage = permRow("Usage access (backup if Accessibility is off)", ca)
        autoUsage.btn.onClick = { try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (t: Throwable) { } }
        swOvIcon = sw(Prefs.OV_ICON, true)
        ca.addView(row("Nova, your helper", "A small bubble that greets you after the boost and offers music", sw(Prefs.NOVA_ON, true)))
        ca.addView(row("Game icon on overlay", "Shows the game you are playing at the corner of the status", swOvIcon))

        val c2 = card("Keep it alive", col, settingsCards)
        c2.addView(tv("Some phones have their own Autostart or Background activity switch. Open app settings and allow both, then lock the app in the recents list.", 12f, P.DIM))
        val ab = PButton(this, "Open app settings", 1, 42f)
        ab.onClick = {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        val ablp = LinearLayout.LayoutParams(-1, -2)
        ablp.topMargin = dp(10f)
        c2.addView(ab, ablp)
        swBoot = sw(Prefs.BOOT, false)
        c2.addView(row("Start after reboot", "Frameline watches for games again, the status shows only when a game opens. Shizuku must be started again after a reboot", swBoot))

        val cd = card("Diagnostics", col, settingsCards)
        cd.addView(tv("If FPS shows --, open this while a game is running, then send me a screenshot.", 12f, P.DIM))
        diagText = tv("", 10f, P.TEXT)
        diagText.typeface = Typeface.MONOSPACE
        diagText.setPadding(0, dp(8f), 0, dp(8f))
        cd.addView(diagText)
        val cb = PButton(this, "Copy report", 1, 42f)
        cb.onClick = {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Frameline report", ExitLog.report(this) + "\n" + AutoLog.text(this) + "\n" + FpsClient.debugText(this)))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
        cd.addView(cb, LinearLayout.LayoutParams(-1, -2))

        val c3 = card("About", col, settingsCards)
        c3.addView(tv("Frameline 4.9", 15f, P.TEXT))
        c3.addView(tv("Privacy and licences will appear here later.", 12f, P.DIM))
    }

    /** Redraws the whole screen after the background picture changed. */
    private fun repaintAll() {
        fun walk(v: View) {
            v.invalidate()
            if (v is ViewGroup) for (k in 0 until v.childCount) walk(v.getChildAt(k))
        }
        walk(window.decorView)
    }

    private fun pageOf(i: Int): View = when (i) { 0 -> pageLive; 1 -> pageSettings; 3 -> pageGames; 4 -> pageBoost; 5 -> pageGallery; 6 -> pagePlayer; else -> pageMusic }
    private fun cardsOf(i: Int): List<View> = when (i) { 0 -> liveCards; 1 -> settingsCards; 3 -> gamesCards; 4 -> boostCards; 5 -> galCards; 6 -> plrCards; else -> musicCards }

    private fun showPage(i: Int) {
        if (i == curPage) return
        val out = pageOf(curPage)
        val inn = pageOf(i)
        out.animate().alpha(0f).translationX(-30f).setDuration(150).withEndAction {
            out.visibility = View.GONE
            out.translationX = 0f
        }.start()
        inn.alpha = 0f
        inn.translationX = 30f
        inn.visibility = View.VISIBLE
        inn.animate().alpha(1f).translationX(0f).setDuration(240).start()
        curPage = i
        preview.setPlaying(i == 0)
        updateVideoPlay()
        startBar.visibility = if (i == 0) View.VISIBLE else View.GONE
        if (i == 3) refreshGames()
        if (i == 4) refreshBoost()
        if (i == 5) refreshGallery()
        if (i == 6) playerTab.refresh()
        if (i == 2) {
            if (!Prefs.bool(this, "beat_asked", false)) {
                Prefs.putBool(this, "beat_asked", true)
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            }
            refreshMusicView()
        }
        Ui.enter(cardsOf(i), 80L)
    }

    // ---------------- lifecycle ----------------

    override fun onStart() {
        super.onStart()
        inForeground = true
        updateVideoPlay()
        try {
            Shizuku.addRequestPermissionResultListener(permListener)
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addBinderDeadListener(deadListener)
        } catch (t: Throwable) { }
    }

    override fun onStop() {
        inForeground = false
        updateVideoPlay()
        if (!pickingFiles && !OverlayService.running) Music.pause()
        try {
            Shizuku.removeRequestPermissionResultListener(permListener)
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeBinderDeadListener(deadListener)
        } catch (t: Throwable) { }
        super.onStop()
    }

    private val demo = object : Runnable {
        override fun run() {
            tick++
            if (curPage == 0) pushPreview()
            if (curPage == 3 && tick % 10 == 0) refreshGamesLive()
            if (curPage == 4 && !Boost.running) refreshBoost(false)
            if (curPage == 1) diagText.text = ExitLog.report(this@MainActivity) + "\n" + AutoLog.text(this@MainActivity) + "\n" + FpsClient.debugText(this@MainActivity)
            main.postDelayed(this, 500)
        }
    }

    override fun onResume() {
        super.onResume()
        // Auto mode should survive the app or the phone being cleaned up: bring the watcher back when the app opens
        if ((Prefs.bool(this, Prefs.AUTO, false) || Prefs.bool(this, Prefs.BOOT, false)) && !OverlayService.running && Settings.canDrawOverlays(this)) {
            try { startForegroundService(Intent(this, OverlayService::class.java).putExtra(OverlayService.EXTRA_WATCH, true)) } catch (t: Throwable) { }
        }
        refresh()
        if (curPage == 3) refreshGames()
        if (curPage == 6) playerTab.refresh()
        preview.setPlaying(true)
        main.removeCallbacks(demo)
        main.post(demo)
    }

    override fun onPause() {
        main.removeCallbacks(demo)
        preview.setPlaying(false)
        super.onPause()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            Toast.makeText(this, if (ok) "Beat sync on. It starts with the next song" else "No permission: faces use a steady rhythm", Toast.LENGTH_LONG).show()
        }
        refresh()
    }

    // ---------------- preview ----------------

    /** Demo numbers for the preview (your real FPS can't be read while this screen is open). */
    private fun pushPreview() {
        val target = Prefs.int(this, Prefs.TARGET, 60).toFloat()
        val dip = (tick % 24) in 20..21
        val crash = (tick % 90) in 70..79            // shows the low-FPS glitch every so often
        val fps = if (crash) 8f + 3f * sin(tick * 1.3f) else target * (if (dip) 0.7f else 0.985f) + sin(tick * 0.9f) * target * 0.012f
        val ft = 1000f / fps
        val frames = FloatArray(48) { i ->
            ft * (1f + 0.09f * sin((i + tick) * 1.7f)) * (if (dip && i > 38) 1.5f else 1f) * (if (crash && i % 5 == 0) 1.3f else 1f)
        }
        val d = FpsData(fps, fps * 0.88f, ft, 34f + 9f * sin(tick * 0.5f), "demo", "OK", frames)
        preview.applyPrefs()
        preview.alpha = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        preview.update(d, StatsReader.read(this, t0))
    }

    // ---------------- actions ----------------

    private fun shizukuAction() {
        when (FpsClient.state(this)) {
            FpsClient.St.NOT_INSTALLED -> Toast.makeText(this, "Install Shizuku first, then come back.", Toast.LENGTH_LONG).show()
            FpsClient.St.NOT_RUNNING -> {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) startActivity(i)
            }
            FpsClient.St.NO_PERMISSION -> try { Shizuku.requestPermission(21) } catch (t: Throwable) { }
            FpsClient.St.READY -> Toast.makeText(this, "Shizuku is linked.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startStop() {
        if (OverlayService.running) {
            if (OverlayService.pinned) {
                // with Auto mode on, STOP only hides the overlay and the watcher keeps going; otherwise stop everything
                val act = if (Prefs.bool(this, Prefs.AUTO, false)) OverlayService.ACTION_HIDE else OverlayService.ACTION_STOP
                startService(Intent(this, OverlayService::class.java).setAction(act))
            } else {
                startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW))
            }
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow display over other apps first.", Toast.LENGTH_LONG).show()
                showPage(1)
                nav.select(5)
                return
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        startBtn.postDelayed({ refresh() }, 600)
    }

    /** Turns Auto mode on or off: starts or stops the quiet game watcher. */
    private fun setAutoMode(on: Boolean) {
        Prefs.putBool(this, Prefs.AUTO, on)
        if (on) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow display over other apps first.", Toast.LENGTH_LONG).show()
                Prefs.putBool(this, Prefs.AUTO, false)
                swAuto.setChecked(false)
                return
            }
            // boosting is part of Auto mode, so switch it on as well (it can still be turned off in the Boost tab)
            Prefs.putBool(this, Prefs.BO_AUTO, true)
            if (!GameAccessService.enabled(this) && !Games.hasUsage(this)) {
                Toast.makeText(this, "Turn on Frameline in Accessibility so it sees which game opens (Android 13+: App info > ⋮ > Allow restricted settings)", Toast.LENGTH_LONG).show()
                try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (t: Throwable) { }
            }
            if (!OverlayService.running) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
                startForegroundService(Intent(this, OverlayService::class.java).putExtra(OverlayService.EXTRA_WATCH, true))
            }
        } else if (OverlayService.running && !OverlayService.pinned) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        }
        startBtn.postDelayed({ refresh() }, 600)
    }

    private fun setMedia(type: String) {
        Prefs.putStr(this, Prefs.MEDIA_TYPE, type)
        Prefs.putInt(this, Prefs.MEDIA_VER, Prefs.int(this, Prefs.MEDIA_VER, 0) + 1)
        if (type.isEmpty()) {
            File(filesDir, "media.dat").delete()
            File(filesDir, "media_s.dat").delete()
        }
        refresh()
        pushPreview()
    }

    private fun icon(pkg: String): android.graphics.drawable.Drawable? =
        try { packageManager.getApplicationIcon(pkg) } catch (t: Throwable) { null }

    private fun buildGames() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        pageGames.addView(col, FrameLayout.LayoutParams(-1, -2))

        val tc = NeonCard(this)
        tc.orientation = LinearLayout.VERTICAL
        turbo = TurboCore(this)
        tc.addView(turbo, LinearLayout.LayoutParams(-1, -2))
        val tlp = LinearLayout.LayoutParams(-1, -2)
        tlp.topMargin = dp(8f)
        col.addView(tc, tlp)
        gamesCards.add(tc)

        // hangar
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ht = tv("HANGAR", 11f, Neon.CYAN)
        ht.letterSpacing = 0.2f
        head.addView(ht, LinearLayout.LayoutParams(0, -2, 1f))
        val addB = PButton(this, "+ Add game", 1, 34f)
        addB.onClick = { pickGame() }
        head.addView(addB, LinearLayout.LayoutParams(dp(112f), -2))
        val hlp = LinearLayout.LayoutParams(-1, -2)
        hlp.topMargin = dp(16f)
        col.addView(head, hlp)
        gamesCards.add(head)
        val hs = android.widget.HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.overScrollMode = View.OVER_SCROLL_NEVER
        hangar = LinearLayout(this)
        hangar.orientation = LinearLayout.HORIZONTAL
        hs.addView(hangar, FrameLayout.LayoutParams(-2, -2))
        val slp = LinearLayout.LayoutParams(-1, -2)
        slp.topMargin = dp(8f)
        col.addView(hs, slp)
        gamesCards.add(hs)

        // optional usage access
        val uc = card("Older history", col, gamesCards)
        uc.addView(tv("Allow Usage access to include play time from before Frameline was tracking. Optional.", 12f, P.DIM))
        val ub = PButton(this, "Allow usage access", 1, 42f)
        ub.onClick = { try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (t: Throwable) { } }
        val ulp = LinearLayout.LayoutParams(-1, -2)
        ulp.topMargin = dp(10f)
        uc.addView(ub, ulp)
        usageCard = uc

        val wc = card("This week", col, gamesCards)
        weekChart = WeekChart(this)
        wc.addView(weekChart, LinearLayout.LayoutParams(-1, -2))

        val mc = card("Most played", col, gamesCards)
        rankBox = LinearLayout(this)
        rankBox.orientation = LinearLayout.VERTICAL
        mc.addView(rankBox)

        val sc = card("Recent sessions", col, gamesCards)
        sessBox = LinearLayout(this)
        sessBox.orientation = LinearLayout.VERTICAL
        sc.addView(sessBox)

        val rc = card("Play time reminder", col, gamesCards)
        rc.addView(tv("A notification once a day when you pass this much play time.", 12f, P.DIM))
        segRemind = Segmented(this, listOf("Off", "1h", "2h", "3h"))
        segRemind.select(Prefs.int(this, Prefs.REMIND, 2).coerceIn(0, 3), false)
        segRemind.onSelect = { i -> Prefs.putInt(this, Prefs.REMIND, i) }
        val rlp = LinearLayout.LayoutParams(-1, -2)
        rlp.topMargin = dp(10f)
        rc.addView(segRemind, rlp)
    }

    private fun refreshBoost(full: Boolean = true) {
        boostCore.setMem(Boost.availMb(this), Boost.totalMb(this))
        boostCore.setOff(FpsClient.state(this) != FpsClient.St.READY)
        if (!full) return
        val r = Boost.last
        boostLog.text = if (r == null) "Nothing yet. Tap the core to run your first boost."
        else r.lines.joinToString("\n") { (if (it.ok) "✓  " else "✕  ") + it.text }
    }

    private fun igniteBoost() {
        if (boostCore.isBusy() || Boost.running) return
        if (FpsClient.state(this) != FpsClient.St.READY) {
            Toast.makeText(this, "Start Shizuku and allow Frameline first", Toast.LENGTH_LONG).show()
            return
        }
        boostCore.start()
        val app = applicationContext
        Thread {
            val r = Boost.run(app, null) { t, p -> runOnUiThread { boostCore.setProgress(p, t) } }
            runOnUiThread {
                boostCore.setMem(Boost.availMb(app), Boost.totalMb(app))
                boostCore.finish(r.freedMb)
                refreshBoost()
            }
        }.start()
    }

    private fun buildBoost() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        pageBoost.addView(col, FrameLayout.LayoutParams(-1, -2))

        val cc = NeonCard(this)
        cc.orientation = LinearLayout.VERTICAL
        boostCore = BoostCore(this)
        boostCore.onTap = { igniteBoost() }
        cc.addView(boostCore, LinearLayout.LayoutParams(-1, -2))
        val clp = LinearLayout.LayoutParams(-1, -2)
        clp.topMargin = dp(8f)
        col.addView(cc, clp)
        boostCards.add(cc)

        val oc = card("What boost does", col, boostCards)
        oc.addView(row("Close background apps", "Frees RAM so the game gets more", sw(Prefs.BO_RAM, true)))
        oc.addView(row("Trim app caches", "Clears junk cache files", sw(Prefs.BO_CACHE, true)))
        oc.addView(row("Lock top refresh rate", "Keeps the screen at its max Hz", sw(Prefs.BO_HZ, true)))
        oc.addView(row("Battery saver off", "Saver slows the CPU down", sw(Prefs.BO_BATT, true)))
        oc.addView(row("Do not disturb", "No pop-ups while you play", sw(Prefs.BO_DND, false)))
        oc.addView(row("Game performance mode", "Auto boost only, if the game supports it", sw(Prefs.BO_GAME, true)))

        val ac = card("Auto boost", col, boostCards)
        ac.addView(row("Boost when a game starts", "Runs with Auto mode, or while the overlay is on. Settings go back when you stop playing", sw(Prefs.BO_AUTO, false)))

        val lc = card("Last boost", col, boostCards)
        boostLog = tv("", 13f, P.TEXT)
        boostLog.setPadding(0, dp(8f), 0, dp(8f))
        lc.addView(boostLog)
        val rb = PButton(this, "RESTORE MY SETTINGS", 1, 44f)
        rb.onClick = {
            val app = applicationContext
            Thread {
                val l = Boost.restore(app)
                runOnUiThread { Toast.makeText(this, l.joinToString(" · ") { it.text }, Toast.LENGTH_LONG).show() }
            }.start()
        }
        lc.addView(rb, LinearLayout.LayoutParams(-1, -2))

        val nc = card("Good to know", col, boostCards)
        val nt = tv("Freed RAM comes back as apps reopen themselves, so boost right before you play. Some phones ignore the refresh rate lock or the game mode. The log above shows what worked.", 12f, P.DIM)
        nt.setPadding(0, dp(6f), 0, 0)
        nc.addView(nt)
    }

    private fun refreshGamesLive() {
        turbo.todayMs = Games.today(this)
    }

    private val iconCache = HashMap<String, android.graphics.drawable.Drawable?>()
    private var gamesGen = 0

    private fun cachedIcon(pkg: String): android.graphics.drawable.Drawable? {
        val d = synchronized(iconCache) { if (iconCache.containsKey(pkg)) iconCache[pkg] else null } ?: return null
        return d.constantState?.newDrawable(resources)?.mutate() ?: d
    }

    /** Loads everything on a background thread, then builds the tab. The app never freezes while it works. */
    private fun refreshGames(force: Boolean = false) {
        val gen = ++gamesGen
        val app = applicationContext
        Thread {
            val games = Games.detect(app, force)
            val totals = Games.totals(app, games.map { it.pkg })
            val today = Games.today(app)
            val week = Games.week(app, null)
            val hasUsage = Games.hasUsage(app)
            val recent = Games.sessions(app).sortedByDescending { it.start }.take(6)
            val last = HashMap<String, Long>()
            for (g in games) last[g.pkg] = Games.lastPlayed(app, g.pkg)
            val need = HashSet<String>()
            for (g in games) need.add(g.pkg)
            for (s in recent) need.add(s.pkg)
            val names = HashMap<String, String>()
            for (g in games) names[g.pkg] = g.name
            for (pk in need) {
                val have = synchronized(iconCache) { iconCache.containsKey(pk) }
                if (!have) {
                    val d = try { app.packageManager.getApplicationIcon(pk) } catch (t: Throwable) { null }
                    synchronized(iconCache) { iconCache[pk] = d }
                }
            }
            // week chart: the most played games each get their own colour, the rest are grouped
            val order = games.sortedByDescending { totals[it.pkg] ?: 0L }.filter { (totals[it.pkg] ?: 0L) > 0L }.take(4)
            val stack = ArrayList<WeekSeg>()
            val sumTop = LongArray(7)
            for (g in order) {
                val wv = Games.week(app, g.pkg)
                for (k in 0 until 7) sumTop[k] += wv[k]
                stack.add(WeekSeg(g.name, IconColor.of(g.pkg, cachedIcon(g.pkg)), wv))
            }
            val other = LongArray(7) { k -> maxOf(0L, week[k] - sumTop[k]) }
            if (other.any { it > 0L }) stack.add(WeekSeg("Other games", 0xFF7C8996.toInt(), other))
            if (stack.isEmpty()) stack.add(WeekSeg("", Neon.CYAN, week))
            for (s in recent) if (names[s.pkg] == null) {
                names[s.pkg] = try {
                    app.packageManager.getApplicationLabel(app.packageManager.getApplicationInfo(s.pkg, 0)).toString()
                } catch (t: Throwable) { s.pkg }
            }
            runOnUiThread {
                if (gen != gamesGen || isFinishing || isDestroyed) return@runOnUiThread
                buildGamesUi(games, totals, today, stack, hasUsage, recent, last, names)
            }
        }.start()
    }

    private fun buildGamesUi(
        games: List<Games.GameApp>, totals: Map<String, Long>, today: Long, stack: List<WeekSeg>, hasUsage: Boolean,
        recent: List<Games.Session>, last: Map<String, Long>, names: Map<String, String>
    ) {
        val maxMs = totals.values.maxOrNull() ?: 0L
        turbo.todayMs = today
        turbo.totalMs = totals.values.sum()
        turbo.gameCount = games.size
        usageCard.visibility = if (hasUsage) View.GONE else View.VISIBLE

        hangar.removeAllViews()
        val sorted = games.sortedByDescending { totals[it.pkg] ?: 0L }
        if (games.isEmpty()) {
            val t = tv("No games found yet. Tap + Add game and pick one.", 13f, P.DIM)
            t.setPadding(dp(4f), dp(12f), 0, dp(12f))
            hangar.addView(t)
        }
        for (g in sorted) {
            val card = GameCard(this, g, cachedIcon(g.pkg), totals[g.pkg] ?: 0L, maxMs, last[g.pkg] ?: 0L)
            card.onOpen = { openDossier(g) }
            val lp = LinearLayout.LayoutParams(-2, -2)
            lp.rightMargin = dp(10f)
            hangar.addView(card, lp)
        }

        weekChart.setStack(stack)

        rankBox.removeAllViews()
        val played = sorted.filter { (totals[it.pkg] ?: 0L) > 0L }.take(5)
        if (played.isEmpty()) {
            rankBox.addView(tv("Play a game with the overlay on and it shows up here.", 12.5f, P.DIM))
        }
        for ((i, g) in played.withIndex()) {
            val r = RankRow(this, i + 1, g, cachedIcon(g.pkg), totals[g.pkg] ?: 0L, maxMs, last[g.pkg] ?: 0L)
            r.onOpen = { openDossier(g) }
            rankBox.addView(r, LinearLayout.LayoutParams(-1, -2))
        }

        sessBox.removeAllViews()
        if (recent.isEmpty()) {
            sessBox.addView(tv("Finished sessions appear here with their FPS wave.", 12.5f, P.DIM))
        }
        for (s in recent) {
            sessBox.addView(SessionRow(this, s, names[s.pkg] ?: s.pkg, cachedIcon(s.pkg)), LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun pickGame() {
        val others = Games.others(this)
        if (others.isEmpty()) { Toast.makeText(this, "No other apps found", Toast.LENGTH_SHORT).show(); return }
        android.app.AlertDialog.Builder(this)
            .setTitle("Add a game")
            .setItems(others.map { it.name }.toTypedArray()) { _, i ->
                Games.add(this, others[i].pkg)
                refreshGames(true)
            }
            .show()
    }

    private fun openDossier(g: Games.GameApp) {
        val dlg = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val fr = FrameLayout(this)
        fr.addView(CyberBg(this), FrameLayout.LayoutParams(-1, -1))
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(36f), dp(16f), dp(28f))
        sv.addView(col, FrameLayout.LayoutParams(-1, -2))
        fr.addView(sv, FrameLayout.LayoutParams(-1, -1))
        val ic = icon(g.pkg)
        val back = PButton(this, "< Back", 1, 40f)
        back.onClick = { dlg.dismiss() }
        col.addView(back, LinearLayout.LayoutParams(dp(110f), -2))
        col.addView(HeroIcon(this, ic), LinearLayout.LayoutParams(-1, -2))
        val nm = tv(g.name, 22f, 0xFFFFFFFF.toInt(), Typeface.BOLD)
        nm.gravity = Gravity.CENTER
        col.addView(nm, LinearLayout.LayoutParams(-1, -2))
        val sub = tv("Last played: " + Games.ago(Games.lastPlayed(this, g.pkg)), 12f, P.DIM)
        sub.gravity = Gravity.CENTER
        col.addView(sub, LinearLayout.LayoutParams(-1, -2))
        val play = PButton(this, "PLAY", 0, 52f)
        play.onClick = {
            val li = packageManager.getLaunchIntentForPackage(g.pkg)
            if (li != null) { dlg.dismiss(); startActivity(li) } else Toast.makeText(this, "Can't open this game", Toast.LENGTH_SHORT).show()
        }
        val plp = LinearLayout.LayoutParams(-1, -2)
        plp.topMargin = dp(14f)
        col.addView(play, plp)

        // stats
        val ss = Games.sessions(this).filter { it.pkg == g.pkg }
        val total = Games.total(this, g.pkg)
        val fpsList = ss.filter { it.avgFps > 0f }
        val avgFps = if (fpsList.isEmpty()) 0f else fpsList.map { it.avgFps }.average().toFloat()
        val lows = ss.filter { it.low > 0f }
        val avgLow = if (lows.isEmpty()) 0f else lows.map { it.low }.average().toFloat()
        val temps = ss.filter { it.avgTemp > 0f }
        val avgTemp = if (temps.isEmpty()) 0f else temps.map { it.avgTemp }.average().toFloat()
        val hours = ss.sumOf { it.ms } / 3_600_000f
        val drain = if (hours > 0.05f) ss.sumOf { it.batDrop } / hours else 0f
        val tiles = listOf(
            StatTile(this, "TOTAL TIME", total / 3_600_000f, "h", 1),
            StatTile(this, "SESSIONS", ss.size.toFloat(), "", 0),
            StatTile(this, "AVG FPS", avgFps, "fps", 0),
            StatTile(this, "1% LOW", avgLow, "fps", 0),
            StatTile(this, "AVG TEMP", avgTemp, "C", 0),
            StatTile(this, "BATTERY", drain, "%/h", 0)
        )
        for (r in 0..1) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0..2) {
                val lp = LinearLayout.LayoutParams(0, -2, 1f)
                lp.setMargins(dp(3f), dp(3f), dp(3f), dp(3f))
                row.addView(tiles[r * 3 + k], lp)
            }
            val rlp = LinearLayout.LayoutParams(-1, -2)
            rlp.topMargin = if (r == 0) dp(14f) else 0
            col.addView(row, rlp)
        }

        val dummy = ArrayList<View>()
        val wc = card("Last 7 days", col, dummy)
        val wch = WeekChart(this)
        wch.set(Games.week(this, g.pkg), IconColor.of(g.pkg, ic))
        wc.addView(wch, LinearLayout.LayoutParams(-1, -2))

        val sc = card("Sessions", col, dummy)
        val recent = ss.sortedByDescending { it.start }.take(5)
        if (recent.isEmpty()) sc.addView(tv("No finished sessions yet. Play with the overlay on.", 12.5f, P.DIM))
        for (s in recent) sc.addView(SessionRow(this, s, g.name, ic), LinearLayout.LayoutParams(-1, -2))

        val pc = card("Profile for this game", col, dummy)
        pc.addView(tv("Applied automatically while this game is in front, then your usual settings come back.", 12f, P.DIM))
        val tv1 = tv("Target FPS", 13f, P.TEXT)
        tv1.setPadding(0, dp(10f), 0, dp(4f))
        pc.addView(tv1)
        val tVals = intArrayOf(0, 30, 60, 90, 120)
        val sT = Segmented(this, listOf("Auto", "30", "60", "90", "120"))
        sT.select(tVals.indexOf(Games.profTarget(this, g.pkg)).coerceAtLeast(0), false)
        pc.addView(sT, LinearLayout.LayoutParams(-1, -2))
        val tv2 = tv("Overlay design", 13f, P.TEXT)
        tv2.setPadding(0, dp(10f), 0, dp(4f))
        pc.addView(tv2)
        val sVals = intArrayOf(-1, 0, 1, 2)
        val sS = Segmented(this, listOf("Auto", "Glass", "Gauge", "Pill"))
        sS.select(sVals.indexOf(Games.profStyle(this, g.pkg)).coerceAtLeast(0), false)
        pc.addView(sS, LinearLayout.LayoutParams(-1, -2))
        val save = { Games.setProf(this, g.pkg, tVals[sT.selected], sVals[sS.selected]) }
        sT.onSelect = { save() }
        sS.onSelect = { save() }

        val hide = PButton(this, "Remove from list", 2, 44f)
        hide.onClick = { Games.hide(this, g.pkg); dlg.dismiss() }
        val hlp = LinearLayout.LayoutParams(-1, -2)
        hlp.topMargin = dp(18f)
        col.addView(hide, hlp)

        dlg.setContentView(fr)
        dlg.setOnDismissListener { refreshGames() }
        dlg.show()
    }

    private lateinit var plHost: LinearLayout
    private lateinit var deckCardV: View
    private var openPl = ""
    private var addTarget = ""

    private fun buildMusic() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        pageMusic.addView(col, FrameLayout.LayoutParams(-1, -2))

        val deckCard = NeonCard(this)
        deckCard.orientation = LinearLayout.VERTICAL
        deckCard.addView(DeckView(this), LinearLayout.LayoutParams(-1, -2))
        val dlp = LinearLayout.LayoutParams(-1, -2)
        dlp.topMargin = dp(8f)
        col.addView(deckCard, dlp)
        deckCardV = deckCard

        plHost = LinearLayout(this)
        plHost.orientation = LinearLayout.VERTICAL
        col.addView(plHost, LinearLayout.LayoutParams(-1, -2))
        showPlaylists(false)
    }

    private fun resetMusicCards() {
        musicCards.clear()
        musicCards.add(deckCardV)
    }

    private fun lp(w: Int, h: Int, top: Int = 0, left: Int = 0): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(w, h)
        l.topMargin = top
        l.leftMargin = left
        return l
    }

    private fun showPlaylists(animate: Boolean) {
        openPl = ""
        plHost.removeAllViews()
        resetMusicCards()
        val pls = Music.playlists(this)
        val pc = card("Playlists", plHost, musicCards)
        val nb = CyBtn(this, "+ NEW PLAYLIST", Cy.PINK)
        nb.onClick = { playlistDialog(null) }
        pc.addView(nb, lp(-1, -2, dp(10f)))
        if (pls.isEmpty()) {
            val t = tv("No playlists yet. Tap New playlist, name it and pick a cover.", 12.5f, P.DIM)
            t.setPadding(0, dp(10f), 0, dp(4f))
            pc.addView(t)
        }
        for (pl in pls) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(10f), dp(8f), dp(14f), dp(8f))
            val act = pl.id == Music.activeId && Music.playing
            r.background = CutDrawable(0xFF131A22.toInt(), if (act) Neon.a(Faces.color(pl.face), 200) else 0x22FFFFFF, dp(1f).toFloat(), dp(14f).toFloat())
            val fv = FaceView(this, pl.face, pl.id)
            fv.sizeDp = 58f
            r.addView(fv)
            val tc = LinearLayout(this)
            tc.orientation = LinearLayout.VERTICAL
            val nm = tv(pl.name, 16f, P.TEXT, Typeface.BOLD)
            nm.maxLines = 1
            nm.ellipsize = android.text.TextUtils.TruncateAt.END
            tc.addView(nm)
            val n = pl.files.size
            tc.addView(tv(if (act) "Playing now" else if (n == 1) "1 song" else "$n songs", 12f, if (act) Neon.GREEN else P.DIM))
            r.addView(tc, lp(0, -2, 0, dp(12f)).also { it.weight = 1f })
            r.addView(tv(">", 18f, P.DIM))
            r.isClickable = true
            r.setOnClickListener { showDetail(pl.id, true) }
            pc.addView(r, lp(-1, -2, dp(8f)))
        }

        val bc = card("Beat sync", plHost, musicCards)
        val bs = PSwitch(this)
        bs.setChecked(Prefs.bool(this, "beat_sync", true))
        bs.onChange = { v ->
            Prefs.putBool(this, "beat_sync", v)
            if (v && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            else Toast.makeText(this, "Applies from the next song", Toast.LENGTH_SHORT).show()
        }
        bc.addView(row("Equalizer follows the beat", "Reads only this app's music. Nothing is recorded.", bs))
        if (animate) Ui.enter(musicCards, 0L)
    }

    private fun showDetail(id: String, animate: Boolean) {
        val pl = Music.playlist(this, id)
        if (pl == null) { showPlaylists(false); return }
        openPl = id
        plHost.removeAllViews()
        resetMusicCards()
        val hc = card("Playlist", plHost, musicCards)
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val fv = FaceView(this, pl.face, pl.id)
        fv.sizeDp = 76f
        top.addView(fv)
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        val nm = tv(pl.name, 20f, P.TEXT, Typeface.BOLD)
        nm.maxLines = 1
        nm.ellipsize = android.text.TextUtils.TruncateAt.END
        tc.addView(nm)
        val n = pl.files.size
        tc.addView(tv((if (n == 1) "1 song" else "$n songs") + "  -  " + Cover.names[pl.face % 5] + " cover", 12f, P.DIM))
        top.addView(tc, lp(0, -2, 0, dp(14f)).also { it.weight = 1f })
        hc.addView(top, lp(-1, -2, dp(12f)))

        val br = LinearLayout(this)
        br.orientation = LinearLayout.HORIZONTAL
        val back = PButton(this, "Back", 1, 42f)
        back.onClick = { showPlaylists(true) }
        br.addView(back, lp(0, -2).also { it.weight = 1f })
        val ed = PButton(this, "Edit", 1, 42f)
        ed.onClick = { playlistDialog(pl) }
        br.addView(ed, lp(0, -2, 0, dp(8f)).also { it.weight = 1f })
        hc.addView(br, lp(-1, -2, dp(12f)))

        val pb = PButton(this, "Play", 0, 44f)
        pb.onClick = { if (n > 0) { Music.playIn(applicationContext, id, 0); pushPreview() } else Toast.makeText(this, "Add songs first", Toast.LENGTH_SHORT).show() }
        hc.addView(pb, lp(-1, -2, dp(8f)))
        val ab = CyBtn(this, "+ ADD SONGS", Cy.CYAN)
        ab.onClick = {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "audio/*"
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            pickingFiles = true
            addTarget = id
            startActivityForResult(i, 32)
        }
        hc.addView(ab, lp(-1, -2, dp(8f)))

        val sc = card("Songs", plHost, musicCards)
        val songs = Music.songsOf(this, id)
        if (songs.isEmpty()) {
            val t = tv("This playlist is empty. Tap Add songs and pick tracks from your phone.", 12.5f, P.DIM)
            t.setPadding(0, dp(8f), 0, dp(4f))
            sc.addView(t)
        }
        for ((i, sg) in songs.withIndex()) {
            val row = TrackRow(this, i + 1, sg.title)
            row.onTap = { Music.playIn(applicationContext, id, i); pushPreview() }
            row.onRemove = { Music.removeFrom(this, id, i); showDetail(id, false); pushPreview() }
            row.onMoved = { dRows -> Music.moveIn(this, id, i, i + dRows); showDetail(id, false); pushPreview() }
            sc.addView(row, lp(-1, -2, if (i == 0) dp(8f) else 0))
        }
        if (songs.isNotEmpty()) {
            val hint = tv("Swipe left to remove. Press and hold, then drag to reorder.", 11f, P.DIM)
            hint.setPadding(dp(4f), dp(8f), 0, 0)
            sc.addView(hint)
        }
        if (animate) Ui.enter(musicCards, 0L)
    }

    private fun refreshMusicView() {
        if (openPl.isEmpty()) showPlaylists(false) else showDetail(openPl, false)
    }

    private fun playlistDialog(ex: Playlist?) {
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18f), dp(18f), dp(18f), dp(16f))
        box.background = CutDrawable(0xFF111820.toInt(), Neon.a(Neon.CYAN, 120), dp(1f).toFloat(), dp(16f).toFloat())
        box.addView(tv(if (ex == null) "New playlist" else "Edit playlist", 18f, P.TEXT, Typeface.BOLD))
        val et = android.widget.EditText(this)
        et.setText(ex?.name ?: "")
        et.hint = "Playlist name"
        et.setHintTextColor(P.DIM)
        et.setTextColor(P.TEXT)
        et.textSize = 16f
        et.isSingleLine = true
        et.filters = arrayOf<android.text.InputFilter>(android.text.InputFilter.LengthFilter(24))
        et.backgroundTintList = android.content.res.ColorStateList.valueOf(Neon.CYAN)
        et.setSelection(et.text.length)
        box.addView(et, lp(-1, -2, dp(12f)))
        val fl = tv("Cover style", 12f, P.DIM)
        fl.setPadding(0, dp(14f), 0, dp(6f))
        box.addView(fl)
        var face = ex?.face ?: 0
        val fname = tv(Cover.names[face % 5], 13f, Neon.CYAN, Typeface.BOLD)
        val chips = ArrayList<FaceView>()
        val rc = LinearLayout(this)
        rc.orientation = LinearLayout.HORIZONTAL
        rc.gravity = Gravity.CENTER
        for (i in 0..4) {
            val fv = FaceView(this, i, null, true)
            fv.sizeDp = 50f
            fv.chosen = i == face
            fv.onTap = {
                face = i
                for (cv in chips) cv.chosen = cv.face == face
                fname.text = Cover.names[i]
            }
            chips.add(fv)
            rc.addView(fv, lp(-2, -2, 0, if (i == 0) 0 else dp(5f)))
        }
        box.addView(rc)
        fname.setPadding(0, dp(8f), 0, 0)
        box.addView(fname)
        if (ex != null) {
            val ph = PButton(this, if (Cover.photo(this, ex.id).isEmpty()) "Choose a photo" else "Change photo", 1, 40f)
            ph.onClick = {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "image/*"
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                pickingFiles = true
                addTarget = ex.id
                dlg.dismiss()
                startActivityForResult(i, 35)
            }
            box.addView(ph, lp(-1, -2, dp(10f)))
            if (Cover.photo(this, ex.id).isNotEmpty()) {
                val rm = PButton(this, "Remove photo", 2, 40f)
                rm.onClick = { Cover.setPhoto(this, ex.id, ""); dlg.dismiss(); refreshMusicView() }
                box.addView(rm, lp(-1, -2, dp(8f)))
            }
        }

        val bw = LinearLayout(this)
        bw.orientation = LinearLayout.HORIZONTAL
        val cancel = PButton(this, "Cancel", 1, 42f)
        cancel.onClick = { dlg.dismiss() }
        bw.addView(cancel, lp(0, -2).also { it.weight = 1f })
        val save = PButton(this, if (ex == null) "Create" else "Save", 0, 42f)
        save.onClick = {
            val nm = et.text.toString()
            dlg.dismiss()
            if (ex == null) {
                val p = Music.createPlaylist(this, nm, face)
                showDetail(p.id, true)
            } else {
                Music.update(this, ex.id, nm, face)
                refreshMusicView()
            }
        }
        bw.addView(save, lp(0, -2, 0, dp(8f)).also { it.weight = 1f })
        box.addView(bw, lp(-1, -2, dp(16f)))
        if (ex != null) {
            val del = PButton(this, "Delete playlist", 2, 40f)
            del.onClick = {
                android.app.AlertDialog.Builder(this)
                    .setTitle("Delete this playlist?")
                    .setMessage("Its songs are removed from the app too.")
                    .setPositiveButton("Delete") { _, _ ->
                        dlg.dismiss()
                        Music.deletePlaylist(this, ex.id)
                        showPlaylists(true)
                        pushPreview()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            box.addView(del, lp(-1, -2, dp(8f)))
        }
        dlg.setContentView(box)
        dlg.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0))
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dlg.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (::playerTab.isInitialized && playerTab.onResult(requestCode, resultCode, data)) return
        if ((requestCode == 33 || requestCode == 34) && resultCode == RESULT_OK && data != null) {
            val uris = ArrayList<Uri>()
            val cd = data.clipData
            if (cd != null) for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) else data.data?.let { uris.add(it) }
            addToGallery(uris)
            return
        }
        if (requestCode == 62) {
            pickingFiles = false
            val u = data?.data
            if (resultCode == RESULT_OK && u != null) {
                val app = applicationContext
                Thread {
                    val ok = Backdrop.set(app, u)
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        if (ok) {
                            bgPick.set("Change image", 1)
                            bgClear.visibility = View.VISIBLE
                            repaintAll()
                        } else Toast.makeText(this, "Could not read that picture", Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
            return
        }
        if (requestCode == 35) {
            pickingFiles = false
            val u = data?.data
            if (resultCode == RESULT_OK && u != null) {
                try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (t: Throwable) { }
                Cover.setPhoto(this, addTarget, u.toString())
                refreshMusicView()
            }
            return
        }
        if (requestCode == 32) pickingFiles = false
        if (requestCode == 32 && resultCode == RESULT_OK && data != null) {
            val uris = ArrayList<Uri>()
            val cd = data.clipData
            if (cd != null) {
                for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
            } else {
                data.data?.let { uris.add(it) }
            }
            Toast.makeText(this, "Adding songs...", Toast.LENGTH_SHORT).show()
            Thread {
                var ok = 0
                val tgt = addTarget
                for (u in uris) if (Music.add(applicationContext, u, tgt)) ok++
                runOnUiThread {
                    refreshMusicView()
                    pushPreview()
                    Toast.makeText(this, if (ok == uris.size) "Added $ok song(s)" else "Added $ok of ${uris.size} (some were not audio files)", Toast.LENGTH_LONG).show()
                }
            }.start()
            return
        }
        if (requestCode != 31 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(this, "Loading...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val mime = contentResolver.getType(uri) ?: ""
                val type = when {
                    mime.startsWith("video") -> "video"
                    mime == "image/gif" || mime == "image/webp" -> "anim"
                    mime.startsWith("image") -> "image"
                    else -> ""
                }
                if (type.isEmpty()) throw RuntimeException("not a video or image")
                val out = File(filesDir, "media.dat")
                val silent = File(filesDir, "media_s.dat")
                silent.delete()
                var total = 0L
                contentResolver.openInputStream(uri)!!.use { ins ->
                    out.outputStream().use { os ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            total += n
                            os.write(buf, 0, n)
                        }
                    }
                }
                if (type == "video") {
                    // a copy with no audio track, so "sound off" is really silent even in recordings
                    if (!stripAudio(out, silent)) silent.delete()
                }
                runOnUiThread { setMedia(type) }
            } catch (t: Throwable) {
                runOnUiThread { Toast.makeText(this, "Could not load: " + t.message, Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun stripAudio(src: File, dst: File): Boolean {
        val ex = MediaExtractor()
        var mux: MediaMuxer? = null
        return try {
            ex.setDataSource(src.absolutePath)
            var vi = -1
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val m = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (m.startsWith("video/")) { vi = i; break }
            }
            if (vi < 0) return false
            ex.selectTrack(vi)
            mux = MediaMuxer(dst.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val ti = mux.addTrack(ex.getTrackFormat(vi))
            var rot = 0
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(src.absolutePath)
                rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                r.release()
            } catch (t: Throwable) { }
            mux.setOrientationHint(rot)
            mux.start()
            val buf = ByteBuffer.allocate(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                info.offset = 0
                info.size = n
                info.presentationTimeUs = ex.sampleTime
                info.flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                mux.writeSampleData(ti, buf, info)
                ex.advance()
            }
            mux.stop()
            true
        } catch (t: Throwable) {
            false
        } finally {
            try { mux?.release() } catch (t: Throwable) { }
            try { ex.release() } catch (t: Throwable) { }
        }
    }

    // ---------------- state -> screen ----------------

    private fun refreshControls() {
        val style = Prefs.int(this, Prefs.STYLE, 0)
        for (i in designCards.indices) designCards[i].setSelected2(i == style)
        segSize.select(Prefs.int(this, Prefs.MODE, 0), false)
        val tg = Prefs.int(this, Prefs.TARGET, 60)
        segTarget.select(listOf(30, 60, 90, 120).indexOf(tg).coerceAtLeast(0), false)
        val op = Prefs.int(this, Prefs.OPACITY, 92)
        slOpacity.setValue(op)
        tvOpacity.text = "Opacity  $op%"
        val sc = Prefs.int(this, Prefs.SCALE, 100)
        slScale.setValue(sc)
        tvScale.text = "Scale  $sc%"
        swGraph.setChecked(Prefs.bool(this, Prefs.GRAPH, true))
        swFx.setChecked(Prefs.bool(this, Prefs.EFFECTS, true))
        swBars.setChecked(Prefs.bool(this, Prefs.BARS, true))
        swFooter.setChecked(Prefs.bool(this, Prefs.FOOTER, true))
        swLock.setChecked(Prefs.bool(this, Prefs.LOCKED, false))
        swSound.setChecked(Prefs.bool(this, Prefs.SOUND, false))
        swBoot.setChecked(Prefs.bool(this, Prefs.BOOT, false))
        swAuto.setChecked(Prefs.bool(this, Prefs.AUTO, false))
        swOvIcon.setChecked(Prefs.bool(this, Prefs.OV_ICON, true))
    }

    private fun refresh() {
        refreshControls()

        val ov = Settings.canDrawOverlays(this)
        val st = FpsClient.state(this)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val free = pm.isIgnoringBatteryOptimizations(packageName)
        val nOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

        setPerm(rowOverlay, ov, "Allowed", "Needed to show the overlay", "Allow")
        val shMsg = when (st) {
            FpsClient.St.NOT_INSTALLED -> "Not installed" to "Install"
            FpsClient.St.NOT_RUNNING -> "Installed, not running. Start it first" to "Open Shizuku"
            FpsClient.St.NO_PERMISSION -> "Running. Needs your permission" to "Grant"
            FpsClient.St.READY -> "Linked" to "Linked"
        }
        setPerm(rowShizuku, st == FpsClient.St.READY, shMsg.first, shMsg.first, shMsg.second)
        setPerm(rowBattery, free, "Unrestricted", "Restricted: the system may close the overlay", "Allow")
        setPerm(rowNotif, nOk, "Allowed", "Hidden: the overlay still runs", "Allow")
        setPerm(autoAcc, GameAccessService.enabled(this), "On", "Turn on for instant game detection", "Open")
        setPerm(autoUsage, Games.hasUsage(this), "Allowed", "Only a backup", "Allow")

        val miss = ArrayList<String>()
        if (!ov) miss.add("overlay permission")
        if (st != FpsClient.St.READY) miss.add("Shizuku (needed for FPS)")
        banner.visibility = if (miss.isEmpty()) View.GONE else View.VISIBLE
        bannerText.text = "Setup needed: " + miss.joinToString(" and ")

        val on = OverlayService.pinned
        val watching = !on && OverlayService.running
        startBtn.set(if (on) "STOP OVERLAY" else "START OVERLAY", if (on) 2 else 0)
        statePill.text = if (on) "OVERLAY ON" else if (watching) "AUTO MODE" else "OVERLAY OFF"
        statePill.setTextColor(if (on || watching) P.GOOD else P.DIM)
        statePill.background = CutDrawable(if (on) 0x2019E6F2 else 0x14FFFFFF, if (on) 0x9919E6F2.toInt() else Ui.EDGE, dp(1f).toFloat(), dp(8f).toFloat())
    }

    private fun setPerm(r: PermRow, ok: Boolean, okText: String, badText: String, btn: String) {
        r.status.text = if (ok) okText else badText
        r.status.setTextColor(if (ok) P.GOOD else P.MID)
        r.btn.visibility = if (ok) View.INVISIBLE else View.VISIBLE
        r.btn.set(btn, 1)
    }
}

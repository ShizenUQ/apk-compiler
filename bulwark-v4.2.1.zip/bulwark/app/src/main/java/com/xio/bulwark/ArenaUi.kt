package com.xio.bulwark

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.BatteryManager
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Where Arena reports an error it caught, so it can be shown on screen instead of closing the app. */
object ArenaErr {
    @Volatile private var last = ""
    var onError: ((String) -> Unit)? = null
    fun note(t: Throwable) {
        val msg = android.util.Log.getStackTraceString(t).lines().take(9).joinToString("\n")
        if (msg == last) return
        last = msg
        onError?.invoke(msg)
    }
}

/** A view whose drawing can never crash the app. If something throws while drawing, the error is reported and the frame is skipped. */
abstract class SafeView(ctx: Context) : View(ctx) {
    override fun draw(canvas: Canvas) {
        val saved = canvas.save()
        try { super.draw(canvas) } catch (t: Throwable) { ArenaErr.note(t) } finally { try { canvas.restoreToCount(saved) } catch (t: Throwable) { } }
    }
}

/** Text helpers for Arena: the angular pixel font when every letter exists in it, a plain bold font otherwise. */
object AUi {
    fun ok(s: String) = s.all { Cy.has(it) }

    /** cy = vertical middle of the line. k = size (about 10k tall). align 0 left, 1 centre, 2 right. */
    fun text(c: Canvas, p: Paint, s: String, x: Float, cy: Float, k: Float, col: Int, al: Float, glow: Boolean, align: Int) {
        if (ok(s)) {
            CyUi.text(c, p, s, x, cy - 5f * k, k, col, al, glow, align)
        } else {
            p.style = Paint.Style.FILL; p.shader = null; p.color = Cy.a(col, al)
            p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            p.textSize = 10f * k
            p.textAlign = when (align) { 1 -> Paint.Align.CENTER; 2 -> Paint.Align.RIGHT; else -> Paint.Align.LEFT }
            c.drawText(s, x, cy + 3.5f * k, p)
            p.textAlign = Paint.Align.LEFT
        }
    }

    fun plain(c: Canvas, p: Paint, s: String, x: Float, base: Float, size: Float, col: Int, bold: Boolean, align: Int) {
        p.style = Paint.Style.FILL; p.shader = null; p.color = col
        p.typeface = Typeface.create("sans-serif-condensed", if (bold) Typeface.BOLD else Typeface.NORMAL)
        p.textSize = size
        p.textAlign = when (align) { 1 -> Paint.Align.CENTER; 2 -> Paint.Align.RIGHT; else -> Paint.Align.LEFT }
        c.drawText(s, x, base, p)
        p.textAlign = Paint.Align.LEFT
    }

    fun r(i: Int): Float { val x = sin(i * 12.9898f) * 43758.547f; return x - floor(x) }
}

/** Animated background of the whole Arena: night gradient, moving neon floor grid, drifting sparks and Nyx. Or your own picture. */
class ArenaBg(ctx: Context) : SafeView(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val art = Paint(Paint.ANTI_ALIAS_FLAG)
    private var custom: Bitmap? = null
    private var running = false
    private var base: LinearGradient? = null
    private var vig: RadialGradient? = null
    private var glow: RadialGradient? = null
    private val src = Rect()
    private val dst = Rect()
    private val moods = intArrayOf(12, 0, 2, 9, 12, 3, 11)

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    fun setCustom(b: Bitmap?) { custom = b; invalidate() }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (w <= 0 || h <= 0) return
        val wf = w.toFloat(); val hf = h.toFloat()
        base = LinearGradient(0f, 0f, 0f, hf, 0xFF04060B.toInt(), 0xFF0A1226.toInt(), Shader.TileMode.CLAMP)
        vig = RadialGradient(wf / 2f, hf / 2f, max(wf, hf) * 0.75f, intArrayOf(0, 0, 0xB8000000.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        val gr = hf * 0.62f
        glow = RadialGradient(wf * 0.78f, hf * 0.45f, gr,
            intArrayOf(Cy.a(Cy.PINK, 0.30f), Cy.a(Cy.CYAN, 0.12f), 0), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val t = Neon.now()
        p.style = Paint.Style.FILL
        p.shader = base; c.drawRect(0f, 0f, w, h, p); p.shader = null

        val bmp = custom
        if (bmp != null) {
            val bw = bmp.width.toFloat(); val bh = bmp.height.toFloat()
            val s = max(w / bw, h / bh)
            val cw = w / s; val ch = h / s
            src.set(((bw - cw) / 2f).toInt(), ((bh - ch) / 2f).toInt(), ((bw + cw) / 2f).toInt(), ((bh + ch) / 2f).toInt())
            dst.set(0, 0, w.toInt(), h.toInt())
            p.color = 0xFFFFFFFF.toInt()
            c.drawBitmap(bmp, src, dst, p)
            p.color = 0xB0040610.toInt(); c.drawRect(0f, 0f, w, h, p)
        } else {
            p.shader = glow; c.drawRect(0f, 0f, w, h, p); p.shader = null
        }

        // neon floor grid
        val hz = h * 0.60f
        p.style = Paint.Style.STROKE; p.strokeWidth = d
        for (i in 0 until 14) {
            val z = ((i + (t * 0.55f) % 1f) / 14f)
            val y = hz + (h - hz) * z * z
            p.color = Cy.a(Cy.CYAN, 0.05f + 0.22f * z)
            c.drawLine(0f, y, w, y, p)
        }
        for (j in -14..14) {
            p.color = Cy.a(Cy.CYAN, 0.10f)
            c.drawLine(w / 2f + j * w * 0.012f, hz, w / 2f + j * w * 0.11f, h, p)
        }
        p.color = Cy.a(Cy.PINK, 0.5f); p.strokeWidth = 1.6f * d
        c.drawLine(0f, hz, w, hz, p)

        // drifting sparks
        p.style = Paint.Style.FILL
        for (i in 0 until 44) {
            val x = AUi.r(i) * w
            val sp = (6f + AUi.r(i + 200) * 20f) * d
            var y = (AUi.r(i + 100) * h - t * sp) % h
            if (y < 0f) y += h
            val tw = 0.5f + 0.5f * sin(t * 2f + i)
            p.color = Cy.a(if (i % 3 == 0) Cy.PINK else Cy.CYAN, 0.10f + 0.28f * tw)
            c.drawCircle(x, y, (0.8f + AUi.r(i + 300) * 1.8f) * d, p)
        }

        // Nyx, big, on the right
        if (bmp == null) {
            val mood = moods[((t / 8f).toInt()) % moods.size]
            val bob = (sin(t * 1.6f) * 0.5f + 0.5f) * 0.4f
            art.style = Paint.Style.FILL; art.shader = null
            val sc = c.save()
            try { NyxChibi.draw(c, art, mood, w * 0.78f, h * 0.46f, h / 200f * 1.3f, t, 0f, bob, 0.92f) }
            catch (e: Throwable) { ArenaErr.note(e) }
            finally { c.restoreToCount(sc) }
        }

        p.shader = vig; p.style = Paint.Style.FILL; c.drawRect(0f, 0f, w, h, p); p.shader = null
    }
}

/** "ARENA" in the corner of the hub. */
class ArenaTitle(ctx: Context) : SafeView(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        p.style = Paint.Style.FILL; p.color = Cy.PINK
        c.drawRect(0f, h * 0.18f, 3f * d, h * 0.82f, p)
        AUi.text(c, p, "ARENA", 12f * d, h * 0.42f, 2.7f * d / 1.2f, Cy.CYAN, 1f, true, 0)
        AUi.text(c, p, "FRAMELINE", 13f * d, h * 0.82f, 0.95f * d, Cy.PINK, 0.9f, false, 0)
    }
}

/** Live phone chips: free RAM, battery temperature, battery level and screen refresh rate. */
class ArenaChips(ctx: Context) : SafeView(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var labels = arrayOf("RAM FREE", "TEMP", "BATTERY", "REFRESH")
    private var values = arrayOf("--", "--", "--", "--")
    private var cols = intArrayOf(Cy.CYAN, Cy.CYAN, Cy.CYAN, Cy.CYAN)
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            refresh()
            postDelayed(this, 1800)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    @Suppress("DEPRECATION")
    private fun refresh() {
        try {
            val avail = Boost.availMb(context); val total = max(1L, Boost.totalMb(context))
            val pct = (avail * 100 / total).toInt()
            values[0] = String.format(java.util.Locale.US, "%.1f GB", avail / 1024f)
            cols[0] = if (pct < 20) 0xFFFF5A4D.toInt() else if (pct < 35) CyUi.YELLOW else CyUi.GREEN
            val b = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (b != null) {
                val lv = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val tp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
                val bp = if (lv >= 0) lv * 100 / max(1, sc) else -1
                values[1] = String.format(java.util.Locale.US, "%.0f C", tp)
                cols[1] = if (tp >= 44f) 0xFFFF5A4D.toInt() else if (tp >= 40f) CyUi.YELLOW else Cy.CYAN
                values[2] = if (bp >= 0) "$bp%" else "--"
                cols[2] = if (bp in 0..14) 0xFFFF5A4D.toInt() else if (bp in 15..29) CyUi.YELLOW else CyUi.GREEN
            }
            val hzv = (context as? Activity)?.windowManager?.defaultDisplay?.refreshRate ?: 60f
            values[3] = String.format(java.util.Locale.US, "%.0f HZ", hzv)
            invalidate()
        } catch (t: Throwable) { }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val gap = 8f * d
        val cw = (w - gap * 3f) / 4f
        for (i in 0 until 4) {
            val l = i * (cw + gap)
            CyUi.chamfer(path, l, d, l + cw, h - d, 7f * d)
            p.style = Paint.Style.FILL; p.shader = null; p.color = 0x99060A12.toInt()
            c.drawPath(path, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d; p.color = Cy.a(cols[i], 0.7f)
            c.drawPath(path, p)
            AUi.text(c, p, labels[i], l + 10f * d, h * 0.30f, 0.85f * d, 0xFF8FA3B8.toInt(), 1f, false, 0)
            AUi.text(c, p, values[i], l + 10f * d, h * 0.68f, 1.5f * d, cols[i], 1f, false, 0)
        }
    }
}

/** One game on the Arena shelf. Tap anywhere on it to play. */
class ArenaTile(
    ctx: Context, val app: Games.GameApp, private val icon: Drawable?,
    private val total: Long, private val last: Long, private val avgFps: Float
) : SafeView(ctx) {
    var onPlay: (() -> Unit)? = null
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var down = false

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((176 * d).toInt(), MeasureSpec.getSize(h))

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; invalidate(); return true }
            MotionEvent.ACTION_UP -> {
                val was = down; down = false; invalidate()
                if (was && e.x in 0f..width.toFloat() && e.y in 0f..height.toFloat()) { performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK); onPlay?.invoke() }
                return true
            }
            MotionEvent.ACTION_CANCEL -> { down = false; invalidate(); return true }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val m = 5f * d
        val col = if (down) Cy.PINK else Cy.CYAN
        CyUi.chamfer(path, m, m, w - m, h - m, 16f * d)
        p.style = Paint.Style.FILL; p.shader = null; p.color = if (down) 0xDD1A0A18.toInt() else 0xCC070B14.toInt()
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.4f * d; p.color = Cy.a(col, if (down) 1f else 0.6f)
        c.drawPath(path, p)
        p.strokeWidth = 2.4f * d; p.color = Cy.PINK
        c.drawLine(m, m + 14f * d, m, m + 44f * d, p)

        val isz = min(w * 0.46f, h * 0.36f)
        val cx = w / 2f; val cy = h * 0.27f
        if (icon != null) {
            icon.setBounds((cx - isz / 2f).toInt(), (cy - isz / 2f).toInt(), (cx + isz / 2f).toInt(), (cy + isz / 2f).toInt())
            icon.draw(c)
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d; p.color = Cy.a(Cy.CYAN, 0.45f)
        c.drawRect(cx - isz / 2f - 4f * d, cy - isz / 2f - 4f * d, cx + isz / 2f + 4f * d, cy + isz / 2f + 4f * d, p)

        val nameY = h * 0.27f + isz / 2f + 22f * d
        AUi.plain(c, p, android.text.TextUtils.ellipsize(app.name.uppercase(), android.text.TextPaint(p).also { it.textSize = 13f * d; it.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD) }, w - 26f * d, android.text.TextUtils.TruncateAt.END).toString(),
            cx, nameY, 13f * d, 0xFFEAFBFF.toInt(), true, 1)

        val lines = arrayOf(
            "PLAYED  " + Games.fmt(total).uppercase(),
            Games.ago(last).uppercase(),
            if (avgFps > 0f) "AVG  " + avgFps.toInt() + " FPS" else "AVG  -- FPS"
        )
        var y = nameY + 20f * d
        for ((i, s) in lines.withIndex()) {
            val fc = if (i == 2 && avgFps > 0f) (if (avgFps >= 50f) CyUi.GREEN else if (avgFps >= 30f) CyUi.YELLOW else 0xFFFF5A4D.toInt()) else 0xFF8FA3B8.toInt()
            AUi.plain(c, p, s, cx, y, 10.5f * d, fc, false, 1)
            y += 15f * d
        }

        val bt = h - m - 46f * d
        CyUi.chamfer(path, m + 12f * d, bt, w - m - 12f * d, h - m - 12f * d, 9f * d)
        val pulse = 0.5f + 0.5f * sin(Neon.now() * 3f)
        p.style = Paint.Style.FILL; p.color = Cy.a(Cy.PINK, if (down) 0.9f else 0.28f + 0.12f * pulse)
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = Cy.PINK
        c.drawPath(path, p)
        AUi.text(c, p, "PLAY", cx, (bt + h - m - 12f * d) / 2f, 1.9f * d, 0xFFFFFFFF.toInt(), 1f, true, 1)
        if (!down) postInvalidateDelayed(90)
    }
}

/**
 * The full-screen sequence that runs when you tap a game: a charging ring around the game icon, every boost
 * step ticking off on the right, the freed memory counting up, a flash, then the game opens.
 */
class ArenaLaunch(ctx: Context, private val icon: Drawable?, private val name: String) : SafeView(ctx) {
    private class Step(var text: String, var state: Int, val at: Long)   // state 0 running, 1 done, 2 failed

    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val steps = ArrayList<Step>()
    private val t0 = SystemClock.uptimeMillis()
    private var target = 0.02f
    private var disp = 0f
    private var freed = -1L
    private var freedAt = 0L
    private var launchAt = 0L
    private var header = "BOOSTING"
    private var scan: LinearGradient? = null

    fun step(text: String, f: Float) {
        if (steps.isNotEmpty()) steps[steps.size - 1].state = 1
        steps.add(Step(text, 0, SystemClock.uptimeMillis()))
        target = max(target, f.coerceIn(0f, 0.99f))
    }

    fun skipped(msg: String) {
        steps.add(Step(msg, 2, SystemClock.uptimeMillis()))
        target = 0.9f
    }

    fun result(r: Boost.Result?) {
        header = "READY"
        target = 1f
        if (r != null) {
            steps.clear()
            val now = SystemClock.uptimeMillis()
            for ((i, l) in r.lines.withIndex()) steps.add(Step(l.text, if (l.ok) 1 else 2, now + i * 90L))
            freed = r.freedMb; freedAt = now
        } else {
            freed = 0L; freedAt = SystemClock.uptimeMillis()
        }
    }

    fun launching() { header = "LAUNCHING"; launchAt = SystemClock.uptimeMillis() }

    private fun ease(x: Float): Float { val k = x.coerceIn(0f, 1f); return 1f - (1f - k) * (1f - k) * (1f - k) }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = (now - t0) / 1000f
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFF03050A.toInt()
        c.drawRect(0f, 0f, w, h, p)
        p.shader = RadialGradient(w * 0.30f, h * 0.5f, h * 0.9f, intArrayOf(Cy.a(Cy.CYAN, 0.20f), Cy.a(Cy.PINK, 0.06f), 0), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p); p.shader = null

        // moving scan lines
        p.style = Paint.Style.STROKE; p.strokeWidth = d
        val off = (t * 40f * d) % (8f * d)
        var y = off
        while (y < h) { p.color = Cy.a(Cy.CYAN, 0.035f); c.drawLine(0f, y, w, y, p); y += 8f * d }

        disp += (target - disp) * 0.07f
        val cx = w * 0.29f; val cy = h * 0.47f
        val R = min(w * 0.19f, h * 0.31f)

        // ring
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f * d; p.color = Cy.a(Cy.CYAN, 0.22f)
        c.drawCircle(cx, cy, R, p)
        rect.set(cx - R, cy - R, cx + R, cy + R)
        p.strokeWidth = 7f * d; p.strokeCap = Paint.Cap.ROUND
        p.color = if (disp > 0.985f) CyUi.GREEN else Cy.CYAN
        c.drawArc(rect, -90f, 360f * disp, false, p)
        p.strokeCap = Paint.Cap.BUTT
        // spinning ticks
        p.strokeWidth = 2f * d
        for (i in 0 until 48) {
            val a = (i / 48f * 2f * PI + t * 0.9f).toFloat()
            val l = if (i % 4 == 0) 14f * d else 7f * d
            p.color = Cy.a(if (i % 4 == 0) Cy.PINK else Cy.CYAN, 0.55f)
            c.drawLine(cx + cos(a) * (R + 10f * d), cy + sin(a) * (R + 10f * d), cx + cos(a) * (R + 10f * d + l), cy + sin(a) * (R + 10f * d + l), p)
        }
        p.style = Paint.Style.FILL; p.color = 0xFF070B14.toInt()
        c.drawCircle(cx, cy, R * 0.80f, p)

        val pop = 1f + 0.04f * sin(t * 4f) + (if (launchAt > 0L) 0.25f * ease((now - launchAt) / 500f) else 0f)
        val isz = R * 1.12f * pop * ease(t / 0.5f)
        if (icon != null) {
            icon.setBounds((cx - isz / 2f).toInt(), (cy - isz / 2f).toInt(), (cx + isz / 2f).toInt(), (cy + isz / 2f).toInt())
            icon.draw(c)
        }
        AUi.plain(c, p, name.uppercase().take(26), cx, cy + R + 52f * d, 15f * d, 0xFFEAFBFF.toInt(), true, 1)
        AUi.text(c, p, "" + (disp * 100f).toInt() + "%", cx, cy + R + 78f * d, 1.6f * d, Cy.CYAN, 1f, false, 1)

        // right side
        val x0 = w * 0.56f
        AUi.text(c, p, header, x0, h * 0.20f, 3.0f * d, if (header == "LAUNCHING") Cy.PINK else CyUi.YELLOW, 1f, true, 0)
        p.style = Paint.Style.FILL; p.color = Cy.PINK
        c.drawRect(x0, h * 0.20f + 22f * d, x0 + 90f * d * ease(t / 0.6f), h * 0.20f + 25f * d, p)
        var ly = h * 0.20f + 58f * d
        for (s in steps.take(7)) {
            val age = ease((now - s.at) / 350f)
            if (age <= 0f) continue
            val xo = x0 + (1f - age) * 40f * d
            val col = when (s.state) { 1 -> CyUi.GREEN; 2 -> 0xFFFF5A4D.toInt(); else -> Cy.CYAN }
            p.style = Paint.Style.FILL; p.color = Cy.a(col, age)
            if (s.state == 0) { if ((now / 220L) % 2L == 0L) c.drawRect(xo, ly - 7f * d, xo + 9f * d, ly + 2f * d, p) }
            else if (s.state == 1) { c.drawRect(xo, ly - 7f * d, xo + 9f * d, ly + 2f * d, p) }
            else { p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d; c.drawLine(xo, ly - 7f * d, xo + 9f * d, ly + 2f * d, p); c.drawLine(xo + 9f * d, ly - 7f * d, xo, ly + 2f * d, p) }
            AUi.plain(c, p, s.text, xo + 20f * d, ly + 1f * d, 14f * d, Cy.a(0xFFEAFBFF.toInt(), age), false, 0)
            ly += 29f * d
        }

        if (freed >= 0L) {
            val k = ease((now - freedAt) / 1300f)
            val v = (freed * k).toLong()
            AUi.text(c, p, "+$v MB", x0, h * 0.80f, 5.0f * d, Cy.PINK, 1f, true, 0)
            AUi.text(c, p, if (freed > 0L) "MEMORY FREED" else "READY TO PLAY", x0, h * 0.80f + 38f * d, 1.5f * d, 0xFF8FA3B8.toInt(), 1f, false, 0)
        }

        // fade in at the start, white flash when launching
        if (t < 0.4f) { p.style = Paint.Style.FILL; p.color = Cy.a(0xFF000000.toInt(), 1f - t / 0.4f); c.drawRect(0f, 0f, w, h, p) }
        if (launchAt > 0L) {
            val f = ((now - launchAt) / 650f).coerceIn(0f, 1f)
            p.style = Paint.Style.FILL; p.color = Cy.a(0xFFFFFFFF.toInt(), f * f)
            c.drawRect(0f, 0f, w, h, p)
        }
        postInvalidateOnAnimation()
    }
}

/** The opening: a scan line, the word ARENA flickering in, a pink underline, then everything fades into the hub. */
class ArenaIntro(ctx: Context) : SafeView(ctx) {
    var onHub: (() -> Unit)? = null
    var onDone: (() -> Unit)? = null
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = SystemClock.uptimeMillis()
    private var hubSent = false
    private var doneSent = false

    private fun ease(x: Float): Float { val k = x.coerceIn(0f, 1f); return 1f - (1f - k) * (1f - k) * (1f - k) }

    override fun onTouchEvent(e: MotionEvent): Boolean = true   // not skippable, and it blocks taps until it is gone

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = (now - t0) / 1000f
        val w = width.toFloat(); val h = height.toFloat()
        val fade = if (t < 2.0f) 1f else (1f - (t - 2.0f) / 0.7f).coerceIn(0f, 1f)
        if (t >= 2.0f && !hubSent) { hubSent = true; post { onHub?.invoke() } }
        if (t >= 2.7f) { if (!doneSent) { doneSent = true; post { onDone?.invoke() } }; return }

        c.saveLayerAlpha(0f, 0f, w, h, (fade * 255f).toInt())
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFF020306.toInt()
        c.drawRect(0f, 0f, w, h, p)

        // grid revealed by the scan line
        val sy = ease(t / 0.7f) * h
        c.save(); c.clipRect(0f, 0f, w, sy)
        p.style = Paint.Style.STROKE; p.strokeWidth = d
        val hz = h * 0.55f
        for (i in 0 until 14) {
            val z = (i + (t * 0.8f) % 1f) / 14f
            val y = hz + (h - hz) * z * z
            p.color = Cy.a(Cy.CYAN, 0.06f + 0.25f * z); c.drawLine(0f, y, w, y, p)
        }
        for (j in -14..14) { p.color = Cy.a(Cy.CYAN, 0.12f); c.drawLine(w / 2f + j * w * 0.012f, hz, w / 2f + j * w * 0.11f, h, p) }
        c.restore()
        if (t < 0.8f) { p.color = Cy.a(Cy.CYAN, 0.9f); p.strokeWidth = 2.5f * d; c.drawLine(0f, sy, w, sy, p) }

        // the word
        val word = "ARENA"
        val k = min(w * 0.52f / 41f, h * 0.20f / 10f)
        val n = ((t - 0.5f) / 0.17f).toInt().coerceIn(0, word.length)
        val jit = if (t < 1.5f) ((AUi.r((now / 55L).toInt()) - 0.5f) * 8f * d) else 0f
        if (n > 0) {
            val s = word.substring(0, n)
            val full = CyUi.width(word, k)
            CyUi.text(c, p, s, w / 2f - full / 2f + jit, h * 0.42f - 5f * k, k, Cy.CYAN, 1f, true, 0)
            if (t < 1.5f) CyUi.text(c, p, s, w / 2f - full / 2f - jit * 1.6f, h * 0.42f - 5f * k, k, Cy.PINK, 0.35f, false, 0)
        }
        val ul = ease((t - 1.25f) / 0.6f)
        if (ul > 0f) {
            val half = w * 0.26f * ul
            p.style = Paint.Style.FILL; p.color = Cy.PINK
            c.drawRect(w / 2f - half, h * 0.42f + 6f * k + 6f * d, w / 2f + half, h * 0.42f + 6f * k + 9f * d, p)
        }
        val sub = ease((t - 1.5f) / 0.5f)
        if (sub > 0f) AUi.text(c, p, "PERFORMANCE HUB", w / 2f, h * 0.42f + 6f * k + 34f * d, 1.5f * d, 0xFFB7C6D8.toInt(), sub, false, 1)

        val fl = (1f - (t - 1.45f) / 0.35f).coerceIn(0f, 1f)
        if (t >= 1.45f && fl > 0f) { p.style = Paint.Style.FILL; p.color = Cy.a(0xFFFFFFFF.toInt(), 0.22f * fl); c.drawRect(0f, 0f, w, h, p) }
        c.restore()
        postInvalidateOnAnimation()
    }
}

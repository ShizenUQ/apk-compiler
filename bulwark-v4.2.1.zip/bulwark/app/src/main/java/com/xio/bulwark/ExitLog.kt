package com.xio.bulwark

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Remembers WHY the app last stopped, so a sudden close is no longer a mystery.
 * Two sources: the last Java crash (saved by us) and Android's own record of how the process ended
 * (low memory, native crash, killed by the system, ...), shown in Settings > Diagnostics.
 */
object ExitLog {
    @Volatile private var installed = false
    private fun file(c: Context) = File(c.filesDir, "last_crash.txt")
    private val fmt = SimpleDateFormat("MMM d HH:mm:ss", Locale.US)

    fun install(c: Context) {
        if (installed) return
        installed = true
        val app = c.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { file(app).writeText(fmt.format(Date()) + "  thread=" + t.name + "\n" + Log.getStackTraceString(e)) } catch (x: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }

    /** Saves an error Arena caught, so Settings > Diagnostics shows it. */
    fun note(c: Context, text: String) {
        try { file(c).writeText(fmt.format(Date()) + "  [Arena caught error]\n" + text) } catch (x: Throwable) { }
    }

    private fun name(r: Int) = when (r) {
        1 -> "EXIT_SELF (app closed itself)"
        2 -> "SIGNALED (killed by a signal)"
        3 -> "LOW_MEMORY (Android needed RAM and killed the app)"
        4 -> "CRASH (Java crash)"
        5 -> "CRASH_NATIVE (crash in native code)"
        6 -> "ANR (app stopped responding)"
        7 -> "INITIALIZATION_FAILURE"
        8 -> "PERMISSION_CHANGE"
        9 -> "EXCESSIVE_RESOURCE_USAGE"
        10 -> "USER_REQUESTED (force stop / swiped away)"
        11 -> "USER_STOPPED"
        12 -> "DEPENDENCY_DIED"
        14 -> "FREEZER"
        15 -> "PACKAGE_STATE_CHANGE"
        16 -> "PACKAGE_UPDATED"
        else -> "OTHER ($r)"
    }

    fun report(c: Context): String {
        val sb = StringBuilder("LAST STOPS\n")
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val list = am.getHistoricalProcessExitReasons(c.packageName, 0, 6)
                if (list.isEmpty()) sb.append("no record yet\n")
                for (i in list) {
                    sb.append(fmt.format(Date(i.timestamp))).append("  ").append(if (i.processName.endsWith(":vlc")) "[video engine] " else "[app] ").append(name(i.reason))
                    sb.append("  mem=").append(i.rss / 1024).append("MB")
                    if (!i.description.isNullOrEmpty()) sb.append("  ").append(i.description)
                    sb.append('\n')
                }
            } catch (t: Throwable) { sb.append("exit info unavailable\n") }
        } else sb.append("exit info needs Android 11+\n")
        try {
            val f = file(c)
            if (f.exists()) sb.append("\nlast Java crash:\n").append(f.readText().take(1500)).append('\n')
        } catch (t: Throwable) { }
        return sb.toString()
    }
}

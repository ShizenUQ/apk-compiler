package com.xio.bulwark

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Resources
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.net.Uri
import rikka.shizuku.Shizuku
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import kotlin.math.min

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.xio.bulwark.STOP"
        const val ACTION_TOGGLE_LOCK = "com.xio.bulwark.TOGGLE_LOCK"
        const val ACTION_TOGGLE_SOUND = "com.xio.bulwark.TOGGLE_SOUND"
        private const val CHANNEL = "bulwark_watch"
        private const val NOTIF_ID = 7
        private const val BASE_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

        const val ACTION_MUSIC_PREV = "com.xio.bulwark.MUSIC_PREV"
        const val ACTION_MUSIC_TOGGLE = "com.xio.bulwark.MUSIC_TOGGLE"
        const val ACTION_MUSIC_NEXT = "com.xio.bulwark.MUSIC_NEXT"

        const val ACTION_SHOW = "com.xio.bulwark.SHOW"
        const val ACTION_HIDE = "com.xio.bulwark.HIDE"
        const val EXTRA_WATCH = "watch"
        private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"

        @Volatile
        var running = false

        /** The status overlay is on screen right now. */
        @Volatile
        var shown = false

        /** The overlay was started by hand and stays up until you stop it. Otherwise Auto mode shows it only during a game. */
        @Volatile
        var pinned = false

        @Volatile
        private var inst: OverlayService? = null

        /** Called by the accessibility service the moment an app window comes to the front. */
        fun front(pkg: String, cls: String?) { inst?.postFront(pkg, cls) }
    }

    private lateinit var wm: WindowManager
    private var root: HudRoot? = null
    private var edgeV: EdgeView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private class Spot(val v: TapSpot, val lp: WindowManager.LayoutParams)
    private val spots = HashMap<String, Spot>()

    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var wh: Handler? = null
    private var t0 = 0L
    private var screenOn = true

    private val loop = object : Runnable {
        override fun run() {
            var next = 1000L
            try {
                val c = applicationContext
                if (shown) {
                    next = 500L
                    val raw = try { FpsClient.sample(c) } catch (t: Throwable) { null }
                    val data = FpsData.parse(raw)
                    val sys = StatsReader.read(c, t0)
                    try { Tracker.feed(c, data, sys) } catch (t: Throwable) { }
                    main.post {
                        try {
                            lastData = data; lastSys = sys
                            root?.applyPrefs()
                            applyWindowState()
                            root?.update(data, sys)
                            syncEdge()
                            edgeV?.applyPrefs()
                            edgeV?.update(data, sys)
                            syncBadge()
                            novaTick(data, sys)
                        } catch (t: Throwable) { }
                    }
                }
                if (!GameAccessService.connected) { if (shown) next = 500L else next = 900L; pollUsage(c, false) }
            } catch (t: Throwable) {
            }
            if (screenOn) wh?.postDelayed(this, next)
        }
    }

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> { screenOn = false; wh?.removeCallbacks(loop) }
                Intent.ACTION_SCREEN_ON -> { screenOn = true; wh?.removeCallbacks(loop); wh?.post(loop) }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ExitLog.install(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        t0 = SystemClock.elapsedRealtime()
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        running = true
        inst = this
        registerReceiver(screenRx, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        Music.onChange = {
            main.post {
                root?.hud?.poke()
                panel?.refreshCurrent()
                try {
                    (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
                } catch (t: Throwable) { }
            }
        }
        worker = HandlerThread("bulwark-sampler").also { it.start() }
        wh = Handler(worker!!.looper)
        wh?.post(loop)
        wh?.post { try { pollUsage(applicationContext, true) } catch (t: Throwable) { } }
        try {
            Shizuku.addBinderReceivedListenerSticky(sBinder)
            Shizuku.addBinderDeadListener(sDead)
            Shizuku.addRequestPermissionResultListener(sPerm)
        } catch (t: Throwable) { }
    }

    private var initDone = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                // stopping from the notification turns Auto mode off too, so the service does not come back by itself
                Prefs.putBool(this, Prefs.AUTO, false)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_LOCK -> toggleLock()
            ACTION_TOGGLE_SOUND -> toggleSound()
            ACTION_MUSIC_PREV -> Music.prev(applicationContext)
            ACTION_MUSIC_TOGGLE -> Music.toggle(applicationContext)
            ACTION_MUSIC_NEXT -> Music.next(applicationContext)
            ACTION_SHOW -> { pinned = true; applyUi() }
            ACTION_HIDE -> { pinned = false; applyUi() }
            else -> if (!initDone) {
                initDone = true
                val watch = if (intent == null) (Prefs.bool(this, Prefs.AUTO, false) || Prefs.bool(this, Prefs.BOOT, false)) else intent.getBooleanExtra(EXTRA_WATCH, false)
                if (watch) {
                    pinned = false
                    notifyState()
                } else {
                    pinned = true
                    applyUi()
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        inst = null
        shown = false
        pinned = false
        try {
            Shizuku.removeBinderReceivedListener(sBinder)
            Shizuku.removeBinderDeadListener(sDead)
            Shizuku.removeRequestPermissionResultListener(sPerm)
        } catch (t: Throwable) { }
        hideChip()
        hideBanner()
        hideNova()
        hideRecap()
        hideBadge()
        hideEdge()
        wh?.removeCallbacksAndMessages(null)
        worker?.quitSafely()
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(screenRx) } catch (t: Throwable) { }
        Music.onChange = null
        hidePanel()
        VideoLib.onChange = null
        pHost?.destroy(); pHost = null
        Music.stop()
        try { Tracker.flush(applicationContext) } catch (t: Throwable) { }
        clearSpots()
        root?.let { try { wm.removeView(it) } catch (t: Throwable) { } }
        root = null
        FpsClient.unbind(applicationContext)
        super.onDestroy()
    }

    // ---------- overlay window ----------

    private fun showOverlay() {
        val dm = Resources.getSystem().displayMetrics
        val v = HudRoot(this)
        v.applyPrefs()
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        edge(lp)
        val sc0 = screen()
        val ratio = if (land()) maxOf(sc0[0], sc0[1]).toFloat() / minOf(sc0[0], sc0[1]) else 1f
        lp.x = Prefs.int(this, kx(), -1).let { if (it >= 0) it else (Prefs.int(this, Prefs.X, (24 * dm.density).toInt()) * (if (land()) ratio else 1f)).toInt() }
        lp.y = Prefs.int(this, ky(), -1).let { if (it >= 0) it else (Prefs.int(this, Prefs.Y, (24 * dm.density).toInt()) / (if (land()) ratio else 1f)).toInt() }
        lp.alpha = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        v.onMusic = { i -> onMusicTap(i) }
        v.onPlayer = { playerTap() }
        if (pHost == null) {
            pHost = PlayerHost(applicationContext, wm, { screen() }, { l -> edge(l) }, {
                val r = root
                if (r == null) null else Rect(lp.x, lp.y, lp.x + r.width, lp.y + r.height)
            })
            pHost?.onState = { root?.hud?.poke() }
        }
        VideoLib.onChange = { main.post { root?.applyPrefs() } }
        v.onDrag = { dx, dy ->
            if (panel != null) hidePanel()
            lp.x += dx
            lp.y += dy
            clamp(v)
            try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
            pHost?.reposition()
            syncBadge()
            replaceAttached()
        }
        v.onDragEnd = { snap(v); pHost?.reposition() }
        v.onToggleLock = { toggleLock() }
        v.onToggleSound = { toggleSound() }
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> syncSpots(); pHost?.reposition(); replaceAttached() }
        try {
            wm.addView(v, lp)
            root = v
            shown = true
            v.post { try { clamp(v); wm.updateViewLayout(v, lp); syncBadge() } catch (t: Throwable) { } }
        } catch (t: Throwable) {
            AutoLog.note("overlay failed: $t")
            if (pinned) stopSelf()
        }
    }

    /** Takes the status overlay off the screen (Auto mode, after the game closes). The service keeps watching. */
    private fun hideOverlay() {
        val r = root ?: return
        hidePanel()
        clearSpots()
        pHost?.destroy(); pHost = null
        VideoLib.onChange = null
        hideBadge()
        try { wm.removeView(r) } catch (t: Throwable) { }
        root = null
        shown = false
        hideEdge()
    }

    private fun notifyState() {
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (t: Throwable) { }
    }

    /**
     * Lets a window use the whole screen, notch side included. Without this, in landscape the system pushes the big
     * overlay away from the notch but not the tiny tap windows, so taps land beside the icons.
     */
    private fun edge(l: WindowManager.LayoutParams) {
        if (Build.VERSION.SDK_INT >= 30) l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else if (Build.VERSION.SDK_INT >= 28) l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    /** Real current screen size (follows rotation). Resources.getSystem() goes stale after a rotation. */
    @Suppress("DEPRECATION")
    private fun screen(): IntArray {
        return try {
            val m = android.util.DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            intArrayOf(m.widthPixels, m.heightPixels)
        } catch (t: Throwable) {
            val m = Resources.getSystem().displayMetrics
            intArrayOf(m.widthPixels, m.heightPixels)
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        hidePanel()
        pHost?.onConfig()
        val v = root ?: return
        main.postDelayed({
            try {
                lp.x = Prefs.int(this, kx(), lp.x)
                lp.y = Prefs.int(this, ky(), lp.y)
                clamp(v)
                wm.updateViewLayout(v, lp)
                clearSpots()
                syncSpots()
                pHost?.onConfig()
                syncBadge()
            } catch (t: Throwable) { }
        }, 350)
    }

    private fun clamp(v: View) {
        val sc = screen()
        val w = if (v.width > 0) v.width else 1
        val h = if (v.height > 0) v.height else 1
        lp.x = lp.x.coerceIn(0, maxOf(0, sc[0] - w))
        lp.y = lp.y.coerceIn(0, maxOf(0, sc[1] - h))
    }

    private fun land(): Boolean { val sc = screen(); return sc[0] > sc[1] }
    private fun kx() = if (land()) "x_land" else Prefs.X
    private fun ky() = if (land()) "y_land" else Prefs.Y

    /** The overlay stays exactly where you drop it. Portrait and landscape remember their own spot. */
    private fun snap(v: View) {
        clamp(v)
        Prefs.putInt(this, kx(), lp.x)
        Prefs.putInt(this, ky(), lp.y)
    }

    // ---------- lock ----------

    private fun toggleLock() {
        val now = !Prefs.bool(this, Prefs.LOCKED, false)
        Prefs.putBool(this, Prefs.LOCKED, now)
        root?.applyPrefs()
        applyWindowState()
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (t: Throwable) { }
    }

    /** Locked = every touch passes through to the game (window opacity must stay at 80% or less on Android 12+). */
    private fun applyWindowState() {
        val v = root ?: return
        val locked = Prefs.bool(this, Prefs.LOCKED, false)
        val op = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        val flags = if (locked) BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else BASE_FLAGS
        val a = if (locked) min(op, 0.8f) else op
        if (lp.flags != flags || lp.alpha != a) {
            lp.flags = flags
            lp.alpha = a
            try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
        }
        if (locked) syncSpots() else clearSpots()
        val vis = if (Prefs.int(this, Prefs.EDGE_MODE, 0) == 2 && edgeV != null) View.INVISIBLE else View.VISIBLE
        if (v.visibility != vis) v.visibility = vis
    }

    // ---------- screen edge ----------

    private fun edgeWanted(): Boolean {
        val g = curGame
        val want = pinned || (g != null && rawFront == g)
        return want && root != null && Prefs.int(this, Prefs.EDGE_MODE, 0) != 0
    }

    private fun syncEdge() {
        val w = edgeWanted()
        if (w && edgeV == null) showEdge() else if (!w && edgeV != null) hideEdge()
    }

    private fun showEdge() {
        if (edgeV != null) return
        val v = EdgeView(this)
        v.applyPrefs()
        val l = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        try { wm.addView(v, l); edgeV = v } catch (t: Throwable) { AutoLog.note("edge failed: $t") }
        val lastD = lastData; val lastS = lastSys
        if (lastD != null && lastS != null) v.update(lastD, lastS)
    }

    private fun hideEdge() {
        val v = edgeV ?: return
        edgeV = null
        try { wm.removeView(v) } catch (t: Throwable) { }
        root?.visibility = View.VISIBLE
    }

    private fun toggleSound() {
        Prefs.putBool(this, Prefs.SOUND, !Prefs.bool(this, Prefs.SOUND, false))
        root?.applyPrefs()
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (t: Throwable) { }
    }

    /**
     * While locked the overlay lets every touch through. The only exceptions are two tiny invisible
     * windows placed exactly over the lock icon (to unlock) and the sound icon (to mute / unmute).
     */
    private fun syncSpots() {
        val r = root ?: return
        if (!Prefs.bool(this, Prefs.LOCKED, false)) return
        spot("lock", r.lockRectPx()) { toggleLock() }
        spot("vid", r.videoTapRectPx()) { toggleSound() }
        spot("img", r.imageTapRectPx()) { r.nextImage() }
        spot("play", r.playerRectPx()) { playerTap() }
        val mr = r.musicRectsPx()
        for (i in 0..3) spot("m$i", mr.getOrNull(i)) { onMusicTap(i) }
    }

    // ---------- player ----------

    private var pHost: PlayerHost? = null

    private fun playerTap() {
        if (panel != null) hidePanel()
        pHost?.iconTap()
    }

    // ---------- music ----------

    private var panel: MusicPanel? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelClosedAt = 0L
    private var panelSide = false
    private var panelMode = 0
    private var panelMax = 0

    private fun onMusicTap(i: Int) {
        val c = applicationContext
        when (i) {
            0 -> if (panel != null) hidePanel()
                 else if (SystemClock.uptimeMillis() - panelClosedAt > 450) showPanel()
            1 -> Music.prev(c)
            2 -> Music.toggle(c)
            3 -> Music.next(c)
        }
        root?.hud?.poke()
    }

    private fun hidePanel() {
        val p = panel ?: return
        panel = null
        panelLp = null
        panelClosedAt = SystemClock.uptimeMillis()
        Music.panelOpen = false
        root?.hud?.poke()
        val a = p.animate().alpha(0f).setDuration(140)
        if (panelSide) a.scaleX(0.85f) else a.scaleY(0.85f)
        a.withEndAction {
            try { wm.removeView(p) } catch (t: Throwable) { }
        }.start()
    }

    private fun showPanel() {
        val r = root ?: return
        val c = applicationContext
        if (Music.playlists(c).isEmpty()) {
            android.widget.Toast.makeText(c, "Create a playlist first: Frameline app > Music", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val dm = Resources.getSystem().displayMetrics
        val sc = screen()
        val sw = sc[0]
        val sh = sc[1]
        val hits = r.hud.musicHits()
        val s = r.hud.scalePx()
        val iconCx = if (hits != null) (hits[0].left + hits[0].right) / 2f * s else 40f * s
        val p = MusicPanel(this)
        val pad = (8 * dm.density).toInt()
        val gap = (2 * dm.density).toInt()
        val pw = maxOf(r.width, (200 * dm.density).toInt()).coerceAtMost(sw - 2 * pad)
        val minH = (130 * dm.density).toInt()
        val spaceBelow = sh - (lp.y + r.height) - pad
        val spaceAbove = lp.y - pad
        // where does it go? below the status, above it, or beside it (never on top of it)
        var mode = 0   // 0 below, 1 above, 2 right, 3 left
        p.side = false
        p.showPlaylists()
        var ph = p.desiredHeight()
        if (spaceBelow >= ph) mode = 0
        else if (spaceAbove >= ph) mode = 1
        else if (lp.x + r.width + pad + pw <= sw) { mode = 2 }
        else if (lp.x - pad - pw >= 0) { mode = 3 }
        else if (spaceBelow >= spaceAbove) { mode = 0; ph = maxOf(minH, spaceBelow) }
        else { mode = 1; ph = maxOf(minH, spaceAbove) }
        val side = mode >= 2
        p.side = side
        if (side) { p.showPlaylists(); ph = minOf(p.desiredHeight(), sh - 2 * pad) }
        val below = mode == 0
        p.wireOnTop = below
        p.showPlaylists()
        p.onPick = { id, i -> Music.playIn(c, id, i); hidePanel() }
        p.onResize = { h -> resizePanel(h) }
        panelMode = mode
        panelMax = when (mode) { 0 -> maxOf(minH, spaceBelow); 1 -> maxOf(minH, spaceAbove); else -> sh - 2 * pad }
        p.onOutside = { hidePanel() }
        val l = WindowManager.LayoutParams(
            pw, ph, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        when (mode) {
            0 -> { l.x = lp.x.coerceIn(0, maxOf(0, sw - pw)); l.y = lp.y + r.height - gap }
            1 -> { l.x = lp.x.coerceIn(0, maxOf(0, sw - pw)); l.y = lp.y - ph + gap }
            2 -> { l.x = lp.x + r.width + pad / 2; l.y = lp.y.coerceIn(pad, maxOf(pad, sh - ph - pad)) }
            else -> { l.x = lp.x - pw - pad / 2; l.y = lp.y.coerceIn(pad, maxOf(pad, sh - ph - pad)) }
        }
        p.wireX = (iconCx + (lp.x - l.x)).coerceIn(12f * dm.density, pw - 12f * dm.density)
        panelSide = side
        p.alpha = 0f
        if (side) {
            p.scaleX = 0.85f
            p.pivotX = if (mode == 2) 0f else pw.toFloat()
            p.pivotY = ph / 2f
        } else {
            p.scaleY = 0.85f
            p.pivotX = p.wireX
            p.pivotY = if (below) 0f else ph.toFloat()
        }
        try {
            wm.addView(p, l)
            panel = p
            panelLp = l
            Music.panelOpen = true
            val an = p.animate().alpha(1f).setDuration(220)
            if (side) an.scaleX(1f) else an.scaleY(1f)
            an.start()
            r.hud.poke()
        } catch (t: Throwable) { }
    }

    /** The box switched between playlists and songs: resize it and keep it attached to the status. */
    private fun resizePanel(want: Int) {
        val p = panel ?: return
        val l = panelLp ?: return
        val r = root ?: return
        val dm = Resources.getSystem().displayMetrics
        val sh = screen()[1]
        val pad = (8 * dm.density).toInt()
        val gap = (2 * dm.density).toInt()
        val h = want.coerceAtMost(maxOf(panelMax, (100 * dm.density).toInt()))
        l.height = h
        when (panelMode) {
            1 -> { l.y = lp.y - h + gap; p.pivotY = h.toFloat() }
            2, 3 -> { l.y = lp.y.coerceIn(pad, maxOf(pad, sh - h - pad)); p.pivotY = h / 2f }
            else -> l.y = lp.y + r.height - gap
        }
        try { wm.updateViewLayout(p, l) } catch (t: Throwable) { }
    }

    private fun spot(name: String, rect: Rect?, onTap: () -> Unit) {
        val old = spots[name]
        if (rect == null || rect.width() <= 0 || rect.height() <= 0) {
            if (old != null) { try { wm.removeView(old.v) } catch (t: Throwable) { }; spots.remove(name) }
            return
        }
        val sc = screen()
        val x = (lp.x + rect.left).coerceIn(0, maxOf(0, sc[0] - rect.width()))
        val y = (lp.y + rect.top).coerceIn(0, maxOf(0, sc[1] - rect.height()))
        if (old != null) {
            if (old.lp.x == x && old.lp.y == y && old.lp.width == rect.width() && old.lp.height == rect.height()) return
            old.lp.x = x; old.lp.y = y; old.lp.width = rect.width(); old.lp.height = rect.height()
            try { wm.updateViewLayout(old.v, old.lp) } catch (t: Throwable) { }
            return
        }
        val v = TapSpot(this)
        v.onTap = onTap
        val l = WindowManager.LayoutParams(rect.width(), rect.height(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, BASE_FLAGS, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        l.x = x; l.y = y
        try {
            wm.addView(v, l)
            spots[name] = Spot(v, l)
        } catch (t: Throwable) { }
    }

    private fun clearSpots() {
        for (sp in spots.values) { try { wm.removeView(sp.v) } catch (t: Throwable) { } }
        spots.clear()
    }

    // ---------- auto mode: driven by "which app is in front" events (Accessibility), no timers ----------

    // main thread only
    private var curGame: String? = null
    private var lastGame: String? = null
    private var rawFront: String? = null
    private var needShizuku = false
    private var boostPending = false      // Shizuku was off at game start: boost as soon as it is on and you are in the game
    private var boostedThisSession = false
    private var chipKind = 0              // 0 none, 1 "Shizuku is off", 2 "go back to the game"
    private var banner: BoostMini? = null
    private var chip: HudChip? = null
    private var badge: GameBadge? = null
    private var badgePkg: String? = null
    private var badgeLp: WindowManager.LayoutParams? = null

    // worker thread only
    private var gameSet: Set<String> = emptySet()
    private var gameNames: Map<String, String> = emptyMap()
    private var gameSetAt = 0L
    private var lastPoll = 0L
    private var polled: String? = null
    private var homePkgs: Set<String>? = null

    private fun homePackages(): Set<String> {
        homePkgs?.let { return it }
        val s = HashSet<String>()
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            for (r in packageManager.queryIntentActivities(i, 0)) s.add(r.activityInfo.packageName)
        } catch (t: Throwable) { }
        s.add("com.transsion.XOSLauncher")
        homePkgs = s
        return s
    }

    private fun imePackage(): String? = try {
        val v = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        if (v == null) null else ComponentName.unflattenFromString(v)?.packageName
    } catch (t: Throwable) { null }

    /** Windows that are not "an app came to the front": system bars, permission popups, the keyboard, our own overlay. */
    private fun realFront(pkg: String, cls: String?): Boolean {
        if (pkg == "android" || pkg == "com.android.systemui" || pkg.contains("permissioncontroller")) return false
        if (cls != null && (cls.startsWith("android.") || cls.startsWith("androidx."))) return false
        if (pkg == packageName) return cls == null || cls.endsWith("Activity")
        if (pkg == imePackage()) return false
        return true
    }

    /** Any thread: an app window came to the front. */
    private fun postFront(pkg: String, cls: String?) {
        val h = wh ?: return
        h.post {
            try {
                if (!realFront(pkg, cls)) return@post
                val now = SystemClock.elapsedRealtime()
                if (now - gameSetAt > 30_000L || gameSet.isEmpty()) {
                    val g = Games.detect(applicationContext)
                    gameSet = g.map { it.pkg }.toSet()
                    gameNames = g.associate { it.pkg to it.name }
                    gameSetAt = now
                }
                val isGame = pkg in gameSet
                val isHome = !isGame && pkg in homePackages() && !(cls ?: "").contains("recent", true)
                val name = gameNames[pkg] ?: pkg
                main.post { onFront(pkg, isGame, isHome, name) }
            } catch (t: Throwable) { }
        }
    }

    private fun onFront(pkg: String, isGame: Boolean, isHome: Boolean, name: String) {
        if (rawFront != pkg) AutoLog.note("front: $pkg" + (if (isGame) " (game)" else if (isHome) " (home)" else ""))
        rawFront = pkg
        names[pkg] = name
        if (isGame) {
            if (curGame != pkg) enterGame(pkg) else resumeGame(pkg)
        } else if (isHome) {
            endSession()
        } else {
            applyUi()
        }
    }

    private val names = HashMap<String, String>()
    private var lastData: FpsData? = null
    private var lastSys: SysData? = null
    private var greeted = false
    private var sessionStart = 0L
    private var lastFreed = 0L
    private var lastBoosted = false
    private var nova: NovaView? = null
    private var novaLp: WindowManager.LayoutParams? = null
    private var pendingPl: Playlist? = null
    private var bannerLp: WindowManager.LayoutParams? = null

    private fun enterGame(pkg: String) {
        val c = applicationContext
        if (curGame != null) endSession()
        rawFront = pkg
        curGame = pkg
        lastGame = pkg
        boostedThisSession = false
        greeted = false
        lastFreed = 0L
        lastBoosted = false
        sessionStart = SystemClock.elapsedRealtime()
        nextTalk = sessionStart + 100_000L + (Math.random() * 60_000L).toLong()
        hotAt = 0L; ramAt = 0L; batAt = 0L
        fpsEma = 0f; badStreak = 0; goodStreak = 0; dipSeen = false
        mileDone.clear()
        pendingClean = ""
        val ready = FpsClient.state(c) == FpsClient.St.READY
        needShizuku = !ready
        boostPending = !ready && Prefs.bool(c, Prefs.BO_AUTO, false)
        AutoLog.note("game opened: ${names[pkg] ?: pkg}, shizuku=" + (if (ready) "on" else "off"))
        hideChip(); hideBanner(); hideRecap()
        applyUi()
        if (ready) { if (!startBoost(pkg)) maybeGreet() } else showShizukuChip()
    }

    private fun resumeGame(pkg: String) {
        val c = applicationContext
        applyUi()
        if (needShizuku && FpsClient.state(c) == FpsClient.St.READY) { shizukuChanged(); return }
        if (chipKind == 2) hideChip()
        if (needShizuku && chipKind == 0) showShizukuChip()
        if (boostPending && !needShizuku) { boostPending = false; if (!startBoost(pkg)) maybeGreet() }
    }

    private fun endSession() {
        val c = applicationContext
        val had = curGame != null
        val endedGame = curGame
        curGame = null
        needShizuku = false
        boostPending = false
        boostedThisSession = false
        greeted = false
        hideChip(); hideBanner(); hideNova()
        if (had) {
            AutoLog.note("game closed")
            if (!pinned) Thread {
                try { Tracker.flush(c) } catch (t: Throwable) { }
                try {
                    val last = Games.sessions(c).lastOrNull { it.pkg == endedGame }
                    if (last != null && System.currentTimeMillis() - last.end < 180_000L) {
                        val fresh = Achievements.scan(c).map { it.name }
                        main.post { showRecap(last, fresh) }
                    }
                } catch (t: Throwable) { }
            }.start()
            Boost.autoEnd(c)
        }
        applyUi()
    }

    /** The one place that decides whether the status overlay is up: pinned by hand, or the game is in front. */
    private fun applyUi() {
        val g = curGame
        val gameFront = g != null && rawFront == g
        val want = pinned || gameFront
        if (want && root == null) showOverlay()
        else if (!want && root != null) hideOverlay()
        syncEdge()
        if (!gameFront || root == null) hideNova()
        if (curGame != null && !gameFront) Tracker.pause()
        if (!gameFront) {
            hideBanner()
            if (chipKind == 1) hideChip()
        }
        syncBadge()
        notifyState()
    }

    private var recap: RecapCard? = null

    private fun hideRecap() {
        val v = recap ?: return
        recap = null
        v.animate().alpha(0f).translationY(-dp(12f).toFloat()).setDuration(200).withEndAction {
            try { wm.removeView(v) } catch (t: Throwable) { }
        }.start()
    }

    /** After a match: a small card with the result, shown over whatever you are doing, tap to close. */
    private fun showRecap(sess: Games.Session, badges: List<String>) {
        if (curGame != null || !Prefs.bool(this, Prefs.NOVA_ON, true) && false) return
        hideRecap()
        val c = applicationContext
        val tgt = Games.profTarget(c, sess.pkg).let { if (it > 0) it else Prefs.int(c, Prefs.TARGET, 60) }
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sess.pkg, 0)).toString() } catch (t: Throwable) { sess.pkg }
        val v = RecapCard(this, sess, label, loadIcon(sess.pkg), badges, tgt)
        val l = WindowManager.LayoutParams(dp(RecapCard.WIDTH_DP.toFloat()), dp(RecapCard.heightDp(badges.size).toFloat()),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, BASE_FLAGS, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        edge(l)
        l.y = dp(56f)
        v.onClose = { if (recap === v) hideRecap() }
        try { wm.addView(v, l) } catch (t: Throwable) { return }
        recap = v
        v.alpha = 0f
        v.translationY = -dp(14f).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(260).start()
    }

    private fun startBoost(pkg: String): Boolean {
        val c = applicationContext
        if (boostedThisSession || !Boost.canAuto(c, pkg)) return false
        boostedThisSession = true
        beginBoost(pkg, names[pkg] ?: pkg)
        return true
    }

    /** Main thread: Shizuku came on, went off or changed permission. */
    private fun shizukuChanged() {
        val c = applicationContext
        val g = curGame ?: return
        val st = FpsClient.state(c)
        if (st == FpsClient.St.READY) {
            if (!needShizuku) return
            needShizuku = false
            AutoLog.note("Shizuku is on")
            hideChip()
            if (rawFront == g) {
                if (boostPending) { boostPending = false; if (!startBoost(g)) maybeGreet() } else maybeGreet()
            } else showReturnChip(g, names[g] ?: g)
        } else {
            if (!needShizuku) {
                needShizuku = true
                boostPending = Prefs.bool(c, Prefs.BO_AUTO, false)
                AutoLog.note("Shizuku went off")
            }
            if (rawFront == g) showShizukuChip()
        }
    }

    private val sBinder = Shizuku.OnBinderReceivedListener { main.post { shizukuChanged() } }
    private val sDead = Shizuku.OnBinderDeadListener { main.post { shizukuChanged() } }
    private val sPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> main.post { shizukuChanged() } }

    /** Backup when Accessibility is off: ask Android's usage events about twice a second. */
    private fun pollUsage(c: Context, force: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastPoll < 900L) return
        lastPoll = now
        val fg = ForegroundApp.top(c) ?: return
        if (fg != polled) { polled = fg; postFront(fg, null) }
    }

    // ---------- windows: boost banner, chips, game badge (main thread) ----------

    private fun loadIcon(pkg: String): android.graphics.drawable.Drawable? =
        try { packageManager.getApplicationIcon(pkg) } catch (t: Throwable) { null }

    /** Sits below the top edge of the screen so it never competes with the system swipe-down area. */
    private fun topWindow(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        val l = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            if (touchable) BASE_FLAGS else BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        edge(l)
        l.y = dp(56f)
        return l
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private class Plc(val x: Int, val y: Int, val side: Int, val ptr: Float)

    /**
     * Finds a spot for a window that touches the status overlay: below it, above it, or beside it, whichever fits.
     * side tells the window where the overlay is (0 above it, 1 below it, 2 left of it, 3 right of it).
     */
    private fun place(sizeOf: (Int) -> IntArray): Plc? {
        val r = root ?: return null
        val rw = r.width
        val rh = r.height
        if (rw <= 0 || rh <= 0) return null
        val sc = screen()
        for (side in 0..3) {
            val m = sizeOf(side)
            val w = m[0]
            val h = m[1]
            when (side) {
                0 -> if (lp.y + rh + h <= sc[1]) {
                    val x = lp.x.coerceIn(0, maxOf(0, sc[0] - w)); return Plc(x, lp.y + rh, 0, lp.x + rw / 2f - x)
                }
                1 -> if (lp.y - h >= 0) {
                    val x = lp.x.coerceIn(0, maxOf(0, sc[0] - w)); return Plc(x, lp.y - h, 1, lp.x + rw / 2f - x)
                }
                2 -> if (lp.x + rw + w <= sc[0]) {
                    val y = lp.y.coerceIn(0, maxOf(0, sc[1] - h)); return Plc(lp.x + rw, y, 2, lp.y + rh / 2f - y)
                }
                else -> if (lp.x - w >= 0) {
                    val y = lp.y.coerceIn(0, maxOf(0, sc[1] - h)); return Plc(lp.x - w, y, 3, lp.y + rh / 2f - y)
                }
            }
        }
        val m = sizeOf(0)
        val x = lp.x.coerceIn(0, maxOf(0, sc[0] - m[0]))
        return Plc(x, (sc[1] - m[1]).coerceAtLeast(0), 0, lp.x + rw / 2f - x)
    }

    private fun placeBanner(b: BoostMini, l: WindowManager.LayoutParams) {
        val sc = screen()
        val p = place { intArrayOf(l.width, l.height) }
        if (p == null) {
            b.side = -1
            l.x = ((sc[0] - l.width) / 2).coerceAtLeast(0); l.y = dp(56f)
        } else {
            b.side = p.side; b.ptr = p.ptr; l.x = p.x; l.y = p.y
        }
    }

    /** The boost card and Nova's bubble stay attached to the status overlay when it moves, folds or rotates. */
    private fun replaceAttached() {
        val b = banner
        val bl = bannerLp
        if (b != null && bl != null) { placeBanner(b, bl); try { wm.updateViewLayout(b, bl) } catch (t: Throwable) { } }
        nova?.let { it.compact = Prefs.bool(this, Prefs.COLLAPSED, false) }
        placeNova()
    }

    private fun beginBoost(pkg: String, name: String) {
        hideBanner()
        val b = BoostMini(this, loadIcon(pkg), name)
        val l = WindowManager.LayoutParams(
            dp(178f), dp(50f), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        placeBanner(b, l)
        try { wm.addView(b, l) } catch (t: Throwable) { return }
        banner = b
        bannerLp = l
        b.onDismiss = { if (banner === b) { hideBanner(); maybeGreet() } }
        b.alpha = 0f
        b.scaleX = 0.92f
        b.scaleY = 0.92f
        b.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).start()
        val app = applicationContext
        Thread {
            var freed = 0L
            try {
                val r = Boost.run(app, pkg) { t, pr -> main.post { b.setProgress(pr, t) } }
                freed = r.freedMb
                AutoLog.note("boost done: +$freed MB")
            } catch (t: Throwable) {
                AutoLog.note("boost failed: $t")
            }
            main.post { lastFreed = freed; lastBoosted = true; b.finish(freed); edgeV?.sweep(Cy.CYAN) }
        }.start()
    }

    private fun hideBanner() {
        val b = banner ?: return
        banner = null
        bannerLp = null
        b.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(240).withEndAction {
            try { wm.removeView(b) } catch (t: Throwable) { }
        }.start()
    }

    private fun showChip(v: HudChip, kind: Int) {
        hideChip()
        val l = topWindow(dp(320f), dp(58f), true)
        try { wm.addView(v, l) } catch (t: Throwable) { return }
        chip = v
        chipKind = kind
        v.onClose = { if (chip === v) hideChip() }
        v.alpha = 0f
        v.translationY = -dp(20f).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(240).start()
    }

    private fun hideChip() {
        val v = chip ?: return
        chip = null
        chipKind = 0
        v.animate().alpha(0f).translationY(-dp(16f).toFloat()).setDuration(200).withEndAction {
            try { wm.removeView(v) } catch (t: Throwable) { }
        }.start()
    }

    private fun showShizukuChip() {
        val c = applicationContext
        val st = FpsClient.state(c)
        val (title, sub) = when (st) {
            FpsClient.St.NOT_INSTALLED -> Pair("FPS needs Shizuku", "It isn't installed. Tap to open Frameline")
            FpsClient.St.NOT_RUNNING -> Pair("Shizuku is off", "FPS can't be read. Tap to open Shizuku")
            FpsClient.St.NO_PERMISSION -> Pair("Allow Frameline in Shizuku", "Tap to allow, then FPS turns on")
            FpsClient.St.READY -> return
        }
        val v = HudChip(this, title, sub, 0)
        v.onTap = { onShizukuChipTap() }
        showChip(v, 1)
    }

    private fun onShizukuChipTap() {
        when (FpsClient.state(applicationContext)) {
            FpsClient.St.NOT_RUNNING -> openApp(SHIZUKU_PKG)
            FpsClient.St.NO_PERMISSION -> { try { Shizuku.requestPermission(21) } catch (t: Throwable) { } }
            FpsClient.St.NOT_INSTALLED -> {
                try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (t: Throwable) { }
            }
            FpsClient.St.READY -> { }
        }
    }

    private fun showReturnChip(pkg: String, name: String) {
        val v = HudChip(this, "Shizuku is on", "Tap to go back to $name", 1)
        v.onTap = { openApp(pkg); hideChip() }
        showChip(v, 2)
    }

    private fun openApp(pkg: String) {
        try {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        } catch (t: Throwable) {
            android.widget.Toast.makeText(applicationContext, "Could not open it", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Nova: the helper that talks from the status overlay ----------

    private fun novaCtx(): NovaCtx {
        val g = curGame ?: ""
        val sys = lastSys
        val dat = lastData
        return NovaCtx(
            names[g] ?: g, lastFreed, lastBoosted,
            ((SystemClock.elapsedRealtime() - sessionStart) / 60000L).toInt(),
            dat?.fps?.toInt()?.coerceAtLeast(0) ?: 0, sys?.bat ?: -1, sys?.temp?.toInt() ?: 0
        )
    }

    /** One greeting per game session, once the boost is over (or right away when there is no boost). */
    private fun maybeGreet() {
        if (greeted || needShizuku || !Prefs.bool(this, Prefs.NOVA_ON, true)) return
        val g = curGame ?: return
        if (rawFront != g || root == null) return
        greeted = true
        showNova(NovaBrain.greeting(applicationContext, novaCtx()))
    }

    private var chipsView: NovaChipsView? = null
    private var chipsLp: WindowManager.LayoutParams? = null
    private var novaTalk: NovaTalk? = null

    private fun hideChips() {
        val v = chipsView ?: return
        chipsView = null
        chipsLp = null
        try { wm.removeView(v) } catch (t: Throwable) { }
    }

    /** The reply chips float as separate little pills beside the bubble, so the bubble itself stays slim. */
    private fun showChips() {
        val tk = novaTalk ?: return
        val bl = novaLp ?: return
        if (tk.chips.isEmpty() || nova == null) return
        hideChips()
        val v = NovaChipsView(this)
        v.onChip = { id -> hideChips(); onNovaChip(id) }
        v.setItems(tk.chips, maxOf(bl.width, dp(230f)).toFloat())
        val m = v.measure()
        val l = WindowManager.LayoutParams(m[0], m[1], WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, BASE_FLAGS, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        chipsView = v
        chipsLp = l
        placeChips()
        try { wm.addView(v, l) } catch (t: Throwable) { chipsView = null; chipsLp = null }
    }

    private fun placeChips() {
        val v = chipsView ?: return
        val l = chipsLp ?: return
        val bl = novaLp ?: return
        val nv = nova ?: return
        val sc = screen()
        val gap = dp(0f)
        val below = nv.side != 1
        var y = if (below) bl.y + bl.height + gap else bl.y - l.height - gap
        if (y + l.height > sc[1]) y = bl.y - l.height - gap
        if (y < 0) y = (bl.y + bl.height + gap).coerceAtMost(maxOf(0, sc[1] - l.height))
        l.x = bl.x.coerceIn(0, maxOf(0, sc[0] - l.width))
        l.y = y
        try { wm.updateViewLayout(v, l) } catch (t: Throwable) { }
    }

    // things Nova may say while you play (checked from the stats loop, no extra timers)
    private var nextTalk = 0L
    private var hotAt = 0L
    private var ramAt = 0L
    private var batAt = 0L
    private var fpsEma = 0f
    private var badStreak = 0
    private var goodStreak = 0
    private var dipSeen = false
    private val mileDone = HashSet<Int>()
    private var pendingClean = ""
    private var cleanFreed = 0L

    private fun speak(t: NovaTalk) {
        showNova(t)
        val level = Prefs.int(this, Prefs.NOVA_LEVEL, 1)
        val gap = if (level >= 2) 120_000L + (Math.random() * 120_000L).toLong() else 240_000L + (Math.random() * 240_000L).toLong()
        nextTalk = SystemClock.elapsedRealtime() + gap
    }

    private fun novaTick(d: FpsData, s: SysData) {
        if (!Prefs.bool(this, Prefs.NOVA_ON, true)) return
        val g = curGame ?: return
        if (rawFront != g || root == null) return
        if (d.fps > 0f) {
            fpsEma = if (fpsEma == 0f) d.fps else fpsEma * 0.95f + d.fps * 0.05f
            if (fpsEma > 25f && d.fps < fpsEma * 0.6f) { badStreak++; goodStreak = 0; if (badStreak >= 4) dipSeen = true }
            else { goodStreak++; badStreak = 0 }
        }
        if (!greeted || nova != null || chipsView != null || banner != null) return
        val now = SystemClock.elapsedRealtime()
        if (now - sessionStart < 45_000L) return
        val calm = d.fps <= 0f || (badStreak == 0 && goodStreak >= 10)
        if (!calm) return
        val c = applicationContext
        val x = novaCtx()
        // helpful offers, at every talkativeness level
        if (s.temp >= 43f && now - hotAt > 480_000L) { hotAt = now; speak(NovaBrain.hot(c, x)); return }
        if (s.ram >= 0.9f && now - ramAt > 900_000L) { ramAt = now; speak(NovaBrain.ramFull(c, x, (s.ram * 100).toInt())); return }
        if (s.bat in 1..15 && !s.charging && now - batAt > 1_200_000L) { batAt = now; speak(NovaBrain.lowBattery(c, x)); return }
        if (Prefs.int(this, Prefs.NOVA_LEVEL, 1) == 0) return
        for (k in intArrayOf(15, 30, 60, 90, 120)) {
            if (x.minutes >= k && k !in mileDone) {
                for (j in intArrayOf(15, 30, 60, 90, 120)) if (j <= k) mileDone.add(j)
                speak(NovaBrain.milestone(c, x, k)); return
            }
        }
        if (dipSeen) { dipSeen = false; speak(NovaBrain.dipOver(c, x)); return }
        if (now >= nextTalk) speak(NovaBrain.smallTalk(c, x))
    }

    private fun startClean(kind: String) {
        val c = applicationContext
        val v = nova ?: return
        if (FpsClient.state(c) != FpsClient.St.READY) { showNova(NovaBrain.shizukuOff(c)); return }
        hideChips()
        pendingClean = kind
        cleanFreed = 0L
        v.startAction(kind, listOf(if (kind == "cool") "Cooling down" else "Cleaning memory"), true)
        placeNova()
        Thread {
            var freed = 0L
            try { freed = Boost.quickClean(c) { t, pr -> main.post { nova?.setActionProgress(pr, t) } } } catch (t: Throwable) { }
            main.post { cleanFreed = freed; nova?.setActionProgress(1f, "Done") }
        }.start()
    }

    private fun showNova(t: NovaTalk) {
        novaTalk = t
        hideChips()
        var v = nova
        if (v == null) {
            v = NovaView(this)
            v.onTyped = { showChips() }
            v.onExpire = { hideNova() }
            v.onActionDone = { onNovaActionDone() }
            val l = WindowManager.LayoutParams(dp(156f), dp(60f), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
            l.gravity = Gravity.TOP or Gravity.START
            edge(l)
            v.compact = Prefs.bool(this, Prefs.COLLAPSED, false)
            v.say(t)
            val p = place { s -> v.measure(s) } ?: return
            v.side = p.side; v.ptr = p.ptr
            val m = v.measure(p.side)
            l.width = m[0]; l.height = m[1]; l.x = p.x; l.y = p.y
            try { wm.addView(v, l) } catch (e: Throwable) { return }
            nova = v
            novaLp = l
            v.alpha = 0f
            v.scaleX = 0.9f
            v.scaleY = 0.9f
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).start()
            return
        }
        v.compact = Prefs.bool(this, Prefs.COLLAPSED, false)
        v.say(t)
        placeNova()
    }

    private fun placeNova() {
        val v = nova ?: return
        val l = novaLp ?: return
        val p = place { s -> v.measure(s) }
        if (p == null) { hideNova(); return }
        v.side = p.side; v.ptr = p.ptr
        val m = v.measure(p.side)
        l.width = m[0]; l.height = m[1]; l.x = p.x; l.y = p.y
        try { wm.updateViewLayout(v, l) } catch (t: Throwable) { }
        placeChips()
    }

    private fun hideNova() {
        hideChips()
        val v = nova ?: return
        nova = null
        novaLp = null
        novaTalk = null
        pendingPl = null
        v.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setDuration(180).withEndAction {
            try { wm.removeView(v) } catch (t: Throwable) { }
        }.start()
    }

    private fun onNovaChip(id: String) {
        val c = applicationContext
        if (curGame == null) return
        val x = novaCtx()
        when {
            id == "music" -> musicFlow(x)
            id.startsWith("pl:") -> {
                val pl = Music.playlist(c, id.substring(3))
                if (pl != null) startMusic(pl, x) else showNova(NovaBrain.noPlaylist(c, x))
            }
            id == "ram" || id == "cool" -> startClean(id)
            id.startsWith("mood_") -> showNova(NovaBrain.moodReply(c, id, x))
            id == "skip" -> { Music.next(c); showNova(NovaTalk("Next one coming up.", emptyList(), 1500L)) }
            else -> showNova(NovaBrain.reply(c, id, x))
        }
    }

    private fun musicFlow(x: NovaCtx) {
        val c = applicationContext
        val pls = Music.playlists(c).filter { it.files.isNotEmpty() }
        when (pls.size) {
            0 -> showNova(NovaBrain.noPlaylist(c, x))
            1 -> startMusic(pls[0], x)
            else -> {
                val last = Prefs.str(c, "nova_pl_last", "")
                val ordered = pls.sortedBy { if (it.id == last) 0 else 1 }
                showNova(NovaBrain.askPlaylist(c, ordered.map { Pair(it.id, (if (it.id == last) "\u2605 " else "") + it.name.take(14)) }, x))
            }
        }
    }

    private fun startMusic(pl: Playlist, x: NovaCtx) {
        val c = applicationContext
        Prefs.putInt(c, "nova_music_yes", Prefs.int(c, "nova_music_yes", 0) + 1)
        Prefs.putStr(c, "nova_pl_last", pl.id)
        pendingPl = pl
        val v = nova ?: return
        hideChips()
        v.startAction("music", listOf(NovaBrain.musicStart(c, pl.name).trimEnd('.'), "Loading " + pl.name.take(16), "Now playing"))
        placeNova()
    }

    private fun onNovaActionDone() {
        if (pendingClean.isNotEmpty()) {
            val k = pendingClean
            pendingClean = ""
            showNova(NovaBrain.cleaned(applicationContext, novaCtx(), cleanFreed, k == "cool"))
            return
        }
        val pl = pendingPl ?: return
        pendingPl = null
        val c = applicationContext
        try { Music.playIn(c, pl.id, 0) } catch (t: Throwable) { }
        showNova(NovaBrain.musicDone(c, pl.name, novaCtx()))
    }

    /** The icon of the game being played, pinned beside the corner of the status overlay. Only while the game is in front. */
    private fun syncBadge() {
        val r = root
        val g = curGame
        if (r == null || g == null || rawFront != g || !Prefs.bool(this, Prefs.OV_ICON, true)) { hideBadge(); return }
        val size = dp(30f)
        val gap = dp(4f)
        val sc = screen()
        var x = lp.x - size - gap
        var y = lp.y
        if (x < 0) { x = lp.x; y = lp.y - size - gap }
        if (y < 0) { x = lp.x + r.width + gap; y = lp.y }
        x = x.coerceIn(0, maxOf(0, sc[0] - size))
        y = y.coerceIn(0, maxOf(0, sc[1] - size))
        val b = badge
        if (b != null && badgePkg == g) {
            val l = badgeLp
            if (l != null && (l.x != x || l.y != y)) {
                l.x = x; l.y = y
                try { wm.updateViewLayout(b, l) } catch (t: Throwable) { }
            }
            return
        }
        hideBadge()
        val v = GameBadge(this, loadIcon(g))
        val l = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        l.x = x; l.y = y
        l.alpha = lp.alpha
        try {
            wm.addView(v, l)
            badge = v; badgeLp = l; badgePkg = g
        } catch (t: Throwable) { }
    }

    private fun hideBadge() {
        val b = badge ?: return
        badge = null; badgeLp = null; badgePkg = null
        try { wm.removeView(b) } catch (t: Throwable) { }
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Overlay watch", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val lock = PendingIntent.getService(
            this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_TOGGLE_LOCK), PendingIntent.FLAG_IMMUTABLE
        )
        val snd = PendingIntent.getService(
            this, 3, Intent(this, OverlayService::class.java).setAction(ACTION_TOGGLE_SOUND), PendingIntent.FLAG_IMMUTABLE
        )
        val locked = Prefs.bool(this, Prefs.LOCKED, false)
        val soundOn = Prefs.bool(this, Prefs.SOUND, false)
        val hasVideo = Prefs.str(this, Prefs.MEDIA_TYPE, "") == "video"
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(if (shown) "Frameline is running" else "Frameline is watching for games")
            .setContentText(
                if (!shown) "Auto mode: open a game and the status shows up."
                else if (locked) "Locked - touches pass through to the game." else "Unlocked - drag the overlay anywhere."
            )
            .setContentIntent(open)
            .setOngoing(true)

        b.addAction(Notification.Action.Builder(icon, "Stop", stop).build())
        return b.build()
    }
}

/** Invisible touch area. Sits over an icon of a locked overlay so only that spot catches taps. */
class TapSpot(ctx: Context) : View(ctx) {
    var onTap: (() -> Unit)? = null

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}

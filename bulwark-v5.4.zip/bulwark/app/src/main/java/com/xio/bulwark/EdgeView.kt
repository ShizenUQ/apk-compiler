package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * A thin neon frame around the whole screen. It never takes touches.
 * Three looks: 0 Circuit (cut corners), 1 Pulse (soft glow), 2 Ticks (dashed ruler).
 * Top edge = FPS bar, bottom edge = session segments, right edge = heat, left edge = battery.
 */
class EdgeView(private val ctx: Context) : View(ctx) {

    var demo = false

    private val d = resources.displayMetrics.density
    private var style = 0
    private var thick = 2f
    private var bright = 0.85f
    private var showFps = true
    private var showTime = true
    private var showSides = true
    private var showRead = false
    private var corner = 2
    private var fxOn = true
    private var lowPower = false
    private var targetFps = 60

    private var data = FpsData.na("NOLINK")
    private var sys: SysData? = null
    private var dispFps = 0f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val frame = Path()
    private val tmp = Path()
    private val seg = Path()
    private val pm = PathMeasure()
    private val rf = RectF()
    private var perim = 0f
    private var cut = 16f

    private var sweepStart = -1L
    private var sweepCol = Cy.CYAN
    private var badUntil = 0L
    private var wasBad = false
    private var lastHour = -1
    private var running = false
    private var lastT = 0L

    private val tk = Runnable { step() }

    fun applyPrefs() {
        style = Prefs.int(ctx, Prefs.EDGE_STYLE, 0).coerceIn(0, 2)
        thick = Prefs.int(ctx, Prefs.EDGE_THICK, 2).coerceIn(1, 6).toFloat()
        bright = Prefs.int(ctx, Prefs.EDGE_BRIGHT, 85).coerceIn(20, 100) / 100f
        showFps = Prefs.bool(ctx, Prefs.EDGE_FPS, true)
        showTime = Prefs.bool(ctx, Prefs.EDGE_TIME, true)
        showSides = Prefs.bool(ctx, Prefs.EDGE_SIDES, true)
        showRead = Prefs.bool(ctx, Prefs.EDGE_READ, false)
        corner = Prefs.int(ctx, Prefs.EDGE_CORNER, 2).coerceIn(0, 3)
        fxOn = Prefs.bool(ctx, Prefs.EDGE_FX, true)
        lowPower = Prefs.bool(ctx, Prefs.EDGE_LOW, false)
        targetFps = Prefs.int(ctx, Prefs.TARGET, 60)
        if (width > 0) buildFrame(width.toFloat(), height.toFloat())
        kick()
        invalidate()
    }

    fun update(f: FpsData, s: SysData) {
        data = f
        sys = s
        val now = SystemClock.uptimeMillis()
        val bad = f.status == "OK" && f.fps >= 0f && f.fps < targetFps * 0.7f
        if (bad && !wasBad && fxOn) badUntil = now + 900
        wasBad = bad
        val secs = sessionSecs(s.session)
        val hr = (secs / 3600L).toInt()
        if (!demo && lastHour >= 0 && hr > lastHour && fxOn) sweep(Cy.PINK)
        lastHour = hr
        kick()
        invalidate()
    }

    /** One bright streak runs around the whole frame. */
    fun sweep(color: Int) {
        if (!fxOn) return
        sweepStart = SystemClock.uptimeMillis()
        sweepCol = color
        kick()
    }

    private fun sessionSecs(s: String): Long {
        val q = s.split(":")
        return try { if (q.size == 3) q[0].toLong() * 3600 + q[1].toLong() * 60 + q[2].toLong() else 0L } catch (t: Throwable) { 0L }
    }

    // ---------- loop ----------

    private fun ambient() = !lowPower && fxOn && style == 1
    private fun hot() = (sys?.temp ?: 0f) >= 43f
    private fun batLow() = sys?.let { it.bat in 0..15 && !it.charging } ?: false

    private fun animating(now: Long): Boolean =
        sweepStart >= 0 || now < badUntil || ambient() || (fxOn && (hot() || batLow())) ||
            (data.fps >= 0f && kotlin.math.abs(dispFps - data.fps) > 0.05f)

    private fun kick() {
        if (!running && isAttachedToWindow) {
            running = true
            lastT = SystemClock.uptimeMillis()
            postOnAnimation(tk)
        }
    }

    private fun step() {
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastT).coerceIn(1L, 80L).toFloat()
        lastT = now
        if (data.fps >= 0f) {
            val diff = data.fps - dispFps
            dispFps = if (kotlin.math.abs(diff) < 0.3f) data.fps else dispFps + diff * min(1f, dt / 140f)
        } else dispFps = 0f
        if (sweepStart >= 0 && now - sweepStart > 1000) sweepStart = -1
        invalidate()
        if (animating(now)) postDelayed(tk, if (lowPower) 70L else 33L) else running = false
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastHour = -1
        kick()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tk)
        running = false
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        buildFrame(w.toFloat(), h.toFloat())
    }

    // ---------- geometry ----------

    private fun inset() = d * 2f + thick * d / 2f

    private fun cutPx(): Float = when (style) { 0 -> 16f * d; 2 -> 12f * d; else -> 0f }

    private fun buildFrame(w: Float, h: Float) {
        val i = inset()
        frame.reset()
        if (style == 1) {
            rf.set(i, i, w - i, h - i)
            val r = min(26f * d, min(w, h) / 4f)
            frame.addRoundRect(rf, r, r, Path.Direction.CW)
        } else {
            val c = cutPx()
            frame.moveTo(i + c, i); frame.lineTo(w - i - c, i); frame.lineTo(w - i, i + c)
            frame.lineTo(w - i, h - i - c); frame.lineTo(w - i - c, h - i); frame.lineTo(i + c, h - i)
            frame.lineTo(i, h - i - c); frame.lineTo(i, i + c); frame.close()
        }
        pm.setPath(frame, true)
        perim = pm.length
    }

    // ---------- colours ----------

    private fun accent(): Int {
        if (data.fps < 0f) return Cy.CYAN
        val r = data.fps / targetFps
        return if (r >= 0.9f) P.GOOD else if (r >= 0.7f) P.MID else P.BAD
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val r = ((a shr 16 and 255) * (1 - k) + (b shr 16 and 255) * k).toInt()
        val g = ((a shr 8 and 255) * (1 - k) + (b shr 8 and 255) * k).toInt()
        val bl = ((a and 255) * (1 - k) + (b and 255) * k).toInt()
        return 0xFF000000.toInt() or (r shl 16) or (g shl 8) or bl
    }

    private fun al(c: Int, a: Float) = Cy.a(c, (a * bright).coerceIn(0f, 1f))

    // ---------- drawing pieces ----------

    private fun line(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        tmp.reset(); tmp.moveTo(x0, y0); tmp.lineTo(x1, y1)
        c.drawPath(tmp, p)
    }

    /** A fill bar from (x0,y0) toward (x1,y1), frac of the way. */
    private fun bar(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, frac: Float, color: Int) {
        if (frac <= 0.003f) return
        val f = min(1f, frac)
        val ex = x0 + (x1 - x0) * f
        val ey = y0 + (y1 - y0) * f
        val tw = thick * d
        p.style = Paint.Style.STROKE
        when (style) {
            0 -> {
                p.strokeCap = Paint.Cap.BUTT
                p.strokeWidth = tw * 3.4f; p.color = al(color, 0.14f); line(c, x0, y0, ex, ey)
                p.strokeWidth = tw * 1.7f; p.color = al(color, 0.95f); line(c, x0, y0, ex, ey)
                p.style = Paint.Style.FILL
                p.color = al(0xFFFFFFFF.toInt(), 0.95f)
                c.drawRect(ex - tw, ey - tw, ex + tw, ey + tw, p)
            }
            1 -> {
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = tw * 4.2f; p.color = al(color, 0.09f); line(c, x0, y0, ex, ey)
                p.strokeWidth = tw * 2.5f; p.color = al(color, 0.2f); line(c, x0, y0, ex, ey)
                p.strokeWidth = tw * 1.4f; p.color = al(color, 0.95f); line(c, x0, y0, ex, ey)
                p.strokeCap = Paint.Cap.BUTT
                p.style = Paint.Style.FILL
                p.color = al(0xFFFFFFFF.toInt(), 0.9f)
                c.drawCircle(ex, ey, tw * 1.1f, p)
            }
            else -> {
                p.strokeCap = Paint.Cap.BUTT
                p.pathEffect = DashPathEffect(floatArrayOf(5f * d, 3.5f * d), 0f)
                p.strokeWidth = tw * 2.2f; p.color = al(color, 0.95f); line(c, x0, y0, ex, ey)
                p.pathEffect = null
            }
        }
        p.style = Paint.Style.STROKE
    }

    /** n separate segments along a line, the first `lit` of them on. */
    private fun segs(c: Canvas, x0: Float, y: Float, x1: Float, n: Int, lit: Float, color: Int, blink: Boolean) {
        val gap = 4f * d
        val sw = (x1 - x0 - gap * (n - 1)) / n
        val tw = thick * d
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            val a = x0 + i * (sw + gap)
            val on = lit - i
            val isOn = on >= 1f || (on > 0f && blink)
            p.color = if (isOn) al(color, 0.95f) else al(Cy.CYAN, 0.16f)
            when (style) {
                0 -> {
                    tmp.reset()
                    tmp.moveTo(a + tw, y - tw * 0.9f); tmp.lineTo(a + sw + tw, y - tw * 0.9f)
                    tmp.lineTo(a + sw, y + tw * 0.9f); tmp.lineTo(a, y + tw * 0.9f); tmp.close()
                    c.drawPath(tmp, p)
                }
                1 -> c.drawCircle(a + sw / 2f, y, tw * (if (isOn) 1.3f else 0.9f), p)
                else -> c.drawRect(a + sw * 0.35f, y - tw * 2f, a + sw * 0.65f, y + tw * 2f, p)
            }
        }
        p.style = Paint.Style.STROKE
    }

    // ---------- main draw ----------

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val now = SystemClock.uptimeMillis()
        val i = inset()
        val cp = cutPx()
        val cr = if (style == 1) min(26f * d, min(w, h) / 4f) else cp
        val tw = thick * d
        val acc = accent()
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.BUTT
        p.pathEffect = null

        // base frame
        when (style) {
            0 -> {
                p.strokeWidth = tw; p.color = al(Cy.CYAN, 0.26f); c.drawPath(frame, p)
                // corner brackets
                p.strokeWidth = tw * 1.5f; p.color = al(Cy.CYAN, 0.95f)
                val ex = 16f * d
                for (k in 0..3) {
                    val sx = if (k == 1 || k == 3) -1f else 1f
                    val sy = if (k >= 2) -1f else 1f
                    val ox = if (sx > 0) i else w - i
                    val oy = if (sy > 0) i else h - i
                    tmp.reset()
                    tmp.moveTo(ox, oy + sy * (cp + ex)); tmp.lineTo(ox, oy + sy * cp)
                    tmp.lineTo(ox + sx * cp, oy); tmp.lineTo(ox + sx * (cp + ex), oy)
                    c.drawPath(tmp, p)
                }
                p.strokeWidth = tw * 1.5f; p.color = al(Cy.PINK, 0.95f)
                line(c, w - i - cp - 34f * d, h - i, w - i - cp - 12f * d, h - i)
            }
            1 -> {
                p.strokeWidth = tw * 4f; p.color = al(Cy.CYAN, 0.05f); c.drawPath(frame, p)
                p.strokeWidth = tw * 2.2f; p.color = al(Cy.CYAN, 0.1f); c.drawPath(frame, p)
                p.strokeWidth = tw; p.color = al(Cy.CYAN, 0.45f); c.drawPath(frame, p)
                if (ambient() && perim > 0f) {
                    val head = ((now % 4200L) / 4200f) * perim
                    runComet(c, head, perim * 0.14f, Cy.CYAN, 0.28f, tw * 1.4f)
                    runComet(c, head, perim * 0.05f, 0xFFFFFFFF.toInt(), 0.85f, tw * 1.8f)
                }
            }
            else -> {
                p.strokeWidth = tw * 1.1f
                p.pathEffect = DashPathEffect(floatArrayOf(5f * d, 3.5f * d), 0f)
                p.color = al(Cy.CYAN, 0.3f)
                c.drawPath(frame, p)
                p.pathEffect = null
                // small corner marks
                p.strokeWidth = tw * 1.6f; p.color = al(Cy.CYAN, 0.9f)
                for (k in 0..3) {
                    val sx = if (k == 1 || k == 3) -1f else 1f
                    val sy = if (k >= 2) -1f else 1f
                    val ox = if (sx > 0) i else w - i
                    val oy = if (sy > 0) i else h - i
                    line(c, ox + sx * cp, oy, ox, oy + sy * cp)
                }
            }
        }

        val x0 = i + cr + 6f * d
        val x1 = w - i - cr - 6f * d

        // top: FPS bar (with a glitch jitter when the frame rate has just crashed)
        if (showFps && data.fps >= 0f && x1 > x0) {
            val frac = (dispFps / targetFps).coerceIn(0f, 1f)
            var jx = 0f
            val glitch = fxOn && now < badUntil
            if (glitch && Cy.rnd((now / 60L).toInt()) < 0.55f) jx = (Cy.rnd((now / 40L).toInt() + 7) - 0.5f) * 8f * d
            c.save()
            c.translate(jx, 0f)
            bar(c, x0, i, x1, i, frac, acc)
            c.restore()
        }

        // bottom: session segments, one per 5 minutes, wraps every hour
        val sy = sys
        if (showTime && sy != null && x1 > x0) {
            val secs = sessionSecs(sy.session)
            val inHour = (secs % 3600L).toFloat() / 300f
            val blink = (now / 500L) % 2L == 0L
            if (fxOn && batLow() && blink) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = tw * 2f; p.color = al(Cy.PINK, 0.9f)
                line(c, x0, h - i, x1, h - i)
            } else {
                segs(c, x0, h - i, x1, 12, inHour, Cy.CYAN, blink)
            }
        }

        // sides: right = heat, left = battery
        if (showSides && sy != null) {
            val yTop = i + cr + 6f * d
            val yBot = h - i - cr - 6f * d
            if (yBot > yTop) {
                if (sy.temp > 0f) {
                    val tf = ((sy.temp - 30f) / 16f).coerceIn(0f, 1f)
                    val col = if (tf < 0.5f) mix(Cy.CYAN, P.MID, tf * 2f) else mix(P.MID, P.BAD, (tf - 0.5f) * 2f)
                    bar(c, w - i, yBot, w - i, yTop, max(0.06f, tf), col)
                }
                if (sy.bat >= 0) {
                    val bf = sy.bat / 100f
                    val col = if (sy.charging) P.GOOD else if (bf > 0.3f) Cy.CYAN else if (bf > 0.15f) P.MID else Cy.PINK
                    bar(c, i, yBot, i, yTop, max(0.04f, bf), col)
                }
            }
        }

        // events
        if (fxOn) {
            if (now < badUntil) {
                val k = (badUntil - now) / 900f
                p.style = Paint.Style.STROKE
                p.strokeWidth = tw * 2.4f
                p.color = al(P.BAD, 0.75f * k)
                c.drawPath(frame, p)
            } else if (hot()) {
                val k = 0.5f + 0.5f * sin(now / 450f)
                p.style = Paint.Style.STROKE
                p.strokeWidth = tw * 2f
                p.color = al(P.MID, 0.12f + 0.3f * k)
                c.drawPath(frame, p)
            }
            if (sweepStart >= 0 && perim > 0f) {
                val e = ((now - sweepStart) / 900f).coerceIn(0f, 1f)
                val head = e * perim * 1.15f
                runComet(c, head, perim * 0.22f, sweepCol, 0.35f, tw * 2.2f)
                runComet(c, head, perim * 0.07f, 0xFFFFFFFF.toInt(), 0.95f, tw * 2.6f)
            }
        }

        if (showRead && sy != null) drawReadout(c, w, h, i, cr, sy)
    }

    /** A bright piece of the frame ending at `head` (distance along the path), `len` long. */
    private fun runComet(c: Canvas, head: Float, len: Float, color: Int, a: Float, sw: Float) {
        if (perim <= 0f) return
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.strokeCap = Paint.Cap.BUTT
        p.color = al(color, a)
        val s = head - len
        seg.reset()
        if (s >= 0f && head <= perim) {
            pm.getSegment(s, head, seg, true)
        } else {
            val hh = ((head % perim) + perim) % perim
            val ss = hh - len
            if (ss >= 0f) pm.getSegment(ss, hh, seg, true)
            else {
                pm.getSegment(0f, hh, seg, true)
                pm.getSegment(perim + ss, perim, seg, true)
            }
        }
        c.drawPath(seg, p)
    }

    private fun drawReadout(c: Canvas, w: Float, h: Float, i: Float, cr: Float, s: SysData) {
        val txt = (if (data.fps >= 0f) dispFps.toInt().toString() + " FPS" else "-- FPS") + "  " + s.session +
            (if (s.temp > 0f) "  " + s.temp.toInt() + "°" else "")
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        p.textSize = 9.5f * d
        val tw = p.measureText(txt)
        val padX = 6f * d
        val bh = 15f * d
        val left = corner == 0 || corner == 2
        val top = corner == 0 || corner == 1
        val bx = if (left) i + cr + 8f * d else w - i - cr - 8f * d - tw - padX * 2
        val by = if (top) i + thick * d * 2f + 6f * d else h - i - thick * d * 2f - 6f * d - bh
        rf.set(bx, by, bx + tw + padX * 2, by + bh)
        p.color = Cy.a(0xFF05080C.toInt(), 0.6f * bright)
        c.drawRoundRect(rf, 3f * d, 3f * d, p)
        p.color = al(0xFFE6EDF3.toInt(), 0.95f)
        p.textAlign = Paint.Align.LEFT
        c.drawText(txt, bx + padX, by + bh * 0.72f, p)
        p.typeface = Typeface.DEFAULT
        p.style = Paint.Style.STROKE
    }
}

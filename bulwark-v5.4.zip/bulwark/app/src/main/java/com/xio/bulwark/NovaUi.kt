package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** The shared look: the same dark chamfered panel, thin edge and pink corner mark as the status overlay. Nothing busy. */
object Glass {
    fun panel(c: Canvas, p: Paint, r: RectF, d: Float, accent: Int) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = 0xEB0A1017.toInt()
        CyUi.drawCut(c, p, r, 7 * d)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = Cy.a(accent, 0.5f)
        CyUi.drawCut(c, p, r, 7 * d)
        p.strokeWidth = 2f * d
        p.strokeCap = Paint.Cap.ROUND
        p.color = Cy.PINK
        c.drawLine(r.left + 1.5f * d, r.top + 11 * d, r.left + 1.5f * d, r.top + 2.5f * d, p)
        c.drawLine(r.left + 1.5f * d, r.top + 2.5f * d, r.left + 10 * d, r.top + 2.5f * d, p)
    }

    /** The small arrow on the edge of a panel that tells where the status overlay is. */
    fun pointer(c: Canvas, p: Paint, path: Path, side: Int, w: Float, h: Float, card: RectF, q: Float, d: Float, accent: Int) {
        p.style = Paint.Style.FILL
        p.color = Cy.a(accent, 0.8f)
        path.reset()
        val a = 4 * d
        when (side) {
            0 -> { path.moveTo(q - a, card.top + d); path.lineTo(q, 0f); path.lineTo(q + a, card.top + d) }
            1 -> { path.moveTo(q - a, card.bottom - d); path.lineTo(q, h); path.lineTo(q + a, card.bottom - d) }
            2 -> { path.moveTo(card.left + d, q - a); path.lineTo(0f, q); path.lineTo(card.left + d, q + a) }
            3 -> { path.moveTo(card.right - d, q - a); path.lineTo(w, q); path.lineTo(card.right - d, q + a) }
            else -> return
        }
        path.close()
        c.drawPath(path, p)
    }
}

private fun medium(): Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
private fun bold(): Typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)

/** Nova's speech bubble: a small, clean panel in the same style as the status overlay, with the line typed out. */
class NovaView(ctx: Context) : View(ctx) {
    var onTyped: (() -> Unit)? = null
    var onExpire: (() -> Unit)? = null
    var onActionDone: (() -> Unit)? = null

    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val path = Path()
    private var talk: NovaTalk? = null
    private var layout: StaticLayout? = null
    private var typedAt = 0L
    private var doneAt = 0L
    private var firedTyped = false
    private var expired = false
    private var running = false

    var compact = false
        set(v) { field = v; relayout() }
    var side = 0           // where the status overlay is: 0 above this bubble, 1 below, 2 left, 3 right
        set(v) { field = v; relayout() }
    var ptr = 0f

    private val m get() = 3 * d
    private val pt get() = 5 * d
    private val cardW get() = (if (compact) 132 else 150) * d
    private val charMs = 22L

    private var actKind = ""
    private var actSteps: List<String> = emptyList()
    private var actAt = 0L
    private var actDone = false
    private val stepMs = 600L

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    fun say(t: NovaTalk) {
        talk = t
        actKind = ""
        typedAt = System.currentTimeMillis()
        doneAt = 0L
        firedTyped = false
        expired = false
        relayout()
    }

    private var actExternal = false
    private var actTarget = 0f
    private var actDisp = 0f
    private var actText = ""

    fun startAction(kind: String, steps: List<String>, external: Boolean = false) {
        actKind = kind
        actSteps = steps
        actAt = System.currentTimeMillis()
        actDone = false
        actExternal = external
        actTarget = 0.05f
        actDisp = 0f
        actText = if (steps.isNotEmpty()) steps[0] else ""
    }

    /** For actions whose real work decides the progress (cleaning memory). */
    fun setActionProgress(pr: Float, text: String) { actTarget = pr; actText = text }

    private fun build(): StaticLayout? {
        val t = talk ?: return null
        tp.typeface = medium()
        tp.textSize = 8.5f * d
        val w = (cardW - 18 * d).toInt().coerceAtLeast(40)
        return StaticLayout.Builder.obtain(t.text, 0, t.text.length, tp, w)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(1.5f * d, 1f).build()
    }

    private fun relayout() { layout = build(); invalidate() }

    /** Window size in px for a given side. */
    fun measure(s: Int): IntArray {
        val w = (cardW + 2 * m + (if (s >= 2) pt else 0f)).toInt()
        val extra = 2 * m + (if (s < 2) pt else 0f)
        if (actKind.isNotEmpty()) return intArrayOf(w, (46 * d + extra).toInt())
        val lh = (layout ?: build())?.height ?: (12 * d).toInt()
        return intArrayOf(w, (8 * d + 9 * d + 3 * d + lh + 8 * d + extra).toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = System.currentTimeMillis()
        val l = m + (if (side == 2) pt else 0f)
        val r = w - m - (if (side == 3) pt else 0f)
        val t = m + (if (side == 0) pt else 0f)
        val b = h - m - (if (side == 1) pt else 0f)
        rr.set(l, t, r, b)
        Glass.panel(c, p, rr, d, Neon.CYAN)
        if (actKind.isNotEmpty()) drawAction(c, l, r, t, b, now) else drawTalk(c, l, t, now)
        val q = ptr.coerceIn(14 * d, (if (side < 2) w else h) - 14 * d)
        rr.set(l, t, r, b)
        Glass.pointer(c, p, path, side, w, h, rr, q, d, Neon.CYAN)
    }

    private fun tag(c: Canvas, x: Float, y: Float) {
        p.style = Paint.Style.FILL
        p.color = Neon.CYAN
        c.drawCircle(x + 2 * d, y - 2.5f * d, 1.8f * d, p)
        p.typeface = bold()
        p.textSize = 6.5f * d
        p.letterSpacing = 0.25f
        p.textAlign = Paint.Align.LEFT
        p.color = Cy.a(Neon.CYAN, 0.9f)
        c.drawText("NOVA", x + 7 * d, y, p)
        p.letterSpacing = 0f
    }

    private fun drawTalk(c: Canvas, l: Float, t: Float, now: Long) {
        val tk = talk ?: return
        val lay = layout ?: return
        tag(c, l + 9 * d, t + 12 * d)
        val typed = ((now - typedAt) / charMs).toInt()
        val ox = l + 9 * d
        val oy = t + 17 * d
        tp.color = 0xFFF2F8FF.toInt()
        for (i in 0 until lay.lineCount) {
            val s = lay.getLineStart(i)
            val e = lay.getLineEnd(i)
            if (typed <= s) break
            c.drawText(tk.text, s, min(typed, e), ox + lay.getLineLeft(i), oy + lay.getLineBaseline(i), tp)
        }
        if (typed >= tk.text.length) {
            if (doneAt == 0L) doneAt = now
            if (!firedTyped) { firedTyped = true; post { onTyped?.invoke() } }
            if (!expired) {
                val hold = if (tk.chips.isEmpty()) tk.holdMs else (if (tk.holdMs < 20_000L) 20_000L else tk.holdMs)
                if (now - doneAt > hold) { expired = true; post { onExpire?.invoke() } }
            }
        } else if ((now / 280) % 2 == 0L) {
            var li = 0
            while (li < lay.lineCount - 1 && lay.getLineEnd(li) <= typed) li++
            val cx = ox + lay.getLineLeft(li) + tp.measureText(tk.text, lay.getLineStart(li), max(lay.getLineStart(li), min(typed, lay.getLineEnd(li))))
            p.style = Paint.Style.FILL
            p.color = Neon.CYAN
            c.drawRect(cx + d, oy + lay.getLineTop(li) + 1.5f * d, cx + 3 * d, oy + lay.getLineBottom(li) - 1.5f * d, p)
        }
    }

    private fun drawAction(c: Canvas, l: Float, r: Float, t: Float, b: Float, now: Long) {
        val el = now - actAt
        val n = max(1, actSteps.size)
        val total = n * stepMs + 400L
        actDisp = min(actTarget, actDisp + 0.015f)
        val prog = if (actExternal) actDisp else (el.toFloat() / total).coerceIn(0f, 1f)
        val step = min(n - 1, (el / stepMs).toInt())
        val label = if (actExternal) actText else actSteps[step]
        val midY = (t + b) / 2f
        if (actKind != "music") { drawClean(c, l, r, t, b, now, prog, label); return }
        // small spinning record
        val cx = l + 22 * d
        val R = 13 * d
        p.style = Paint.Style.FILL
        p.color = 0xFF05080C.toInt()
        c.drawCircle(cx, midY, R, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = Cy.a(Neon.CYAN, 0.25f)
        c.drawCircle(cx, midY, R * 0.7f, p)
        rr.set(cx - R + d, midY - R + d, cx + R - d, midY + R - d)
        p.strokeWidth = 2f * d
        p.strokeCap = Paint.Cap.ROUND
        p.color = Neon.CYAN
        c.drawArc(rr, now / 5f, 55f, false, p)
        p.color = Cy.PINK
        c.drawArc(rr, now / 5f + 180f, 55f, false, p)
        p.style = Paint.Style.FILL
        p.color = Cy.PINK
        c.drawCircle(cx, midY, 3.6f * d, p)
        // current step + equalizer
        val tx = l + 44 * d
        val maxW = r - tx - 8 * d
        tag(c, tx - 2 * d, t + 12 * d)
        p.typeface = medium()
        p.textSize = 8.5f * d
        p.color = 0xFFF2F8FF.toInt()
        p.textAlign = Paint.Align.LEFT
        c.drawText(TextUtils.ellipsize(label, TextPaint(p), maxW, TextUtils.TruncateAt.END).toString(), tx, t + 23 * d, p)
        val bars = 14
        val bw = (maxW - (bars - 1) * 1.6f * d) / bars
        p.style = Paint.Style.FILL
        for (i in 0 until bars) {
            val k = 0.5f + 0.5f * sin(now / 120f + i * 0.8f)
            val bh = (2 + 8 * k) * d * (0.3f + 0.7f * prog)
            p.color = Cy.a(if (i % 4 == 0) Cy.PINK else Neon.CYAN, 0.9f)
            val bx = tx + i * (bw + 1.6f * d)
            c.drawRect(bx, b - 6 * d - bh, bx + bw, b - 6 * d, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.4f * d
        p.color = Cy.a(Neon.GREEN, 0.9f)
        c.drawLine(tx, b - 4 * d, tx + maxW * prog, b - 4 * d, p)
        if (prog >= 1f && !actDone) { actDone = true; post { onActionDone?.invoke() } }
    }

    /** Clearing memory or cooling down: a ring that empties and refills while data is pulled in, with the real step text. */
    private fun drawClean(c: Canvas, l: Float, r: Float, t: Float, b: Float, now: Long, prog: Float, label: String) {
        val cool = actKind == "cool"
        val accent = if (cool) 0xFF6FD3FF.toInt() else Neon.CYAN
        val midY = (t + b) / 2f
        val cx = l + 22 * d
        val R = 13 * d
        rr.set(cx - R, midY - R, cx + R, midY + R)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 2.4f * d
        p.color = Cy.a(accent, 0.2f)
        c.drawArc(rr, 0f, 360f, false, p)
        p.color = accent
        c.drawArc(rr, -90f, 360f * prog, false, p)
        p.strokeWidth = 1.4f * d
        p.color = Cy.a(accent, 0.7f)
        c.drawArc(rr, now / 3f, 40f, false, p)
        p.style = Paint.Style.FILL
        for (i in 0 until 7) {
            val k = ((now / 1000f) * 0.9f + i * 0.143f) % 1f
            val a = (i * 51f + now / 25f) * PI.toFloat() / 180f
            val rad = R + 11 * d * (1f - k)
            p.color = Cy.a(accent, 0.85f * k)
            c.drawCircle(cx + cos(a) * rad, midY + sin(a) * rad, (1.5f - 0.5f * k) * d, p)
        }
        p.typeface = bold()
        p.textSize = 6.5f * d
        p.textAlign = Paint.Align.CENTER
        p.color = accent
        c.drawText((prog * 100).toInt().toString(), cx, midY + 2.4f * d, p)
        val tx = l + 44 * d
        val maxW = r - tx - 8 * d
        tag(c, tx - 2 * d, t + 12 * d)
        p.typeface = medium()
        p.textSize = 8.5f * d
        p.color = 0xFFF2F8FF.toInt()
        p.textAlign = Paint.Align.LEFT
        c.drawText(TextUtils.ellipsize(label, TextPaint(p), maxW, TextUtils.TruncateAt.END).toString(), tx, t + 23 * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * d
        p.color = Cy.a(accent, 0.18f)
        c.drawLine(tx, b - 6 * d, tx + maxW, b - 6 * d, p)
        p.color = if (cool) accent else Neon.GREEN
        c.drawLine(tx, b - 6 * d, tx + maxW * prog, b - 6 * d, p)
        if (actExternal && actTarget >= 1f && actDisp >= 0.995f && !actDone) { actDone = true; post { onActionDone?.invoke() } }
        if (!actExternal && prog >= 1f && !actDone) { actDone = true; post { onActionDone?.invoke() } }
    }
}

/** The tappable replies: small separate pills in one tidy row next to the bubble. */
class NovaChipsView(ctx: Context) : View(ctx) {
    var onChip: ((String) -> Unit)? = null
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private var items: List<NovaChip> = emptyList()
    private var rects: List<RectF> = emptyList()
    private var maxW = 0f
    private var t0 = System.currentTimeMillis()
    private var pressed = -1
    private var running = false
    private val ch = 19 * d

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    private fun textW(i: Int): Float {
        p.typeface = medium()
        p.textSize = 8.5f * d
        return p.measureText(items[i].label)
    }

    fun setItems(list: List<NovaChip>, maxWidthPx: Float) {
        items = list
        maxW = maxWidthPx
        t0 = System.currentTimeMillis()
        pressed = -1
        val out = ArrayList<RectF>()
        var x = 2 * d
        var y = 2 * d
        for (i in items.indices) {
            val w = textW(i) + 18 * d
            if (x > 2 * d && x + w > maxW - 2 * d) { x = 2 * d; y += ch + 4 * d }
            out.add(RectF(x, y, x + w, y + ch))
            x += w + 5 * d
        }
        rects = out
        invalidate()
    }

    fun measure(): IntArray {
        val bottom = rects.maxOfOrNull { it.bottom } ?: ch
        return intArrayOf(maxW.toInt(), (bottom + 2 * d).toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { pressed = hit(e.x, e.y); invalidate() }
            MotionEvent.ACTION_UP -> {
                val h = hit(e.x, e.y)
                pressed = -1
                invalidate()
                if (h >= 0) onChip?.invoke(items[h].id)
            }
            MotionEvent.ACTION_CANCEL -> { pressed = -1; invalidate() }
        }
        return true
    }

    private fun hit(x: Float, y: Float): Int {
        for (i in rects.indices) if (rects[i].contains(x, y)) return i
        return -1
    }

    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis()
        p.typeface = medium()
        p.textSize = 8.5f * d
        p.textAlign = Paint.Align.CENTER
        for (i in items.indices) {
            val k = ((now - t0 - i * 70L) / 220f).coerceIn(0f, 1f)
            if (k <= 0f) continue
            val r0 = rects.getOrNull(i) ?: continue
            val off = (1f - k) * 6 * d
            rr.set(r0.left, r0.top + off, r0.right, r0.bottom + off)
            val quiet = items[i].id.startsWith("bye")
            val col = if (quiet) 0xFF9AA7B4.toInt() else Neon.CYAN
            p.style = Paint.Style.FILL
            p.color = Cy.a(0xFF0A1017.toInt(), 0.92f * k)
            CyUi.drawCut(c, p, rr, 5 * d)
            if (pressed == i) { p.color = Cy.a(col, 0.35f); CyUi.drawCut(c, p, rr, 5 * d) }
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f * d
            p.color = Cy.a(col, 0.75f * k)
            CyUi.drawCut(c, p, rr, 5 * d)
            p.style = Paint.Style.FILL
            p.color = Cy.a(if (quiet) 0xFFCFD8E0.toInt() else 0xFFFFFFFF.toInt(), k)
            c.drawText(items[i].label, rr.centerX(), rr.centerY() + 3 * d, p)
        }
    }
}

/** A small window that shows Boost working: a ring around the game icon pulling data in, then what was freed. */
class BoostMini(ctx: Context, private val icon: Drawable?, @Suppress("unused") private val gameName: String) : View(ctx) {
    var onDismiss: (() -> Unit)? = null
    var side = -1
    var ptr = 0f

    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val path = Path()
    private var target = 0.04f
    private var disp = 0f
    private var stepText = "Starting"
    private var freed = -1L
    private var doneAt = 0L
    private var dismissed = false
    private val t0 = System.currentTimeMillis()
    private var running = false

    fun setProgress(pr: Float, text: String) { target = pr; stepText = text }
    fun finish(freedMb: Long) { target = 1f; freed = freedMb }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onTouchEvent(e: MotionEvent): Boolean = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = System.currentTimeMillis()
        val t = (now - t0) / 1000f
        disp = min(target, disp + 0.012f)
        if (freed >= 0L && disp >= 0.995f && doneAt == 0L) doneAt = now
        val done = doneAt != 0L
        val td = if (done) (now - doneAt) / 1000f else 0f
        if (done && td > 1.8f && !dismissed) { dismissed = true; post { onDismiss?.invoke() } }
        val accent = if (done) Neon.GREEN else Neon.CYAN
        val m = 3 * d
        val pt = 5 * d
        val l = m + (if (side == 2) pt else 0f)
        val r = w - m - (if (side == 3) pt else 0f)
        val top = m + (if (side == 0) pt else 0f)
        val bot = h - m - (if (side == 1) pt else 0f)

        rr.set(l, top, r, bot)
        Glass.panel(c, p, rr, d, accent)
        val cy = (top + bot) / 2f
        val cx = l + 25 * d
        val R = 14 * d
        if (icon != null) {
            val s = 18 * d
            c.save()
            path.reset()
            path.addRoundRect(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, 5 * d, 5 * d, Path.Direction.CW)
            c.clipPath(path)
            icon.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
            icon.draw(c)
            c.restore()
        }
        rr.set(cx - R, cy - R, cx + R, cy + R)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 2.2f * d
        p.color = Cy.a(accent, 0.2f)
        c.drawArc(rr, 0f, 360f, false, p)
        p.color = accent
        c.drawArc(rr, -90f, 360f * disp, false, p)
        if (!done) {
            p.style = Paint.Style.FILL
            for (i in 0 until 8) {
                val k = (t * 0.9f + i * 0.125f) % 1f
                val a = (i * 45f + t * 40f) * PI.toFloat() / 180f
                val rad = R + 12 * d * (1f - k)
                p.color = Cy.a(Neon.CYAN, 0.85f * k)
                c.drawCircle(cx + cos(a) * rad, cy + sin(a) * rad, (1.6f - 0.5f * k) * d, p)
            }
        } else {
            val s = td / 0.7f
            if (s in 0f..1f) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f * d * (1f - s)
                p.color = Cy.a(Neon.GREEN, 0.8f * (1f - s))
                c.drawCircle(cx, cy, R * (1f + 0.7f * s), p)
            }
        }
        val tx = cx + R + 11 * d
        val maxW = r - tx - 9 * d
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = bold()
        p.textSize = 6.5f * d
        p.letterSpacing = 0.25f
        p.color = Cy.a(accent, 0.95f)
        c.drawText(if (done) "READY" else "BOOST", tx, top + 12 * d, p)
        p.letterSpacing = 0f
        p.typeface = medium()
        if (!done) {
            p.textSize = 8.5f * d
            p.color = 0xFFF2F8FF.toInt()
            c.drawText(TextUtils.ellipsize(stepText, TextPaint(p), maxW, TextUtils.TruncateAt.END).toString(), tx, cy + 5 * d, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * d
            p.color = Cy.a(Neon.CYAN, 0.18f)
            c.drawLine(tx, bot - 6 * d, tx + maxW, bot - 6 * d, p)
            if (disp > 0.01f) {
                p.shader = LinearGradient(tx, 0f, tx + maxW, 0f, Neon.CYAN, Neon.GREEN, Shader.TileMode.CLAMP)
                c.drawLine(tx, bot - 6 * d, tx + maxW * disp, bot - 6 * d, p)
                p.shader = null
            }
        } else if (freed > 0L) {
            val k = (td / 0.8f).coerceIn(0f, 1f)
            val v = (freed * (1f - (1f - k) * (1f - k) * (1f - k))).toLong()
            p.typeface = bold()
            p.textSize = 14f * d
            p.color = Neon.GREEN
            c.drawText("+$v MB", tx, cy + 8 * d, p)
            p.typeface = medium()
            p.textSize = 7f * d
            p.color = 0xFF9AA7B4.toInt()
            c.drawText("memory freed", tx, bot - 5 * d, p)
        } else {
            p.typeface = bold()
            p.textSize = 11f * d
            p.color = Neon.GREEN
            c.drawText("RAM is clean", tx, cy + 6 * d, p)
            p.typeface = medium()
            p.textSize = 7f * d
            p.color = 0xFF9AA7B4.toInt()
            c.drawText("nothing to free", tx, bot - 5 * d, p)
        }
        val q = ptr.coerceIn(14 * d, (if (side < 2) w else h) - 14 * d)
        rr.set(l, top, r, bot)
        Glass.pointer(c, p, path, side, w, h, rr, q, d, accent)
    }
}

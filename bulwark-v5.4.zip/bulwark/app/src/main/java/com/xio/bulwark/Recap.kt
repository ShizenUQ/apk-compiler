package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** What you see for a few seconds after a match ends: time, FPS, heat, battery, the FPS wave and any new badges. */
class RecapCard(
    ctx: Context,
    private val s: Games.Session,
    private val name: String,
    private val icon: Drawable?,
    private val badges: List<String>,
    private val target: Int
) : View(ctx) {
    var onClose: (() -> Unit)? = null

    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val path = Path()
    private val born = System.currentTimeMillis()
    private var closed = false
    private var running = false
    private val m = 3 * d

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    private fun fire() { if (!closed) { closed = true; onClose?.invoke() } }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) post { fire() }
        return true
    }

    private fun verdict(): Pair<String, Int> {
        val r = if (target > 0) s.avgFps / target else 1f
        return when {
            s.avgFps <= 0f -> Pair("NO FPS DATA", 0xFF9AA7B4.toInt())
            r >= 0.9f -> Pair("SMOOTH", Neon.GREEN)
            r >= 0.7f -> Pair("DECENT", 0xFFFFC857.toInt())
            else -> Pair("ROUGH", 0xFFFF5C5C.toInt())
        }
    }

    companion object {
        fun heightDp(badges: Int) = 148 + 16 * min(badges, 2)
        const val WIDTH_DP = 236
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = System.currentTimeMillis()
        val age = (now - born) / 1000f
        if (age > 11f) post { fire() }
        val (vt, vc) = verdict()
        rr.set(m, m, w - m, h - m)
        Glass.panel(c, p, rr, d, Neon.CYAN)
        val l = rr.left + 12 * d
        val r = rr.right - 12 * d
        var y = rr.top + 14 * d

        // header: tag, icon, game
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 6.5f * d
        p.letterSpacing = 0.25f
        p.color = Cy.a(Neon.CYAN, 0.9f)
        c.drawText("MATCH RECAP", l, y, p)
        p.letterSpacing = 0f
        p.textAlign = Paint.Align.RIGHT
        p.color = vc
        c.drawText(vt, r, y, p)
        y += 8 * d
        if (icon != null) {
            val sz = 26 * d
            c.save()
            path.reset()
            path.addRoundRect(l, y, l + sz, y + sz, 7 * d, 7 * d, Path.Direction.CW)
            c.clipPath(path)
            icon.setBounds(l.toInt(), y.toInt(), (l + sz).toInt(), (y + sz).toInt())
            icon.draw(c)
            c.restore()
        }
        val tx = l + (if (icon != null) 34 * d else 0f)
        val tp = TextPaint(p)
        tp.textAlign = Paint.Align.LEFT
        tp.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        tp.textSize = 15f * d
        tp.color = 0xFFFFFFFF.toInt()
        c.drawText(Games.fmt(s.ms), tx, y + 14 * d, tp)
        tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tp.textSize = 8.5f * d
        tp.color = 0xFF9AA7B4.toInt()
        c.drawText(TextUtils.ellipsize(name, tp, r - tx, TextUtils.TruncateAt.END).toString(), tx, y + 25 * d, tp)
        y += 34 * d

        // stat columns
        val labels = arrayOf("AVG FPS", "LOW", "TEMP", "BATTERY")
        val values = arrayOf(
            if (s.avgFps > 0f) s.avgFps.toInt().toString() else "--",
            if (s.low > 0f) s.low.toInt().toString() else "--",
            if (s.avgTemp > 0f) s.avgTemp.toInt().toString() + "°" else "--",
            "-" + s.batDrop + "%"
        )
        val cw = (r - l) / 4f
        for (i in 0 until 4) {
            val x = l + i * cw
            p.textAlign = Paint.Align.LEFT
            p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            p.textSize = 6f * d
            p.letterSpacing = 0.15f
            p.color = 0xFF7B8794.toInt()
            c.drawText(labels[i], x, y, p)
            p.letterSpacing = 0f
            p.textSize = 12f * d
            p.color = 0xFFF2F8FF.toInt()
            c.drawText(values[i], x, y + 14 * d, p)
        }
        y += 22 * d

        // FPS wave
        val w0 = s.wave
        val gx0 = l
        val gx1 = r
        val gy0 = y
        val gy1 = y + 26 * d
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = 0x14FFFFFF
        c.drawLine(gx0, gy1, gx1, gy1, p)
        if (w0.size >= 2) {
            val mx = max(w0.maxOrNull() ?: 1f, target.toFloat())
            val shown = min(w0.size, max(2, ((age / 0.9f) * w0.size).toInt()))
            path.reset()
            for (i in 0 until shown) {
                val x = gx0 + (gx1 - gx0) * i / (w0.size - 1f)
                val yy = gy1 - (gy1 - gy0) * (w0[i] / mx).coerceIn(0f, 1f)
                if (i == 0) path.moveTo(x, yy) else path.lineTo(x, yy)
            }
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            p.strokeWidth = 3f * d
            p.color = Cy.a(vc, 0.18f)
            c.drawPath(path, p)
            p.strokeWidth = 1.5f * d
            p.color = vc
            c.drawPath(path, p)
        }
        y = gy1 + 10 * d

        // new badges
        for (b in badges.take(2)) {
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.LEFT
            p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            p.textSize = 6f * d
            p.letterSpacing = 0.15f
            p.color = Cy.PINK
            c.drawText("UNLOCKED", l, y + 5 * d, p)
            p.letterSpacing = 0f
            p.textSize = 9f * d
            p.color = 0xFFFFFFFF.toInt()
            c.drawText(b, l + 42 * d, y + 5.5f * d, p)
            y += 16 * d
        }
    }
}

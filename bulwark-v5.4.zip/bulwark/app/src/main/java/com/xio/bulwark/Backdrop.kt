package com.xio.bulwark

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/** Optional picture behind every screen of the app. The picked image is copied and shrunk, so it survives the original being moved. */
object Backdrop {
    @Volatile var version = 0
        private set
    private var bmp: Bitmap? = null
    private var loadedVer = -1

    private fun file(c: Context) = File(c.filesDir, "backdrop.jpg")

    fun has(c: Context): Boolean = file(c).exists()

    /** How dark the picture is covered, 20..85 (percent). */
    fun dim(c: Context): Int = ((100 - clarity(c)) * 0.8f).toInt()

    /** How clearly the picture shows, 0..100 (100 = no cover at all). Default is nearly clear. */
    fun clarity(c: Context): Int = Prefs.int(c, "bg_clarity", 85).coerceIn(0, 100)
    fun setClarity(c: Context, v: Int) { Prefs.putInt(c, "bg_clarity", v.coerceIn(0, 100)); version++ }

    /** The picture, or null when none is chosen. Loaded once and kept. */
    @Synchronized
    fun bitmap(c: Context): Bitmap? {
        if (loadedVer == version) return bmp
        loadedVer = version
        bmp = try {
            val f = file(c)
            if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
        } catch (t: Throwable) { null }
        return bmp
    }

    /** Copies the picked image into the app, scaled so its long side is at most 1600 px. Returns false if it could not be read. */
    fun set(c: Context, uri: Uri): Boolean {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 1600) sample *= 2
            val o = BitmapFactory.Options()
            o.inSampleSize = sample
            val raw = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return false
            val big = maxOf(raw.width, raw.height)
            val out = if (big > 1600) {
                val k = 1600f / big
                Bitmap.createScaledBitmap(raw, (raw.width * k).toInt().coerceAtLeast(1), (raw.height * k).toInt().coerceAtLeast(1), true)
            } else raw
            val tmp = File(c.filesDir, "backdrop.tmp")
            tmp.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            val f = file(c)
            if (f.exists()) f.delete()
            if (!tmp.renameTo(f)) return false
            version++
            return true
        } catch (t: Throwable) {
            return false
        }
    }

    fun clear(c: Context) {
        try { file(c).delete() } catch (t: Throwable) { }
        version++
    }
}

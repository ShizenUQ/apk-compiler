package com.xio.bulwark

import android.content.Context
import java.util.Calendar

/** One thing Nova says: the text, the quick replies for it, and how long it stays when nobody answers. */
class NovaChip(val id: String, val label: String)

class NovaTalk(val text: String, val chips: List<NovaChip>, val holdMs: Long = 2800L)

/** What Nova knows about the moment when she talks. */
class NovaCtx(
    val game: String,
    val freedMb: Long,
    val boosted: Boolean,
    val minutes: Int,
    val fps: Int,
    val bat: Int,
    val temp: Int
) {
    var gapMin = -1L       // minutes since a game was last opened (-1 = never)
    var today = 1          // which game session of the day this is
    var sameGame = false   // same game as last time
}

/**
 * Nova's voice. She is not a fixed script: what she says depends on what is really going on (how long since you last
 * played, how many sessions today, the time, battery, heat, what the boost freed) and she does not always speak.
 * Lines are short and casual, she remembers what she said lately and what you usually choose. All of it is on the
 * phone, no internet.
 */
object NovaBrain {
    private val rnd = java.util.Random()

    private fun recent(c: Context): MutableList<String> =
        Prefs.str(c, "nova_recent", "").split("|").filter { it.isNotEmpty() }.toMutableList()

    private fun pick(c: Context, tag: String, opts: List<String>): String {
        val r = recent(c)
        val fresh = opts.indices.filter { (tag + it) !in r }
        val pool = if (fresh.isEmpty()) opts.indices.toList() else fresh
        val i = pool[rnd.nextInt(pool.size)]
        r.add(tag + i)
        while (r.size > 40) r.removeAt(0)
        Prefs.putStr(c, "nova_recent", r.joinToString("|"))
        return opts[i]
    }

    private fun fill(s: String, x: NovaCtx): String =
        s.replace("{g}", x.game).replace("{mb}", x.freedMb.toString()).replace("{min}", x.minutes.toString())
            .replace("{fps}", x.fps.toString()).replace("{bat}", x.bat.toString()).replace("{t}", x.temp.toString())
            .replace("{n}", x.today.toString())

    private fun hour() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    /** Remembers when a game was last opened and how many sessions happened today. */
    private fun touch(c: Context, x: NovaCtx) {
        val now = System.currentTimeMillis()
        val last = Prefs.str(c, "nova_last_t", "0").toLongOrNull() ?: 0L
        val lastGame = Prefs.str(c, "nova_last_g", "")
        val day = now / 86_400_000L
        val sameDay = (Prefs.str(c, "nova_day", "0").toLongOrNull() ?: 0L) == day
        val n = if (sameDay) Prefs.int(c, "nova_today", 0) + 1 else 1
        x.gapMin = if (last == 0L) -1L else (now - last) / 60_000L
        x.today = n
        x.sameGame = lastGame == x.game
        Prefs.putStr(c, "nova_last_t", now.toString())
        Prefs.putStr(c, "nova_last_g", x.game)
        Prefs.putStr(c, "nova_day", day.toString())
        Prefs.putInt(c, "nova_today", n)
    }

    private val dawn = listOf(
        "Morning, handsome. Early start.", "Up already? Nice.", "Fresh day, handsome. Let's play.", "Morning. Coffee first, or straight in?",
        "First match of the day. Make it a good one."
    )
    private val first = listOf(
        "Hey handsome.", "Welcome back.", "There you are.", "Ready when you are, handsome.", "Evening, handsome. Let's go.", "Good to see you."
    )
    private val again = listOf(
        "Back already? I like it.", "Round {n}, handsome.", "Couldn't stay away, huh.", "Another one. Respect.", "Session {n} today. You're on a roll.",
        "Quick break, handsome. Welcome back."
    )
    private val miss = listOf(
        "Been a while, handsome. Missed you.", "Long time no see. {g} missed you too.", "You're back. I was getting bored.", "Finally. Where've you been?"
    )
    private val late = listOf(
        "It's late, handsome. One game, okay?", "Night owl mode. I'm here.", "Still up? Fine, I'll keep you company.", "The world's asleep. We're not.",
        "Late one. I'll watch the heat for you."
    )
    private val freed = listOf(
        "Freed {mb} MB. {g} should fly.", "{mb} MB lighter. You're set.", "Cleared {mb} MB for you, handsome.", "Swept out {mb} MB. Go get them."
    )
    private val clean = listOf(
        "RAM was already clean. Nice.", "Nothing to clear. You keep it tidy.", "All tuned. Nothing in the way.", "Phone's in great shape, handsome."
    )
    private val lowbat = listOf(
        "Battery's at {bat}%, handsome. Careful.", "Only {bat}% left. Short game?", "{bat}% battery. Maybe plug in soon."
    )
    private val hot = listOf(
        "Phone's already at {t} degrees. I'll keep an eye on it.", "It's warm, {t}°C. Let's not push it.", "{t}°C already. Watching it."
    )
    private val plain = listOf(
        "I'm watching your stats.", "Status is up. Play on.", "I've got your back.", "All set on my side."
    )

    fun greeting(c: Context, x: NovaCtx): NovaTalk {
        touch(c, x)
        val h = hour()
        val night = h >= 23 || h < 5
        val lines = ArrayList<String>()
        // the one thing that matters most right now
        val line = when {
            x.bat in 1..19 -> pick(c, "lb", lowbat)
            x.temp >= 42 -> pick(c, "ht", hot)
            night && rnd.nextInt(3) > 0 -> pick(c, "lt", late)
            x.gapMin > 2880 -> pick(c, "ms", miss)
            x.gapMin in 0..25 && x.today > 1 -> pick(c, "ag", again)
            x.boosted && rnd.nextInt(10) < 6 -> if (x.freedMb > 0) pick(c, "fr", freed) else pick(c, "cl", clean)
            h in 5..10 && x.today == 1 -> pick(c, "dw", dawn)
            x.boosted -> if (x.freedMb > 0) pick(c, "fr", freed) else pick(c, "cl", clean)
            rnd.nextInt(2) == 0 -> pick(c, "fs", first)
            else -> pick(c, "pl", plain)
        }
        lines.add(line)
        // sometimes a second short thought, so two greetings are rarely the same shape
        if (x.boosted && x.freedMb > 0 && line !in freed.map { fill(it, x) } && rnd.nextInt(3) == 0) lines.add(fill(pick(c, "fr", freed), x))
        val text = fill(lines.joinToString(" "), x)

        // how much she wants to talk: sometimes just a line, no buttons
        val roll = rnd.nextInt(100)
        if (roll < 30) return NovaTalk(text, emptyList(), 3200L)
        val musicNo = Prefs.int(c, "nova_music_no", 0)
        val musicYes = Prefs.int(c, "nova_music_yes", 0)
        val list = ArrayList<NovaChip>()
        val wantsMusic = musicNo < musicYes + 3
        if (wantsMusic && roll < 85) list.add(NovaChip("music", listOf("Play music", "Some music?", "Music").random()))
        if (roll % 2 == 0) list.add(listOf(NovaChip("how", "How am I doing?"), NovaChip("joke", "Say something")).random())
        else list.add(NovaChip("go", listOf("Let's go", "Ready", "On it").random()))
        list.add(NovaChip("bye", listOf("Not now", "Later", "Nah").random()))
        return NovaTalk(text, list.take(3))
    }

    fun reply(c: Context, id: String, x: NovaCtx): NovaTalk {
        when (id) {
            "go" -> return NovaTalk(fill(pick(c, "go", listOf(
                "Go get them, handsome.", "I'll stay quiet. Good luck.", "Show them what you've got.", "Locked in. Have fun.",
                "Don't forget to blink.", "Win one for me.", "Go be legendary.", "Right behind you."
            )), x), emptyList(), 1800L)
            "bye" -> {
                val n = Prefs.int(c, "nova_music_no", 0) + 1
                Prefs.putInt(c, "nova_music_no", n)
                val t = if (n == 3) "Okay, I'll stop asking about music." else pick(c, "by", listOf(
                    "No worries.", "Okay, I'm out of your way.", "Got it. Shout if you need me.", "Sure thing.", "I'll be quiet, handsome.", "Fine, fine."
                ))
                return NovaTalk(t, emptyList(), 1500L)
            }
            "bye2" -> return NovaTalk(pick(c, "b2", listOf(
                "No problem.", "Okay, I'll leave it.", "Got it. Say so if it gets worse.", "Fine by me.", "Alright, your call, handsome."
            )), emptyList(), 1500L)
            "thanks" -> return NovaTalk(pick(c, "th", listOf(
                "Anytime, handsome.", "That's what I'm here for.", "Always.", "Now go win.", "Happy to help.", "Don't mention it."
            )), emptyList(), 1500L)
            "how" -> {
                val a = pick(c, "hm", listOf("{min} min in on {g}.", "{min} minutes so far.", "You've played {min} min.", "{min} min on the clock."))
                val b = if (x.fps > 0) pick(c, "hf", listOf(" Holding {fps} FPS.", " {fps} FPS, steady.", " Frames look good at {fps}.")) else ""
                val d = pick(c, "hb", listOf(" Battery {bat}%, {t}°C.", " {t}°C and {bat}% left.", " Phone's at {t}°C, battery {bat}%."))
                return NovaTalk(fill(a + b + d, x), listOf(NovaChip("music", "Play music"), NovaChip("thanks", "Thanks")))
            }
            "joke" -> {
                val a = pick(c, "jk", listOf(
                    "I don't blink, so I never miss a frame.", "If lag was a person, I'd escort it out.", "Somewhere a battery is rooting for you.",
                    "Hydrate. Even legends need water.", "I was going to joke about RAM but I forgot it.", "You're the coolest thing on this phone. Literally, at {t}°C.",
                    "Fun fact: I count every frame. You're doing great.", "Don't tell the other apps, you're my favourite.", "Ping is just anxiety with numbers.",
                    "Your thumbs deserve a trophy.", "I'd high five you but, no hands.", "Sleep is just a loading screen for tomorrow.", "Rule one: never trust a lobby with one bar of signal."
                ))
                return NovaTalk(fill(a, x), listOf(NovaChip("joke", "Another"), NovaChip("music", "Play music"), NovaChip("thanks", "Thanks")))
            }
        }
        return NovaTalk("Anything else?", listOf(NovaChip("bye", "That's all")))
    }

    fun noPlaylist(c: Context, x: NovaCtx) = NovaTalk(pick(c, "np", listOf(
        "No playlist yet. Make one in Frameline > Music.", "I'd love to, but there's no playlist. Add one in Music.", "Nothing to play. Create a playlist in the Music tab."
    )), emptyList(), 3200L)

    fun askPlaylist(c: Context, names: List<Pair<String, String>>, x: NovaCtx): NovaTalk {
        val chips = names.take(4).map { NovaChip("pl:" + it.first, it.second) } + NovaChip("bye", "Not now")
        return NovaTalk(pick(c, "ap", listOf("Which playlist?", "Pick one and I'll start it.", "What are we in the mood for?", "Choose your soundtrack.")), chips, 30_000L)
    }

    fun musicStart(c: Context, name: String): String = pick(c, "ms2", listOf(
        "On it, handsome", "Tuning in", "Coming right up", "Let me set the mood", "Warming up the speakers"
    ))

    fun musicDone(c: Context, name: String, x: NovaCtx): NovaTalk = NovaTalk(pick(c, "md", listOf(
        "Now playing $name.", "$name is on. Turn it up.", "Done. $name, as ordered.", "$name. Enjoy, handsome.", "Your soundtrack is live."
    )), listOf(NovaChip("skip", "Next song"), NovaChip("thanks", "Thanks")), 8000L)

    // ---------- while you play ----------

    private fun lead(c: Context, tag: String, opts: List<String>, chance: Int = 55): String =
        if (rnd.nextInt(100) < chance) pick(c, tag, opts) + " " else ""

    private val hotLead = listOf("Hey,", "Heads up,", "Psst,", "Handsome,", "Quick note,", "Small thing,", "By the way,")
    private val hotCore = listOf(
        "the phone is at {t}°C.", "it's getting warm, {t}°C.", "your phone hit {t}°C.", "I'm reading {t}°C on the back.",
        "things are heating up, {t}°C now.", "{t}°C and climbing.", "it's {t}°C in there.", "the temperature just reached {t}°C."
    )
    private val hotAsk = listOf(
        "Want me to clear the RAM?", "Should I lighten the load?", "I can free some memory, want that?", "Shall I cool things down a bit?",
        "Want me to clean it up?", "I can ease the load if you say so.", "Want a quick clean?", "Should I take care of it?"
    )

    fun hot(c: Context, x: NovaCtx) = NovaTalk(
        fill(lead(c, "hl", hotLead) + pick(c, "hc", hotCore) + " " + pick(c, "ha", hotAsk), x),
        listOf(NovaChip("cool", listOf("Cool it down", "Yes, do it", "Go ahead").random()), NovaChip("bye2", listOf("Not now", "Later", "I'm fine").random())), 30_000L
    )

    private val ramLead = listOf("Hey,", "Heads up,", "Handsome,", "FYI,", "Quick one,", "Noticed something,")
    private val ramCore = listOf(
        "memory is getting full.", "RAM is almost maxed out.", "you're using {ramp}% of your RAM.", "there's not much RAM left.",
        "your RAM is stuffed, {ramp}% used.", "background apps are eating memory."
    )
    private val ramAsk = listOf(
        "Want me to clear it?", "Should I clean it up?", "Shall I free some up?", "Want a quick RAM clean?", "I can sweep it, okay?", "Want me to take care of it?"
    )

    fun ramFull(c: Context, x: NovaCtx, pct: Int) = NovaTalk(
        fill(lead(c, "rl", ramLead) + pick(c, "rc", ramCore) + " " + pick(c, "ra", ramAsk), x).replace("{ramp}", pct.toString()),
        listOf(NovaChip("ram", listOf("Clear RAM", "Yes, clear it", "Do it").random()), NovaChip("bye2", listOf("Not now", "Later", "Skip").random())), 30_000L
    )

    private val batCore = listOf(
        "battery is at {bat}%.", "only {bat}% left.", "you're down to {bat}%.", "battery just dropped to {bat}%.", "{bat}% battery remaining."
    )
    private val batTail = listOf(
        "Maybe plug in soon.", "Keep a charger close.", "This one might be your last match.", "Finish the round and top up.", "I'll keep watching it.", "Don't let it die mid-fight."
    )

    fun lowBattery(c: Context, x: NovaCtx) = NovaTalk(
        fill(lead(c, "bl", listOf("Careful,", "Heads up,", "Handsome,", "Hey,", "Just so you know,")) + pick(c, "bc", batCore) + " " + pick(c, "bt", batTail), x),
        listOf(NovaChip("thanks", listOf("Okay", "Got it", "Thanks").random())), 6000L
    )

    fun milestone(c: Context, x: NovaCtx, min: Int): NovaTalk {
        val core = when {
            min >= 120 -> listOf("{min} minutes in. That's marathon territory.", "Two hours already. Legend.", "{min} min. Your thumbs deserve a medal.")
            min >= 60 -> listOf("One hour of {g}. Hydrate!", "An hour in. Stretch those fingers.", "{min} minutes. Time flies when you're winning.", "That's an hour on {g}. Not bad.")
            min >= 30 -> listOf("Half an hour in, handsome.", "{min} min on {g}. Still going strong?", "30 minutes down. How's the match?", "Half an hour. You're warmed up now.")
            else -> listOf("{min} minutes in. Good pace.", "Quarter of an hour already.", "{min} min. We're just getting started.", "15 minutes in. Feeling it?")
        }
        val chips = if (min >= 60) listOf(NovaChip("music", "Some music?"), NovaChip("thanks", "Thanks")) else emptyList()
        return NovaTalk(fill(pick(c, "mi" + (if (min >= 60) 2 else if (min >= 30) 1 else 0), core), x), chips, 4000L)
    }

    fun dipOver(c: Context, x: NovaCtx) = NovaTalk(fill(pick(c, "dp", listOf(
        "That dip is gone. Smooth again.", "Frames are back to normal.", "Whew, that stutter passed.", "Back to {fps} FPS. Nice.",
        "Lag spike over. I was worried for a sec.", "Steady again at {fps}."
    )), x), emptyList(), 3000L)

    private val mood = listOf(
        "How's the match going?", "Winning or suffering?", "Be honest, how's it going?", "Tell me, are we winning?", "Mood check. How's the game?", "So, how are things in there?"
    )
    private val idle = listOf(
        "{min} minutes in and {fps} FPS. Looking good.", "Your phone is at {t}°C. All calm.", "Still here, still watching your frames.", "Everything looks stable on my side.",
        "You play with focus. I like it.", "Battery {bat}%, no worries yet.", "Quiet match? I'll stay out of the way.", "I could get used to watching you play.",
        "No lag, no heat. Perfect run so far.", "Your aim is better than my jokes.", "Mental note: you're a pretty cool player.", "Don't mind me, just counting frames.",
        "That's {min} minutes of pure focus.", "Smooth {fps} FPS. Show them how it's done."
    )

    fun smallTalk(c: Context, x: NovaCtx): NovaTalk {
        val musicNo = Prefs.int(c, "nova_music_no", 0)
        val musicYes = Prefs.int(c, "nova_music_yes", 0)
        val roll = rnd.nextInt(100)
        if (roll < 35) return NovaTalk(
            pick(c, "md0", mood),
            listOf(NovaChip("mood_w", "Winning"), NovaChip("mood_c", "Chilling"), NovaChip("mood_s", "Struggling")), 25_000L
        )
        if (roll < 60 && musicNo < musicYes + 3 && Music.count(c) > 0) return NovaTalk(
            fill(pick(c, "mq", listOf(
                "Want some music while you play?", "How about a soundtrack?", "I could put on some music. Interested?", "This match needs a playlist, don't you think?",
                "Music? Just say the word.", "Feel like some tunes?"
            )), x),
            listOf(NovaChip("music", listOf("Play music", "Yes please", "Sure").random()), NovaChip("bye", listOf("Not now", "No thanks", "Later").random())), 25_000L
        )
        return NovaTalk(fill(pick(c, "idl", idle), x), emptyList(), 3500L)
    }

    fun moodReply(c: Context, id: String, x: NovaCtx): NovaTalk = when (id) {
        "mood_w" -> NovaTalk(pick(c, "mw", listOf(
            "Of course you are. Keep it up!", "That's my handsome.", "Winning looks good on you.", "Never doubted you for a second.", "Save some wins for the rest of us."
        )), emptyList(), 2500L)
        "mood_c" -> NovaTalk(pick(c, "mc", listOf(
            "Relaxed play is the best play.", "Chill mode. I respect it.", "No pressure, just vibes.", "Take it easy, handsome.", "Slow and steady, nice."
        )), emptyList(), 2500L)
        else -> NovaTalk(pick(c, "ms3", listOf(
            "Tough one? Breathe. You've got this.", "Rough match happens. Next one's yours.", "Don't tilt, handsome. Reset and refocus.", "Everyone struggles. Music might help."
        )), listOf(NovaChip("music", "Some music?"), NovaChip("bye2", "I'm okay")), 12_000L)
    }

    fun cleaned(c: Context, x: NovaCtx, freed: Long, cool: Boolean): NovaTalk {
        val t = if (freed > 0) pick(c, "cf", listOf(
            "Done. {mb} MB freed.", "Cleared {mb} MB. Feels lighter already.", "{mb} MB back. Should run cooler.", "All clean. Got {mb} MB back for you."
        )) else pick(c, "c0", listOf(
            "Already clean, nothing to free.", "Your RAM was fine. Nothing to clear.", "Tidy already. Nothing found."
        ))
        val tail = if (cool) pick(c, "ct", listOf(" Give it a minute to settle.", " The temperature should ease off soon.", " I'll keep watching the heat.")) else ""
        return NovaTalk(fill(t + tail, x), emptyList(), 3500L)
    }

    fun shizukuOff(c: Context) = NovaTalk(pick(c, "so", listOf(
        "I need Shizuku for that, and it's off.", "Can't do it without Shizuku. It's off right now.", "Shizuku is off, so I can't clean. Turn it on and ask again."
    )), emptyList(), 3500L)
}

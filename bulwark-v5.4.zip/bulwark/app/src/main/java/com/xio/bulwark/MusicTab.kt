package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** The big "now playing" deck: reactor ring with an energy bolt, equalizer bars, progress and the three buttons. */
class DeckView(ctx: Context) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val bolt = Path()
    private val tri = Path()
    private var running = false
    private var seekFrac = -1f
    private var energy = 0f

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!isShown || windowVisibility != View.VISIBLE) { tickIdle = true; return }
            invalidate()
            postDelayed(this, 33)
        }
    }

    private var tickIdle = false

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (396 * d).toInt())
    }

    private fun cx() = width / 2f
    private fun barL() = 24 * d
    private fun barR() = width - 24 * d
    private val barY get() = 278 * d
    private val ctlY get() = 350 * d

    private fun mmss(ms: Int): String {
        val s = max(0, ms) / 1000
        return String.format("%d:%02d", s / 60, s % 60)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val t = Neon.now()
        val playing = Music.playing
        val has = Music.index >= 0
        energy += ((if (playing) 1f else 0f) - energy) * 0.12f
        Beat.step(playing)
        val cx = cx()
        val cy = 118 * d
        val R = 72 * d
        val pos = Music.position()
        val dur = Music.duration()
        val frac = if (seekFrac >= 0f) seekFrac else if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f

        // glow
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, R * 1.5f, Neon.a(Faces.color(Music.activeFace(context)), (26 + 54 * energy + 50 * Beat.kick * energy).toInt()), 0, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R * 1.5f, p)
        p.shader = null

        // ring track + progress
        rr.set(cx - R, cy - R, cx + R, cy + R)
        p.strokeWidth = 4.5f * d
        p.color = Neon.a(Neon.CYAN, 40)
        c.drawArc(rr, 0f, 360f, false, p)
        if (has) {
            p.color = Neon.GREEN
            c.drawArc(rr, -90f, 360f * frac, false, p)
        }
        // spinning spark on the ring while playing
        if (energy > 0.05f) {
            p.color = Neon.a(Neon.CYAN, (200 * energy).toInt())
            c.drawArc(rr, (t * 120f) % 360f, 18f, false, p)
        }
        p.strokeCap = Paint.Cap.BUTT

        // the playlist's face
        val apl = Music.playlist(context, Music.activeId)
        val cs = R * 1.18f
        Cover.draw(c, p, context, apl?.id, apl?.face ?: 0, apl?.name ?: "", cx - cs / 2f, cy - cs / 2f, cx + cs / 2f, cy + cs / 2f, d, playing)

        // title
        val title = if (has) Music.title(context) else "Nothing playing"
        CyUi.title(c, p, title, cx, cy + R + 42 * d, 1.25f * d, if (has) 0xFFFFFFFF.toInt() else 0xFF8B96A3.toInt(), w - 48 * d, 1, 19 * d)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 12 * d
        p.letterSpacing = 0f
        p.color = 0xFF6F7C8A.toInt()
        val total = Music.count(context)
        val pn = Music.activeName(context)
        val sub = if (pn.isEmpty()) "Create a playlist below to get started" else if (total == 0) "$pn is empty. Add songs to it" else if (has) "$pn  -  track ${Music.index + 1} of $total" else "$pn  -  tap a song, or press play"
        c.drawText(sub, cx, cy + R + 68 * d, p)

        // progress bar
        val bl = barL()
        val br = barR()
        val by = barY
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3.2f * d
        p.color = Neon.a(Neon.CYAN, 36)
        c.drawLine(bl, by, br, by, p)
        if (has && frac > 0f) {
            val fx = bl + (br - bl) * frac
            p.shader = LinearGradient(bl, 0f, max(fx, bl + 1f), 0f, Neon.CYAN, Neon.GREEN, Shader.TileMode.CLAMP)
            c.drawLine(bl, by, fx, by, p)
            p.shader = null
            p.style = Paint.Style.FILL
            p.color = Neon.a(Neon.GREEN, 70)
            c.drawCircle(fx, by, 9 * d, p)
            p.color = 0xFFFFFFFF.toInt()
            c.drawCircle(fx, by, 4.6f * d, p)
        }
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL
        p.typeface = Typeface.MONOSPACE
        p.textSize = 10.5f * d
        p.color = 0xFF6F7C8A.toInt()
        p.textAlign = Paint.Align.LEFT
        c.drawText(mmss(if (seekFrac >= 0f) (seekFrac * dur).toInt() else pos), bl, by + 20 * d, p)
        p.textAlign = Paint.Align.RIGHT
        c.drawText(mmss(dur), br, by + 20 * d, p)

        // buttons
        val y = ctlY
        val dim = total == 0
        val col = if (dim) 0xFF4A5560.toInt() else 0xFFE6EDF3.toInt()
        p.style = Paint.Style.FILL
        p.color = col
        for (side in intArrayOf(-1, 1)) {
            val x = cx + side * 92 * d
            tri.reset()
            tri.moveTo(x - side * 8 * d, y - 9 * d)
            tri.lineTo(x + side * 3 * d, y)
            tri.lineTo(x - side * 8 * d, y + 9 * d)
            tri.close()
            c.drawPath(tri, p)
            val b0 = x + side * 5 * d
            val b1 = x + side * 7.6f * d
            rr.set(min(b0, b1), y - 9 * d, max(b0, b1), y + 9 * d)
            c.drawRect(rr, p)
        }
        // play / pause
        val pr = 30 * d
        if (playing) {
            val k = 0.5f + 0.5f * sin(t * 5f)
            p.style = Paint.Style.FILL
            p.color = Neon.a(Neon.GREEN, (40 + 50 * k).toInt())
            c.drawCircle(cx, y, pr + 7 * d * k, p)
            p.shader = LinearGradient(cx - pr, y - pr, cx + pr, y + pr, Neon.GREEN, Neon.CYAN, Shader.TileMode.CLAMP)
            c.drawCircle(cx, y, pr, p)
            p.shader = null
            p.color = 0xFF04120C.toInt()
            rr.set(cx - 8 * d, y - 10 * d, cx - 3 * d, y + 10 * d); c.drawRect(rr, p)
            rr.set(cx + 3 * d, y - 10 * d, cx + 8 * d, y + 10 * d); c.drawRect(rr, p)
        } else {
            p.style = Paint.Style.FILL
            p.color = 0xFF111B24.toInt()
            c.drawCircle(cx, y, pr, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.6f * d
            p.color = if (dim) Neon.a(Neon.CYAN, 50) else Neon.CYAN
            c.drawCircle(cx, y, pr, p)
            p.style = Paint.Style.FILL
            p.color = if (dim) 0xFF4A5560.toInt() else 0xFFFFFFFF.toInt()
            tri.reset()
            tri.moveTo(cx - 6 * d, y - 11 * d); tri.lineTo(cx + 12 * d, y); tri.lineTo(cx - 6 * d, y + 11 * d); tri.close()
            c.drawPath(tri, p)
        }
    }

    private var seeking = false

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val dur = Music.duration()
        val nearBar = abs(e.y - barY) < 22 * d && Music.index >= 0 && dur > 0
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (nearBar) {
                    seeking = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    seekFrac = ((e.x - barL()) / (barR() - barL())).coerceIn(0f, 1f)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (seeking) seekFrac = ((e.x - barL()) / (barR() - barL())).coerceIn(0f, 1f)
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (seeking) {
                    if (seekFrac >= 0f && dur > 0) Music.seek((seekFrac * dur).toInt())
                    seeking = false
                    seekFrac = -1f
                    return true
                }
                val app = context.applicationContext
                val y = ctlY
                if (abs(e.y - y) < 40 * d) {
                    if (Music.count(app) == 0) {
                        Toast.makeText(context, "Add songs first", Toast.LENGTH_SHORT).show()
                        return true
                    }
                    val cx = cx()
                    when {
                        hypot(e.x - cx, e.y - y) < 40 * d -> Music.toggle(app)
                        abs(e.x - (cx - 92 * d)) < 34 * d -> Music.prev(app)
                        abs(e.x - (cx + 92 * d)) < 34 * d -> Music.next(app)
                        else -> return true
                    }
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
            }
            MotionEvent.ACTION_CANCEL -> { seeking = false; seekFrac = -1f }
        }
        return true
    }
}

/** One song in the playlist. Tap = play, swipe left = remove, press and hold then drag = move. */
class TrackRow(ctx: Context, private val num: Int, private val title: String) : View(ctx) {
    var onTap: (() -> Unit)? = null
    var onRemove: (() -> Unit)? = null
    var onMoved: ((Int) -> Unit)? = null

    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()
    private var sx = 0f
    private var mode = 0            // 0 idle, 1 swipe, 2 drag
    private var downX = 0f
    private var downY = 0f
    private var long = false
    private var pressed = false
    private var running = false
    private val longRun = Runnable {
        long = true
        mode = 2
        parent?.requestDisallowInterceptTouchEvent(true)
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        animate().scaleX(1.03f).scaleY(1.03f).setDuration(120).start()
        invalidate()
    }
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!isShown || windowVisibility != View.VISIBLE) { tickIdle = true; return }
            invalidate()
            postDelayed(this, 50)
        }
    }

    private var tickIdle = false

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        removeCallbacks(longRun)
        super.onDetachedFromWindow()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (ROW_DP * d).toInt())
    }

    private fun reset() {
        removeCallbacks(longRun)
        mode = 0; long = false; pressed = false
        animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(160).start()
        val from = sx
        if (from != 0f) {
            val a = android.animation.ValueAnimator.ofFloat(from, 0f)
            a.duration = 180
            a.addUpdateListener { sx = it.animatedValue as Float; invalidate() }
            a.start()
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                pressed = true; mode = 0; long = false
                postDelayed(longRun, 450)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (mode == 0 && (abs(dx) > slop || abs(dy) > slop)) {
                    removeCallbacks(longRun)
                    if (abs(dx) > abs(dy) && dx < 0) {
                        mode = 1
                        parent?.requestDisallowInterceptTouchEvent(true)
                    } else {
                        pressed = false
                        invalidate()
                        return true           // vertical move: the page scrolls
                    }
                }
                if (mode == 1) { sx = min(0f, dx); invalidate() }
                if (mode == 2) { translationY = dy }
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                when (mode) {
                    1 -> {
                        if (sx < -width * 0.35f) {
                            val a = android.animation.ValueAnimator.ofFloat(sx, -width.toFloat())
                            a.duration = 140
                            a.addUpdateListener { sx = it.animatedValue as Float; invalidate() }
                            a.addListener(object : android.animation.AnimatorListenerAdapter() {
                                override fun onAnimationEnd(an: android.animation.Animator) { onRemove?.invoke() }
                            })
                            a.start()
                            mode = 0; pressed = false
                        } else reset()
                    }
                    2 -> {
                        val rows = (translationY / height).roundToInt()
                        reset()
                        if (rows != 0) onMoved?.invoke(rows)
                    }
                    else -> {
                        val wasLong = long
                        reset()
                        if (!wasLong) onTap?.invoke()
                    }
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> { reset(); return true }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = Neon.now()
        val current = Music.index == num - 1
        val playing = current && Music.playing
        // "Remove" label revealed behind the row while swiping
        if (sx < -20 * d) {
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            p.textSize = 12 * d
            p.color = Neon.a(0xFFFF5A4D.toInt(), min(255f, -sx / (w * 0.35f) * 255f).toInt())
            c.drawText("Remove", w + sx / 2f, h / 2f + 4 * d, p)
        }
        c.save()
        c.translate(sx, 0f)
        r.set(2 * d, 3 * d, w - 2 * d, h - 3 * d)
        p.style = Paint.Style.FILL
        p.color = if (mode == 2) Neon.a(Neon.CYAN, 50) else if (current) Neon.a(Neon.CYAN, 30) else if (pressed) Neon.a(Neon.CYAN, 20) else 0x0CFFFFFF
        CyUi.drawCut(c, p, r, 12 * d)
        if (mode == 2 || current) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.2f * d
            p.color = Neon.a(Neon.CYAN, if (mode == 2) 220 else 90)
            CyUi.drawCut(c, p, r, 12 * d)
        }
        p.style = Paint.Style.FILL
        if (current) {
            p.color = Neon.CYAN
            r.set(2 * d, 12 * d, 5 * d, h - 12 * d)
            c.drawRoundRect(r, 2 * d, 2 * d, p)
        }
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        p.textSize = 11 * d
        p.color = if (current) Neon.CYAN else 0xFF5F6B78.toInt()
        c.drawText(String.format("%02d", num), 16 * d, h / 2f + 4 * d, p)
        CyUi.title(c, p, title, 46 * d, h / 2f, 0.92f * d, if (current) 0xFFFFFFFF.toInt() else 0xFFC9D3DD.toInt(), w - 48 * d - 64 * d, 0, 14.5f * d)
        if (current) {
            p.color = Neon.GREEN
            for (i in 0..3) {
                val k = if (playing) 0.3f + 0.7f * (0.5f + 0.5f * sin(t * (5f + i * 1.7f) + i * 1.3f)) else 0.2f
                val bh = 16 * d * k
                val x = w - 50 * d + i * 5.5f * d
                r.set(x, h / 2f + 8 * d - bh, x + 3.2f * d, h / 2f + 8 * d)
                c.drawRoundRect(r, 1.4f * d, 1.4f * d, p)
            }
        } else {
            // grip hint: three short lines
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.3f * d
            p.strokeCap = Paint.Cap.ROUND
            p.color = 0xFF3B4650.toInt()
            for (k in -1..1) c.drawLine(w - 34 * d, h / 2f + k * 4.5f * d, w - 22 * d, h / 2f + k * 4.5f * d, p)
            p.strokeCap = Paint.Cap.BUTT
        }
        c.restore()
    }

    companion object { const val ROW_DP = 54f }
}


/** A square playlist cover. With plId it shows that playlist (photo or pattern); without, the pattern [face] (for the picker). */
class FaceView(ctx: Context, var face: Int, var plId: String? = null, var demo: Boolean = false) : View(ctx) {
    var chosen = false
    var sizeDp = 64f
    var onTap: (() -> Unit)? = null
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        setOnClickListener { if (onTap != null) { performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); onTap?.invoke() } }
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((sizeDp * d).toInt(), (sizeDp * d).toInt())

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val pl = if (plId != null) Music.playlist(context, plId!!) else null
        val hot = chosen || (pl != null && Music.playing && Music.activeId == pl.id)
        Cover.draw(c, p, context, plId, pl?.face ?: face, pl?.name ?: "", 2 * d, 2 * d, w - 2 * d, h - 2 * d, d, hot)
    }
}

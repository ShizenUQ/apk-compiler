package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import java.util.Calendar
import java.util.TimeZone

/** Badges earned from your own recorded sessions. Nothing here needs the internet. */
object Achievements {
    class Def(val id: String, val name: String, val desc: String, val icon: Int, val test: (List<Games.Session>) -> Boolean)

    private const val MIN = 60_000L

    private fun day(ms: Long): Long = (ms + TimeZone.getDefault().getOffset(ms)) / 86_400_000L
    private fun hour(ms: Long): Int { val c = Calendar.getInstance(); c.timeInMillis = ms; return c.get(Calendar.HOUR_OF_DAY) }

    private fun streak(ss: List<Games.Session>): Int {
        val days = ss.map { day(it.start) }.toSortedSet().toList()
        var best = 0
        var run = 0
        var prev = Long.MIN_VALUE
        for (d in days) {
            run = if (d == prev + 1) run + 1 else 1
            if (run > best) best = run
            prev = d
        }
        return best
    }

    val all: List<Def> = listOf(
        Def("first", "First Blood", "Finish your first recorded session", 0) { it.isNotEmpty() },
        Def("reg", "Regular", "Finish 10 sessions", 1) { it.size >= 10 },
        Def("vet", "Veteran", "Finish 50 sessions", 2) { it.size >= 50 },
        Def("h10", "Ten Hours", "10 hours of recorded play", 3) { s -> s.sumOf { it.ms } >= 10 * 60 * MIN },
        Def("h50", "Fifty Hours", "50 hours of recorded play", 3) { s -> s.sumOf { it.ms } >= 50 * 60 * MIN },
        Def("mar", "Marathon", "Play 2 hours in one session", 4) { s -> s.any { it.ms >= 120 * MIN } },
        Def("owl", "Night Owl", "A 10 minute session that starts between midnight and 5 AM", 5) { s -> s.any { it.ms >= 10 * MIN && hour(it.start) in 0..4 } },
        Def("bird", "Early Bird", "A 10 minute session that starts between 5 and 8 AM", 6) { s -> s.any { it.ms >= 10 * MIN && hour(it.start) in 5..7 } },
        Def("silk", "Silky 90", "Average 88 FPS or more over a 10 minute session", 7) { s -> s.any { it.ms >= 10 * MIN && it.avgFps >= 88f } },
        Def("steady", "Rock Steady", "A 15 minute session where the lowest FPS stayed within 80% of the average", 8) { s ->
            s.any { it.ms >= 15 * MIN && it.avgFps > 0f && it.low > 0f && it.low >= it.avgFps * 0.8f }
        },
        Def("ice", "Ice Cold", "A 20 minute session with the phone under 37 degrees on average", 9) { s ->
            s.any { it.ms >= 20 * MIN && it.avgTemp > 0f && it.avgTemp <= 37f }
        },
        Def("batt", "Iron Battery", "A 30 minute session that used 5% battery or less", 10) { s -> s.any { it.ms >= 30 * MIN && it.batDrop <= 5 } },
        Def("str7", "Seven Day Streak", "Play on 7 days in a row", 11) { streak(it) >= 7 },
        Def("mix", "Variety Pack", "Play 3 different games in one day", 12) { s ->
            s.groupBy { day(it.start) }.values.any { d -> d.map { it.pkg }.toSet().size >= 3 }
        }
    )

    private fun done(c: Context): Set<String> = Prefs.str(c, "ach_done", "").split(",").filter { it.isNotEmpty() }.toSet()

    fun status(c: Context): List<Pair<Def, Boolean>> {
        val ss = Games.sessions(c)
        val d = done(c)
        return all.map { Pair(it, it.id in d || it.test(ss)) }
    }

    /** Saves and returns the badges earned since the last time this ran. */
    fun scan(c: Context): List<Def> {
        val ss = Games.sessions(c)
        val d = done(c)
        val fresh = all.filter { it.id !in d && it.test(ss) }
        if (fresh.isNotEmpty()) Prefs.putStr(c, "ach_done", (d + fresh.map { it.id }).joinToString(","))
        return fresh
    }
}

/** A tile for every badge: lit when earned, dim when not. Tap one to read what it needs. */
class BadgeGrid(ctx: Context) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val path = Path()
    private var items: List<Pair<Achievements.Def, Boolean>> = emptyList()
    private val cols = 3
    private val tileH get() = 84 * d
    private val gap get() = 8 * d

    fun set(list: List<Pair<Achievements.Def, Boolean>>) { items = list; requestLayout(); invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val rows = (items.size + cols - 1) / cols
        setMeasuredDimension(MeasureSpec.getSize(w), (rows * tileH + max0(rows - 1) * gap + 4 * d).toInt())
    }

    private fun max0(v: Int) = if (v < 0) 0 else v

    private fun tile(i: Int): RectF {
        val tw = (width - gap * (cols - 1)) / cols
        val r = i / cols
        val c = i % cols
        return RectF(c * (tw + gap), r * (tileH + gap), c * (tw + gap) + tw, r * (tileH + gap) + tileH)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            for (i in items.indices) if (tile(i).contains(e.x, e.y)) {
                val (a, ok) = items[i]
                Toast.makeText(context, a.name + ": " + a.desc + (if (ok) "  (earned)" else ""), Toast.LENGTH_SHORT).show()
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        for (i in items.indices) {
            val (a, ok) = items[i]
            val t = tile(i)
            val col = if (ok) Neon.CYAN else 0xFF4A5560.toInt()
            rr.set(t.left + d, t.top + d, t.right - d, t.bottom - d)
            p.style = Paint.Style.FILL
            p.color = if (ok) Cy.a(Neon.CYAN, 0.10f) else 0x14FFFFFF
            CyUi.drawCut(c, p, rr, 8 * d)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f * d
            p.color = Cy.a(col, if (ok) 0.7f else 0.35f)
            CyUi.drawCut(c, p, rr, 8 * d)
            icon(c, a.icon, t.centerX(), t.top + 31 * d, 13 * d, col, ok)
            tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            tp.textSize = 10.5f * d
            tp.textAlign = Paint.Align.CENTER
            tp.color = if (ok) 0xFFFFFFFF.toInt() else 0xFF7B8794.toInt()
            c.drawText(TextUtils.ellipsize(a.name, tp, t.width() - 10 * d, TextUtils.TruncateAt.END).toString(), t.centerX(), t.bottom - 14 * d, tp)
        }
    }

    /** Small neon pictures, all drawn from lines. */
    private fun icon(c: Canvas, k: Int, cx: Float, cy: Float, r: Float, col: Int, ok: Boolean) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = 1.8f * d
        p.color = if (ok) col else Cy.a(col, 0.8f)
        path.reset()
        fun pt(x: Float, y: Float, first: Boolean) { if (first) path.moveTo(cx + x * r, cy + y * r) else path.lineTo(cx + x * r, cy + y * r) }
        fun poly(vararg v: Float, close: Boolean = false) {
            var i = 0
            while (i < v.size) { pt(v[i], v[i + 1], i == 0); i += 2 }
            if (close) path.close()
        }
        when (k) {
            0 -> poly(0f, -1f, 0.3f, -0.3f, 1f, -0.2f, 0.45f, 0.3f, 0.6f, 1f, 0f, 0.6f, -0.6f, 1f, -0.45f, 0.3f, -1f, -0.2f, -0.3f, -0.3f, close = true)
            1 -> { poly(-0.8f, -0.2f, 0f, -0.9f, 0.8f, -0.2f); poly(-0.8f, 0.7f, 0f, 0f, 0.8f, 0.7f) }
            2 -> poly(0f, -1f, 0.9f, -0.5f, 0.7f, 0.5f, 0f, 1f, -0.7f, 0.5f, -0.9f, -0.5f, close = true)
            3 -> { c.drawCircle(cx, cy, r * 0.9f, p); poly(0f, -0.5f, 0f, 0f, 0.4f, 0.3f) }
            4 -> { poly(-0.9f, 0.6f, -0.9f, -0.2f, 0f, -0.9f, 0.9f, -0.2f, 0.9f, 0.6f, close = true); poly(-0.9f, 0.6f, 0.9f, 0.6f) }
            5 -> { path.addArc(RectF(cx - r * 0.8f, cy - r * 0.8f, cx + r * 0.8f, cy + r * 0.8f), 60f, 240f); poly(0.5f, -0.8f, 0.9f, -0.2f) }
            6 -> { c.drawCircle(cx, cy + r * 0.2f, r * 0.45f, p); poly(-1f, 0.2f, -0.6f, 0.2f); poly(0.6f, 0.2f, 1f, 0.2f); poly(0f, -0.9f, 0f, -0.5f) }
            7 -> poly(0.2f, -1f, -0.6f, 0.15f, 0f, 0.15f, -0.2f, 1f, 0.6f, -0.15f, 0f, -0.15f, close = true)
            8 -> { poly(-1f, 0.5f, -0.4f, -0.5f, 0.2f, 0.2f, 0.6f, -0.7f, 1f, 0.3f) }
            9 -> { poly(0f, -1f, 0f, 1f); poly(-0.9f, -0.5f, 0.9f, 0.5f); poly(-0.9f, 0.5f, 0.9f, -0.5f) }
            10 -> { poly(-0.9f, -0.5f, 0.7f, -0.5f, 0.7f, 0.5f, -0.9f, 0.5f, close = true); poly(0.7f, -0.2f, 1f, -0.2f, 1f, 0.2f, 0.7f, 0.2f); poly(-0.5f, 0f, 0.3f, 0f) }
            11 -> { poly(-1f, 0.8f, -1f, 0.1f, -0.4f, 0.1f, -0.4f, -0.4f, 0.2f, -0.4f, 0.2f, -0.9f, 0.9f, -0.9f) }
            else -> { poly(0f, -1f, 1f, 0f, 0f, 1f, -1f, 0f, close = true); poly(0f, -0.4f, 0.4f, 0f, 0f, 0.4f, -0.4f, 0f, close = true) }
        }
        c.drawPath(path, p)
    }
}

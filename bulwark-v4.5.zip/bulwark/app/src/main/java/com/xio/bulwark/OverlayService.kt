package com.xio.bulwark

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Resources
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.net.Uri
import rikka.shizuku.Shizuku
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import kotlin.math.min

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.xio.bulwark.STOP"
        const val ACTION_TOGGLE_LOCK = "com.xio.bulwark.TOGGLE_LOCK"
        const val ACTION_TOGGLE_SOUND = "com.xio.bulwark.TOGGLE_SOUND"
        private const val CHANNEL = "bulwark_watch"
        private const val NOTIF_ID = 7
        private const val BASE_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

        const val ACTION_MUSIC_PREV = "com.xio.bulwark.MUSIC_PREV"
        const val ACTION_MUSIC_TOGGLE = "com.xio.bulwark.MUSIC_TOGGLE"
        const val ACTION_MUSIC_NEXT = "com.xio.bulwark.MUSIC_NEXT"

        const val ACTION_SHOW = "com.xio.bulwark.SHOW"
        const val ACTION_HIDE = "com.xio.bulwark.HIDE"
        const val EXTRA_WATCH = "watch"
        private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"

        @Volatile
        var running = false

        /** The status overlay is on screen right now. */
        @Volatile
        var shown = false

        /** The overlay was started by hand and stays up until you stop it. Otherwise Auto mode shows it only during a game. */
        @Volatile
        var pinned = false
    }

    private lateinit var wm: WindowManager
    private var root: HudRoot? = null
    private lateinit var lp: WindowManager.LayoutParams
    private class Spot(val v: TapSpot, val lp: WindowManager.LayoutParams)
    private val spots = HashMap<String, Spot>()

    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var wh: Handler? = null
    private var t0 = 0L
    private var screenOn = true

    private val loop = object : Runnable {
        override fun run() {
            var next = 800L
            try {
                val c = applicationContext
                if (shown) {
                    next = 500L
                    val raw = try { FpsClient.sample(c) } catch (t: Throwable) { null }
                    val data = FpsData.parse(raw)
                    val sys = StatsReader.read(c, t0)
                    try { Tracker.feed(c, data, sys) } catch (t: Throwable) { }
                    main.post {
                        try {
                            root?.applyPrefs()
                            applyWindowState()
                            root?.update(data, sys)
                            syncBadge()
                        } catch (t: Throwable) { }
                    }
                    try { watchTick(data.pkg) } catch (t: Throwable) { }
                } else {
                    try { watchTick(null) } catch (t: Throwable) { }
                }
            } catch (t: Throwable) {
            }
            if (screenOn) wh?.postDelayed(this, next)
        }
    }

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> { screenOn = false; wh?.removeCallbacks(loop) }
                Intent.ACTION_SCREEN_ON -> { screenOn = true; wh?.removeCallbacks(loop); wh?.post(loop) }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ExitLog.install(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        t0 = SystemClock.elapsedRealtime()
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        running = true
        registerReceiver(screenRx, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        Music.onChange = {
            main.post {
                root?.hud?.poke()
                panel?.refreshCurrent()
                try {
                    (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
                } catch (t: Throwable) { }
            }
        }
        worker = HandlerThread("bulwark-sampler").also { it.start() }
        wh = Handler(worker!!.looper)
        wh?.post(loop)
    }

    private var initDone = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                // stopping from the notification turns Auto mode off too, so the service does not come back by itself
                Prefs.putBool(this, Prefs.AUTO, false)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_LOCK -> toggleLock()
            ACTION_TOGGLE_SOUND -> toggleSound()
            ACTION_MUSIC_PREV -> Music.prev(applicationContext)
            ACTION_MUSIC_TOGGLE -> Music.toggle(applicationContext)
            ACTION_MUSIC_NEXT -> Music.next(applicationContext)
            ACTION_SHOW -> { pinned = true; if (root == null) showOverlay(); notifyState() }
            ACTION_HIDE -> {
                pinned = false
                if (root != null && curGame == null) hideOverlay()
                notifyState()
            }
            else -> if (!initDone) {
                initDone = true
                val watch = if (intent == null) (Prefs.bool(this, Prefs.AUTO, false) || Prefs.bool(this, Prefs.BOOT, false)) else intent.getBooleanExtra(EXTRA_WATCH, false)
                if (watch) {
                    pinned = false
                    notifyState()
                } else {
                    pinned = true
                    showOverlay()
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        shown = false
        pinned = false
        hideChip()
        hideBanner()
        hideBadge()
        wh?.removeCallbacksAndMessages(null)
        worker?.quitSafely()
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(screenRx) } catch (t: Throwable) { }
        Music.onChange = null
        hidePanel()
        VideoLib.onChange = null
        pHost?.destroy(); pHost = null
        Music.stop()
        try { Tracker.flush(applicationContext) } catch (t: Throwable) { }
        clearSpots()
        root?.let { try { wm.removeView(it) } catch (t: Throwable) { } }
        root = null
        FpsClient.unbind(applicationContext)
        super.onDestroy()
    }

    // ---------- overlay window ----------

    private fun showOverlay() {
        val dm = Resources.getSystem().displayMetrics
        val v = HudRoot(this)
        v.applyPrefs()
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        edge(lp)
        lp.x = Prefs.int(this, kx(), Prefs.int(this, Prefs.X, (24 * dm.density).toInt()))
        lp.y = Prefs.int(this, ky(), Prefs.int(this, Prefs.Y, (24 * dm.density).toInt()))
        lp.alpha = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        v.onMusic = { i -> onMusicTap(i) }
        v.onPlayer = { playerTap() }
        if (pHost == null) {
            pHost = PlayerHost(applicationContext, wm, { screen() }, { l -> edge(l) }, {
                val r = root
                if (r == null) null else Rect(lp.x, lp.y, lp.x + r.width, lp.y + r.height)
            })
            pHost?.onState = { root?.hud?.poke() }
        }
        VideoLib.onChange = { main.post { root?.applyPrefs() } }
        v.onDrag = { dx, dy ->
            if (panel != null) hidePanel()
            lp.x += dx
            lp.y += dy
            clamp(v)
            try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
            pHost?.reposition()
            syncBadge()
        }
        v.onDragEnd = { snap(v); pHost?.reposition() }
        v.onToggleLock = { toggleLock() }
        v.onToggleSound = { toggleSound() }
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> syncSpots(); pHost?.reposition() }
        try {
            wm.addView(v, lp)
            root = v
            shown = true
            notifyState()
        } catch (t: Throwable) {
            stopSelf()
        }
    }

    /** Takes the status overlay off the screen (Auto mode, after the game closes). The service keeps watching. */
    private fun hideOverlay() {
        val r = root ?: return
        hidePanel()
        clearSpots()
        pHost?.destroy(); pHost = null
        VideoLib.onChange = null
        hideBadge()
        try { wm.removeView(r) } catch (t: Throwable) { }
        root = null
        shown = false
        notifyState()
    }

    private fun notifyState() {
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (t: Throwable) { }
    }

    /**
     * Lets a window use the whole screen, notch side included. Without this, in landscape the system pushes the big
     * overlay away from the notch but not the tiny tap windows, so taps land beside the icons.
     */
    private fun edge(l: WindowManager.LayoutParams) {
        if (Build.VERSION.SDK_INT >= 30) l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else if (Build.VERSION.SDK_INT >= 28) l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    /** Real current screen size (follows rotation). Resources.getSystem() goes stale after a rotation. */
    @Suppress("DEPRECATION")
    private fun screen(): IntArray {
        return try {
            val m = android.util.DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            intArrayOf(m.widthPixels, m.heightPixels)
        } catch (t: Throwable) {
            val m = Resources.getSystem().displayMetrics
            intArrayOf(m.widthPixels, m.heightPixels)
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        hidePanel()
        pHost?.onConfig()
        val v = root ?: return
        main.postDelayed({
            try {
                lp.x = Prefs.int(this, kx(), lp.x)
                lp.y = Prefs.int(this, ky(), lp.y)
                clamp(v)
                wm.updateViewLayout(v, lp)
                clearSpots()
                syncSpots()
                pHost?.onConfig()
            } catch (t: Throwable) { }
        }, 350)
    }

    private fun clamp(v: View) {
        val sc = screen()
        val w = if (v.width > 0) v.width else 1
        val h = if (v.height > 0) v.height else 1
        lp.x = lp.x.coerceIn(0, maxOf(0, sc[0] - w))
        lp.y = lp.y.coerceIn(0, maxOf(0, sc[1] - h))
    }

    private fun land(): Boolean { val sc = screen(); return sc[0] > sc[1] }
    private fun kx() = if (land()) "x_land" else Prefs.X
    private fun ky() = if (land()) "y_land" else Prefs.Y

    /** The overlay stays exactly where you drop it. Portrait and landscape remember their own spot. */
    private fun snap(v: View) {
        clamp(v)
        Prefs.putInt(this, kx(), lp.x)
        Prefs.putInt(this, ky(), lp.y)
    }

    // ---------- lock ----------

    private fun toggleLock() {
        val now = !Prefs.bool(this, Prefs.LOCKED, false)
        Prefs.putBool(this, Prefs.LOCKED, now)
        root?.applyPrefs()
        applyWindowState()
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (t: Throwable) { }
    }

    /** Locked = every touch passes through to the game (window opacity must stay at 80% or less on Android 12+). */
    private fun applyWindowState() {
        val v = root ?: return
        val locked = Prefs.bool(this, Prefs.LOCKED, false)
        val op = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        val flags = if (locked) BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else BASE_FLAGS
        val a = if (locked) min(op, 0.8f) else op
        if (lp.flags != flags || lp.alpha != a) {
            lp.flags = flags
            lp.alpha = a
            try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
        }
        if (locked) syncSpots() else clearSpots()
    }

    private fun toggleSound() {
        Prefs.putBool(this, Prefs.SOUND, !Prefs.bool(this, Prefs.SOUND, false))
        root?.applyPrefs()
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (t: Throwable) { }
    }

    /**
     * While locked the overlay lets every touch through. The only exceptions are two tiny invisible
     * windows placed exactly over the lock icon (to unlock) and the sound icon (to mute / unmute).
     */
    private fun syncSpots() {
        val r = root ?: return
        if (!Prefs.bool(this, Prefs.LOCKED, false)) return
        spot("lock", r.lockRectPx()) { toggleLock() }
        spot("vid", r.videoTapRectPx()) { toggleSound() }
        spot("img", r.imageTapRectPx()) { r.nextImage() }
        spot("play", r.playerRectPx()) { playerTap() }
        val mr = r.musicRectsPx()
        for (i in 0..3) spot("m$i", mr.getOrNull(i)) { onMusicTap(i) }
    }

    // ---------- player ----------

    private var pHost: PlayerHost? = null

    private fun playerTap() {
        if (panel != null) hidePanel()
        pHost?.iconTap()
    }

    // ---------- music ----------

    private var panel: MusicPanel? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelClosedAt = 0L
    private var panelSide = false
    private var panelMode = 0
    private var panelMax = 0

    private fun onMusicTap(i: Int) {
        val c = applicationContext
        when (i) {
            0 -> if (panel != null) hidePanel()
                 else if (SystemClock.uptimeMillis() - panelClosedAt > 450) showPanel()
            1 -> Music.prev(c)
            2 -> Music.toggle(c)
            3 -> Music.next(c)
        }
        root?.hud?.poke()
    }

    private fun hidePanel() {
        val p = panel ?: return
        panel = null
        panelLp = null
        panelClosedAt = SystemClock.uptimeMillis()
        Music.panelOpen = false
        root?.hud?.poke()
        val a = p.animate().alpha(0f).setDuration(140)
        if (panelSide) a.scaleX(0.85f) else a.scaleY(0.85f)
        a.withEndAction {
            try { wm.removeView(p) } catch (t: Throwable) { }
        }.start()
    }

    private fun showPanel() {
        val r = root ?: return
        val c = applicationContext
        if (Music.playlists(c).isEmpty()) {
            android.widget.Toast.makeText(c, "Create a playlist first: Frameline app > Music", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val dm = Resources.getSystem().displayMetrics
        val sc = screen()
        val sw = sc[0]
        val sh = sc[1]
        val hits = r.hud.musicHits()
        val s = r.hud.scalePx()
        val iconCx = if (hits != null) (hits[0].left + hits[0].right) / 2f * s else 40f * s
        val p = MusicPanel(this)
        val pad = (8 * dm.density).toInt()
        val gap = (2 * dm.density).toInt()
        val pw = maxOf(r.width, (200 * dm.density).toInt()).coerceAtMost(sw - 2 * pad)
        val minH = (130 * dm.density).toInt()
        val spaceBelow = sh - (lp.y + r.height) - pad
        val spaceAbove = lp.y - pad
        // where does it go? below the status, above it, or beside it (never on top of it)
        var mode = 0   // 0 below, 1 above, 2 right, 3 left
        p.side = false
        p.showPlaylists()
        var ph = p.desiredHeight()
        if (spaceBelow >= ph) mode = 0
        else if (spaceAbove >= ph) mode = 1
        else if (lp.x + r.width + pad + pw <= sw) { mode = 2 }
        else if (lp.x - pad - pw >= 0) { mode = 3 }
        else if (spaceBelow >= spaceAbove) { mode = 0; ph = maxOf(minH, spaceBelow) }
        else { mode = 1; ph = maxOf(minH, spaceAbove) }
        val side = mode >= 2
        p.side = side
        if (side) { p.showPlaylists(); ph = minOf(p.desiredHeight(), sh - 2 * pad) }
        val below = mode == 0
        p.wireOnTop = below
        p.showPlaylists()
        p.onPick = { id, i -> Music.playIn(c, id, i); hidePanel() }
        p.onResize = { h -> resizePanel(h) }
        panelMode = mode
        panelMax = when (mode) { 0 -> maxOf(minH, spaceBelow); 1 -> maxOf(minH, spaceAbove); else -> sh - 2 * pad }
        p.onOutside = { hidePanel() }
        val l = WindowManager.LayoutParams(
            pw, ph, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        when (mode) {
            0 -> { l.x = lp.x.coerceIn(0, maxOf(0, sw - pw)); l.y = lp.y + r.height - gap }
            1 -> { l.x = lp.x.coerceIn(0, maxOf(0, sw - pw)); l.y = lp.y - ph + gap }
            2 -> { l.x = lp.x + r.width + pad / 2; l.y = lp.y.coerceIn(pad, maxOf(pad, sh - ph - pad)) }
            else -> { l.x = lp.x - pw - pad / 2; l.y = lp.y.coerceIn(pad, maxOf(pad, sh - ph - pad)) }
        }
        p.wireX = (iconCx + (lp.x - l.x)).coerceIn(12f * dm.density, pw - 12f * dm.density)
        panelSide = side
        p.alpha = 0f
        if (side) {
            p.scaleX = 0.85f
            p.pivotX = if (mode == 2) 0f else pw.toFloat()
            p.pivotY = ph / 2f
        } else {
            p.scaleY = 0.85f
            p.pivotX = p.wireX
            p.pivotY = if (below) 0f else ph.toFloat()
        }
        try {
            wm.addView(p, l)
            panel = p
            panelLp = l
            Music.panelOpen = true
            val an = p.animate().alpha(1f).setDuration(220)
            if (side) an.scaleX(1f) else an.scaleY(1f)
            an.start()
            r.hud.poke()
        } catch (t: Throwable) { }
    }

    /** The box switched between playlists and songs: resize it and keep it attached to the status. */
    private fun resizePanel(want: Int) {
        val p = panel ?: return
        val l = panelLp ?: return
        val r = root ?: return
        val dm = Resources.getSystem().displayMetrics
        val sh = screen()[1]
        val pad = (8 * dm.density).toInt()
        val gap = (2 * dm.density).toInt()
        val h = want.coerceAtMost(maxOf(panelMax, (100 * dm.density).toInt()))
        l.height = h
        when (panelMode) {
            1 -> { l.y = lp.y - h + gap; p.pivotY = h.toFloat() }
            2, 3 -> { l.y = lp.y.coerceIn(pad, maxOf(pad, sh - h - pad)); p.pivotY = h / 2f }
            else -> l.y = lp.y + r.height - gap
        }
        try { wm.updateViewLayout(p, l) } catch (t: Throwable) { }
    }

    private fun spot(name: String, rect: Rect?, onTap: () -> Unit) {
        val old = spots[name]
        if (rect == null || rect.width() <= 0 || rect.height() <= 0) {
            if (old != null) { try { wm.removeView(old.v) } catch (t: Throwable) { }; spots.remove(name) }
            return
        }
        val sc = screen()
        val x = (lp.x + rect.left).coerceIn(0, maxOf(0, sc[0] - rect.width()))
        val y = (lp.y + rect.top).coerceIn(0, maxOf(0, sc[1] - rect.height()))
        if (old != null) {
            if (old.lp.x == x && old.lp.y == y && old.lp.width == rect.width() && old.lp.height == rect.height()) return
            old.lp.x = x; old.lp.y = y; old.lp.width = rect.width(); old.lp.height = rect.height()
            try { wm.updateViewLayout(old.v, old.lp) } catch (t: Throwable) { }
            return
        }
        val v = TapSpot(this)
        v.onTap = onTap
        val l = WindowManager.LayoutParams(rect.width(), rect.height(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, BASE_FLAGS, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        l.x = x; l.y = y
        try {
            wm.addView(v, l)
            spots[name] = Spot(v, l)
        } catch (t: Throwable) { }
    }

    private fun clearSpots() {
        for (sp in spots.values) { try { wm.removeView(sp.v) } catch (t: Throwable) { } }
        spots.clear()
    }

    // ---------- auto mode: notice a game, boost, show the status, help with Shizuku ----------

    @Volatile private var curGame: String? = null
    @Volatile private var lastGame: String? = null
    @Volatile private var needShizuku = false
    @Volatile private var boostPending = false   // Shizuku came on while you were away: boost as soon as you are back
    @Volatile private var chipKind = 0   // 0 none, 1 "Shizuku is off", 2 "go back to the game"
    private var missSince = 0L
    private var gameSet: Set<String> = emptySet()
    private var gameNames: Map<String, String> = emptyMap()
    private var gameSetAt = 0L
    private var lastWatch = 0L
    private var banner: BoostBanner? = null
    private var chip: HudChip? = null
    private var badge: GameBadge? = null
    private var badgePkg: String? = null
    private var badgeLp: WindowManager.LayoutParams? = null
    private val chipHider = Runnable { hideChip() }

    private fun isTransient(pkg: String): Boolean =
        pkg == packageName || pkg == SHIZUKU_PKG || pkg == "com.android.systemui" ||
            pkg == "com.google.android.permissioncontroller" || pkg == "com.android.permissioncontroller"

    /** Worker thread. Called about twice a second with the game in front (when the overlay is up) or null. */
    private fun watchTick(fpsPkg: String?) {
        val c = applicationContext
        val now = SystemClock.elapsedRealtime()
        if (fpsPkg.isNullOrEmpty() && now - lastWatch < 700L) return
        lastWatch = now
        if (now - gameSetAt > 60_000L || gameSet.isEmpty()) {
            val g = Games.detect(c)
            gameSet = g.map { it.pkg }.toSet()
            gameNames = g.associate { it.pkg to it.name }
            gameSetAt = now
        }
        val fg = if (!fpsPkg.isNullOrEmpty()) fpsPkg else ForegroundApp.top(c)
        if (fg != lastFg) { lastFg = fg; AutoLog.note("front: $fg" + (if (fg != null && fg in gameSet) " (game)" else "")) }
        if (fg != null) {
            if (fg in gameSet) {
                missSince = 0L
                if (curGame != fg) onGameEnter(fg) else onGameStill(fg)
            } else if (!isTransient(fg) && curGame != null) {
                if (missSince == 0L) missSince = now
                else if (now - missSince > 4000L) onGameLeave()
            }
        }
        if (needShizuku) shizukuCheck(fg)
        // self-repair: a game is in front but the status is not up (or the other way round)
        val cg = curGame
        if (!pinned) {
            if (cg != null && !shown) main.post {
                if (curGame == cg && root == null && banner == null && !pinned) { AutoLog.note("repair: showing the overlay"); showOverlay(); syncBadge() }
            } else if (cg == null && shown) main.post {
                if (curGame == null && root != null && banner == null && !pinned) { AutoLog.note("repair: hiding the overlay"); hideOverlay() }
            }
        }
    }

    private var lastFg: String? = null

    private fun onGameEnter(pkg: String) {
        val c = applicationContext
        curGame = pkg
        lastGame = pkg
        missSince = 0L
        val ready = FpsClient.state(c) == FpsClient.St.READY
        val boost = ready && Boost.canAuto(c, pkg)
        if (boost) Boost.markAuto(pkg)
        needShizuku = !ready
        val name = gameNames[pkg] ?: pkg
        AutoLog.note("game opened: $name, shizuku=" + (if (ready) "on" else "off") + ", boost=" + boost)
        main.post {
            if (curGame != pkg) return@post
            hideChip()
            if (boost) beginBoost(pkg, name)
            else {
                if (root == null && !pinned) showOverlay()
                syncBadge()
            }
            if (!ready) main.postDelayed({ if (curGame == pkg && needShizuku) showShizukuChip() }, 1500L)
        }
    }

    private fun onGameStill(pkg: String) {
        if (boostPending) {
            // you are back in the game after turning Shizuku on
            boostPending = false
            AutoLog.note("back in the game after Shizuku, boosting")
            main.post { hideChip() }
            startBoostIfAllowed(pkg)
        } else if (chipKind == 2) {
            main.post { hideChip() }
        }
    }

    private fun onGameLeave() {
        val c = applicationContext
        curGame = null
        needShizuku = false
        boostPending = false
        missSince = 0L
        AutoLog.note("game closed")
        if (!pinned) {
            try { Tracker.flush(c) } catch (t: Throwable) { }
            Boost.autoEnd(c)
        }
        main.post {
            hideChip()
            hideBanner()
            hideBadge()
            if (!pinned) hideOverlay()
        }
    }

    @Synchronized
    private fun startBoostIfAllowed(pkg: String) {
        val c = applicationContext
        if (!Boost.canAuto(c, pkg)) return
        Boost.markAuto(pkg)
        val name = gameNames[pkg] ?: pkg
        main.post { if (curGame == pkg) beginBoost(pkg, name) }
    }

    /** Worker thread: Shizuku was off when the game opened. Notice when it comes on. */
    private fun shizukuCheck(fg: String?) {
        val c = applicationContext
        if (FpsClient.state(c) != FpsClient.St.READY) return
        needShizuku = false
        AutoLog.note("Shizuku is on")
        val g = lastGame ?: return
        val name = gameNames[g] ?: g
        if (Prefs.bool(c, Prefs.BO_AUTO, false)) boostPending = true
        main.post {
            hideChip()
            if (fg == g) {
                if (boostPending) { boostPending = false; startBoostIfAllowed(g) }
            } else showReturnChip(g, name)
        }
    }

    // ---------- windows: boost banner, chips, game badge (main thread) ----------

    private fun loadIcon(pkg: String): android.graphics.drawable.Drawable? =
        try { packageManager.getApplicationIcon(pkg) } catch (t: Throwable) { null }

    private fun topWindow(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        val l = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            if (touchable) BASE_FLAGS else BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        edge(l)
        l.y = (22 * resources.displayMetrics.density).toInt()
        return l
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun beginBoost(pkg: String, name: String) {
        hideBanner()
        val b = BoostBanner(this, loadIcon(pkg), name)
        val l = topWindow(dp(310f), dp(84f), false)
        try {
            wm.addView(b, l)
        } catch (t: Throwable) {
            if (root == null && !pinned) showOverlay()
            return
        }
        banner = b
        b.alpha = 0f
        b.translationY = -dp(26f).toFloat()
        b.animate().alpha(1f).translationY(0f).setDuration(260).start()
        val app = applicationContext
        // whatever the boost does, the status must come up: after the result, or after 5 seconds at the latest
        main.postDelayed({
            if (curGame == pkg && root == null && !pinned) { AutoLog.note("boost slow, showing the overlay anyway"); showOverlay(); syncBadge() }
        }, 5000L)
        Thread {
            var freed = 0L
            try {
                val r = Boost.run(app, pkg) { t, pr -> main.post { b.setProgress(pr, t) } }
                freed = r.freedMb
                AutoLog.note("boost done: +$freed MB")
            } catch (t: Throwable) {
                AutoLog.note("boost failed: $t")
            }
            main.post {
                b.finish(freed)
                // let the result sink in, then bring up the status overlay on top of the game
                main.postDelayed({
                    if (curGame == pkg && root == null && !pinned) showOverlay()
                    syncBadge()
                }, 2300L)
                main.postDelayed({ if (banner === b) hideBanner() }, 3000L)
            }
        }.start()
    }

    private fun hideBanner() {
        val b = banner ?: return
        banner = null
        b.animate().alpha(0f).translationY(-dp(20f).toFloat()).setDuration(240).withEndAction {
            try { wm.removeView(b) } catch (t: Throwable) { }
        }.start()
    }

    private fun showChip(v: HudChip, kind: Int, hideAfterMs: Long) {
        hideChip()
        val l = topWindow(dp(320f), dp(58f), true)
        try { wm.addView(v, l) } catch (t: Throwable) { return }
        chip = v
        chipKind = kind
        v.alpha = 0f
        v.translationY = -dp(20f).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(240).start()
        main.removeCallbacks(chipHider)
        main.postDelayed(chipHider, hideAfterMs)
    }

    private fun hideChip() {
        main.removeCallbacks(chipHider)
        val v = chip ?: return
        chip = null
        chipKind = 0
        v.animate().alpha(0f).translationY(-dp(16f).toFloat()).setDuration(200).withEndAction {
            try { wm.removeView(v) } catch (t: Throwable) { }
        }.start()
    }

    private fun showShizukuChip() {
        val c = applicationContext
        val st = FpsClient.state(c)
        val (title, sub) = when (st) {
            FpsClient.St.NOT_INSTALLED -> Pair("FPS needs Shizuku", "It isn't installed. Tap to open Frameline")
            FpsClient.St.NOT_RUNNING -> Pair("Shizuku is off", "FPS can't be read. Tap to open Shizuku")
            FpsClient.St.NO_PERMISSION -> Pair("Allow Frameline in Shizuku", "Tap to allow, then FPS turns on")
            FpsClient.St.READY -> return
        }
        val v = HudChip(this, title, sub, 0)
        v.onTap = { onShizukuChipTap() }
        showChip(v, 1, 16_000L)
    }

    private fun onShizukuChipTap() {
        when (FpsClient.state(applicationContext)) {
            FpsClient.St.NOT_RUNNING -> openApp(SHIZUKU_PKG)
            FpsClient.St.NO_PERMISSION -> { try { Shizuku.requestPermission(21) } catch (t: Throwable) { } }
            FpsClient.St.NOT_INSTALLED -> {
                try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (t: Throwable) { }
            }
            FpsClient.St.READY -> { }
        }
    }

    private fun showReturnChip(pkg: String, name: String) {
        val v = HudChip(this, "Shizuku is on", "Tap to go back to $name", 1)
        v.onTap = { openApp(pkg); hideChip() }
        showChip(v, 2, 45_000L)
    }

    private fun openApp(pkg: String) {
        try {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        } catch (t: Throwable) {
            android.widget.Toast.makeText(applicationContext, "Could not open it", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    /** The icon of the game being played, pinned beside the corner of the status overlay. */
    private fun syncBadge() {
        val r = root
        val g = curGame
        if (r == null || g == null || !Prefs.bool(this, Prefs.OV_ICON, true)) { hideBadge(); return }
        val size = dp(30f)
        val gap = dp(4f)
        val sc = screen()
        var x = lp.x - size - gap
        var y = lp.y
        if (x < 0) { x = lp.x; y = lp.y - size - gap }
        if (y < 0) { x = lp.x + r.width + gap; y = lp.y }
        x = x.coerceIn(0, maxOf(0, sc[0] - size))
        y = y.coerceIn(0, maxOf(0, sc[1] - size))
        val b = badge
        if (b != null && badgePkg == g) {
            val l = badgeLp
            if (l != null && (l.x != x || l.y != y)) {
                l.x = x; l.y = y
                try { wm.updateViewLayout(b, l) } catch (t: Throwable) { }
            }
            return
        }
        hideBadge()
        val v = GameBadge(this, loadIcon(g))
        val l = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        l.x = x; l.y = y
        l.alpha = lp.alpha
        try {
            wm.addView(v, l)
            badge = v; badgeLp = l; badgePkg = g
        } catch (t: Throwable) { }
    }

    private fun hideBadge() {
        val b = badge ?: return
        badge = null; badgeLp = null; badgePkg = null
        try { wm.removeView(b) } catch (t: Throwable) { }
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Overlay watch", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val lock = PendingIntent.getService(
            this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_TOGGLE_LOCK), PendingIntent.FLAG_IMMUTABLE
        )
        val snd = PendingIntent.getService(
            this, 3, Intent(this, OverlayService::class.java).setAction(ACTION_TOGGLE_SOUND), PendingIntent.FLAG_IMMUTABLE
        )
        val locked = Prefs.bool(this, Prefs.LOCKED, false)
        val soundOn = Prefs.bool(this, Prefs.SOUND, false)
        val hasVideo = Prefs.str(this, Prefs.MEDIA_TYPE, "") == "video"
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(if (shown) "Frameline is running" else "Frameline is watching for games")
            .setContentText(
                if (!shown) "Auto mode: open a game and the status shows up."
                else if (locked) "Locked - touches pass through to the game." else "Unlocked - drag the overlay anywhere."
            )
            .setContentIntent(open)
            .setOngoing(true)

        b.addAction(Notification.Action.Builder(icon, "Stop", stop).build())
        return b.build()
    }
}

/** Invisible touch area. Sits over an icon of a locked overlay so only that spot catches taps. */
class TapSpot(ctx: Context) : View(ctx) {
    var onTap: (() -> Unit)? = null

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}

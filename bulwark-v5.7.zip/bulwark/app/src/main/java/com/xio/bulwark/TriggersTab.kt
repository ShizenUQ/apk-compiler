package com.xio.bulwark

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

/** The big banner at the top of the Triggers tab. */
private class FxHero(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val r = RectF()
    private var bg: Shader? = null
    var animCount = 0
    var soundCount = 0

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 158f))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bg = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xF0142230.toInt(), 0xF00A0F15.toInt(), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat()
        val h = height.toFloat()
        CyUi.chamfer(path, d, d, w - d, h - d, 24 * d)
        p.style = Paint.Style.FILL
        p.shader = bg
        c.drawPath(path, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Cy.a(Cy.CYAN, 0.4f)
        c.drawPath(path, p)
        p.strokeWidth = 2.6f * d
        p.strokeCap = Paint.Cap.BUTT
        p.color = Cy.PINK
        c.drawLine(d, 30 * d, d, 3 * d, p)
        c.drawLine(d, 3 * d, 58 * d, 3 * d, p)
        p.color = Cy.CYAN
        c.drawLine(w - 58 * d, h - 3 * d, w - 30 * d, h - 3 * d, p)

        CyUi.text(c, p, "TRIGGERS", 20 * d, 22 * d, 3.2f * d, Cy.CYAN, 1f, true, 0)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 12.5f * d
        p.textAlign = Paint.Align.LEFT
        p.color = P.DIM
        c.drawText("Make animations. Let sounds play them.", 20 * d, 82 * d, p)

        // equaliser bars: they move with what is heard while listening, otherwise they breathe
        val t = Neon.now()
        val listening = CaptureBus.running
        val lv = CaptureBus.level
        val bx0 = w - 104 * d
        for (i in 0 until 9) {
            val idle = 0.12f + 0.1f * (0.5f + 0.5f * sin(t * 1.6f + i * 0.7f))
            val live = lv * (0.45f + 0.55f * abs(sin(t * 7f + i * 1.3f)))
            val f = if (listening) maxOf(idle, live) else idle
            val bh = (8f + 52f * f) * d
            val x = bx0 + i * 9.5f * d
            p.color = Cy.a(if (listening) Cy.PINK else Cy.CYAN, if (listening) 0.95f else 0.5f)
            r.set(x, 40 * d + (60 * d - bh) / 2f, x + 5 * d, 40 * d + (60 * d + bh) / 2f)
            c.drawRect(r, p)
        }

        // little status chips along the bottom
        val k = 0.85f * d
        var x = 20f * d
        val y = h - 34f * d
        val items = listOf("ANIMATIONS  " + animCount, "SOUND TRIGGERS  " + soundCount, if (listening) "LISTENING" else "LISTENING OFF")
        for ((i, s) in items.withIndex()) {
            val wTxt = CyUi.width(s, k)
            val on = i == 2 && listening
            val col = if (on) Cy.PINK else Cy.CYAN
            r.set(x, y, x + wTxt + 16 * d, y + 22 * d)
            p.style = Paint.Style.FILL
            p.color = Cy.a(col, 0.14f)
            c.drawRect(r, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f * d
            p.color = Cy.a(col, 0.55f)
            c.drawRect(r, p)
            CyUi.text(c, p, s, x + 8 * d, y + 6 * d, k, 0xFFEAFBFF.toInt(), 1f, false, 0)
            x += wTxt + 16 * d + 8 * d
        }
        postInvalidateDelayed(66)
    }
}

/** A row of round colour choices. */
private class SwatchRow(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var selected = -1
    var onPick: ((Int) -> Unit)? = null

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 46f))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val n = FxStore.swatches.size
            val i = (e.x / (width.toFloat() / n)).toInt().coerceIn(0, n - 1)
            selected = i
            invalidate()
            onPick?.invoke(FxStore.swatches[i])
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val n = FxStore.swatches.size
        val cw = width.toFloat() / n
        for (i in 0 until n) {
            val cx = cw * i + cw / 2f
            val cy = height / 2f
            p.style = Paint.Style.FILL
            p.color = FxStore.swatches[i]
            c.drawCircle(cx, cy, (if (i == selected) 13f else 11f) * d, p)
            if (i == selected) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f * d
                p.color = 0xFFFFFFFF.toInt()
                c.drawCircle(cx, cy, 17f * d, p)
            }
        }
    }
}

class TriggersTab(private val act: Activity, private val page: ScrollView, private val cards: ArrayList<View>) {
    private val d = act.resources.displayMetrics.density
    private fun dp(v: Float) = (v * d).toInt()
    private val ui = Handler(Looper.getMainLooper())
    private val col = LinearLayout(act)

    private lateinit var hero: FxHero
    private lateinit var stage: FxStage
    private lateinit var animBox: LinearLayout
    private lateinit var custBox: LinearLayout
    private val groupA = LinearLayout(act)
    private val groupB = LinearLayout(act)
    private lateinit var segA: PButton
    private lateinit var segB: PButton
    private lateinit var snd: SoundSection
    private val ux = FxUi(act, cards)
    private var selLayer = -1
    private val layerSync = ArrayList<() -> Unit>()
    private var editBox: LinearLayout? = null
    private var stepsBox: LinearLayout? = null
    private val stepNames = ArrayList<TextView>()
    private val stepSubs = ArrayList<TextView>()
    private val stepDots = ArrayList<TextView>()

    private var selId = "b_victory"
    private var selStep = 0
    private var building = false
    private val tick = object : Runnable {
        override fun run() {
            if (page.visibility != View.VISIBLE) return
            if (groupB.visibility == View.VISIBLE) snd.tick()
            hero.soundCount = TriggerStore.all(act).size
            hero.invalidate()
            ui.postDelayed(this, 300)
        }
    }

    // ---------- small builders ----------

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(act)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        t.typeface = Typeface.create("sans-serif-medium", if (bold) Typeface.BOLD else Typeface.NORMAL)
        return t
    }

    private fun label(s: String): TextView {
        val t = tv(s, 12f, P.DIM)
        t.setPadding(0, dp(12f), 0, dp(4f))
        return t
    }

    private fun card(title: String): LinearLayout {
        val c = NeonCard(act)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16f), dp(14f), dp(16f), dp(16f))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(12f)
        c.layoutParams = lp
        c.addView(CyTitle(act, title.uppercase(), "", Cy.CYAN))
        (if (building) groupA else col).addView(c)
        cards.add(c)
        return c
    }

    private fun row(title: String, sub: String?, ctl: View): LinearLayout {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(9f), 0, dp(9f))
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.addView(tv(title, 15f, P.TEXT))
        if (sub != null) c.addView(tv(sub, 11.5f, P.DIM))
        r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(ctl, LinearLayout.LayoutParams(-2, -2))
        return r
    }

    private fun toast(s: String) { Toast.makeText(act, s, Toast.LENGTH_SHORT).show() }

    private fun ask(title: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(act)
        et.setText(initial)
        et.setSelection(et.text.length)
        et.setSingleLine(true)
        AlertDialog.Builder(act).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> ok(et.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun cur(): FxAnim? = FxStore.get(act, selId) ?: FxStore.all(act).firstOrNull()

    private fun secs(ms: Int) = String.format(Locale.US, "%.1f s", ms / 1000f)

    private fun describe(e: FxEffect): String =
        String.format(Locale.US, "%.1f s to %.1f s", e.startMs / 1000f, (e.startMs + e.durMs) / 1000f) +
            (if (e.type == FxType.TEXT) "   \"" + e.text + "\"" else "")

    // ---------- build ----------

    fun build() {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        page.addView(col, FrameLayout.LayoutParams(-1, -2))
        page.overScrollMode = View.OVER_SCROLL_NEVER

        val all = FxStore.all(act)
        selId = Prefs.str(act, "fx_sel", "b_victory")
        if (all.none { it.id == selId }) selId = all.first().id

        hero = FxHero(act)
        val hl = LinearLayout.LayoutParams(-1, -2)
        hl.topMargin = dp(8f)
        col.addView(hero, hl)
        cards.add(hero)

        segA = PButton(act, "Animations", 0, 46f)
        segA.onClick = { showGroup(false) }
        segB = PButton(act, "Sounds", 1, 46f)
        segB.onClick = { showGroup(true) }
        val seg = ux.buttons(segA, segB)
        col.addView(seg, ux.top(seg, 12f))
        groupA.orientation = LinearLayout.VERTICAL
        groupB.orientation = LinearLayout.VERTICAL
        col.addView(groupA, LinearLayout.LayoutParams(-1, -2))
        col.addView(groupB, LinearLayout.LayoutParams(-1, -2))
        building = true

        // --- stage ---
        val sc = card("Stage")
        stage = FxStage(act)
        stage.loop = Prefs.bool(act, "fx_loop", false)
        stage.onTap = { stage.anim = cur(); stage.play() }
        stage.onStart = { cur()?.let { FxAudio.play(it.audio, it.volume) } }
        stage.onLayerSelect = { i -> selLayer = i; layerSync.forEach { it() } ; renderLayerRows() }
        stage.onLayerMoved = { layerSync.forEach { it() }; ui.removeCallbacks(saveLater); ui.postDelayed(saveLater, 600) }
        val sl = LinearLayout.LayoutParams(-1, -2)
        sl.topMargin = dp(6f)
        sc.addView(stage, sl)
        val br = LinearLayout(act)
        br.orientation = LinearLayout.HORIZONTAL
        val bPlay = PButton(act, "Play", 0, 44f)
        bPlay.onClick = { stage.anim = cur(); stage.play() }
        val bStop = PButton(act, "Stop", 1, 44f)
        bStop.onClick = { stage.stop() }
        val l1 = LinearLayout.LayoutParams(0, -2, 1f)
        l1.rightMargin = dp(8f)
        br.addView(bPlay, l1)
        br.addView(bStop, LinearLayout.LayoutParams(0, -2, 1f))
        val bl = LinearLayout.LayoutParams(-1, -2)
        bl.topMargin = dp(12f)
        sc.addView(br, bl)
        val swLoop = PSwitch(act)
        swLoop.setChecked(stage.loop)
        swLoop.onChange = { v ->
            Prefs.putBool(act, "fx_loop", v)
            stage.loop = v
            if (v) { stage.anim = cur(); stage.play() }
        }
        sc.addView(row("Loop", "Keep replaying while you adjust", swLoop))

        // --- animations list ---
        val ac = card("Animations")
        animBox = LinearLayout(act)
        animBox.orientation = LinearLayout.VERTICAL
        ac.addView(animBox)
        val ar = LinearLayout(act)
        ar.orientation = LinearLayout.HORIZONTAL
        val bNew = PButton(act, "Create", 0, 44f)
        bNew.onClick = { createAnim() }
        val bDup = PButton(act, "Duplicate", 1, 44f)
        bDup.onClick = { dupAnim() }
        val bDel = PButton(act, "Delete", 2, 44f)
        bDel.onClick = { delAnim() }
        val a1 = LinearLayout.LayoutParams(0, -2, 1f)
        a1.rightMargin = dp(6f)
        val a2 = LinearLayout.LayoutParams(0, -2, 1f)
        a2.rightMargin = dp(6f)
        ar.addView(bNew, a1)
        ar.addView(bDup, a2)
        ar.addView(bDel, LinearLayout.LayoutParams(0, -2, 1f))
        val arl = LinearLayout.LayoutParams(-1, -2)
        arl.topMargin = dp(12f)
        ac.addView(ar, arl)
        delBtn = bDel

        // --- customize ---
        val cc = card("Customize")
        custBox = LinearLayout(act)
        custBox.orientation = LinearLayout.VERTICAL
        cc.addView(custBox)

        building = false
        // --- group B: sounds ---
        snd = SoundSection(ux, groupB)
        groupB.visibility = View.GONE
        showGroup(Prefs.str(act, "fx_group", "a") == "b")
    }

    private fun showGroup(b: Boolean) {
        Prefs.putStr(act, "fx_group", if (b) "b" else "a")
        groupA.visibility = if (b) View.GONE else View.VISIBLE
        groupB.visibility = if (b) View.VISIBLE else View.GONE
        segA.set("Animations", if (b) 1 else 0)
        segB.set("Sounds", if (b) 0 else 1)
        if (b) { stage.stop(); snd.refresh() }
        hero.invalidate()
    }

    private lateinit var delBtn: PButton

    // ---------- animations ----------

    private fun renderAnims() {
        animBox.removeAllViews()
        val all = FxStore.all(act)
        animBox.addView(label("Built-in"))
        for (a in all) if (a.builtIn) animBox.addView(animRow(a))
        animBox.addView(label("My animations"))
        var mine = 0
        for (a in all) if (!a.builtIn) { animBox.addView(animRow(a)); mine++ }
        if (mine == 0) {
            val t = tv("Nothing here yet. Tap Create to make your own.", 12.5f, P.DIM)
            t.setPadding(0, dp(4f), 0, dp(4f))
            animBox.addView(t)
        }
        val a = cur()
        delBtn.set(if (a != null && a.builtIn) "Reset" else "Delete", if (a != null && a.builtIn) 1 else 2)
        hero.animCount = all.size
        hero.soundCount = TriggerStore.all(act).size
    }

    private fun animRow(a: FxAnim): View {
        val on = a.id == selId
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = CutDrawable(
            if (on) 0x3319E6F2 else 0x0FFFFFFF,
            if (on) 0xCC19E6F2.toInt() else 0x33FFFFFF,
            dp(1f).toFloat(), dp(10f).toFloat()
        )
        r.setPadding(dp(14f), dp(10f), dp(12f), dp(10f))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(6f)
        r.layoutParams = lp
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.addView(tv(a.name, 15f, if (on) 0xFFFFFFFF.toInt() else P.TEXT, on))
        c.addView(tv(a.effects.size.toString() + " steps  -  " + secs(a.totalMs()) + (if (a.layers.isNotEmpty()) "  -  " + a.layers.size + " pictures" else ""), 11.5f, P.DIM))
        r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        val tag = tv(if (a.builtIn) "BUILT-IN" else "MINE", 9.5f, if (on) Cy.CYAN else P.DIM)
        tag.letterSpacing = 0.12f
        r.addView(tag)
        r.setOnClickListener { select(a.id, true) }
        return r
    }

    private fun select(id: String, play: Boolean) {
        selId = id
        selStep = 0
        selLayer = -1
        stage.editMode = false
        Prefs.putStr(act, "fx_sel", id)
        renderAnims()
        renderCustomize()
        stage.anim = cur()
        if (play) stage.play()
    }

    private fun createAnim() {
        val all = FxStore.all(act)
        var n = 1
        while (all.any { it.name == "My animation $n" }) n++
        val a = FxAnim(FxStore.newId(), "My animation $n", false)
        a.effects.add(FxEffect(FxType.COMET, FxStore.CYAN, 70, 50, 0, 1500))
        FxStore.add(act, a)
        select(a.id, true)
    }

    private fun dupAnim() {
        val a = cur() ?: return
        val b = a.copyAs(FxStore.newId(), a.name + " copy")
        FxStore.add(act, b)
        select(b.id, true)
    }

    private fun delAnim() {
        val a = cur() ?: return
        if (a.builtIn) {
            FxStore.reset(act, a.id)
            select(a.id, true)
            toast("Back to how it came")
            return
        }
        AlertDialog.Builder(act).setTitle("Delete \"" + a.name + "\"?")
            .setPositiveButton("Delete") { _, _ ->
                FxStore.remove(act, a.id)
                select(FxStore.all(act).first().id, false)
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- customize ----------

    private val replay = Runnable {
        FxStore.save(act)
        stage.anim = cur()
        stage.play()
    }

    private fun changed() {
        refreshStepRow()
        ui.removeCallbacks(replay)
        ui.postDelayed(replay, 450)
    }

    private fun refreshStepRow() {
        val a = cur() ?: return
        val e = a.effects.getOrNull(selStep) ?: return
        stepNames.getOrNull(selStep)?.text = FxType.names[e.type]
        stepSubs.getOrNull(selStep)?.text = describe(e)
        stepDots.getOrNull(selStep)?.setTextColor(dotColor(e))
    }

    private fun dotColor(e: FxEffect) = if (e.type == FxType.SHAKE) 0xFFB0BAC6.toInt() else e.color

    private fun renderCustomize() {
        custBox.removeAllViews()
        val a = cur() ?: return

        // name
        val nr = LinearLayout(act)
        nr.orientation = LinearLayout.HORIZONTAL
        nr.gravity = Gravity.CENTER_VERTICAL
        val nm = tv(a.name, 17f, 0xFFFFFFFF.toInt(), true)
        nr.addView(nm, LinearLayout.LayoutParams(0, -2, 1f))
        if (!a.builtIn) {
            val rn = PButton(act, "Rename", 1, 38f)
            rn.onClick = {
                ask("Name", a.name) { s ->
                    if (s.isNotEmpty()) { a.name = s; FxStore.save(act); nm.text = s; renderAnims() }
                }
            }
            nr.addView(rn, LinearLayout.LayoutParams(dp(110f), -2))
        }
        custBox.addView(nr)

        custBox.addView(label("Steps. They run on one timeline, so several can play at once."))
        val sb = LinearLayout(act)
        sb.orientation = LinearLayout.VERTICAL
        stepsBox = sb
        custBox.addView(sb)
        renderSteps()

        val br = LinearLayout(act)
        br.orientation = LinearLayout.HORIZONTAL
        val bAdd = PButton(act, "Add step", 0, 42f)
        bAdd.onClick = {
            val x = cur()
            if (x != null) {
                x.effects.add(FxEffect(FxType.GLOW, FxStore.CYAN, 70, 50, 0, 1500))
                selStep = x.effects.size - 1
                FxStore.save(act)
                renderSteps(); renderEditor(); renderAnims()
                changed()
            }
        }
        val bCopy = PButton(act, "Copy step", 1, 42f)
        bCopy.onClick = {
            val x = cur()
            val e = x?.effects?.getOrNull(selStep)
            if (x != null && e != null) {
                x.effects.add(e.copy())
                selStep = x.effects.size - 1
                FxStore.save(act)
                renderSteps(); renderEditor(); renderAnims()
                changed()
            }
        }
        val bRem = PButton(act, "Remove", 2, 42f)
        bRem.onClick = {
            val x = cur()
            if (x != null && x.effects.isNotEmpty() && selStep in x.effects.indices) {
                x.effects.removeAt(selStep)
                selStep = (selStep - 1).coerceAtLeast(0)
                FxStore.save(act)
                renderSteps(); renderEditor(); renderAnims()
                changed()
            }
        }
        val c1 = LinearLayout.LayoutParams(0, -2, 1f)
        c1.rightMargin = dp(6f)
        val c2 = LinearLayout.LayoutParams(0, -2, 1f)
        c2.rightMargin = dp(6f)
        br.addView(bAdd, c1)
        br.addView(bCopy, c2)
        br.addView(bRem, LinearLayout.LayoutParams(0, -2, 1f))
        val brl = LinearLayout.LayoutParams(-1, -2)
        brl.topMargin = dp(10f)
        custBox.addView(br, brl)

        val eb = LinearLayout(act)
        eb.orientation = LinearLayout.VERTICAL
        editBox = eb
        custBox.addView(eb)
        renderEditor()

        val pb = LinearLayout(act)
        pb.orientation = LinearLayout.VERTICAL
        picBox = pb
        custBox.addView(pb)
        renderLayerRows()
        val ab = LinearLayout(act)
        ab.orientation = LinearLayout.VERTICAL
        custBox.addView(ab)
        renderAudio(ab)
    }

    private var picBox: LinearLayout? = null

    private fun divider(into: LinearLayout) {
        val line = View(act)
        line.setBackgroundColor(0x2219E6F2)
        into.addView(line, ux.top(line, 18f, -1, 1))
    }

    private fun choice(into: LinearLayout, title: String, names: Array<String>, get: () -> Int, put: (Int) -> Unit) {
        into.addView(label(title))
        val bs = ArrayList<PButton>()
        val paint = { for ((i, b) in bs.withIndex()) b.set(names[i], if (get() == i) 0 else 1) }
        for ((i, n) in names.withIndex()) {
            val b = PButton(act, n, 1, 38f)
            b.onClick = { put(i); paint(); changed() }
            bs.add(b)
        }
        paint()
        into.addView(ux.buttons(*bs.toTypedArray()))
    }

    private fun renderLayerRows() {
        val pb = picBox ?: return
        pb.removeAllViews()
        layerSync.clear()
        val a = cur() ?: return
        divider(pb)
        pb.addView(label("Pictures. Add from your gallery, then drag them on the stage."))
        val ar = LinearLayout(act)
        ar.orientation = LinearLayout.HORIZONTAL
        val bAdd = PButton(act, "Add picture", 0, 42f)
        bAdd.onClick = {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
            try { act.startActivityForResult(i, 73) } catch (t: Throwable) { ux.toast("No picker found") }
        }
        val bCopy = PButton(act, "Copy", 1, 42f)
        bCopy.onClick = {
            val l = a.layers.getOrNull(selLayer)
            if (l != null) {
                val c = l.copy(); c.x = (c.x + 0.05f).coerceAtMost(1f); c.y = (c.y + 0.05f).coerceAtMost(1f)
                a.layers.add(c); selLayer = a.layers.size - 1
                FxStore.save(act); stage.selLayer = selLayer; renderLayerRows(); renderAnims(); stage.invalidate()
            }
        }
        val bRem = PButton(act, "Remove", 2, 42f)
        bRem.onClick = {
            if (selLayer in a.layers.indices) {
                a.layers.removeAt(selLayer)
                selLayer = a.layers.size - 1
                FxStore.save(act); stage.selLayer = selLayer; renderLayerRows(); renderAnims(); stage.invalidate()
                changed()
            }
        }
        pb.addView(ux.buttons(bAdd, bCopy, bRem))

        // place mode
        val sw = PSwitch(act)
        sw.setChecked(stage.editMode)
        sw.onChange = { v ->
            ui.removeCallbacks(replay)
            stage.anim = a
            stage.selLayer = selLayer
            stage.editMode = v
            if (!v) { stage.anim = cur(); stage.play() }
        }
        pb.addView(row("Place pictures on stage", "Drag to move, pinch to make bigger or smaller", sw))

        if (a.layers.isEmpty()) {
            pb.addView(tv("No pictures yet.", 12.5f, P.DIM))
            return
        }
        if (selLayer !in a.layers.indices) selLayer = 0
        stage.selLayer = selLayer
        for ((i, l) in a.layers.withIndex()) {
            val on = i == selLayer
            val r = LinearLayout(act)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.background = CutDrawable(
                if (on) 0x3319E6F2 else 0x0FFFFFFF, if (on) 0xCC19E6F2.toInt() else 0x33FFFFFF,
                dp(1f).toFloat(), dp(9f).toFloat()
            )
            r.setPadding(dp(10f), dp(8f), dp(12f), dp(8f))
            r.layoutParams = ux.top(r, 5f)
            val th = android.widget.ImageView(act)
            th.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            try {
                val o = android.graphics.BitmapFactory.Options(); o.inSampleSize = 8
                th.setImageBitmap(android.graphics.BitmapFactory.decodeFile(l.path, o))
            } catch (t: Throwable) { }
            r.addView(th, LinearLayout.LayoutParams(dp(44f), dp(44f)))
            val c = LinearLayout(act)
            c.orientation = LinearLayout.VERTICAL
            c.setPadding(dp(12f), 0, 0, 0)
            c.addView(tv("Picture " + (i + 1), 14f, if (on) 0xFFFFFFFF.toInt() else P.TEXT, on))
            c.addView(tv((l.scale * 100).toInt().toString() + "%  -  " + secs(l.startMs) + " to " + secs(l.startMs + l.durMs), 11f, P.DIM))
            r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
            val idx = i
            r.setOnClickListener { selLayer = idx; stage.selLayer = idx; stage.invalidate(); renderLayerRows() }
            pb.addView(r)
        }
        val l = a.layers[selLayer]
        pb.addView(label("Picture " + (selLayer + 1) + " settings"))
        fun sl(title: (Int) -> String, lo: Int, hi: Int, get: () -> Int, put: (Int) -> Unit) {
            val lab = label(title(get()))
            pb.addView(lab)
            val s = PSlider(act, lo, hi)
            s.setValue(get())
            s.onValue = { x -> put(x); lab.text = title(x); changed() }
            layerSync.add { s.setValue(get().coerceIn(lo, hi)); lab.text = title(get()) }
            pb.addView(s, LinearLayout.LayoutParams(-1, -2))
        }
        sl({ "Size  $it %" }, 10, 400, { (l.scale * 100).toInt() }) { l.scale = it / 100f }
        sl({ "Rotate  $it deg" }, -180, 180, { l.rot.toInt() }) { l.rot = it.toFloat() }
        sl({ "Opacity  $it %" }, 5, 100, { (l.alpha * 100).toInt() }) { l.alpha = it / 100f }
        sl({ "Starts at  " + secs(it * 100) }, 0, 100, { l.startMs / 100 }) { l.startMs = it * 100 }
        sl({ "Lasts  " + secs(it * 100) }, 2, 100, { (l.durMs / 100).coerceIn(2, 100) }) { l.durMs = it * 100 }
        choice(pb, "Enter", arrayOf("None", "Fade", "Pop", "Slide"), { l.intro }) { l.intro = it }
        choice(pb, "Exit", arrayOf("None", "Fade", "Shrink"), { l.outro }) { l.outro = it }
        val bc = PButton(act, "Centre on stage", 1, 40f)
        bc.onClick = { l.x = 0.5f; l.y = 0.5f; stage.invalidate(); FxStore.save(act); changed() }
        pb.addView(bc, ux.top(bc, 10f))
    }

    private fun renderAudio(ab: LinearLayout) {
        val a = cur() ?: return
        divider(ab)
        ab.addView(label("Sound. Plays together with the animation."))
        if (a.audio.isEmpty() || !java.io.File(a.audio).exists()) {
            val b = PButton(act, "Add sound", 0, 42f)
            b.onClick = {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*")
                try { act.startActivityForResult(i, 74) } catch (t: Throwable) { ux.toast("No picker found") }
            }
            ab.addView(b)
            return
        }
        ab.addView(tv("Sound attached", 14f, P.TEXT))
        val lab = label("Volume  " + a.volume + " %")
        ab.addView(lab)
        val s = PSlider(act, 0, 100)
        s.setValue(a.volume)
        s.onValue = { v -> a.volume = v; lab.text = "Volume  $v %"; ui.removeCallbacks(saveLater); ui.postDelayed(saveLater, 500) }
        ab.addView(s, LinearLayout.LayoutParams(-1, -2))
        val bt = PButton(act, "Test sound", 1, 40f)
        bt.onClick = { FxAudio.play(a.audio, a.volume) }
        val bs = PButton(act, "Stop", 1, 40f)
        bs.onClick = { FxAudio.stop() }
        val br = PButton(act, "Remove", 2, 40f)
        br.onClick = { FxAudio.stop(); a.audio = ""; FxStore.save(act); renderCustomize() }
        ab.addView(ux.buttons(bt, bs, br), ux.top(bt, 10f))
    }

    private val saveLater = Runnable { FxStore.save(act) }

    private fun renderSteps() {
        val sb = stepsBox ?: return
        val a = cur() ?: return
        sb.removeAllViews()
        stepNames.clear(); stepSubs.clear(); stepDots.clear()
        if (a.effects.isEmpty()) {
            sb.addView(tv("No steps yet. Tap Add step.", 12.5f, P.DIM))
            return
        }
        if (selStep !in a.effects.indices) selStep = 0
        for ((i, e) in a.effects.withIndex()) {
            val on = i == selStep
            val r = LinearLayout(act)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.background = CutDrawable(
                if (on) 0x3319E6F2 else 0x0FFFFFFF,
                if (on) 0xCC19E6F2.toInt() else 0x33FFFFFF,
                dp(1f).toFloat(), dp(9f).toFloat()
            )
            r.setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(5f)
            r.layoutParams = lp
            val num = tv((i + 1).toString(), 13f, if (on) Cy.CYAN else P.DIM, true)
            num.setPadding(0, 0, dp(12f), 0)
            r.addView(num)
            val c = LinearLayout(act)
            c.orientation = LinearLayout.VERTICAL
            val n = tv(FxType.names[e.type], 14f, if (on) 0xFFFFFFFF.toInt() else P.TEXT, on)
            val s = tv(describe(e), 11f, P.DIM)
            c.addView(n)
            c.addView(s)
            r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
            val dot = tv("●", 16f, dotColor(e))
            r.addView(dot)
            stepNames.add(n); stepSubs.add(s); stepDots.add(dot)
            val idx = i
            r.setOnClickListener {
                selStep = idx
                renderSteps()
                renderEditor()
            }
            sb.addView(r)
        }
    }

    private fun slider(parent: LinearLayout, title: (Int) -> String, lo: Int, hi: Int, v: Int, put: (Int) -> Unit) {
        val lab = label(title(v))
        parent.addView(lab)
        val s = PSlider(act, lo, hi)
        s.setValue(v)
        s.onValue = { x -> put(x); lab.text = title(x); changed() }
        parent.addView(s, LinearLayout.LayoutParams(-1, -2))
    }

    private fun renderEditor() {
        val eb = editBox ?: return
        eb.removeAllViews()
        val a = cur() ?: return
        val e = a.effects.getOrNull(selStep) ?: return

        val line = View(act)
        line.setBackgroundColor(0x2219E6F2)
        val ll = LinearLayout.LayoutParams(-1, 1)
        ll.topMargin = dp(14f)
        eb.addView(line, ll)
        eb.addView(label("Step " + (selStep + 1) + " settings"))

        // type
        val tr = LinearLayout(act)
        tr.orientation = LinearLayout.HORIZONTAL
        tr.gravity = Gravity.CENTER_VERTICAL
        val prev = PButton(act, "<", 1, 42f)
        val next = PButton(act, ">", 1, 42f)
        val tn = tv(FxType.names[e.type], 16f, 0xFFFFFFFF.toInt(), true)
        tn.gravity = Gravity.CENTER
        val cycle = { dir: Int ->
            val n = FxType.names.size
            e.type = ((e.type + dir) % n + n) % n
            if (e.type == FxType.TEXT && e.text.isEmpty()) e.text = "WIN"
            changed()
            renderEditor()
        }
        prev.onClick = { cycle(-1) }
        next.onClick = { cycle(1) }
        tr.addView(prev, LinearLayout.LayoutParams(dp(56f), -2))
        tr.addView(tn, LinearLayout.LayoutParams(0, -2, 1f))
        tr.addView(next, LinearLayout.LayoutParams(dp(56f), -2))
        eb.addView(tr)
        val hint = tv(FxType.hints[e.type], 11.5f, P.DIM)
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, dp(4f), 0, 0)
        eb.addView(hint, LinearLayout.LayoutParams(-1, -2))

        if (e.type != FxType.SHAKE) {
            eb.addView(label("Colour"))
            val sw = SwatchRow(act)
            sw.selected = FxStore.swatches.indexOfFirst { it == e.color }
            sw.onPick = { cc -> e.color = cc; changed() }
            eb.addView(sw, LinearLayout.LayoutParams(-1, -2))
        }
        if (e.type == FxType.TEXT) {
            val tb = PButton(act, "Change", 1, 38f)
            val tl = tv("Word:  " + e.text, 14f, P.TEXT)
            tb.onClick = {
                ask("Word to show", e.text) { s ->
                    if (s.isNotEmpty()) { e.text = s.take(16); tl.text = "Word:  " + e.text; changed() }
                }
            }
            val wr = LinearLayout(act)
            wr.orientation = LinearLayout.HORIZONTAL
            wr.gravity = Gravity.CENTER_VERTICAL
            wr.setPadding(0, dp(10f), 0, 0)
            wr.addView(tl, LinearLayout.LayoutParams(0, -2, 1f))
            wr.addView(tb, LinearLayout.LayoutParams(dp(110f), -2))
            eb.addView(wr)
        }
        val powerName = when (e.type) {
            FxType.SHAKE -> "Shake strength"
            FxType.TEXT -> "Size"
            FxType.FLASH -> "Brightness"
            else -> "Power"
        }
        slider(eb, { "$powerName  $it" }, 0, 100, e.power) { e.power = it }
        slider(eb, { "Speed  $it" }, 0, 100, e.speed) { e.speed = it }
        slider(eb, { "Starts at  " + secs(it * 50) }, 0, 60, e.startMs / 50) { e.startMs = it * 50 }
        slider(eb, { "Lasts  " + secs(it * 50) }, 2, 80, (e.durMs / 50).coerceIn(2, 80)) { e.durMs = it * 50 }
    }

    // ---------- lifecycle ----------

    fun refresh() {
        renderAnims()
        renderCustomize()
        stage.anim = cur()
        ui.removeCallbacks(tick)
        ui.post(tick)
        if (groupB.visibility == View.VISIBLE) snd.refresh()
    }

    fun onResult(code: Int, res: Int, data: Intent?): Boolean {
        if (snd.onResult(code, res, data)) { ui.removeCallbacks(tick); ui.post(tick); return true }
        if (res != Activity.RESULT_OK || data?.data == null) return code == 73 || code == 74
        val uri = data.data!!
        val a = cur() ?: return true
        if (code == 73) {
            val f = copyIn(uri, "img_")
            if (f == null) { ux.toast("Could not read that picture"); return true }
            a.layers.add(FxLayer(f.absolutePath, 0.5f, 0.5f, 1f))
            selLayer = a.layers.size - 1
            FxStore.save(act)
            stage.anim = a
            stage.selLayer = selLayer
            renderCustomize(); renderAnims()
            changed()
            return true
        }
        if (code == 74) {
            val f = copyIn(uri, "a_")
            if (f == null) { ux.toast("Could not read that audio"); return true }
            a.audio = f.absolutePath
            FxStore.save(act)
            renderCustomize()
            return true
        }
        return false
    }

    fun onPermission(granted: Boolean) { snd.onPermission(granted) }

    private fun copyIn(uri: android.net.Uri, prefix: String): java.io.File? {
        return try {
            val dir = java.io.File(act.filesDir, "fx")
            dir.mkdirs()
            val f = java.io.File(dir, prefix + System.currentTimeMillis().toString(36))
            act.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } } ?: return null
            if (f.length() == 0L) null else f
        } catch (t: Throwable) { null }
    }
}

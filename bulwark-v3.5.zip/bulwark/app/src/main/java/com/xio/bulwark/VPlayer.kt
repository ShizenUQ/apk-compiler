package com.xio.bulwark

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.view.Surface
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer as Vlc
import org.videolan.libvlc.interfaces.IVLCVout

/**
 * Video engine of the floating player, built on libVLC. It decodes in software when the phone's
 * hardware decoder cannot (10-bit HEVC / H.264, MKV, long HD episodes), and still uses hardware when it can.
 * The methods are named like android.media.MediaPlayer so PlayerHost changes very little.
 * All callbacks arrive on the main thread.
 */
class VPlayer(ctx: Context) {

    companion object {
        @Volatile private var lib: LibVLC? = null
        /** Speed-minded options; if this build of libVLC dislikes any of them, start with none. */
        private fun create(c: Context): LibVLC = try {
            LibVLC(c, arrayListOf("--avcodec-skiploopfilter=1", "--avcodec-fast", "--file-caching=1500"))
        } catch (t: Throwable) {
            LibVLC(c, arrayListOf<String>())
        }
        private fun lib(c: Context): LibVLC = lib ?: synchronized(this) {
            lib ?: create(c.applicationContext).also { lib = it }
        }
    }

    private val app = ctx.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val player = Vlc(lib(app))
    private var pfd: ParcelFileDescriptor? = null
    private var released = false
    private var attached = false
    private var surface: Surface? = null
    private var winW = 0
    private var winH = 0
    private var firstPlay = true
    private var length = 0L
    private var startAt = 0
    private var wantVolume = 100

    var videoWidth = 0
        private set
    var videoHeight = 0
        private set

    /** The first time playback really runs: duration is known. */
    var onReady: ((Int) -> Unit)? = null
    var onVideoSize: ((Int, Int) -> Unit)? = null
    var onEnd: (() -> Unit)? = null
    var onError: (() -> Unit)? = null
    /** Sound is playing but no picture appeared. */
    var onNoPicture: (() -> Unit)? = null

    private val layoutListener = IVLCVout.OnNewVideoLayoutListener { _, w, h, vw, vh, sn, sd ->
        main.post {
            if (released) return@post
            var ww = if (vw > 0) vw else w
            val hh = if (vh > 0) vh else h
            if (sn > 0 && sd > 0) ww = ww * sn / sd
            if (ww > 0 && hh > 0) {
                videoWidth = ww; videoHeight = hh
                onVideoSize?.invoke(ww, hh)
            }
        }
    }

    init {
        player.setEventListener { e ->
            when (e.type) {
                Vlc.Event.Playing -> main.post {
                    if (released) return@post
                    if (firstPlay) {
                        firstPlay = false
                        length = player.length
                        player.volume = wantVolume
                        onReady?.invoke(length.toInt())
                        main.postDelayed({
                            if (!released && player.isPlaying && videoWidth == 0) onNoPicture?.invoke()
                        }, 5000)
                    }
                }
                Vlc.Event.LengthChanged -> length = e.lengthChanged
                Vlc.Event.EndReached -> main.post { if (!released) onEnd?.invoke() }
                Vlc.Event.EncounteredError -> main.post { if (!released) onError?.invoke() }
                else -> {}
            }
        }
    }

    /** Opens the video and starts it. Call setSurface/setSize first so the picture has somewhere to go. */
    fun open(uri: Uri, startAtMs: Int): Boolean {
        return try {
            startAt = startAtMs
            val l = lib(app)
            val media = if (uri.scheme == "content") {
                val f = app.contentResolver.openFileDescriptor(uri, "r") ?: return false
                pfd = f
                Media(l, f.fileDescriptor)
            } else Media(l, uri)
            media.setHWDecoderEnabled(true, false)   // hardware first, software only when the chip cannot do it
            if (startAtMs > 0) media.addOption(":start-time=" + (startAtMs / 1000.0))   // start there: no jump after play
            player.media = media
            media.release()
            player.play()
            true
        } catch (t: Throwable) {
            false
        }
    }

    fun setSurface(s: Surface?) {
        if (released) return
        if (s != null && s === surface && attached) return
        surface = s
        val out = player.vlcVout
        try {
            if (attached) { out.detachViews(); attached = false }
            if (s != null) {
                out.setVideoSurface(s, null)
                if (winW > 0 && winH > 0) out.setWindowSize(winW, winH)
                out.attachViews(layoutListener)
                attached = true
            }
        } catch (t: Throwable) { }
    }

    fun setSize(w: Int, h: Int) {
        winW = w; winH = h
        if (released || !attached) return
        try { player.vlcVout.setWindowSize(w, h) } catch (t: Throwable) { }
    }

    val isPlaying: Boolean get() = try { !released && player.isPlaying } catch (t: Throwable) { false }
    val currentPosition: Int get() = try { if (released) 0 else max0(player.time) } catch (t: Throwable) { 0 }
    val duration: Int get() = try { if (released) 0 else max0(if (length > 0) length else player.length) } catch (t: Throwable) { 0 }

    private fun max0(v: Long): Int = if (v < 0) 0 else if (v > Int.MAX_VALUE) Int.MAX_VALUE else v.toInt()

    fun start() { if (!released) try { player.play() } catch (t: Throwable) { } }
    fun pause() { if (!released) try { player.pause() } catch (t: Throwable) { } }
    fun seekTo(ms: Int) { if (!released) try { player.time = ms.toLong() } catch (t: Throwable) { } }

    fun setVolume(l: Float, r: Float) {
        wantVolume = (maxOf(l, r) * 100f).toInt().coerceIn(0, 100)
        if (!released) try { player.volume = wantVolume } catch (t: Throwable) { }
    }

    fun release() {
        if (released) return
        released = true
        main.removeCallbacksAndMessages(null)
        val p = player
        val f = pfd
        pfd = null
        try { p.setEventListener(null) } catch (t: Throwable) { }
        try { if (attached) p.vlcVout.detachViews() } catch (t: Throwable) { }
        attached = false
        // stopping and releasing can block for a moment, so keep it off the main thread
        Thread {
            try { p.stop() } catch (t: Throwable) { }
            try { p.release() } catch (t: Throwable) { }
            try { f?.close() } catch (t: Throwable) { }
        }.start()
    }
}

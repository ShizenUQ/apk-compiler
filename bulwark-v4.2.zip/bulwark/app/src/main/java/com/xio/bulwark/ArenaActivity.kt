package com.xio.bulwark

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * ARENA: the game hub. A second launcher icon of the same app, always landscape.
 * Opening plays an intro; tapping a game plays a full-screen boost sequence and then starts the game.
 */
class ArenaActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private var d = 1f
    private lateinit var root: FrameLayout
    private lateinit var bg: ArenaBg
    private lateinit var hub: LinearLayout
    private lateinit var strip: LinearLayout
    private var intro: ArenaIntro? = null
    private var seq: ArenaLaunch? = null
    private var launching = false

    private fun dp(v: Float) = (v * d).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        if (Build.VERSION.SDK_INT >= 28) {
            val a = window.attributes
            a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = a
        }
        d = Ui.dp(this, 1f)
        immersive()

        root = FrameLayout(this)
        root.setBackgroundColor(0xFF03050A.toInt())
        bg = ArenaBg(this)
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        buildHub()
        hub.alpha = 0f
        root.addView(hub, FrameLayout.LayoutParams(-1, -1))

        val opening = ArenaIntro(this)
        opening.onHub = { hub.animate().alpha(1f).setDuration(600).start() }
        opening.onDone = { root.removeView(opening); intro = null }
        intro = opening
        root.addView(opening, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        loadBackground()
        loadGames()
    }

    @Suppress("DEPRECATION")
    private fun immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    override fun onBackPressed() {
        if (launching || intro != null) return
        super.onBackPressed()
    }

    // ---------------- layout ----------------

    private fun buildHub() {
        hub = LinearLayout(this)
        hub.orientation = LinearLayout.VERTICAL
        hub.setPadding(dp(34f), dp(12f), dp(34f), dp(12f))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(ArenaTitle(this), LinearLayout.LayoutParams(dp(220f), dp(52f)))
        val chips = ArenaChips(this)
        val clp = LinearLayout.LayoutParams(0, dp(46f), 1f)
        clp.leftMargin = dp(14f); clp.rightMargin = dp(14f)
        top.addView(chips, clp)
        val exit = CyBtn(this, "EXIT", Cy.PINK)
        exit.onClick = { finish() }
        top.addView(exit, LinearLayout.LayoutParams(dp(96f), LinearLayout.LayoutParams.WRAP_CONTENT))
        hub.addView(top, LinearLayout.LayoutParams(-1, -2))

        val sv = HorizontalScrollView(this)
        sv.isHorizontalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.isFillViewport = true
        strip = LinearLayout(this)
        strip.orientation = LinearLayout.HORIZONTAL
        sv.addView(strip, FrameLayout.LayoutParams(-2, -1))
        val slp = LinearLayout.LayoutParams(-1, 0, 1f)
        slp.topMargin = dp(10f); slp.bottomMargin = dp(10f)
        hub.addView(sv, slp)

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        val seg = CySeg(this, listOf("BALANCED", "MAX", "LIGHT"), Cy.CYAN)
        seg.select(Prefs.int(this, "ar_preset", 0))
        applyPreset(seg.selected)
        seg.onSelect = { i -> applyPreset(i) }
        bar.addView(seg, LinearLayout.LayoutParams(dp(330f), LinearLayout.LayoutParams.WRAP_CONTENT))
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val add = CyBtn(this, "ADD GAME", CyUi.YELLOW)
        add.onClick = { addGameDialog() }
        bar.addView(add, LinearLayout.LayoutParams(dp(150f), LinearLayout.LayoutParams.WRAP_CONTENT))
        val bgb = CyBtn(this, "BACKGROUND", Cy.CYAN)
        bgb.onClick = { backgroundDialog() }
        val blp = LinearLayout.LayoutParams(dp(160f), LinearLayout.LayoutParams.WRAP_CONTENT)
        blp.leftMargin = dp(10f)
        bar.addView(bgb, blp)
        hub.addView(bar, LinearLayout.LayoutParams(-1, -2))
    }

    /** What the boost does before a game opens. BALANCED = the usual, MAX = everything, LIGHT = only free up RAM. */
    private fun applyPreset(i: Int) {
        Prefs.putInt(this, "ar_preset", i)
        val f = when (i) {
            1 -> booleanArrayOf(true, true, true, true, true, true)
            2 -> booleanArrayOf(true, false, false, false, false, false)
            else -> booleanArrayOf(true, true, true, true, false, true)
        }
        Prefs.putBool(this, Prefs.BO_RAM, f[0]); Prefs.putBool(this, Prefs.BO_CACHE, f[1])
        Prefs.putBool(this, Prefs.BO_HZ, f[2]); Prefs.putBool(this, Prefs.BO_BATT, f[3])
        Prefs.putBool(this, Prefs.BO_DND, f[4]); Prefs.putBool(this, Prefs.BO_GAME, f[5])
    }

    // ---------------- games ----------------

    private fun loadGames() {
        val app = applicationContext
        Thread {
            val tiles = ArrayList<ArenaTile>()
            try {
                val list = Games.detect(app, true)
                val tot = Games.totals(app, list.map { it.pkg })
                val ses = Games.sessions(app)
                val pm = app.packageManager
                val rows = list.map { g ->
                    val mine = ses.filter { it.pkg == g.pkg }
                    val last = if (Tracker.livePkg == g.pkg) System.currentTimeMillis() else (mine.maxOfOrNull { it.end } ?: 0L)
                    val fps = mine.filter { it.avgFps > 0f }.let { l -> if (l.isEmpty()) 0f else l.map { it.avgFps }.average().toFloat() }
                    val icon: Drawable? = try { pm.getApplicationIcon(g.pkg) } catch (t: Throwable) { null }
                    Triple(g, last, Pair(tot[g.pkg] ?: 0L, Pair(fps, icon)))
                }.sortedByDescending { it.second }
                main.post {
                    for (r in rows) {
                        val t = ArenaTile(this, r.first, r.third.second.second, r.third.first, r.second, r.third.second.first)
                        t.onPlay = { play(r.first, r.third.second.second) }
                        tiles.add(t)
                    }
                    showTiles(tiles)
                }
            } catch (t: Throwable) {
                main.post { showTiles(tiles) }
            }
        }.start()
    }

    private fun showTiles(tiles: List<ArenaTile>) {
        strip.removeAllViews()
        if (tiles.isEmpty()) {
            val tv = TextView(this)
            tv.text = "No games found yet.\nTap ADD GAME and pick the ones you play."
            tv.setTextColor(0xFFB7C6D8.toInt()); tv.textSize = 15f
            tv.gravity = Gravity.CENTER_VERTICAL
            strip.addView(tv, LinearLayout.LayoutParams(-2, -1))
            return
        }
        for (t in tiles) {
            val lp = LinearLayout.LayoutParams(-2, -1)
            lp.rightMargin = dp(12f)
            strip.addView(t, lp)
        }
    }

    private fun addGameDialog() {
        val app = applicationContext
        Thread {
            val others = try { Games.others(app) } catch (t: Throwable) { emptyList() }
            main.post {
                if (others.isEmpty()) { Toast.makeText(this, "No other apps found", Toast.LENGTH_SHORT).show(); return@post }
                val names = others.map { it.name }.toTypedArray()
                AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle("Add a game")
                    .setItems(names) { _, i ->
                        Games.add(app, others[i].pkg)
                        loadGames()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }.start()
    }

    // ---------------- background ----------------

    private fun loadBackground() {
        val s = Prefs.str(this, "ar_bg", "")
        if (s.isEmpty()) { bg.setCustom(null); return }
        Thread {
            val bmp = decode(Uri.parse(s))
            main.post { bg.setCustom(bmp) }
        }.start()
    }

    private fun decode(u: Uri): Bitmap? = try {
        val o = BitmapFactory.Options(); o.inJustDecodeBounds = true
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (o.outWidth / sample > 2200) sample *= 2
        val o2 = BitmapFactory.Options(); o2.inSampleSize = sample
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
    } catch (t: Throwable) { null }

    private fun backgroundDialog() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Arena background")
            .setItems(arrayOf("Choose a picture from my phone", "Use Nyx (default)")) { _, i ->
                if (i == 0) {
                    val pick = Intent(Intent.ACTION_OPEN_DOCUMENT)
                    pick.addCategory(Intent.CATEGORY_OPENABLE)
                    pick.type = "image/*"
                    pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    try { startActivityForResult(pick, 71) } catch (t: Throwable) { Toast.makeText(this, "No picker available", Toast.LENGTH_SHORT).show() }
                } else {
                    Prefs.putStr(this, "ar_bg", "")
                    bg.setCustom(null)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 71 || resultCode != RESULT_OK) return
        val u = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (t: Throwable) { }
        Prefs.putStr(this, "ar_bg", u.toString())
        loadBackground()
    }

    // ---------------- launch ----------------

    private fun play(g: Games.GameApp, icon: Drawable?) {
        if (launching) return
        launching = true
        val s = ArenaLaunch(this, icon, g.name)
        seq = s
        root.addView(s, FrameLayout.LayoutParams(-1, -1))
        val app = applicationContext
        Thread {
            val start = System.currentTimeMillis()
            var result: Boost.Result? = null
            try {
                if (FpsClient.state(app) == FpsClient.St.READY) {
                    result = Boost.run(app, g.pkg) { txt, f -> main.post { s.step(txt, f) } }
                    Prefs.putBool(app, "bo_arena", true)
                } else {
                    main.post { s.skipped("Shizuku is not running - boost skipped") }
                }
            } catch (t: Throwable) {
                main.post { s.skipped("Boost stopped - launching anyway") }
            }
            val wait = 3400L - (System.currentTimeMillis() - start)
            if (wait > 0) Thread.sleep(wait)
            main.post { s.result(result) }
            Thread.sleep(1700)
            main.post { s.launching() }
            Thread.sleep(700)
            main.post { startGame(g.pkg) }
        }.start()
    }

    private fun startGame(pkg: String) {
        try {
            if (Settings.canDrawOverlays(this)) {
                try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (t: Throwable) { }
            }
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } else Toast.makeText(this, "Cannot open this game", Toast.LENGTH_LONG).show()
        } catch (t: Throwable) {
            Toast.makeText(this, "Cannot open this game", Toast.LENGTH_LONG).show()
        }
        main.postDelayed({ finish() }, 500)
    }
}

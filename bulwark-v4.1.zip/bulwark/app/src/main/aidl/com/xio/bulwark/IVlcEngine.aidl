package com.xio.bulwark;

import android.os.ParcelFileDescriptor;
import android.view.Surface;
import com.xio.bulwark.IVlcCallback;

/** The video engine, running in its own process. Every call returns at once (oneway). */
oneway interface IVlcEngine {
    void setCallback(IVlcCallback cb);
    void open(in ParcelFileDescriptor fd, String uri, int startAtMs, int mode, boolean smooth);
    void setSurface(in Surface s);
    void setSize(int w, int h);
    void start();
    void pause();
    void seekTo(int ms);
    void setVolume(int percent);
    void stop();
    void release();
}

package com.xio.bulwark;

oneway interface IVlcCallback {
    void onReady(int durMs);
    void onVideoSize(int w, int h);
    void onEnd();
    void onError();
    void onTime(int posMs, int durMs, boolean playing);
}

package com.xio.bulwark

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.Process
import android.view.Surface

/**
 * Runs the video engine in a separate process (":vlc"). If libVLC crashes, or Android kills the engine
 * because of low memory, only this process dies; the status overlay keeps running.
 * When the last client unbinds, the whole process is killed, which returns all of libVLC's memory at once.
 */
class VlcService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var core: VlcCore? = null
    private var cb: IVlcCallback? = null
    private var ticking = false

    private val events = object : VlcCore.Listener {
        override fun ready(durMs: Int) { try { cb?.onReady(durMs) } catch (t: Throwable) { } }
        override fun size(w: Int, h: Int) { try { cb?.onVideoSize(w, h) } catch (t: Throwable) { } }
        override fun end() { try { cb?.onEnd() } catch (t: Throwable) { } }
        override fun error() { try { cb?.onError() } catch (t: Throwable) { } }
    }

    private val tick = object : Runnable {
        override fun run() {
            val c = core
            if (c == null || !ticking) { ticking = false; return }
            try { cb?.onTime(c.position, c.durationMs, c.isPlaying) } catch (t: Throwable) { }
            main.postDelayed(this, 250)
        }
    }

    private val binder = object : IVlcEngine.Stub() {
        override fun setCallback(c: IVlcCallback?) { main.post { cb = c } }

        override fun open(fd: ParcelFileDescriptor?, uri: String?, startAtMs: Int, mode: Int, smooth: Boolean) {
            main.post {
                val old = core
                if (old != null && old.smooth != smooth) { old.release(); core = null }
                val c = core ?: try { VlcCore(this@VlcService, smooth, events).also { core = it } } catch (t: Throwable) { null }
                if (c != null && old !== c) {
                    // a new engine starts with the window the host already told us about
                    if (pendingW > 0 && pendingH > 0) c.setSize(pendingW, pendingH)
                    pendingSurface?.let { c.setSurface(it) }
                }
                if (c == null || !c.open(fd, uri, startAtMs, mode)) { try { cb?.onError() } catch (t: Throwable) { } }
                else if (!ticking) { ticking = true; main.post(tick) }
            }
        }

        override fun setSurface(s: Surface?) { main.post { pendingSurface = s; core?.setSurface(s) } }
        override fun setSize(w: Int, h: Int) { main.post { pendingW = w; pendingH = h; core?.setSize(w, h) } }
        override fun start() { main.post { core?.start() } }
        override fun pause() { main.post { core?.pause() } }
        override fun seekTo(ms: Int) { main.post { core?.seekTo(ms) } }
        override fun setVolume(percent: Int) { main.post { core?.setVolume(percent) } }
        override fun stop() { main.post { core?.stopMedia() } }
        override fun release() { main.post { shutdownCore() } }
    }

    // the surface and size can arrive before the first video is opened
    private var pendingSurface: Surface? = null
    private var pendingW = 0
    private var pendingH = 0

    private fun shutdownCore() {
        ticking = false
        main.removeCallbacks(tick)
        val c = core
        core = null
        try { c?.release() } catch (t: Throwable) { }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    /** While a video is open, the engine is a foreground service too, so Android keeps it alive next to a heavy game. */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("bulwark_engine", "Video player", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
            val n = Notification.Builder(this, "bulwark_engine")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Frameline player")
                .setContentText("Playing video")
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 29) startForeground(8, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(8, n)
        } catch (t: Throwable) { }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        shutdownCore()
        super.onDestroy()
        // free all of libVLC's memory at once instead of leaving it cached in a background process
        Process.killProcess(Process.myPid())
    }
}

package com.xio.bulwark

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.view.Surface

/**
 * Video engine of the floating player. The actual libVLC engine runs in its own process (VlcService), so this
 * class is only a thin remote control: it never loads libVLC itself, and if the engine crashes or is killed,
 * the status overlay stays alive and just gets onDied().
 * The methods are named like android.media.MediaPlayer. All callbacks arrive on the main thread.
 */
class VPlayer(ctx: Context, val smooth: Boolean) {
    private val app = ctx.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var eng: IVlcEngine? = null
    private var bound = false
    private var released = false
    private var lastSurface: Surface? = null
    private val pending = ArrayList<(IVlcEngine) -> Unit>()

    @Volatile private var pos = 0
    @Volatile private var dur = 0
    @Volatile private var playing = false

    /** Where this video was asked to resume (ms); 0 when it starts from the beginning. */
    var startAt = 0
        private set
    var videoWidth = 0
        private set
    var videoHeight = 0
        private set

    var onReady: ((Int) -> Unit)? = null
    var onVideoSize: ((Int, Int) -> Unit)? = null
    var onEnd: (() -> Unit)? = null
    var onError: (() -> Unit)? = null
    /** The engine process crashed or was killed. The overlay itself is fine. */
    var onDied: (() -> Unit)? = null

    private val cbk = object : IVlcCallback.Stub() {
        override fun onReady(durMs: Int) { main.post { if (!released) { dur = durMs; onReady?.invoke(durMs) } } }
        override fun onVideoSize(w: Int, h: Int) { main.post { if (!released) { videoWidth = w; videoHeight = h; onVideoSize?.invoke(w, h) } } }
        override fun onEnd() { main.post { if (!released) onEnd?.invoke() } }
        override fun onError() { main.post { if (!released) onError?.invoke() } }
        override fun onTime(posMs: Int, durMs: Int, isPlaying: Boolean) { pos = posMs; if (durMs > 0) dur = durMs; playing = isPlaying }
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            main.post {
                if (released) return@post
                val e = IVlcEngine.Stub.asInterface(b)
                eng = e
                try { e.setCallback(cbk) } catch (t: Throwable) { }
                val ops = ArrayList(pending); pending.clear()
                for (op in ops) try { op(e) } catch (t: Throwable) { }
            }
        }
        override fun onServiceDisconnected(n: ComponentName?) { main.post { died() } }
        override fun onBindingDied(n: ComponentName?) { main.post { died() } }
    }

    init { bind() }

    private fun bind() {
        if (bound || released) return
        val it = Intent(app, VlcService::class.java)
        // started as a foreground service as well as bound, so the engine is much harder for Android to kill
        try { app.startForegroundService(it) } catch (t: Throwable) { }
        bound = try { app.bindService(it, conn, Context.BIND_AUTO_CREATE) } catch (t: Throwable) { false }
    }

    private fun unbind() {
        if (!bound) return
        bound = false
        try { app.unbindService(conn) } catch (t: Throwable) { }
    }

    private fun died() {
        if (released) return
        eng = null
        pending.clear()
        playing = false
        lastSurface = null
        unbind()
        onDied?.invoke()
    }

    /** Runs now if the engine is connected, otherwise as soon as it connects. */
    private fun run(op: (IVlcEngine) -> Unit) {
        if (released) return
        val e = eng
        if (e != null) { try { op(e) } catch (t: Throwable) { } }
        else { bind(); pending.add(op) }
    }

    /** mode: 0 auto (hardware first, software if the chip cannot), 1 hardware only, 2 software only. */
    fun open(uri: Uri, startAtMs: Int, mode: Int): Boolean {
        if (released) return false
        val fd: ParcelFileDescriptor? = if (uri.scheme == "content") {
            (try { app.contentResolver.openFileDescriptor(uri, "r") } catch (t: Throwable) { null }) ?: return false
        } else null
        startAt = startAtMs
        videoWidth = 0; videoHeight = 0
        pos = 0; dur = 0; playing = true
        run { e -> try { e.open(fd, uri.toString(), startAtMs, mode, smooth) } finally { try { fd?.close() } catch (t: Throwable) { } } }
        return true
    }

    fun stopMedia() { playing = false; run { it.stop() } }

    fun setSurface(s: Surface?) {
        if (released) return
        if (s != null && s === lastSurface) return
        lastSurface = s
        run { it.setSurface(s) }
    }

    fun setSize(w: Int, h: Int) { run { it.setSize(w, h) } }

    val isPlaying: Boolean get() = !released && playing
    val currentPosition: Int get() = pos
    val duration: Int get() = dur

    fun start() { playing = true; run { it.start() } }
    fun pause() { playing = false; run { it.pause() } }
    fun seekTo(ms: Int) { pos = ms; run { it.seekTo(ms) } }
    fun setVolume(l: Float, r: Float) { val v = (maxOf(l, r) * 100f).toInt().coerceIn(0, 100); run { it.setVolume(v) } }

    /** Ends the engine process completely, so all of its memory comes back. */
    fun release() {
        if (released) return
        val e = eng
        try { e?.release() } catch (t: Throwable) { }
        released = true
        eng = null
        pending.clear()
        main.removeCallbacksAndMessages(null)
        unbind()
        try { app.stopService(Intent(app, VlcService::class.java)) } catch (t: Throwable) { }
    }
}

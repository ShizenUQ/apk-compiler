package com.xio.bulwark

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.view.Surface
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer as Vlc
import org.videolan.libvlc.interfaces.IVLCVout

/**
 * The libVLC engine itself. It only ever runs inside VlcService, which lives in its own process,
 * so a crash or a memory kill here can never take the status overlay down. Everything runs on that process's main thread.
 */
class VlcCore(ctx: Context, val smooth: Boolean, private val l: Listener) {

    interface Listener {
        fun ready(durMs: Int)
        fun size(w: Int, h: Int)
        fun end()
        fun error()
    }

    companion object {
        private var libSmooth: LibVLC? = null
        private var libPlain: LibVLC? = null

        /** Tries the strongest set of options first and falls back to simpler ones if this libVLC rejects any. */
        private fun build(c: Context, smooth: Boolean): LibVLC {
            val sets: List<List<String>> = if (smooth) listOf(
                listOf("--no-drop-late-frames", "--no-skip-frames", "--no-avcodec-hurry-up"),
                listOf("--no-drop-late-frames", "--no-skip-frames"),
                emptyList()
            ) else listOf(emptyList())
            for (o in sets) {
                try { return LibVLC(c, ArrayList(o)) } catch (t: Throwable) { }
            }
            return LibVLC(c, ArrayList<String>())
        }

        /** No-glitch mode: never drop frames, never skip decoding. Late frames show late instead of breaking the picture. */
        @Synchronized
        private fun lib(c: Context, smooth: Boolean): LibVLC =
            if (smooth) libSmooth ?: build(c.applicationContext, true).also { libSmooth = it }
            else libPlain ?: build(c.applicationContext, false).also { libPlain = it }
    }

    private val app = ctx.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val player = Vlc(lib(app, smooth))
    private var pfd: ParcelFileDescriptor? = null
    private var released = false
    private var attached = false
    private var surface: Surface? = null
    private var winW = 0
    private var winH = 0
    private var firstPlay = true
    private var length = 0L
    private var startAt = 0
    private var wantVolume = 100

    private val layoutListener = IVLCVout.OnNewVideoLayoutListener { _, w, h, vw, vh, sn, sd ->
        main.post {
            if (released) return@post
            var ww = if (vw > 0) vw else w
            val hh = if (vh > 0) vh else h
            if (sn > 0 && sd > 0) ww = ww * sn / sd
            if (ww > 0 && hh > 0) l.size(ww, hh)
        }
    }

    init {
        player.setEventListener { e ->
            when (e.type) {
                Vlc.Event.Playing -> main.post {
                    if (released) return@post
                    if (firstPlay) {
                        firstPlay = false
                        length = player.length
                        // resume: a real seek, so the decoder starts from a clean keyframe
                        if (startAt > 0) player.time = startAt.toLong()
                        player.volume = wantVolume
                        l.ready(length.toInt())
                    }
                }
                Vlc.Event.LengthChanged -> length = e.lengthChanged
                Vlc.Event.EndReached -> main.post { if (!released) l.end() }
                Vlc.Event.EncounteredError -> main.post { if (!released) l.error() }
                else -> {}
            }
        }
    }

    /** mode: 0 auto (hardware first, software if the chip cannot), 1 hardware only, 2 software only. */
    fun open(fd: ParcelFileDescriptor?, uri: String?, startAtMs: Int, mode: Int): Boolean {
        if (released) return false
        return try {
            stopMedia()
            firstPlay = true
            length = 0L
            startAt = startAtMs
            val lib = lib(app, smooth)
            val media = if (fd != null) { pfd = fd; Media(lib, fd.fileDescriptor) } else Media(lib, Uri.parse(uri))
            when (mode) {
                1 -> media.setHWDecoderEnabled(true, true)
                2 -> media.setHWDecoderEnabled(false, false)
                else -> media.setHWDecoderEnabled(true, false)
            }
            if (smooth) { media.addOption(":no-drop-late-frames"); media.addOption(":no-skip-frames") }
            player.media = media
            media.release()
            player.play()
            true
        } catch (t: Throwable) {
            false
        }
    }

    fun stopMedia() {
        if (released) return
        try { player.stop() } catch (t: Throwable) { }
        try { pfd?.close() } catch (t: Throwable) { }
        pfd = null
    }

    fun setSurface(s: Surface?) {
        if (released) return
        surface = s
        val out = player.vlcVout
        try {
            if (attached) { out.detachViews(); attached = false }
            if (s != null && s.isValid) {
                out.setVideoSurface(s, null)
                if (winW > 0 && winH > 0) out.setWindowSize(winW, winH)
                out.attachViews(layoutListener)
                attached = true
            }
        } catch (t: Throwable) { }
    }

    fun setSize(w: Int, h: Int) {
        winW = w; winH = h
        if (released || !attached) return
        try { player.vlcVout.setWindowSize(w, h) } catch (t: Throwable) { }
    }

    val isPlaying: Boolean get() = try { !released && player.isPlaying } catch (t: Throwable) { false }
    val position: Int get() = try { if (released) 0 else max0(player.time) } catch (t: Throwable) { 0 }
    val durationMs: Int get() = try { if (released) 0 else max0(if (length > 0) length else player.length) } catch (t: Throwable) { 0 }
    private fun max0(v: Long): Int = if (v < 0) 0 else if (v > Int.MAX_VALUE) Int.MAX_VALUE else v.toInt()

    fun start() { if (!released) try { player.play() } catch (t: Throwable) { } }
    fun pause() { if (!released) try { player.pause() } catch (t: Throwable) { } }
    fun seekTo(ms: Int) { if (!released) try { player.time = ms.toLong() } catch (t: Throwable) { } }
    fun setVolume(percent: Int) {
        wantVolume = percent.coerceIn(0, 100)
        if (!released) try { player.volume = wantVolume } catch (t: Throwable) { }
    }

    fun release() {
        if (released) return
        released = true
        main.removeCallbacksAndMessages(null)
        try { player.setEventListener(null) } catch (t: Throwable) { }
        try { player.stop() } catch (t: Throwable) { }
        try { if (attached) player.vlcVout.detachViews() } catch (t: Throwable) { }
        attached = false
        try { player.release() } catch (t: Throwable) { }
        try { pfd?.close() } catch (t: Throwable) { }
        pfd = null
    }
}

package com.xio.bulwark

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** What the status needs to know to draw the player icon. */
object PlayerState {
    @Volatile var open = false
    @Volatile var listOpen = false
    @Volatile var playing = false
    @Volatile var frac = 0f
}

/** Thumbnails of library videos, loaded in the background and remembered. */
object VThumbs {
    private val pool = Executors.newFixedThreadPool(2)
    private val cache = object : LruCache<String, Bitmap>(80) {}
    private val main = Handler(Looper.getMainLooper())

    fun peek(v: VItem): Bitmap? = cache.get(v.id)

    fun load(c: Context, v: VItem, cb: (Bitmap?) -> Unit) {
        val hit = cache.get(v.id)
        if (hit != null) { cb(hit); return }
        val app = c.applicationContext
        pool.execute {
            var b: Bitmap? = null
            try {
                if (Build.VERSION.SDK_INT >= 29) b = app.contentResolver.loadThumbnail(Uri.parse(v.uri), Size(480, 300), null)
            } catch (t: Throwable) { }
            if (b == null) {
                try {
                    val m = MediaMetadataRetriever()
                    m.setDataSource(app, Uri.parse(v.uri))
                    b = m.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    m.release()
                } catch (t: Throwable) { }
            }
            if (b != null) cache.put(v.id, b)
            main.post { cb(b) }
        }
    }
}

/** Shows a long, thin outline in the app's panel style around any rectangle. */
private fun panelEdge(c: Canvas, p: Paint, path: Path, w: Float, h: Float, d: Float, cut: Float) {
    CyUi.chamfer(path, d, d, w - d, h - d, cut)
    p.style = Paint.Style.STROKE
    p.strokeWidth = 1.2f * d
    p.color = Cy.a(Cy.CYAN, 0.5f)
    c.drawPath(path, p)
    p.strokeCap = Paint.Cap.BUTT
    p.strokeWidth = 2.2f * d
    p.color = Cy.PINK
    val v = min(w, h) * 0.3f
    val hz = min(w * 0.5f, 46 * d)
    c.drawLine(d, v, d, 2 * d, p); c.drawLine(d, 2 * d, hz, 2 * d, p)
    p.color = Cy.CYAN
    c.drawLine(w - hz, h - 2 * d, w - hz * 0.5f, h - 2 * d, p)
    p.strokeWidth = d
    p.color = Cy.a(Cy.CYAN, 0.45f)
    for (i in 0 until 4) c.drawLine(w - cut - 4 * d - i * 5 * d, 6 * d, w - cut - 4 * d - i * 5 * d, 10 * d, p)
}

/** The floating video window: video, controls that show on tap, a seek bar. */
private class PlayerView(ctx: Context) : FrameLayout(ctx) {
    val d = Ui.dp(ctx, 1f)
    val tv = TextureView(ctx)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    var title = ""
    var playing = false
    var soundOn = true
    var dur = 0
    var pos = 0
    var showCtl = true
    var seeking = false
    var seekFrac = 0f

    var onToggle: (() -> Unit)? = null
    var onPrev: (() -> Unit)? = null
    var onNext: (() -> Unit)? = null
    var onSkip: ((Int) -> Unit)? = null
    var onSeek: ((Float) -> Unit)? = null
    var onSound: (() -> Unit)? = null
    var onMin: (() -> Unit)? = null
    var onClose: (() -> Unit)? = null
    var onSize: (() -> Unit)? = null
    var onTouchAny: (() -> Unit)? = null

    private val rPrev = RectF(); private val rBack = RectF(); private val rPlay = RectF()
    private val rFwd = RectF(); private val rNext = RectF(); private val rSnd = RectF()
    private val rSeek = RectF(); private val rMin = RectF(); private val rClose = RectF(); private val rSize = RectF()

    init {
        setWillNotDraw(false)
        setBackgroundColor(0xFF000000.toInt())
        addView(tv, LayoutParams(-1, -1, Gravity.CENTER))
    }

    /** Fit the video inside the window (never cropped, thin bars if the shape differs). */
    fun fit(vw: Int, vh: Int) {
        if (vw <= 0 || vh <= 0 || width <= 0) return
        val iw = width - 4 * d; val ih = height - 4 * d
        val s = min(iw / vw, ih / vh)
        val lp = LayoutParams((vw * s).toInt(), (vh * s).toInt(), Gravity.CENTER)
        tv.layoutParams = lp
    }

    var vw = 0
    var vh = 0
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { fit(vw, vh); layoutCtl() }

    private fun layoutCtl() {
        val w = width.toFloat(); val h = height.toFloat()
        val bs = min(30 * d, w / 8.2f)
        val sy = h - 14 * d
        rSeek.set(10 * d, sy - 5 * d, w - 10 * d, sy + 5 * d)
        val cy = sy - 8 * d - bs / 2f
        val cx = w / 2f
        val gap = bs * 1.12f
        rPlay.set(cx - bs / 2, cy - bs / 2, cx + bs / 2, cy + bs / 2)
        rBack.set(rPlay); rBack.offset(-gap, 0f); rPrev.set(rBack); rPrev.offset(-gap, 0f)
        rFwd.set(rPlay); rFwd.offset(gap, 0f); rNext.set(rFwd); rNext.offset(gap, 0f)
        rSnd.set(w - 10 * d - bs, cy - bs / 2, w - 10 * d, cy + bs / 2)
        val ts = 20 * d
        rClose.set(w - 6 * d - ts, 5 * d, w - 6 * d, 5 * d + ts)
        rMin.set(rClose); rMin.offset(-ts - 4 * d, 0f)
        rSize.set(rMin); rSize.offset(-ts - 4 * d, 0f)
    }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (rPlay.isEmpty) layoutCtl()
        if (showCtl) {
            p.style = Paint.Style.FILL
            p.color = 0x99000000.toInt()
            c.drawRect(0f, 0f, w, 30 * d, p)
            c.drawRect(0f, h - 78 * d.coerceAtMost(h / 80f * d), w, h, p)
            // title
            val k = 0.7f * d
            var s = title.uppercase()
            val room = rSize.left - 14 * d
            if (CyUi.supported(s)) {
                while (s.isNotEmpty() && CyUi.width(s, k) > room) s = s.dropLast(1)
                CyUi.text(c, p, s, 10 * d, 10 * d, k, 0xFFEAFBFF.toInt(), 1f, false)
            } else {
                p.color = 0xFFEAFBFF.toInt(); p.textSize = 11 * d; p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                p.textAlign = Paint.Align.LEFT
                var t = title
                while (t.length > 1 && p.measureText(t) > room) t = t.dropLast(1)
                c.drawText(t, 10 * d, 19 * d, p)
            }
            small(c, rSize, "SZ"); 
            // minimise and close
            box(c, rMin); p.style = Paint.Style.STROKE; p.strokeWidth = 1.8f * d; p.color = Cy.CYAN
            c.drawLine(rMin.left + 5 * d, rMin.centerY() + 3 * d, rMin.right - 5 * d, rMin.centerY() + 3 * d, p)
            box(c, rClose); p.color = CyUi.YELLOW
            c.drawLine(rClose.left + 5.5f * d, rClose.top + 5.5f * d, rClose.right - 5.5f * d, rClose.bottom - 5.5f * d, p)
            c.drawLine(rClose.right - 5.5f * d, rClose.top + 5.5f * d, rClose.left + 5.5f * d, rClose.bottom - 5.5f * d, p)
            // transport
            glyph(c, rPrev, 0); glyph(c, rBack, 1); glyph(c, rPlay, if (playing) 3 else 2); glyph(c, rFwd, 4); glyph(c, rNext, 5)
            glyph(c, rSnd, if (soundOn) 6 else 7)
            // seek
            val f = if (seeking) seekFrac else if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
            val ty = rSeek.centerY()
            p.style = Paint.Style.FILL
            p.color = 0xFF2A3442.toInt()
            c.drawRect(rSeek.left, ty - 1.5f * d, rSeek.right, ty + 1.5f * d, p)
            p.color = Cy.CYAN
            c.drawRect(rSeek.left, ty - 1.5f * d, rSeek.left + rSeek.width() * f, ty + 1.5f * d, p)
            p.color = 0xFFFFFFFF.toInt()
            val tx = rSeek.left + rSeek.width() * f
            c.drawRect(tx - 2.5f * d, ty - 5 * d, tx + 2.5f * d, ty + 5 * d, p)
            val tk = 0.55f * d
            val shownPos = if (seeking) (seekFrac * dur).toLong() else pos.toLong()
            CyUi.text(c, p, VideoLib.fmt(shownPos), rSeek.left, ty - 17 * d, tk, 0xFFEAFBFF.toInt(), 1f, false)
            CyUi.text(c, p, VideoLib.fmt(dur.toLong()), rSeek.right, ty - 17 * d, tk, 0xFF9FB0C2.toInt(), 1f, false, 2)
        }
        panelEdge(c, p, path, w, h, d, 10 * d)
    }

    private fun box(c: Canvas, r: RectF) {
        p.style = Paint.Style.FILL; p.color = 0xAA0B1118.toInt(); c.drawRect(r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = Cy.a(Cy.CYAN, 0.6f); c.drawRect(r, p)
    }

    private fun small(c: Canvas, r: RectF, s: String) {
        box(c, r)
        CyUi.text(c, p, s, r.centerX(), r.centerY() - 3.5f * d, 0.55f * d, Cy.CYAN, 1f, false, 1)
    }

    /** kind: 0 prev, 1 back 10, 2 play, 3 pause, 4 forward 10, 5 next, 6 sound on, 7 sound off. */
    private fun glyph(c: Canvas, r: RectF, kind: Int) {
        val cx = r.centerX(); val cy = r.centerY(); val u = r.width() * 0.2f
        p.style = Paint.Style.FILL
        p.color = if (kind == 2 || kind == 3) CyUi.YELLOW else 0xFFEAFBFF.toInt()
        if (kind == 2 || kind == 3) {
            CyUi.chamfer(path, r.left, r.top, r.right, r.bottom, 6 * d)
            p.color = Cy.a(CyUi.YELLOW, 0.2f); c.drawPath(path, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.3f * d; p.color = CyUi.YELLOW; c.drawPath(path, p)
            p.style = Paint.Style.FILL
        }
        path.reset()
        when (kind) {
            0 -> { c.drawRect(cx - 2.2f * u, cy - 1.8f * u, cx - 1.5f * u, cy + 1.8f * u, p); path.moveTo(cx + 2f * u, cy - 1.8f * u); path.lineTo(cx - 1.2f * u, cy); path.lineTo(cx + 2f * u, cy + 1.8f * u); path.close() }
            5 -> { c.drawRect(cx + 1.5f * u, cy - 1.8f * u, cx + 2.2f * u, cy + 1.8f * u, p); path.moveTo(cx - 2f * u, cy - 1.8f * u); path.lineTo(cx + 1.2f * u, cy); path.lineTo(cx - 2f * u, cy + 1.8f * u); path.close() }
            2 -> { path.moveTo(cx - 1.3f * u, cy - 1.8f * u); path.lineTo(cx + 2f * u, cy); path.lineTo(cx - 1.3f * u, cy + 1.8f * u); path.close() }
            3 -> { c.drawRect(cx - 1.7f * u, cy - 1.7f * u, cx - 0.5f * u, cy + 1.7f * u, p); c.drawRect(cx + 0.5f * u, cy - 1.7f * u, cx + 1.7f * u, cy + 1.7f * u, p) }
            1 -> { path.moveTo(cx - 0.5f * u, cy - 1.6f * u); path.lineTo(cx - 2.6f * u, cy); path.lineTo(cx - 0.5f * u, cy + 1.6f * u); path.close()
                   CyUi.text(c, p, "10", cx + 1.4f * u, cy - 2.6f * d, 0.5f * d, 0xFFEAFBFF.toInt(), 1f, false, 1) }
            4 -> { path.moveTo(cx + 0.5f * u, cy - 1.6f * u); path.lineTo(cx + 2.6f * u, cy); path.lineTo(cx + 0.5f * u, cy + 1.6f * u); path.close()
                   CyUi.text(c, p, "10", cx - 1.4f * u, cy - 2.6f * d, 0.5f * d, 0xFFEAFBFF.toInt(), 1f, false, 1) }
            6, 7 -> {
                path.moveTo(cx - 2.2f * u, cy - 0.9f * u); path.lineTo(cx - 0.8f * u, cy - 0.9f * u); path.lineTo(cx + 0.9f * u, cy - 2f * u)
                path.lineTo(cx + 0.9f * u, cy + 2f * u); path.lineTo(cx - 0.8f * u, cy + 0.9f * u); path.lineTo(cx - 2.2f * u, cy + 0.9f * u); path.close()
            }
        }
        c.drawPath(path, p)
        if (kind == 6) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.4f * d; p.color = 0xFFEAFBFF.toInt()
            c.drawLine(cx + 2.2f * u, cy - 1f * u, cx + 2.2f * u, cy + 1f * u, p)
            c.drawLine(cx + 3.2f * u, cy - 1.8f * u, cx + 3.2f * u, cy + 1.8f * u, p)
        }
        if (kind == 7) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.6f * d; p.color = Cy.PINK
            c.drawLine(cx + 1.8f * u, cy - 1.6f * u, cx + 3.4f * u, cy + 1.6f * u, p)
            c.drawLine(cx + 3.4f * u, cy - 1.6f * u, cx + 1.8f * u, cy + 1.6f * u, p)
        }
    }

    // ---- touch ----
    private var downX = 0f
    private var downY = 0f
    private var onSeekBar = false
    private var moved = false

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = true

    private fun fracAt(x: Float) = ((x - rSeek.left) / max(1f, rSeek.width())).coerceIn(0f, 1f)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                onTouchAny?.invoke()
                downX = e.x; downY = e.y; moved = false
                onSeekBar = showCtl && dur > 0 && e.y > rSeek.top - 8 * d && e.y < rSeek.bottom + 8 * d && e.x > rSeek.left - 6 * d && e.x < rSeek.right + 6 * d
                if (onSeekBar) { seeking = true; seekFrac = fracAt(e.x); invalidate() }
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(e.x - downX) > 8 * d || abs(e.y - downY) > 8 * d) moved = true
                if (onSeekBar) { seekFrac = fracAt(e.x); invalidate() }
            }
            MotionEvent.ACTION_UP -> {
                if (onSeekBar) { seeking = false; onSeek?.invoke(seekFrac); invalidate(); return true }
                if (!showCtl) { showCtl = true; invalidate(); return true }
                val x = e.x; val y = e.y
                when {
                    rClose.contains(x, y) -> onClose?.invoke()
                    rMin.contains(x, y) -> onMin?.invoke()
                    rSize.contains(x, y) -> onSize?.invoke()
                    rPlay.contains(x, y) -> onToggle?.invoke()
                    rPrev.contains(x, y) -> onPrev?.invoke()
                    rNext.contains(x, y) -> onNext?.invoke()
                    rBack.contains(x, y) -> onSkip?.invoke(-10000)
                    rFwd.contains(x, y) -> onSkip?.invoke(10000)
                    rSnd.contains(x, y) -> onSound?.invoke()
                    else -> { showCtl = false; invalidate() }
                }
            }
            MotionEvent.ACTION_CANCEL -> { seeking = false }
        }
        return true
    }
}

/** The small icon the player shrinks into. */
private class PlayerChip(ctx: Context) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    var frac = 0f
    var onTap: (() -> Unit)? = null

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        CyUi.chamfer(path, d, d, w - d, h - d, 6 * d)
        p.style = Paint.Style.FILL; p.color = 0xE6090C12.toInt(); c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d; p.color = Cy.a(Cy.CYAN, 0.8f); c.drawPath(path, p)
        p.style = Paint.Style.FILL
        p.color = Cy.CYAN
        path.reset()
        val cx = w / 2f; val cy = h / 2f - 1.5f * d
        path.moveTo(cx - 3.5f * d, cy - 5 * d); path.lineTo(cx + 5 * d, cy); path.lineTo(cx - 3.5f * d, cy + 5 * d); path.close()
        c.drawPath(path, p)
        p.color = 0xFF1F2A3A.toInt()
        c.drawRect(7 * d, h - 5.5f * d, w - 7 * d, h - 3.5f * d, p)
        p.color = CyUi.YELLOW
        c.drawRect(7 * d, h - 5.5f * d, 7 * d + (w - 14 * d) * frac, h - 3.5f * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}

/** Container that tells the host when you tap outside of it. */
private class OutsideFrame(ctx: Context) : FrameLayout(ctx) {
    var onOutside: (() -> Unit)? = null
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) { onOutside?.invoke(); return true }
        return super.onTouchEvent(e)
    }
}

/** Small angular chip used for the playlist switcher in the list panel. */
private class PlChip(ctx: Context, private val text: String, private val on: Boolean) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    var onTap: (() -> Unit)? = null
    private val k = 0.62f * d
    private val s = text.uppercase()
    override fun onMeasure(w: Int, h: Int) {
        val tw = if (CyUi.supported(s)) CyUi.width(s, k) else 40 * d
        setMeasuredDimension((tw + 22 * d).toInt(), (26 * d).toInt())
    }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        CyUi.chamfer(path, d, d, w - d, h - d, 6 * d)
        p.style = Paint.Style.FILL; p.color = Cy.a(Cy.CYAN, if (on) 0.3f else 0.06f); c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = (if (on) 1.5f else 1f) * d; p.color = Cy.a(Cy.CYAN, if (on) 0.95f else 0.3f); c.drawPath(path, p)
        CyUi.label(c, p, text, w / 2f, h / 2f, k, if (on) 0xFFFFFFFF.toInt() else 0xFF9FB0C2.toInt(), false, context)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}

/** One video line in the list panel. */
private class VRow(ctx: Context, val v: VItem, val now: Boolean) : LinearLayout(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val img = ImageView(ctx)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val frac = if (v.dur > 0) (VideoLib.pos(ctx, v.id).toFloat() / v.dur).coerceIn(0f, 1f) else 0f

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setWillNotDraw(false)
        val pd = (4 * d).toInt()
        setPadding(pd, pd, pd, pd)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.setBackgroundColor(0xFF0B1118.toInt())
        addView(img, LayoutParams((56 * d).toInt(), (32 * d).toInt()))
        val col = LinearLayout(ctx)
        col.orientation = VERTICAL
        col.setPadding((8 * d).toInt(), 0, 0, 0)
        val t = TextView(ctx)
        t.text = v.title; t.textSize = 11.5f; t.maxLines = 1; t.ellipsize = android.text.TextUtils.TruncateAt.END
        t.setTextColor(if (now) Cy.CYAN else 0xFFE8ECF2.toInt())
        t.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        col.addView(t)
        val m = TextView(ctx)
        m.text = VideoLib.fmt(v.dur) + (if (frac > 0.02f) "  -  " + (frac * 100).toInt() + "% watched" else "")
        m.textSize = 9.5f; m.setTextColor(0xFF8B96A3.toInt())
        col.addView(m)
        addView(col, LayoutParams(0, -2, 1f))
        val b = VThumbs.peek(v)
        if (b != null) img.setImageBitmap(b) else VThumbs.load(ctx, v) { bm -> if (bm != null) img.setImageBitmap(bm) }
    }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        p.style = Paint.Style.FILL
        p.color = 0xFF161C26.toInt()
        c.drawRect(0f, height - 1f, width.toFloat(), height.toFloat(), p)
        if (frac > 0.02f) {
            val x0 = 4 * d; val w = 56 * d
            val y = 4 * d + 32 * d - 2.5f * d
            p.color = 0xAA000000.toInt(); c.drawRect(x0, y, x0 + w, y + 2.5f * d, p)
            p.color = CyUi.YELLOW; c.drawRect(x0, y, x0 + w * frac, y + 2.5f * d, p)
        }
        if (now) { p.color = Cy.CYAN; c.drawRect(0f, 4 * d, 2.5f * d, height - 4 * d, p) }
    }
}

/**
 * Runs the whole floating player: the list that opens from the icon under Nyx, the landscape player window,
 * and the small icon it shrinks into. It stays glued to the status.
 */
class PlayerHost(
    private val ctx: Context,
    private val wm: WindowManager,
    private val screen: () -> IntArray,
    private val edge: (WindowManager.LayoutParams) -> Unit,
    private val anchor: () -> Rect?
) {
    private val d = ctx.resources.displayMetrics.density
    private val main = Handler(Looper.getMainLooper())
    private fun dp(v: Float) = (v * d).toInt()

    private val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED

    private fun lp(w: Int, h: Int, extra: Int = 0): WindowManager.LayoutParams {
        val l = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags or extra, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        return l
    }

    private fun add(v: View, l: WindowManager.LayoutParams): Boolean = try { wm.addView(v, l); true } catch (t: Throwable) { false }
    private fun del(v: View?) { if (v != null) try { wm.removeView(v) } catch (t: Throwable) { } }
    private fun upd(v: View?, l: WindowManager.LayoutParams?) { if (v != null && l != null) try { wm.updateViewLayout(v, l) } catch (t: Throwable) { } }

    /** Where a window of this size goes: below the status, else above, else beside it. */
    private fun place(l: WindowManager.LayoutParams, alignRight: Boolean = false) {
        val a = anchor() ?: return
        val sc = screen()
        val w = l.width; val h = l.height
        val gap = dp(3f)
        var x = if (alignRight) a.right - w else a.left
        x = x.coerceIn(0, max(0, sc[0] - w))
        var y = a.bottom + gap
        if (y + h > sc[1]) {
            y = a.top - h - gap
            if (y < 0) {
                if (a.right + gap + w <= sc[0]) { x = a.right + gap; y = a.top }
                else if (a.left - gap - w >= 0) { x = a.left - gap - w; y = a.top }
                else y = sc[1] - h
            }
        }
        l.x = x
        l.y = y.coerceIn(0, max(0, sc[1] - h))
    }

    // =========================================================== list panel

    private var panel: OutsideFrame? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelClosedAt = 0L
    private var viewList = VideoLib.ALL

    fun iconTap() {
        if (minimized) { restore(); return }
        if (panel != null) { closePanel(); return }
        if (System.currentTimeMillis() - panelClosedAt < 350) return
        openPanel()
    }

    private fun closePanel() {
        del(panel); panel = null; panelLp = null
        panelClosedAt = System.currentTimeMillis()
        PlayerState.listOpen = false
        onState?.invoke()
    }

    var onState: (() -> Unit)? = null

    private fun openPanel() {
        val vids0 = VideoLib.videos(ctx)
        if (vids0.isEmpty()) {
            Toast.makeText(ctx, "Add videos first: Frameline app > Player", Toast.LENGTH_LONG).show()
            return
        }
        viewList = VideoLib.activeId(ctx)
        buildPanel()
    }

    private fun buildPanel() {
        val old = panel
        val sc = screen()
        val w = min(sc[0] - dp(16f), dp(236f))
        val h = min(sc[1] - dp(24f), dp(290f))
        val frame = OutsideFrame(ctx)
        val cp = CyPanel(ctx)
        cp.setPadding(dp(10f), dp(6f), dp(10f), dp(8f))
        val vids = VideoLib.videosOf(ctx, viewList)
        val pl = VideoLib.playlist(ctx, viewList)
        cp.addView(CyTitle(ctx, "PLAYER", (pl?.name ?: "ALL VIDEOS").uppercase().take(14), Cy.CYAN))
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val chips = LinearLayout(ctx)
        chips.orientation = LinearLayout.HORIZONTAL
        fun chip(name: String, id: String) {
            val c = PlChip(ctx, name, id == viewList)
            c.onTap = { viewList = id; VideoLib.setActive(ctx, id); buildPanel() }
            val l = LinearLayout.LayoutParams(-2, -2)
            l.rightMargin = dp(6f)
            chips.addView(c, l)
        }
        if (VideoLib.playlists(ctx).isEmpty()) chip("All", VideoLib.ALL)
        for (l in VideoLib.playlists(ctx)) chip(l.name, l.id)
        hs.addView(chips)
        cp.addView(hs, LinearLayout.LayoutParams(-1, -2))
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        if (vids.isEmpty()) {
            val t = TextView(ctx)
            t.text = "This playlist is empty. Add videos in the app."
            t.setTextColor(0xFF8B96A3.toInt()); t.textSize = 12.5f
            t.setPadding(dp(4f), dp(14f), dp(4f), dp(14f))
            col.addView(t)
        }
        for ((i, v) in vids.withIndex()) {
            val r = VRow(ctx, v, v.id == curId && player != null)
            r.setOnClickListener { playList(vids, i); closePanel() }
            col.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        sv.addView(col)
        val lpS = LinearLayout.LayoutParams(-1, 0, 1f)
        lpS.topMargin = dp(6f)
        cp.addView(sv, lpS)
        frame.addView(cp, FrameLayout.LayoutParams(-1, -1))
        frame.onOutside = { closePanel() }

        // height follows the content, but never more than fits
        val want = dp(92f) + vids.size * dp(42f)
        val l = lp(w, min(h, max(dp(150f), want)), WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH)
        place(l)
        del(old)
        if (add(frame, l)) { panel = frame; panelLp = l; PlayerState.listOpen = true; onState?.invoke() }
    }

    // =========================================================== player

    private var playerV: PlayerView? = null
    private var player: PlayerView?
        get() = playerV
        set(v) { playerV = v }
    private var playerLp: WindowManager.LayoutParams? = null

    private var queue: List<VItem> = emptyList()
    private var idx = 0
    private var curId = ""
    private var mp: MediaPlayer? = null
    private var prepared = false
    private var surf: Surface? = null
    private var pendingStart = false
    private var minimized = false
    private var pausedAt = 0L

    private fun playSize(): IntArray {
        val sc = screen()
        var w = dp(floatArrayOf(210f, 290f, 390f)[VideoLib.size(ctx)])
        w = min(w, sc[0] - dp(16f))
        var h = w * 9 / 16
        if (h > sc[1] - dp(24f)) { h = sc[1] - dp(24f); w = h * 16 / 9 }
        return intArrayOf(w, h)
    }

    fun playList(list: List<VItem>, i: Int) {
        if (list.isEmpty()) return
        queue = list
        idx = i.coerceIn(0, list.size - 1)
        saveNow()
        showWindow()
        startCurrent()
    }

    private fun showWindow() {
        if (playerV != null) return
        minimized = false
        val v = PlayerView(ctx)
        val s = playSize()
        val l = lp(s[0], s[1])
        place(l)
        v.soundOn = VideoLib.sound(ctx)
        v.tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                surf = Surface(st)
                val m = mp
                if (m != null) try { m.setSurface(surf) } catch (t: Throwable) { }
                if (pendingStart) { pendingStart = false; startCurrent() }
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                try { mp?.setSurface(null) } catch (t: Throwable) { }
                try { surf?.release() } catch (t: Throwable) { }
                surf = null
                return true
            }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        v.onToggle = { toggle() }
        v.onPrev = { step(-1) }
        v.onNext = { step(1) }
        v.onSkip = { ms -> skip(ms) }
        v.onSeek = { f -> val m = mp; if (m != null && prepared) { m.seekTo((f * m.duration).toInt()); v.pos = (f * m.duration).toInt(); v.invalidate() } }
        v.onSound = { v.soundOn = !v.soundOn; Prefs.putBool(ctx, "vp_sound", v.soundOn); applyVolume(); v.invalidate() }
        v.onMin = { minimize() }
        v.onClose = { close() }
        v.onSize = {
            VideoLib.setSize(ctx, (VideoLib.size(ctx) + 1) % 3)
            relayout()
        }
        v.onTouchAny = { armHide() }
        if (add(v, l)) { player = v; playerLp = l; PlayerState.open = true; onState?.invoke() }
    }

    private fun relayout() {
        val v = player ?: return
        val l = playerLp ?: return
        val s = playSize()
        l.width = s[0]; l.height = s[1]
        place(l)
        upd(v, l)
        v.fit(v.vw, v.vh)
    }

    private fun startCurrent() {
        val v = player ?: return
        val it = queue.getOrNull(idx) ?: return
        if (surf == null) { pendingStart = true; return }
        releasePlayer()
        curId = it.id
        v.title = it.title
        v.dur = it.dur.toInt()
        v.pos = 0
        v.vw = 0; v.vh = 0
        v.playing = false
        v.invalidate()
        try {
            val m = MediaPlayer()
            m.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build())
            m.setDataSource(ctx, Uri.parse(it.uri))
            m.setSurface(surf)
            m.setOnVideoSizeChangedListener { _, w, h -> v.vw = w; v.vh = h; v.fit(w, h) }
            m.setOnPreparedListener { pm ->
                prepared = true
                v.dur = pm.duration
                val saved = VideoLib.pos(ctx, it.id)
                if (saved in 3000 until (pm.duration - 4000)) pm.seekTo(saved)
                applyVolume()
                pm.start()
                v.playing = true
                v.showCtl = true
                armHide()
                tickStart()
                v.invalidate()
            }
            m.setOnCompletionListener {
                VideoLib.setPos(ctx, curId, 0)
                if (idx < queue.size - 1) { idx++; startCurrent() }
                else { v.playing = false; v.showCtl = true; v.invalidate(); pausedAt = System.currentTimeMillis(); schedShrink() }
            }
            m.setOnErrorListener { _, _, _ ->
                Toast.makeText(ctx, "Cannot play this video. If you removed it from your phone, delete it in the app. Or allow video access again.", Toast.LENGTH_LONG).show()
                v.playing = false; v.invalidate(); true
            }
            mp = m
            prepared = false
            m.prepareAsync()
        } catch (t: Throwable) {
            Toast.makeText(ctx, "Cannot open this video", Toast.LENGTH_LONG).show()
        }
        onState?.invoke()
    }

    private fun applyVolume() {
        val m = mp ?: return
        val on = player?.soundOn ?: VideoLib.sound(ctx)
        try { if (on) m.setVolume(1f, 1f) else m.setVolume(0f, 0f) } catch (t: Throwable) { }
    }

    private fun toggle() {
        val m = mp ?: return
        val v = player ?: return
        if (!prepared) return
        try {
            if (m.isPlaying) { m.pause(); v.playing = false; PlayerState.playing = false; onState?.invoke(); saveNow(); pausedAt = System.currentTimeMillis(); schedShrink() }
            else { m.start(); v.playing = true; PlayerState.playing = true; onState?.invoke(); armHide() }
        } catch (t: Throwable) { }
        v.invalidate()
    }

    private fun step(dir: Int) {
        if (queue.isEmpty()) return
        saveNow()
        idx = ((idx + dir) % queue.size + queue.size) % queue.size
        startCurrent()
    }

    private fun skip(ms: Int) {
        val m = mp ?: return
        if (!prepared) return
        try {
            val t = (m.currentPosition + ms).coerceIn(0, max(0, m.duration - 500))
            m.seekTo(t)
            player?.pos = t
            player?.invalidate()
        } catch (t: Throwable) { }
        armHide()
    }

    private fun saveNow() {
        val m = mp ?: return
        if (!prepared || curId.isEmpty()) return
        try { VideoLib.setPos(ctx, curId, m.currentPosition) } catch (t: Throwable) { }
    }

    private fun releasePlayer() {
        saveNow()
        main.removeCallbacks(tick)
        try { mp?.release() } catch (t: Throwable) { }
        mp = null
        prepared = false
    }

    // ---- ticking: seek bar and saved progress ----
    private var tickN = 0
    private val tick = object : Runnable {
        override fun run() {
            val m = mp
            val v = player
            if (m != null && prepared) {
                try {
                    if (v != null && !v.seeking) { v.pos = m.currentPosition; if (v.showCtl) v.invalidate() }
                    tickN++
                    if (tickN % 4 == 0 && m.isPlaying) VideoLib.setPos(ctx, curId, m.currentPosition)
                    if (m.duration > 0) {
                        val f = m.currentPosition.toFloat() / m.duration
                        val pl = m.isPlaying
                        if (abs(f - PlayerState.frac) > 0.004f || pl != PlayerState.playing) { PlayerState.frac = f; PlayerState.playing = pl; onState?.invoke() }
                    }
                } catch (t: Throwable) { }
            }
            main.postDelayed(this, 500)
        }
    }

    private fun tickStart() { main.removeCallbacks(tick); main.postDelayed(tick, 500) }

    // ---- controls fade away when playing ----
    private val hideRun = Runnable {
        val v = player ?: return@Runnable
        if (v.playing && !v.seeking) { v.showCtl = false; v.invalidate() }
    }

    private fun armHide() {
        main.removeCallbacks(hideRun)
        main.postDelayed(hideRun, 3500)
    }

    // ---- shrink to the small icon when paused for a while ----
    private val shrinkRun = Runnable {
        val v = player ?: return@Runnable
        if (!v.playing && VideoLib.autoShrink(ctx) && System.currentTimeMillis() - pausedAt >= 5800) minimize()
    }

    private fun schedShrink() {
        main.removeCallbacks(shrinkRun)
        main.postDelayed(shrinkRun, 6000)
    }

    fun minimize() {
        val v = player ?: return
        try { mp?.let { if (prepared && it.isPlaying) it.pause() } } catch (t: Throwable) { }
        v.playing = false
        PlayerState.playing = false
        saveNow()
        main.removeCallbacks(hideRun); main.removeCallbacks(shrinkRun)
        try { mp?.setSurface(null) } catch (t: Throwable) { }
        del(v); player = null; playerLp = null
        minimized = true
        PlayerState.open = true
        onState?.invoke()
    }

    private fun restore() {
        if (!minimized) return
        minimized = false
        showWindow()
        val v = player ?: return
        v.title = queue.getOrNull(idx)?.title ?: ""
        v.dur = try { if (prepared) mp?.duration ?: 0 else 0 } catch (t: Throwable) { 0 }
        // the surface comes back a moment later: play from where it was
        main.post { resumeAfterRestore() }
    }

    private fun resumeAfterRestore() {
        val v = player ?: return
        val m = mp
        if (m == null || !prepared) { startCurrent(); return }
        if (surf == null) { main.postDelayed({ resumeAfterRestore() }, 80); return }
        try { m.setSurface(surf); m.start(); v.playing = true; v.vw = m.videoWidth; v.vh = m.videoHeight; v.fit(v.vw, v.vh); armHide() } catch (t: Throwable) { }
        v.invalidate()
    }

    fun close() {
        main.removeCallbacks(hideRun); main.removeCallbacks(shrinkRun)
        releasePlayer()
        del(player); player = null; playerLp = null
        minimized = false
        PlayerState.open = false
        PlayerState.playing = false
        PlayerState.frac = 0f
        onState?.invoke()
    }

    // =========================================================== lifecycle

    /** The status moved or turned: keep the windows with it. */
    fun reposition() {
        panelLp?.let { l -> place(l); upd(panel, l) }
        playerLp?.let { l -> place(l); upd(player, l) }
    }

    fun onConfig() {
        relayout()
        reposition()
    }

    fun destroy() {
        closePanel()
        close()
        main.removeCallbacksAndMessages(null)
    }
}

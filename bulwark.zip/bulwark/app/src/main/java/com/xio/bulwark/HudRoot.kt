package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.hypot

/** Holds the drawn HUD plus the video box, and handles touch (tap = fold, drag = move, long-press / lock icon = lock). */
class HudRoot(private val ctx: Context) : FrameLayout(ctx) {

    val hud = HudView(ctx)
    private val vbox = MediaBox(ctx, 0)
    private val ibox = MediaBox(ctx, 1)
    private var soundOn = false
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private var vRect: Rect? = null
    private var iRect: Rect? = null
    private var galIdx = 0
    private var galCount = 0

    /** false = just a picture (used for the in-app preview): no touch, always muted. */
    var interactive = true

    var onDrag: ((Int, Int) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null
    var onToggleLock: (() -> Unit)? = null
    var onToggleSound: (() -> Unit)? = null
    /** 0 = open / close the song list, 1 = previous, 2 = play / pause, 3 = next. */
    var onMusic: ((Int) -> Unit)? = null

    init {
        addView(hud, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        vbox.visibility = View.GONE
        ibox.visibility = View.GONE
        addView(vbox, LayoutParams(1, 1))
        addView(ibox, LayoutParams(1, 1))
        setWillNotDraw(false)
        hud.onTick = { syncMedia() }
        ibox.onPos = { i, n -> galIdx = i; galCount = n; invalidate() }
    }

    fun applyPrefs() {
        vbox.load()
        ibox.load()
        val snd = Prefs.bool(ctx, Prefs.SOUND, false) && interactive
        vbox.configure(snd)
        soundOn = snd
        invalidate()
        hud.hasVideo = vbox.hasSource
        hud.hasImage = ibox.hasSource
        hud.applyPrefs()
    }

    fun update(d: FpsData, s: SysData) = hud.update(d, s)

    /** Pause / resume the clips (used when the app screen goes to the background). */
    fun setPlaying(p: Boolean) {
        if (vbox.visibility == View.VISIBLE) vbox.setActive(p)
        if (ibox.visibility == View.VISIBLE) ibox.setActive(p)
    }

    /** Lock icon spot in pixels (inside this view), or null. */
    fun lockRectPx(): Rect? {
        val r = hud.lockHit() ?: return null
        val s = hud.scalePx()
        return Rect((r.left * s).toInt(), (r.top * s).toInt(), (r.right * s).toInt(), (r.bottom * s).toInt())
    }

    /** Music buttons in pixels (inside this view), same order as onMusic. */
    fun musicRectsPx(): List<Rect> {
        val l = hud.musicHits() ?: return emptyList()
        val s = hud.scalePx()
        return l.map { Rect((it.left * s).toInt(), (it.top * s).toInt(), (it.right * s).toInt(), (it.bottom * s).toInt()) }
    }

    /** Tap area of the video screen (tap = sound on / off), in pixels, or null. */
    fun videoTapRectPx(): Rect? {
        val r = vRect ?: return null
        if (vbox.visibility != View.VISIBLE) return null
        return Rect(r)
    }

    /** Tap area of the image screen (tap = next picture), in pixels, or null. */
    fun imageTapRectPx(): Rect? {
        val r = iRect ?: return null
        if (ibox.visibility != View.VISIBLE) return null
        return Rect(r)
    }

    fun nextImage() = ibox.advance()

    private fun sync1(box: MediaBox, r: Rect?, old: Rect?): Rect? {
        if (r != null && box.hasSource) {
            if (box.visibility != View.VISIBLE) {
                box.alpha = 0f
                box.visibility = View.VISIBLE
                box.setActive(true)
                box.animate().alpha(1f).setDuration(320).start()
                requestLayout()
            }
            if (old != r) requestLayout()
            return r
        } else if (box.visibility == View.VISIBLE) {
            box.animate().cancel()
            box.setActive(false)
            box.visibility = View.GONE
        }
        return null
    }

    private fun syncMedia() {
        vRect = sync1(vbox, hud.videoRect(), vRect)
        iRect = sync1(ibox, hud.imageRect(), iRect)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        hud.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED)
        val v = vRect
        if (v != null && vbox.visibility == View.VISIBLE) {
            vbox.measure(MeasureSpec.makeMeasureSpec(v.width(), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(v.height(), MeasureSpec.EXACTLY))
        }
        val i = iRect
        if (i != null && ibox.visibility == View.VISIBLE) {
            ibox.measure(MeasureSpec.makeMeasureSpec(i.width(), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(i.height(), MeasureSpec.EXACTLY))
        }
        setMeasuredDimension(hud.measuredWidth, hud.measuredHeight)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        hud.layout(0, 0, hud.measuredWidth, hud.measuredHeight)
        val v = vRect
        if (v != null && vbox.visibility == View.VISIBLE) vbox.layout(v.left, v.top, v.right, v.bottom)
        val i = iRect
        if (i != null && ibox.visibility == View.VISIBLE) ibox.layout(i.left, i.top, i.right, i.bottom)
    }

    private val fp = Path()

    /**
     * Hard-edged frame around a screen: cut corners, a double line, bright diagonals on the cuts, thick corner brackets and a
     * small label plate on the top edge. Drawn once, nothing moves.
     */
    private fun frame(c: Canvas, r: Rect, label: String, base: Int, accent: Int, s: Float, icon: Int, extra: String) {
        val l = r.left.toFloat(); val t = r.top.toFloat(); val rr = r.right.toFloat(); val b = r.bottom.toFloat()
        val w = rr - l; val h = b - t
        val k = MediaBox.cut(w, h)
        fp.reset()
        fp.moveTo(l, t); fp.lineTo(rr - k, t); fp.lineTo(rr, t + k); fp.lineTo(rr, b); fp.lineTo(l + k, b); fp.lineTo(l, b - k); fp.close()
        ip.style = Paint.Style.STROKE
        ip.strokeCap = Paint.Cap.BUTT
        ip.strokeJoin = Paint.Join.MITER
        ip.strokeWidth = 5f * s
        ip.color = Cy.a(base, 0.13f)
        c.drawPath(fp, ip)
        ip.strokeWidth = 1.2f * s
        ip.color = Cy.a(base, 0.95f)
        c.drawPath(fp, ip)
        val inset = 2.6f * s
        c.save()
        c.scale((w - 2 * inset) / w, (h - 2 * inset) / h, l + w / 2f, t + h / 2f)
        ip.strokeWidth = 0.7f * s
        ip.color = Cy.a(base, 0.35f)
        c.drawPath(fp, ip)
        c.restore()
        ip.strokeWidth = 2.6f * s
        ip.color = accent
        c.drawLine(rr - k, t, rr, t + k, ip)
        c.drawLine(l + k, b, l, b - k, ip)
        val len = minOf(w, h) * 0.3f
        ip.strokeWidth = 2.2f * s
        ip.color = base
        c.drawLine(l, t, l + len, t, ip); c.drawLine(l, t, l, t + len, ip)
        c.drawLine(rr, b, rr - len, b, ip); c.drawLine(rr, b, rr, b - len, ip)
        ip.strokeWidth = 0.9f * s
        ip.color = Cy.a(base, 0.6f)
        for (i in 0 until 3) { val x = rr - k - (3f + i * 2.4f) * s; c.drawLine(x, t + 1.6f * s, x, t + 3.4f * s, ip) }
        // label plate sitting on the top edge
        val kk = 0.36f * s
        val tw = Cy.twidth(label, kk) - 2.2f * kk
        val ex = if (extra.isEmpty()) 0f else Cy.twidth(extra, kk) - 2.2f * kk + 3f * s
        val ic = if (icon >= 0) 6.5f * s else 0f
        val px0 = l + len + 3f * s
        val px1 = px0 + tw + ex + ic + 6f * s
        val ph = 5.6f * s
        ip.style = Paint.Style.FILL
        ip.color = 0xFF060A10.toInt()
        c.drawRect(px0, t - ph / 2f, px1, t + ph / 2f, ip)
        ip.style = Paint.Style.STROKE
        ip.strokeWidth = 0.7f * s
        ip.color = Cy.a(base, 0.9f)
        c.drawRect(px0, t - ph / 2f, px1, t + ph / 2f, ip)
        var x = px0 + 3f * s
        val ty = t - 5f * kk
        for (ch in label) { Cy.glyph(c, ip, ch, x, ty, kk, base, 1f, false); x += Cy.adv(ch, kk) }
        x += 1.2f * s - 2.2f * kk + 2.2f * kk
        if (extra.isNotEmpty()) {
            for (ch in extra) { Cy.glyph(c, ip, ch, x, ty, kk, 0xFFEAFBFF.toInt(), 0.95f, false); x += Cy.adv(ch, kk) }
        }
        if (icon >= 0) {
            val cx = px1 - 4.6f * s
            val cy = t
            ip.style = Paint.Style.FILL
            ip.color = 0xFFEAFBFF.toInt()
            fp.reset()
            fp.moveTo(cx - 2.4f * s, cy - 0.9f * s); fp.lineTo(cx - 1f * s, cy - 0.9f * s); fp.lineTo(cx + 0.6f * s, cy - 2.2f * s)
            fp.lineTo(cx + 0.6f * s, cy + 2.2f * s); fp.lineTo(cx - 1f * s, cy + 0.9f * s); fp.lineTo(cx - 2.4f * s, cy + 0.9f * s); fp.close()
            c.drawPath(fp, ip)
            ip.style = Paint.Style.STROKE
            ip.strokeWidth = 0.7f * s
            if (icon == 1) {
                ip.color = accent
                c.drawArc(cx - 0.6f * s, cy - 1.6f * s, cx + 2.2f * s, cy + 1.6f * s, -50f, 100f, false, ip)
            } else {
                ip.color = Cy.PINK
                c.drawLine(cx + 1.1f * s, cy - 1.6f * s, cx + 3f * s, cy + 1.6f * s, ip)
                c.drawLine(cx + 3f * s, cy - 1.6f * s, cx + 1.1f * s, cy + 1.6f * s, ip)
            }
        }
    }

    /** Frames round both screens, plus a segmented progress line along the bottom of the image screen. */
    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val s = hud.scalePx()
        val vr = vRect
        if (vr != null && vbox.visibility == View.VISIBLE) frame(c, vr, "VID", Cy.CYAN, CyUi.YELLOW, s, if (soundOn) 1 else 0, "")
        val mr = iRect
        if (mr != null && ibox.visibility == View.VISIBLE) {
            frame(c, mr, "IMG", Cy.PINK, Cy.CYAN, s, -1, if (galCount > 0) String.format("%02d/%02d", galIdx + 1, galCount) else "")
            if (galCount > 1) {
                ip.style = Paint.Style.STROKE
                ip.strokeWidth = maxOf(1.5f, 1.1f * s)
                ip.strokeCap = Paint.Cap.BUTT
                val x0 = mr.left + 6f * s
                val x1 = mr.right - 6f * s
                val gap = 1.2f * s
                val sw = (x1 - x0 - gap * (galCount - 1)) / galCount
                val y = mr.bottom - 4.5f * s
                for (i in 0 until galCount) {
                    ip.color = if (i == galIdx) 0xFFFFFFFF.toInt() else 0x55FFFFFF
                    val a = x0 + i * (sw + gap)
                    c.drawLine(a, y, a + sw, y, ip)
                }
            }
        }
    }

    // ---- touch ----
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var longFired = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop * 1.5f
    private val longRun = Runnable { longFired = true; onToggleLock?.invoke() }

    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean = interactive

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; lastX = downX; lastY = downY
                moved = false; longFired = false
                postDelayed(longRun, 650)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.rawX - downX, e.rawY - downY) > slop) {
                    moved = true
                    removeCallbacks(longRun)
                }
                if (moved) onDrag?.invoke((e.rawX - lastX).toInt(), (e.rawY - lastY).toInt())
                lastX = e.rawX; lastY = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                if (moved) onDragEnd?.invoke()
                else if (!longFired) {
                    val s = hud.scalePx()
                    val lr = hud.lockHit()
                    val vr = videoTapRectPx()
                    val ir = imageTapRectPx()
                    val mh = hud.musicHits()
                    val nh = hud.nyxHit()
                    var mi = -1
                    if (mh != null) for ((k, rc) in mh.withIndex()) if (rc.contains(e.x / s, e.y / s)) { mi = k; break }
                    if (mi >= 0) onMusic?.invoke(mi)
                    else if (vr != null && vr.contains(e.x.toInt(), e.y.toInt())) {
                        val f = onToggleSound
                        if (f != null) f() else { Prefs.putBool(ctx, Prefs.SOUND, !Prefs.bool(ctx, Prefs.SOUND, false)); applyPrefs() }
                    } else if (ir != null && ir.contains(e.x.toInt(), e.y.toInt())) ibox.advance()
                    else if (nh != null && nh.contains(e.x / s, e.y / s)) hud.nyxPoke()
                    else if (lr != null && lr.contains(e.x / s, e.y / s)) onToggleLock?.invoke()
                    else {
                        val fh = hud.foldHit()
                        if (fh != null && fh.contains(e.x / s, e.y / s)) hud.toggleFold()
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longRun)
        }
        return true
    }
}

package com.xio.bulwark

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private fun lerpTo(v: View, from: Float, to: Float, ms: Long, f: (Float) -> Unit) {
    val a = ValueAnimator.ofFloat(from, to)
    a.duration = ms
    a.interpolator = DecelerateInterpolator(1.8f)
    a.addUpdateListener { f(it.animatedValue as Float); v.invalidate() }
    a.start()
}

/** Draws time as "12h 40m" with the cyber digits. Returns its width. */
private fun drawTime(c: Canvas, p: Paint, ms: Long, cx: Float, base: Float, h: Float, d: Float, color: Int, center: Boolean): Float {
    val mins = ms / 60_000L
    val hh = mins / 60
    val mm = mins % 60
    val k = h / 10f
    val hs = hh.toString()
    val ms2 = if (hh > 0) String.format("%02d", mm) else mm.toString()
    val unit = h * 0.55f
    p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    p.textSize = unit
    p.style = Paint.Style.FILL
    val uw = p.measureText("h") + 3 * d
    val gap = 5 * d
    val total = (if (hh > 0) Cy.width(hs.length, k) + uw + gap else 0f) + Cy.width(ms2.length, k) + p.measureText("m")
    var x = if (center) cx - total / 2f else cx
    if (hh > 0) {
        x += Cy.text(c, p, hs, x, base, h, color)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = unit
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.color = Cy.a(color, 0.7f)
        c.drawText("h", x + 2 * d, base, p)
        x += uw + gap
    }
    x += Cy.text(c, p, ms2, x, base, h, color)
    p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    p.textSize = unit
    p.style = Paint.Style.FILL
    p.textAlign = Paint.Align.LEFT
    p.color = Cy.a(color, 0.7f)
    c.drawText("m", x + 1 * d, base, p)
    return total
}

/** The animated "turbo core" at the top of the Games tab. Spins up while a game is running. */
class TurboCore(ctx: Context) : View(ctx) {
    var todayMs = 0L
    var totalMs = 0L
    var gameCount = 0
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rr = RectF()
    private var energy = 0f
    private var ang = 0f
    private var lastT = 0L
    private var running = false
    private var liveName = ""
    private var livePk = ""

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!isShown || windowVisibility != View.VISIBLE) { tickIdle = true; return }
            invalidate()
            postDelayed(this, 33)
        }
    }

    private var tickIdle = false

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (214 * d).toInt())

    private fun pt(cx: Float, cy: Float, r: Float, deg: Float, out: FloatArray) {
        val a = deg * 0.0174533f
        out[0] = cx + cos(a) * r
        out[1] = cy + sin(a) * r
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val now = SystemClock.uptimeMillis()
        val t = now / 1000f
        val live = Tracker.livePkg
        val on = live.isNotEmpty()
        energy += ((if (on) 1f else 0f) - energy) * 0.06f
        val dt = if (lastT == 0L) 0.033f else min(0.1f, (now - lastT) / 1000f)
        lastT = now
        ang = (ang + (36f + 560f * energy * energy) * dt) % 3600f
        if (live != livePk) {
            livePk = live
            liveName = ""
            if (on) {
                liveName = try {
                    context.packageManager.getApplicationLabel(context.packageManager.getApplicationInfo(live, 0)).toString()
                } catch (e: Throwable) { live }
            }
        }
        val cx = w / 2f
        val cy = 100 * d
        val R = 62 * d

        // speed lines
        if (energy > 0.08f) {
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = 1.4f * d
            for (i in 0 until 9) {
                val sp = 260f * energy * (0.5f + Cy.rnd(i * 3))
                val len = (24 + 50 * Cy.rnd(i * 5 + 1)) * d
                val y = cy + (Cy.rnd(i * 7 + 2) * 2f - 1f) * R * 0.95f
                val x = ((t * sp * d + Cy.rnd(i * 11) * (w + 120 * d)) % (w + 120 * d)) - 60 * d
                p.color = Cy.a(if (i % 2 == 0) Neon.CYAN else Neon.GREEN, 0.5f * energy)
                c.drawLine(x, y, x + len, y, p)
            }
            p.strokeCap = Paint.Cap.BUTT
        }

        // glow
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, R * 1.7f, Cy.a(Neon.CYAN, 0.1f + 0.3f * energy), 0, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R * 1.7f, p)
        p.shader = null

        // outer ticks
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * d
        for (i in 0 until 48) {
            val a = (i * 7.5f - ang * 0.15f) * 0.0174533f
            val major = i % 4 == 0
            p.color = Cy.a(Neon.CYAN, if (major) 0.55f else 0.22f)
            val r0 = R + 8 * d
            val r1 = r0 + (if (major) 7 else 4) * d
            c.drawLine(cx + cos(a) * r0, cy + sin(a) * r0, cx + cos(a) * r1, cy + sin(a) * r1, p)
        }
        // rotating ring arcs
        rr.set(cx - R, cy - R, cx + R, cy + R)
        p.strokeWidth = 3f * d
        p.strokeCap = Paint.Cap.ROUND
        p.color = Cy.a(Neon.CYAN, 0.2f)
        c.drawArc(rr, 0f, 360f, false, p)
        p.color = Neon.GREEN
        c.drawArc(rr, ang * 0.6f, 70f + 40f * energy, false, p)
        p.color = Neon.CYAN
        c.drawArc(rr, -ang * 0.9f + 180f, 40f + 40f * energy, false, p)
        p.strokeCap = Paint.Cap.BUTT

        // blades
        val q = FloatArray(2)
        val q2 = FloatArray(2)
        val q3 = FloatArray(2)
        val q4 = FloatArray(2)
        val n = 12
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            val a = ang + i * (360f / n)
            val sweep = 34f + 22f * energy
            path.reset()
            pt(cx, cy, 24 * d, a, q); path.moveTo(q[0], q[1])
            pt(cx, cy, 40 * d, a + sweep * 0.5f, q2)
            pt(cx, cy, 54 * d, a + sweep, q3)
            path.quadTo(q2[0], q2[1], q3[0], q3[1])
            pt(cx, cy, 54 * d, a + sweep + 6f, q4)
            path.lineTo(q4[0], q4[1])
            pt(cx, cy, 38 * d, a + sweep * 0.45f + 8f, q2)
            pt(cx, cy, 24 * d, a + 10f, q)
            path.quadTo(q2[0], q2[1], q[0], q[1])
            path.close()
            p.color = Cy.a(if (i % 2 == 0) Neon.CYAN else Neon.GREEN, 0.28f + 0.5f * energy)
            c.drawPath(path, p)
        }

        // hub
        p.style = Paint.Style.FILL
        p.color = 0xFF070D12.toInt()
        c.drawCircle(cx, cy, 27 * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * d
        p.color = Cy.a(Neon.CYAN, 0.6f + 0.4f * energy)
        c.drawCircle(cx, cy, 27 * d, p)
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.letterSpacing = 0.15f
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 7.5f * d
        p.color = if (on) Neon.GREEN else 0xFF7C8996.toInt()
        c.drawText(if (on) "LIVE" else "TODAY", cx, cy - 9 * d, p)
        p.letterSpacing = 0f
        if (on) {
            val sec = ((now - Tracker.liveStart) / 1000L).toInt()
            p.typeface = Typeface.MONOSPACE
            p.textSize = 11.5f * d
            p.color = 0xFFFFFFFF.toInt()
            c.drawText(String.format("%d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60), cx, cy + 9 * d, p)
        } else {
            drawTime(c, p, todayMs, cx, cy + 10 * d, 11f * d, d, 0xFFFFFFFF.toInt(), true)
        }

        // sparks while running
        if (energy > 0.5f && ((t * 9f).toInt() % 3) == 0) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f * d
            p.color = Cy.a(0xFFBFFBFF.toInt(), 0.9f)
            val seed = (t * 9f).toInt()
            val a = Cy.rnd(seed) * 6.283f
            Cy.arc(c, p, cx + cos(a) * (R + 14 * d), cy + sin(a) * (R + 14 * d),
                cx + cos(a + 0.15f) * (R + 34 * d), cy + sin(a + 0.15f) * (R + 34 * d), seed, 3 * d)
        }

        // side stats
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 9 * d
        p.letterSpacing = 0.2f
        p.color = 0xFF6F7C8A.toInt()
        c.drawText("ALL TIME", 18 * d, 42 * d, p)
        p.textAlign = Paint.Align.RIGHT
        c.drawText("GAMES", w - 18 * d, 42 * d, p)
        p.letterSpacing = 0f
        drawTime(c, p, totalMs, 18 * d, 64 * d, 15 * d, d, 0xFFFFFFFF.toInt(), false)
        val gs = gameCount.toString()
        val gw = Cy.width(gs.length, 1.5f * d)
        Cy.text(c, p, gs, w - 18 * d - gw, 64 * d, 15 * d, 0xFFFFFFFF.toInt())

        // bottom line
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 12 * d
        p.color = if (on) Cy.a(0xFFFFFFFF.toInt(), 0.9f) else 0xFF6F7C8A.toInt()
        val msg = if (on) liveName else if (gameCount == 0) "Add or install a game to begin" else "Idle. Start a game to spin it up."
        val tt = TextUtils.ellipsize(msg, TextPaint(p), w - 40 * d, TextUtils.TruncateAt.END).toString()
        c.drawText(tt, cx, height - 14 * d, p)
    }
}

/** A tall card for one game: big icon, total time, share of your play time and when you last played. */
class GameCard(ctx: Context, val app: Games.GameApp, private val icon: Drawable?, private val total: Long, private val maxMs: Long, private val last: Long) : View(ctx) {
    var onOpen: (() -> Unit)? = null
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private var fill = 0f
    private var down = false
    private var running = false

    init {
        isClickable = true
        setOnClickListener { onOpen?.invoke() }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!isShown || windowVisibility != View.VISIBLE) { tickIdle = true; return }
            invalidate()
            postDelayed(this, 40)
        }
    }

    private var tickIdle = false

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
        lerpTo(this, 0f, 1f, 800) { fill = it }
    }

    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((150 * d).toInt(), (218 * d).toInt())

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false
                animate().scaleX(1f).scaleY(1f).setDuration(200).start()
            }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = Neon.now()
        rr.set(d, d, w - d, h - d)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, 0xF2131E29.toInt(), 0xF2070B10.toInt(), Shader.TileMode.CLAMP)
        CyUi.drawCut(c, p, rr, 16 * d)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Cy.a(Neon.CYAN, if (down) 0.9f else 0.35f)
        CyUi.drawCut(c, p, rr, 16 * d)
        // corner brackets
        p.strokeWidth = 1.6f * d
        p.color = Cy.a(Neon.GREEN, 0.7f)
        val m = 6 * d
        val k = 11 * d
        c.drawLine(m, m + k, m, m, p); c.drawLine(m, m, m + k, m, p)
        c.drawLine(w - m - k, h - m, w - m, h - m, p); c.drawLine(w - m, h - m, w - m, h - m - k, p)

        val cx = w / 2f
        val cy = 66 * d
        // glow + rotating ring around the icon
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, 56 * d, Cy.a(Neon.CYAN, 0.28f), 0, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, 56 * d, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * d
        p.strokeCap = Paint.Cap.ROUND
        rr.set(cx - 46 * d, cy - 46 * d, cx + 46 * d, cy + 46 * d)
        p.color = Cy.a(Neon.CYAN, 0.2f)
        c.drawArc(rr, 0f, 360f, false, p)
        p.color = Neon.GREEN
        c.drawArc(rr, (t * 70f) % 360f, 60f, false, p)
        p.color = Neon.CYAN
        c.drawArc(rr, (-t * 50f + 180f) % 360f, 30f, false, p)
        p.strokeCap = Paint.Cap.BUTT
        if (icon != null) {
            val s = 66 * d
            c.save()
            val clip = Path()
            clip.addRoundRect(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, 15 * d, 15 * d, Path.Direction.CW)
            c.clipPath(clip)
            icon.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
            icon.draw(c)
            c.restore()
        }
        // name
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 13 * d
        p.color = 0xFFFFFFFF.toInt()
        c.drawText(TextUtils.ellipsize(app.name, TextPaint(p), w - 24 * d, TextUtils.TruncateAt.END).toString(), cx, 140 * d, p)
        // time
        if (total > 0L) {
            drawTime(c, p, total, cx, 168 * d, 18 * d, d, Neon.CYAN, true)
        } else {
            p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.textSize = 13 * d
            p.color = 0xFF6F7C8A.toInt()
            c.drawText("No time yet", cx, 166 * d, p)
        }
        // share of the most played game
        val bl = 18 * d
        val br = w - 18 * d
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3.4f * d
        p.color = Cy.a(Neon.CYAN, 0.18f)
        c.drawLine(bl, 183 * d, br, 183 * d, p)
        val frac = if (maxMs > 0) (total.toFloat() / maxMs).coerceIn(0f, 1f) * fill else 0f
        if (frac > 0.01f) {
            p.shader = LinearGradient(bl, 0f, br, 0f, Neon.CYAN, Neon.GREEN, Shader.TileMode.CLAMP)
            c.drawLine(bl, 183 * d, bl + (br - bl) * frac, 183 * d, p)
            p.shader = null
        }
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 10.5f * d
        p.color = 0xFF6F7C8A.toInt()
        c.drawText(Games.ago(last), cx, 202 * d, p)
    }
}

/** Bars for the last 7 days. */
class WeekChart(ctx: Context) : View(ctx) {
    private var vals = LongArray(7)
    private var grow = 0f
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()

    fun set(v: LongArray) {
        vals = v
        lerpTo(this, 0f, 1f, 800) { grow = it }
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (150 * d).toInt())

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val mx = max(1L, vals.maxOrNull() ?: 1L)
        val best = vals.indices.maxByOrNull { vals[it] } ?: 0
        val slot = w / 7f
        val bw = slot * 0.42f
        val top = 26 * d
        val bot = h - 24 * d
        val days = arrayOf("S", "M", "T", "W", "T", "F", "S")
        val cal = Calendar.getInstance()
        for (i in 0 until 7) {
            val x = slot * i + slot / 2f
            cal.timeInMillis = Games.dayStart(i - 6) + 3_600_000L
            val label = days[cal.get(Calendar.DAY_OF_WEEK) - 1]
            val f = vals[i].toFloat() / mx * grow
            val bh = max(3 * d, (bot - top) * f)
            val isBest = i == best && vals[i] > 0
            rr.set(x - bw / 2, bot - (bot - top), x + bw / 2, bot)
            p.style = Paint.Style.FILL
            p.color = Cy.a(Neon.CYAN, 0.08f)
            c.drawRoundRect(rr, 4 * d, 4 * d, p)
            rr.set(x - bw / 2, bot - bh, x + bw / 2, bot)
            p.shader = LinearGradient(0f, bot - bh, 0f, bot,
                if (isBest) Neon.GREEN else Neon.CYAN, Cy.a(if (isBest) Neon.GREEN else Neon.CYAN, 0.25f), Shader.TileMode.CLAMP)
            c.drawRoundRect(rr, 4 * d, 4 * d, p)
            p.shader = null
            if (isBest) {
                p.color = Cy.a(Neon.GREEN, 0.2f)
                rr.inset(-3 * d, -3 * d)
                c.drawRoundRect(rr, 6 * d, 6 * d, p)
                p.textAlign = Paint.Align.CENTER
                p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                p.textSize = 10.5f * d
                p.color = 0xFFFFFFFF.toInt()
                c.drawText(Games.fmt(vals[i]), x, bot - bh - 7 * d, p)
            }
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            p.textSize = 11 * d
            p.color = if (i == 6) Neon.CYAN else 0xFF6F7C8A.toInt()
            c.drawText(label, x, h - 6 * d, p)
        }
    }
}

/** One row in "Most played". */
class RankRow(ctx: Context, private val rank: Int, private val app: Games.GameApp, private val icon: Drawable?, private val total: Long, private val maxMs: Long, private val last: Long) : View(ctx) {
    var onOpen: (() -> Unit)? = null
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private var fill = 0f
    private var down = false

    init {
        isClickable = true
        setOnClickListener { onOpen?.invoke() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); lerpTo(this, 0f, 1f, 700) { fill = it } }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (62 * d).toInt())

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) { down = true; invalidate() }
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) { down = false; invalidate() }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (down) {
            p.style = Paint.Style.FILL
            p.color = Cy.a(Neon.CYAN, 0.1f)
            rr.set(0f, 2 * d, w, h - 2 * d)
            c.drawRoundRect(rr, 10 * d, 10 * d, p)
        }
        Cy.text(c, p, rank.toString(), 4 * d, h / 2f + 6 * d, 12 * d, if (rank == 1) Neon.GREEN else 0xFF5F6B78.toInt())
        if (icon != null) {
            c.save()
            val clip = Path()
            clip.addRoundRect(26 * d, h / 2f - 19 * d, 64 * d, h / 2f + 19 * d, 10 * d, 10 * d, Path.Direction.CW)
            c.clipPath(clip)
            icon.setBounds((26 * d).toInt(), (h / 2f - 19 * d).toInt(), (64 * d).toInt(), (h / 2f + 19 * d).toInt())
            icon.draw(c)
            c.restore()
        }
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 14 * d
        p.color = 0xFFFFFFFF.toInt()
        c.drawText(TextUtils.ellipsize(app.name, TextPaint(p), w - 70 * d - 92 * d, TextUtils.TruncateAt.END).toString(), 74 * d, h / 2f - 4 * d, p)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 10.5f * d
        p.color = 0xFF6F7C8A.toInt()
        c.drawText(Games.ago(last), 74 * d, h / 2f + 11 * d, p)
        // bar under the name
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 2.4f * d
        val bl = 74 * d
        val br = w - 92 * d
        p.color = Cy.a(Neon.CYAN, 0.15f)
        c.drawLine(bl, h - 7 * d, br, h - 7 * d, p)
        val f = if (maxMs > 0) (total.toFloat() / maxMs).coerceIn(0f, 1f) * fill else 0f
        if (f > 0.01f) {
            p.color = Neon.CYAN
            c.drawLine(bl, h - 7 * d, bl + (br - bl) * f, h - 7 * d, p)
        }
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL
        val tw = drawTime(c, p, total, 0f, -1000f, 14 * d, d, Neon.CYAN, false)   // measure only (drawn off screen)
        drawTime(c, p, total, w - 4 * d - tw, h / 2f + 6 * d, 14 * d, d, Neon.CYAN, false)
    }
}

/** One finished play session with its FPS wave. */
class SessionRow(ctx: Context, private val s: Games.Session, private val name: String, private val icon: Drawable?) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var grow = 0f

    override fun onAttachedToWindow() { super.onAttachedToWindow(); lerpTo(this, 0f, 1f, 800) { grow = it } }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (62 * d).toInt())

    private fun whenText(): String {
        val cal = Calendar.getInstance()
        cal.timeInMillis = s.start
        val day = when {
            s.start >= Games.dayStart() -> "Today"
            s.start >= Games.dayStart(-1) -> "Yesterday"
            else -> "" + cal.get(Calendar.DAY_OF_MONTH) + "/" + (cal.get(Calendar.MONTH) + 1)
        }
        return day + " " + String.format("%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)) + " - " + Games.fmt(s.ms)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (icon != null) {
            c.save()
            val clip = Path()
            clip.addRoundRect(2 * d, h / 2f - 17 * d, 36 * d, h / 2f + 17 * d, 9 * d, 9 * d, Path.Direction.CW)
            c.clipPath(clip)
            icon.setBounds((2 * d).toInt(), (h / 2f - 17 * d).toInt(), (36 * d).toInt(), (h / 2f + 17 * d).toInt())
            icon.draw(c)
            c.restore()
        }
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 13.5f * d
        p.color = 0xFFFFFFFF.toInt()
        c.drawText(TextUtils.ellipsize(name, TextPaint(p), w - 46 * d - 120 * d, TextUtils.TruncateAt.END).toString(), 46 * d, h / 2f - 3 * d, p)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 10.5f * d
        p.color = 0xFF6F7C8A.toInt()
        c.drawText(whenText(), 46 * d, h / 2f + 12 * d, p)
        // right side: average FPS number + wave
        val fx = w - 112 * d
        val fs = if (s.avgFps > 0f) s.avgFps.toInt().toString() else "--"
        val col = if (s.avgFps <= 0f) 0xFF6F7C8A.toInt() else if (s.avgFps >= 50f) Neon.GREEN else if (s.avgFps >= 30f) 0xFFF2C14E.toInt() else 0xFFFF5A4D.toInt()
        Cy.text(c, p, fs, w - Cy.width(fs.length, 1.3f * d) - 22 * d, h / 2f - 3 * d, 13 * d, col)
        p.style = Paint.Style.FILL
        p.textSize = 9 * d
        p.color = 0xFF6F7C8A.toInt()
        p.textAlign = Paint.Align.RIGHT
        c.drawText("fps", w - 2 * d, h / 2f - 3 * d, p)
        if (s.wave.size >= 2) {
            val mn = s.wave.minOrNull() ?: 0f
            val mx = max(s.wave.maxOrNull() ?: 1f, mn + 1f)
            val x0 = fx
            val x1 = w - 4 * d
            val y0 = h / 2f + 4 * d
            val y1 = h - 6 * d
            path.reset()
            for ((i, v) in s.wave.withIndex()) {
                val x = x0 + (x1 - x0) * i / (s.wave.size - 1).toFloat()
                val y = y1 - (v - mn) / (mx - mn) * (y1 - y0) * grow
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.3f * d
            p.strokeJoin = Paint.Join.MITER
            p.color = Cy.a(col, 0.35f)
            p.strokeWidth = 3f * d
            c.drawPath(path, p)
            p.strokeWidth = 1.2f * d
            p.color = col
            c.drawPath(path, p)
        }
    }
}

/** Big icon inside the ring-and-bolt style frame. */
class HeroIcon(ctx: Context, private val icon: Drawable?) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private var running = false
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!isShown || windowVisibility != View.VISIBLE) { tickIdle = true; return }
            invalidate()
            postDelayed(this, 33)
        }
    }

    private var tickIdle = false

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (170 * d).toInt())

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val t = Neon.now()
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, 90 * d, Cy.a(Neon.CYAN, 0.35f), 0, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, 90 * d, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3f * d
        rr.set(cx - 66 * d, cy - 66 * d, cx + 66 * d, cy + 66 * d)
        p.color = Cy.a(Neon.CYAN, 0.2f)
        c.drawArc(rr, 0f, 360f, false, p)
        p.color = Neon.GREEN
        c.drawArc(rr, (t * 90f) % 360f, 90f, false, p)
        p.color = Neon.CYAN
        c.drawArc(rr, (-t * 60f + 120f) % 360f, 50f, false, p)
        p.strokeCap = Paint.Cap.BUTT
        p.strokeWidth = 1.4f * d
        for (i in 0 until 40) {
            val a = (i * 9f + t * 8f) * 0.0174533f
            p.color = Cy.a(Neon.CYAN, if (i % 5 == 0) 0.6f else 0.2f)
            val r0 = 74 * d
            val r1 = r0 + (if (i % 5 == 0) 7 else 4) * d
            c.drawLine(cx + cos(a) * r0, cy + sin(a) * r0, cx + cos(a) * r1, cy + sin(a) * r1, p)
        }
        if (icon != null) {
            val s = 92 * d
            c.save()
            val clip = Path()
            clip.addRoundRect(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, 20 * d, 20 * d, Path.Direction.CW)
            c.clipPath(clip)
            icon.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
            icon.draw(c)
            c.restore()
        }
    }
}

/** A number tile that counts up when it appears. */
class StatTile(ctx: Context, private val label: String, private val value: Float, private val unit: String, private val decimals: Int) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private var f = 0f

    override fun onAttachedToWindow() { super.onAttachedToWindow(); lerpTo(this, 0f, 1f, 900) { f = it } }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (78 * d).toInt())

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        rr.set(2 * d, 2 * d, w - 2 * d, h - 2 * d)
        p.style = Paint.Style.FILL
        p.color = Cy.a(Neon.CYAN, 0.07f)
        CyUi.drawCut(c, p, rr, 12 * d)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = Cy.a(Neon.CYAN, 0.3f)
        CyUi.drawCut(c, p, rr, 12 * d)
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 9 * d
        p.letterSpacing = 0.15f
        p.color = 0xFF6F7C8A.toInt()
        c.drawText(label, 12 * d, 20 * d, p)
        p.letterSpacing = 0f
        val v = value * f
        val str = if (decimals == 0) Math.round(v).toString() else String.format(java.util.Locale.US, "%." + decimals + "f", v)
        val parts = str.split(".")
        var x = 12 * d
        val base = 56 * d
        val hh = 20 * d
        if (value <= 0f) {
            Cy.text(c, p, "--", x, base, hh, 0xFF4A5560.toInt())
        } else {
            x += Cy.text(c, p, parts[0], x, base, hh, 0xFFFFFFFF.toInt())
            p.style = Paint.Style.FILL
            if (parts.size > 1) {
                p.color = 0xFFFFFFFF.toInt()
                c.drawRect(x + 1 * d, base - 2.4f * d, x + 3.6f * d, base, p)
                x += 6 * d
                x += Cy.text(c, p, parts[1], x, base, hh, 0xFFFFFFFF.toInt())
            }
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            p.textSize = 11 * d
            p.color = Cy.a(Neon.CYAN, 0.9f)
            c.drawText(unit, x + 4 * d, base, p)
        }
    }
}

package com.xio.bulwark

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

class Song(val file: String, val title: String)
class Playlist(val id: String, var name: String, var face: Int, val files: MutableList<String>)

/** Playlists (each holds songs copied into the app) and one MediaPlayer. The "active" playlist is the one that plays. */
object Music {
    private val lib = LinkedHashMap<String, String>()      // file -> title
    private val pls = ArrayList<Playlist>()
    private var loaded = false
    private var queue: List<Song> = emptyList()
    private var mp: MediaPlayer? = null

    var activeId = ""
        private set
    var index = -1
        private set
    @Volatile var playing = false
        private set
    @Volatile var panelOpen = false
    var onChange: (() -> Unit)? = null

    private fun dir(c: Context) = File(c.filesDir, "music").also { it.mkdirs() }
    private fun libFile(c: Context) = File(dir(c), "list.txt")
    private fun plFile(c: Context) = File(dir(c), "playlists.txt")
    private fun clean(s: String) = s.replace("\t", " ").replace("\n", " ").replace(",", " ")

    @Synchronized
    private fun ensure(c: Context) {
        if (loaded) return
        loaded = true
        lib.clear(); pls.clear()
        val lf = libFile(c)
        if (lf.exists()) for (ln in lf.readLines()) {
            val p = ln.split("\t")
            if (p.size >= 2 && File(dir(c), p[0]).exists()) lib[p[0]] = p[1]
        }
        val pf = plFile(c)
        if (pf.exists()) {
            for (ln in pf.readLines()) {
                val p = ln.split("\t")
                if (p.size >= 3) {
                    val fl = if (p.size >= 4 && p[3].isNotEmpty()) p[3].split(",").filter { lib.containsKey(it) }.toMutableList() else ArrayList()
                    pls.add(Playlist(p[0], p[2], p[1].toIntOrNull() ?: 0, fl))
                }
            }
        } else if (lib.isNotEmpty()) {
            pls.add(Playlist("p" + System.currentTimeMillis(), "My songs", 0, lib.keys.toMutableList()))
            savePl(c)
        }
        activeId = Prefs.str(c, "pl_active", "")
        if (pls.none { it.id == activeId }) activeId = pls.firstOrNull()?.id ?: ""
        rebuild()
    }

    private fun rebuild() {
        val pl = pls.firstOrNull { it.id == activeId }
        queue = pl?.files?.mapNotNull { f -> lib[f]?.let { Song(f, it) } } ?: emptyList()
    }

    private fun saveLib(c: Context) {
        libFile(c).writeText(lib.entries.joinToString("\n") { it.key + "\t" + clean(it.value) })
    }

    private fun savePl(c: Context) {
        plFile(c).writeText(pls.joinToString("\n") { it.id + "\t" + it.face + "\t" + clean(it.name) + "\t" + it.files.joinToString(",") })
    }

    private fun dropUnused(c: Context) {
        val used = HashSet<String>()
        for (p in pls) used.addAll(p.files)
        val dead = lib.keys.filter { it !in used }
        for (f in dead) { lib.remove(f); File(dir(c), f).delete() }
        if (dead.isNotEmpty()) saveLib(c)
    }

    // ---- playlists ----
    fun playlists(c: Context): List<Playlist> { ensure(c); return pls }
    fun playlist(c: Context, id: String): Playlist? { ensure(c); return pls.firstOrNull { it.id == id } }
    fun songsOf(c: Context, id: String): List<Song> {
        ensure(c)
        val pl = pls.firstOrNull { it.id == id } ?: return emptyList()
        return pl.files.mapNotNull { f -> lib[f]?.let { Song(f, it) } }
    }

    @Synchronized
    fun createPlaylist(c: Context, name: String, face: Int): Playlist {
        ensure(c)
        val n = clean(name).trim().ifEmpty { "Playlist ${pls.size + 1}" }
        val p = Playlist("p" + System.currentTimeMillis() + (Math.random() * 100).toInt(), n, face, ArrayList())
        pls.add(p)
        if (pls.size == 1) { activeId = p.id; Prefs.putStr(c, "pl_active", p.id); rebuild() }
        savePl(c)
        onChange?.invoke()
        return p
    }

    @Synchronized
    fun update(c: Context, id: String, name: String, face: Int) {
        ensure(c)
        val p = pls.firstOrNull { it.id == id } ?: return
        p.name = clean(name).trim().ifEmpty { p.name }
        p.face = face
        savePl(c)
        onChange?.invoke()
    }

    @Synchronized
    fun deletePlaylist(c: Context, id: String) {
        ensure(c)
        if (id == activeId) stop()
        pls.removeAll { it.id == id }
        if (id == activeId) {
            activeId = pls.firstOrNull()?.id ?: ""
            Prefs.putStr(c, "pl_active", activeId)
            index = -1
            rebuild()
        }
        savePl(c)
        dropUnused(c)
        onChange?.invoke()
    }

    fun activeFace(c: Context): Int { ensure(c); return pls.firstOrNull { it.id == activeId }?.face ?: 0 }
    fun activeName(c: Context): String { ensure(c); return pls.firstOrNull { it.id == activeId }?.name ?: "" }

    private fun setActive(c: Context, id: String) {
        if (id == activeId) return
        release()
        playing = false
        index = -1
        activeId = id
        Prefs.putStr(c, "pl_active", id)
        rebuild()
    }

    // ---- songs ----
    fun list(c: Context): List<Song> { ensure(c); return queue }
    fun count(c: Context): Int = list(c).size
    fun title(c: Context): String = list(c).getOrNull(index)?.title ?: ""

    /** Copies one audio file into the app and puts it in the playlist. Returns false if it is not audio or could not be read. */
    fun add(c: Context, uri: Uri, plId: String): Boolean {
        return try {
            ensure(c)
            val mime = c.contentResolver.getType(uri) ?: ""
            if (mime.isNotEmpty() && !mime.startsWith("audio") && mime != "application/ogg") return false
            var name = "song"
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) name = it.getString(0) ?: name
            }
            val title = name.substringBeforeLast('.', name)
            val fn = "s" + System.currentTimeMillis() + "_" + (Math.random() * 1000).toInt() + ".dat"
            val out = File(dir(c), fn)
            var total = 0L
            c.contentResolver.openInputStream(uri)!!.use { ins ->
                out.outputStream().use { os ->
                    val buf = ByteArray(65536)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > 60L * 1024 * 1024) { out.delete(); return false }
                        os.write(buf, 0, n)
                    }
                }
            }
            synchronized(this) {
                val pl = pls.firstOrNull { it.id == plId }
                if (pl == null) { out.delete(); return false }
                lib[fn] = title
                pl.files.add(fn)
                saveLib(c); savePl(c)
                if (plId == activeId) rebuild()
            }
            true
        } catch (t: Throwable) {
            false
        }
    }

    @Synchronized
    fun removeFrom(c: Context, plId: String, i: Int) {
        ensure(c)
        val pl = pls.firstOrNull { it.id == plId } ?: return
        if (i !in pl.files.indices) return
        if (plId == activeId) {
            if (i == index) { release(); playing = false; index = -1 }
            else if (i < index) index--
        }
        pl.files.removeAt(i)
        savePl(c)
        dropUnused(c)
        if (plId == activeId) rebuild()
        onChange?.invoke()
    }

    @Synchronized
    fun moveIn(c: Context, plId: String, from: Int, to: Int) {
        ensure(c)
        val pl = pls.firstOrNull { it.id == plId } ?: return
        if (from !in pl.files.indices) return
        val t = to.coerceIn(0, pl.files.size - 1)
        if (t == from) return
        val f = pl.files.removeAt(from)
        pl.files.add(t, f)
        if (plId == activeId) {
            if (index == from) index = t
            else if (from < index && t >= index) index--
            else if (from > index && t <= index) index++
            rebuild()
        }
        savePl(c)
    }

    /** Play song i of this playlist (it becomes the active playlist). */
    fun playIn(c: Context, plId: String, i: Int) {
        ensure(c)
        if (pls.none { it.id == plId }) return
        setActive(c, plId)
        play(c, i)
    }

    fun position(): Int = try { mp?.currentPosition ?: 0 } catch (t: Throwable) { 0 }
    fun duration(): Int = try { mp?.duration ?: 0 } catch (t: Throwable) { 0 }
    fun seek(ms: Int) { try { mp?.seekTo(ms) } catch (t: Throwable) { } }

    fun pause() {
        try {
            val m = mp
            if (m != null && m.isPlaying) { m.pause(); playing = false; onChange?.invoke() }
        } catch (t: Throwable) { }
    }

    fun play(c: Context, i: Int) {
        val l = list(c)
        if (l.isEmpty()) return
        val n = ((i % l.size) + l.size) % l.size
        release()
        try {
            val m = MediaPlayer()
            m.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            m.setDataSource(File(dir(c), l[n].file).absolutePath)
            m.setOnCompletionListener { next(c) }          // after the last song it loops to the first
            m.setOnErrorListener { _, _, _ -> playing = false; onChange?.invoke(); true }
            m.prepare()
            m.start()
            mp = m
            index = n
            playing = true
            Beat.attach(c.applicationContext, m.audioSessionId)
        } catch (t: Throwable) {
            release()
            playing = false
        }
        onChange?.invoke()
    }

    fun toggle(c: Context) {
        val m = mp
        if (m == null) { play(c, if (index < 0) 0 else index); return }
        try {
            if (m.isPlaying) { m.pause(); playing = false } else { m.start(); playing = true }
        } catch (t: Throwable) { }
        onChange?.invoke()
    }

    fun next(c: Context) = play(c, (if (index < 0) 0 else index) + 1)
    fun prev(c: Context) = play(c, (if (index < 0) 0 else index) - 1)

    private fun release() {
        Beat.detach()
        try { mp?.release() } catch (t: Throwable) { }
        mp = null
    }

    fun stop() {
        release()
        playing = false
        index = -1
        onChange?.invoke()
    }
}

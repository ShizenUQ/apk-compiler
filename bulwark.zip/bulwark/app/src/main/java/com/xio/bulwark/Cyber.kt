package com.xio.bulwark

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

object Neon {
    const val CYAN = 0xFF19E6F2.toInt()
    const val GREEN = 0xFF3DDC97.toInt()
    const val VIOLET = 0xFF8F6BFF.toInt()
    fun a(c: Int, alpha: Int): Int = (c and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
    fun now(): Float = (SystemClock.uptimeMillis() % 1_000_000L) / 1000f
}

/** Backdrop: dark gradient, soft glow and a faint grid. Static on purpose, so it costs no CPU while you scroll. */
class CyberBg(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var base: Shader? = null
    private var glowA: Shader? = null
    private var glowB: Shader? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        base = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFF05080C.toInt(), 0xFF0B1118.toInt(), Shader.TileMode.CLAMP)
        glowA = android.graphics.RadialGradient(w * 0.22f, h * 0.12f, w * 0.7f, Neon.a(Neon.CYAN, 38), 0, Shader.TileMode.CLAMP)
        glowB = android.graphics.RadialGradient(w * 0.82f, h * 0.9f, w * 0.8f, Neon.a(Neon.VIOLET, 30), 0, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val d = Ui.dp(context, 1f)
        p.style = Paint.Style.FILL
        p.shader = base
        c.drawRect(0f, 0f, w, h, p)
        p.shader = glowA
        c.drawRect(0f, 0f, w, h, p)
        p.shader = glowB
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = Neon.a(Neon.CYAN, 14)
        val step = 34 * d
        var y = step * 0.5f
        while (y < h) { c.drawLine(0f, y, w, y, p); y += step }
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, h, p); x += step }
    }
}

/** Card with cut corners, the same panel as the Gallery tab. Static: no running light. */
class NeonCard(ctx: Context) : LinearLayout(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var fillShader: Shader? = null

    init {
        setWillNotDraw(false)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        fillShader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xF0101820.toInt(), 0xF00A0F15.toInt(), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        CyUi.chamfer(path, d, d, width - d, height - d, 16 * d)
        p.style = Paint.Style.FILL
        p.shader = fillShader
        c.drawPath(path, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = Cy.a(Cy.CYAN, 0.28f)
        c.drawPath(path, p)
    }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val d = Ui.dp(context, 1f)
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.BUTT
        p.strokeWidth = 2.2f * d
        p.color = Cy.PINK
        c.drawLine(d, 22 * d, d, 2 * d, p); c.drawLine(d, 2 * d, 46 * d, 2 * d, p)
        p.color = Cy.CYAN
        c.drawLine(w - 46 * d, h - 2 * d, w - 22 * d, h - 2 * d, p)
        p.strokeWidth = 1f * d
        p.color = Cy.a(Cy.CYAN, 0.45f)
        for (i in 0 until 4) c.drawLine(w - 14 * d - i * 5 * d, 6 * d, w - 14 * d - i * 5 * d, 10 * d, p)
    }
}

/** Header logo: a ring with an energy bolt, pulsing glow and crackling arcs. */
class BoltLogo(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bolt = Path()
    private val arc = Path()
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!isShown || windowVisibility != View.VISIBLE) { tickIdle = true; return }
            invalidate()
            postDelayed(this, 33)
        }
    }

    private var tickIdle = false

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val t = Neon.now()
        val pulse = 0.5f + 0.5f * sin(t * 2.6f)
        val flick = if (((t * 7f).toInt() % 11) == 0) 1f else 0f      // quick flash now and then
        p.style = Paint.Style.FILL
        p.shader = android.graphics.RadialGradient(cx, cy, s * 0.55f,
            Neon.a(Neon.CYAN, (50 + 60 * pulse + 80 * flick).toInt()), 0, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, s * 0.55f, p)
        p.shader = null
        // ring, with a gap that rotates
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = s * 0.055f
        val rr = s * 0.40f
        val ro = RectF(cx - rr, cy - rr, cx + rr, cy + rr)
        p.color = Neon.a(Neon.CYAN, 60)
        c.drawArc(ro, 0f, 360f, false, p)
        p.color = Neon.GREEN
        c.drawArc(ro, (t * 140f) % 360f, 110f, false, p)
        p.color = Neon.CYAN
        c.drawArc(ro, (t * -90f + 180f) % 360f, 50f, false, p)
        // bolt
        val u = s / 100f
        bolt.reset()
        bolt.moveTo(cx + 6 * u, cy - 30 * u)
        bolt.lineTo(cx - 14 * u, cy + 4 * u)
        bolt.lineTo(cx - 1 * u, cy + 4 * u)
        bolt.lineTo(cx - 7 * u, cy + 30 * u)
        bolt.lineTo(cx + 15 * u, cy - 7 * u)
        bolt.lineTo(cx + 2 * u, cy - 7 * u)
        bolt.close()
        p.style = Paint.Style.FILL
        p.color = Neon.a(Neon.CYAN, (60 + 70 * pulse).toInt())
        c.save(); c.scale(1.18f, 1.18f, cx, cy); c.drawPath(bolt, p); c.restore()
        p.color = Ui.mix(0xFFFFFFFF.toInt(), Neon.CYAN, 0.25f * (1f - pulse))
        c.drawPath(bolt, p)
        // crackling arcs
        val seed = (t * 9f).toInt()
        for (k in 0..1) {
            val ang = ((seed * 67 + k * 180) % 360) * 0.01745f
            val show = ((seed + k * 3) % 4) != 0
            if (!show) continue
            arc.reset()
            var x = cx + kotlin.math.cos(ang) * s * 0.40f
            var y = cy + kotlin.math.sin(ang) * s * 0.40f
            arc.moveTo(x, y)
            for (j in 1..3) {
                val a2 = ang + (((seed + j * 5 + k) % 7) - 3) * 0.06f
                x = cx + kotlin.math.cos(a2) * s * (0.40f - j * 0.075f)
                y = cy + kotlin.math.sin(a2) * s * (0.40f - j * 0.075f)
                arc.lineTo(x, y)
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = s * 0.022f
            p.color = Neon.a(Neon.GREEN, 220)
            c.drawPath(arc, p)
        }
        p.strokeCap = Paint.Cap.BUTT
    }
}

/** App title with a moving light and a short glitch every few seconds. */
class GlitchTitle(ctx: Context, private val text: String) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!isShown || windowVisibility != View.VISIBLE) { tickIdle = true; return }
            invalidate()
            postDelayed(this, 40)
        }
    }

    private var tickIdle = false

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onMeasure(w: Int, h: Int) {
        val d = Ui.dp(context, 1f)
        p.textSize = 21 * d
        p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        p.letterSpacing = 0.16f
        setMeasuredDimension((p.measureText(text) + 6 * d).toInt(), (30 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val t = Neon.now()
        p.textSize = 21 * d
        p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        p.letterSpacing = 0.16f
        val base = 23 * d
        val glitch = (t % 5f) in 4.7f..4.85f
        p.style = Paint.Style.FILL
        if (glitch) {
            val o = 2.4f * d * (if (((t * 40f).toInt() % 2) == 0) 1 else -1)
            p.shader = null
            p.color = Neon.a(Neon.CYAN, 200)
            c.drawText(text, 2 * d + o, base, p)
            p.color = Neon.a(0xFFFF3D7F.toInt(), 170)
            c.drawText(text, 2 * d - o, base, p)
        }
        val tw = p.measureText(text)
        val sweep = ((t * 0.35f) % 1.6f - 0.3f) * tw
        p.shader = LinearGradient(sweep - 40 * d, 0f, sweep + 40 * d, 0f,
            intArrayOf(0xFFE6EDF3.toInt(), Neon.CYAN, 0xFFE6EDF3.toInt()), null, Shader.TileMode.CLAMP)
        c.drawText(text, 2 * d, base, p)
        p.shader = null
        p.letterSpacing = 0f
    }
}

/** One picture in the gallery grid: thumbnail, a play badge on clips, dimmed when hidden from the status loop. */
class GalTile(ctx: Context, val item: GItem, private val index: Int) : View(ctx) {
    var onTap: (() -> Unit)? = null
    var onHold: (() -> Unit)? = null
    private var bmp: Bitmap? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()
    private var held = false
    private var down = false

    fun setBmp(b: Bitmap?) { bmp = b; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val ww = MeasureSpec.getSize(w)
        setMeasuredDimension(ww, (ww * 1.18f).toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                held = false; down = true; invalidate()
                postDelayed(longRun, 480)
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                down = false; invalidate()
                if (!held) onTap?.invoke()
            }
            MotionEvent.ACTION_CANCEL -> { removeCallbacks(longRun); down = false; invalidate() }
            MotionEvent.ACTION_MOVE -> if (e.x < 0 || e.y < 0 || e.x > width || e.y > height) { removeCallbacks(longRun); down = false; invalidate() }
        }
        return true
    }

    private val longRun = Runnable {
        held = true; down = false; invalidate()
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        onHold?.invoke()
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat()
        val h = height.toFloat()
        CyUi.chamfer(path, 0f, 0f, w, h, 14 * d)
        p.style = Paint.Style.FILL
        p.color = 0xFF05080C.toInt()
        c.drawPath(path, p)
        val b = bmp
        if (b != null) {
            c.save()
            c.clipPath(path)
            val s = max(w / b.width, h / b.height)
            val m = Matrix()
            m.postScale(s, s)
            m.postTranslate((w - b.width * s) / 2f, (h - b.height * s) / 2f)
            p.alpha = if (item.on) 255 else 90
            c.drawBitmap(b, m, p)
            p.alpha = 255
            c.restore()
        }
        if (item.type == "anim") {
            CyUi.text(c, p, "GIF", w - 8 * d, 7 * d, 0.55f * d, 0xFFFFFFFF.toInt(), 0.95f, false, 2)
        }
        val k = 0.55f * d
        val lab = String.format("I-%02d", index + 1)
        CyUi.chamfer(path, 0f, h - 18 * d, CyUi.width(lab, k) + 16 * d, h, 6 * d)
        p.style = Paint.Style.FILL
        p.color = 0xCC05080C.toInt()
        c.drawPath(path, p)
        CyUi.text(c, p, lab, 7 * d, h - 12.5f * d, k, Cy.CYAN, 1f, false)
        if (!item.on) {
            CyUi.text(c, p, "HIDDEN", w / 2f, h / 2f - 4 * d, 0.7f * d, 0xFFFFFFFF.toInt(), 0.95f, false, 1)
        }
        CyUi.chamfer(path, d, d, w - d, h - d, 14 * d)
        p.style = Paint.Style.STROKE
        p.strokeWidth = (if (down) 2.2f else 1.1f) * d
        p.color = if (down) CyUi.GREEN else Cy.a(Cy.CYAN, 0.55f)
        c.drawPath(path, p)
    }
}

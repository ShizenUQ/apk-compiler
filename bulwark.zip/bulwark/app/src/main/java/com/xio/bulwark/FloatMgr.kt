package com.xio.bulwark

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Floating windows over the game: a web window (a real browser in a frame) and app windows (a real app
 * started in Android's freeform mode through Shizuku, with our own title bar on top of it).
 */
class FloatMgr(
    private val ctx: Context,
    private val wm: WindowManager,
    private val screen: () -> IntArray,
    private val edge: (WindowManager.LayoutParams) -> Unit
) {
    private val d = ctx.resources.displayMetrics.density
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

    private val flagsBase = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED

    private fun dp(v: Float) = (v * d).toInt()

    private fun lp(w: Int, h: Int, x: Int, y: Int): WindowManager.LayoutParams {
        val l = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flagsBase, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        l.x = x; l.y = y
        return l
    }

    private fun land(): Boolean { val s = screen(); return s[0] > s[1] }
    private fun key(k: String) = if (land()) k + "_l" else k

    private fun add(v: View, l: WindowManager.LayoutParams): Boolean =
        try { wm.addView(v, l); true } catch (t: Throwable) { false }

    private fun del(v: View?) { if (v != null) try { wm.removeView(v) } catch (t: Throwable) { } }
    private fun upd(v: View?, l: WindowManager.LayoutParams?) { if (v != null && l != null) try { wm.updateViewLayout(v, l) } catch (t: Throwable) { } }

    // =============================================================== WIN tab

    private var tab: WinTab? = null
    private var tabLp: WindowManager.LayoutParams? = null

    /** Keeps the WIN tab hanging under (or above) the status. Called whenever the status moves. */
    fun placeTab(sx: Int, sy: Int, sw: Int, sh: Int) {
        if (!Prefs.bool(ctx, "win_on", true)) { removeTab(); return }
        val sc = screen()
        val w = dp(46f)
        val h = dp(17f)
        var x = sx + sw - w
        var y = sy + sh + dp(2f)
        if (y + h > sc[1]) y = sy - h - dp(2f)
        x = x.coerceIn(0, max(0, sc[0] - w))
        y = y.coerceIn(0, max(0, sc[1] - h))
        val t = tab
        val l = tabLp
        if (t != null && l != null) {
            if (l.x != x || l.y != y) { l.x = x; l.y = y; upd(t, l) }
            return
        }
        val v = WinTab(ctx)
        v.onTap = { if (panel != null) closePanel() else openPanel() }
        val nl = lp(w, h, x, y)
        if (add(v, nl)) { tab = v; tabLp = nl }
    }

    private fun removeTab() { del(tab); tab = null; tabLp = null; closePanel() }

    // =============================================================== launcher panel

    private var panel: CyWin? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var result: TextView? = null

    private fun openPanel() {
        if (panel != null) return
        val sc = screen()
        val w = min(sc[0] - dp(16f), dp(340f))
        val h = min((sc[1] * 0.78f).toInt(), dp(520f))
        val win = CyWin(ctx, "WIN")
        win.title = "LAUNCHER"
        win.buttons = listOf("x" to "X")
        win.onBtn = { if (it == "x") closePanel() }
        val l = lp(w, h, (sc[0] - w) / 2, max(dp(24f), (sc[1] - h) / 2))
        win.onMove = { dx, dy -> l.x = (l.x + dx).coerceIn(0, max(0, screen()[0] - l.width)); l.y = (l.y + dy).coerceIn(0, max(0, screen()[1] - l.height)); upd(win, l) }

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(10f), dp(6f), dp(10f), dp(10f))
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.addView(col, ViewGroup.LayoutParams(MATCH, ViewGroup.LayoutParams.WRAP_CONTENT))
        win.content.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))

        fun head(s: String) = CyLabel(ctx, s, CyUi.YELLOW).also { col.addView(it, LinearLayout.LayoutParams(MATCH, dp(28f))) }
        fun chip(s: String, c: Int, f: () -> Unit): CyLabel {
            val v = CyLabel(ctx, s, c, true)
            v.onTap = f
            return v
        }
        fun note(s: String): TextView {
            val t = TextView(ctx)
            t.text = s; t.textSize = 11f; t.setTextColor(0xFF7C8696.toInt())
            t.typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            t.setPadding(dp(2f), dp(2f), dp(2f), dp(6f))
            col.addView(t, LinearLayout.LayoutParams(MATCH, ViewGroup.LayoutParams.WRAP_CONTENT))
            return t
        }
        fun row(items: List<CyLabel>) {
            val r = LinearLayout(ctx)
            r.orientation = LinearLayout.HORIZONTAL
            for ((i, it) in items.withIndex()) {
                val lpp = LinearLayout.LayoutParams(0, dp(34f), 1f)
                if (i > 0) lpp.leftMargin = dp(6f)
                r.addView(it, lpp)
            }
            val rl = LinearLayout.LayoutParams(MATCH, ViewGroup.LayoutParams.WRAP_CONTENT)
            rl.bottomMargin = dp(6f)
            col.addView(r, rl)
        }

        head("WEB WINDOW")
        row(listOf(
            chip("TIKTOK", Cy.CYAN) { openWeb("https://www.tiktok.com"); closePanel() },
            chip("YOUTUBE", Cy.CYAN) { openWeb("https://m.youtube.com"); closePanel() },
            chip("TWITCH", Cy.CYAN) { openWeb("https://m.twitch.tv"); closePanel() }
        ))
        val last = Prefs.str(ctx, "web_last", "")
        row(listOf(
            chip("SEARCH", Cy.CYAN) { openWeb("https://www.google.com"); closePanel() },
            chip("LAST PAGE", if (last.isEmpty()) 0xFF566074.toInt() else Cy.CYAN) { if (last.isNotEmpty()) { openWeb(last); closePanel() } }
        ))

        head("APP WINDOW")
        note("Opens a real app as a floating window. Needs Shizuku and Freeform windows on in Developer options.")
        row(listOf(chip("TEST APP WINDOW", CyUi.YELLOW) { launchApp("com.android.settings", "SETTINGS") }))
        val res = TextView(ctx)
        res.textSize = 10.5f; res.setTextColor(0xFFFCEE0A.toInt()); res.typeface = Typeface.MONOSPACE
        res.setPadding(dp(2f), 0, dp(2f), dp(8f))
        col.addView(res, LinearLayout.LayoutParams(MATCH, ViewGroup.LayoutParams.WRAP_CONTENT))
        result = res

        val list = LinearLayout(ctx)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list, LinearLayout.LayoutParams(MATCH, ViewGroup.LayoutParams.WRAP_CONTENT))
        loadApps(list)

        if (add(win, l)) { panel = win; panelLp = l; tab?.open = true }
    }

    private fun closePanel() {
        del(panel); panel = null; panelLp = null; result = null
        tab?.open = false
    }

    private class AppEntry(val label: String, val pkg: String, val icon: Drawable?)

    private fun loadApps(list: LinearLayout) {
        io.execute {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = try {
                pm.queryIntentActivities(i, 0)
                    .filter { it.activityInfo.packageName != ctx.packageName }
                    .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, try { it.loadIcon(pm) } catch (t: Throwable) { null }) }
                    .distinctBy { it.pkg }
                    .sortedBy { it.label.lowercase() }
            } catch (t: Throwable) { emptyList() }
            main.post {
                if (panel == null) return@post
                for (a in apps) {
                    val r = LinearLayout(ctx)
                    r.orientation = LinearLayout.HORIZONTAL
                    r.gravity = Gravity.CENTER_VERTICAL
                    r.setPadding(dp(4f), dp(6f), dp(4f), dp(6f))
                    val ic = ImageView(ctx)
                    ic.setImageDrawable(a.icon)
                    r.addView(ic, LinearLayout.LayoutParams(dp(28f), dp(28f)))
                    val t = TextView(ctx)
                    t.text = a.label; t.textSize = 14f; t.setTextColor(0xFFE8ECF2.toInt())
                    t.typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
                    t.setPadding(dp(12f), 0, 0, 0)
                    t.maxLines = 1
                    r.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    val bar = View(ctx)
                    bar.setBackgroundColor(0xFF161A22.toInt())
                    r.setOnClickListener { launchApp(a.pkg, a.label.uppercase()) }
                    list.addView(r, LinearLayout.LayoutParams(MATCH, ViewGroup.LayoutParams.WRAP_CONTENT))
                    list.addView(bar, LinearLayout.LayoutParams(MATCH, 1))
                }
            }
        }
    }

    // =============================================================== web window

    private var web: CyWin? = null
    private var webLp: WindowManager.LayoutParams? = null
    private var wv: WebView? = null
    private var addr: EditText? = null
    private var mini = false
    private var saveW = 0
    private var saveH = 0
    private var alphaIdx = 0
    private var typing = false

    private fun norm(s0: String): String {
        val s = s0.trim()
        if (s.isEmpty()) return "https://www.google.com"
        if (s.startsWith("http://") || s.startsWith("https://")) return s
        if (s.contains(' ') || !s.contains('.')) return "https://www.google.com/search?q=" + URLEncoder.encode(s, "UTF-8")
        return "https://$s"
    }

    private fun webFocus(on: Boolean) {
        val l = webLp ?: return
        typing = on
        l.flags = if (on) l.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv() else l.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        upd(web, l)
        web?.lit = if (on) setOf("key") else emptySet()
        if (!on) {
            try { (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(addr?.windowToken, 0) } catch (t: Throwable) { }
        }
    }

    private fun saveWeb() {
        val l = webLp ?: return
        if (mini) return
        Prefs.putInt(ctx, key("web_x"), l.x); Prefs.putInt(ctx, key("web_y"), l.y)
        Prefs.putInt(ctx, key("web_w"), l.width); Prefs.putInt(ctx, key("web_h"), l.height)
    }

    fun openWeb(url: String) {
        val cur = wv
        if (cur != null) {
            cur.loadUrl(url)
            if (mini) toggleMini()
            return
        }
        val sc = screen()
        val sw = sc[0]; val sh = sc[1]
        var w = Prefs.int(ctx, key("web_w"), 0)
        var h = Prefs.int(ctx, key("web_h"), 0)
        if (w <= 0 || h <= 0) {
            if (sw > sh) { w = (sw * 0.42f).toInt(); h = (sh * 0.82f).toInt() }
            else { w = (sw * 0.86f).toInt(); h = (sh * 0.5f).toInt() }
        }
        w = w.coerceIn(dp(200f), sw); h = h.coerceIn(dp(160f), sh)
        val x = Prefs.int(ctx, key("web_x"), sw - w - dp(8f)).coerceIn(0, max(0, sw - w))
        val y = Prefs.int(ctx, key("web_y"), max(dp(60f), (sh * 0.1f).toInt())).coerceIn(0, max(0, sh - h))

        val win = CyWin(ctx, "WEB")
        win.title = "LOADING"
        win.buttons = listOf("key" to "KEY", "op" to "OP", "mn" to "MIN", "x" to "X")
        val l = lp(w, h, x, y)

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val ed = EditText(ctx)
        ed.setSingleLine()
        ed.textSize = 12f
        ed.typeface = Typeface.MONOSPACE
        ed.setTextColor(0xFFE8ECF2.toInt())
        ed.setHintTextColor(0xFF566074.toInt())
        ed.hint = "address or search"
        ed.setBackgroundColor(0xFF0E131B.toInt())
        ed.setPadding(dp(10f), 0, dp(10f), 0)
        ed.imeOptions = EditorInfo.IME_ACTION_GO
        ed.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        col.addView(ed, LinearLayout.LayoutParams(MATCH, dp(30f)))
        val line = View(ctx)
        line.setBackgroundColor(Cy.a(Cy.CYAN, 0.25f))
        col.addView(line, LinearLayout.LayoutParams(MATCH, 1))

        val v = WebView(ctx)
        val st = v.settings
        st.javaScriptEnabled = true
        st.domStorageEnabled = true
        st.mediaPlaybackRequiresUserGesture = false
        st.useWideViewPort = true
        st.loadWithOverviewMode = true
        st.setSupportZoom(true)
        st.builtInZoomControls = true
        st.displayZoomControls = false
        st.userAgentString = st.userAgentString.replace("; wv", "").replace("Version/4.0 ", "")
        try {
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(v, true)
        } catch (t: Throwable) { }
        v.setBackgroundColor(0xFF000000.toInt())
        v.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                val u = request.url.scheme ?: ""
                return !(u == "http" || u == "https")
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (url != null && !ed.hasFocus()) ed.setText(url)
                if (url != null) Prefs.putStr(ctx, "web_last", url)
                val t = view.title
                win.title = if (t.isNullOrBlank()) "WEB" else t
            }
        }
        v.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, title: String?) { if (!title.isNullOrBlank()) win.title = title }
        }
        col.addView(v, LinearLayout.LayoutParams(MATCH, 0, 1f))
        win.content.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        ed.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_GO || a == EditorInfo.IME_ACTION_DONE) {
                v.loadUrl(norm(ed.text.toString()))
                ed.clearFocus()
                webFocus(false)
                true
            } else false
        }
        ed.setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_DOWN) webFocus(true); false }

        win.onMove = { dx, dy ->
            l.x = (l.x + dx).coerceIn(0, max(0, screen()[0] - l.width))
            l.y = (l.y + dy).coerceIn(0, max(0, screen()[1] - l.height))
            upd(win, l)
        }
        win.onResize = { dw, dh ->
            val s2 = screen()
            l.width = (l.width + dw).coerceIn(dp(200f), max(dp(200f), s2[0] - l.x))
            l.height = (l.height + dh).coerceIn(dp(160f), max(dp(160f), s2[1] - l.y))
            upd(win, l)
        }
        win.onEnd = { saveWeb() }
        win.onMiniTap = { toggleMini() }
        win.onBtn = { b ->
            when (b) {
                "x" -> closeWeb()
                "mn" -> toggleMini()
                "key" -> webFocus(!typing)
                "op" -> {
                    alphaIdx = (alphaIdx + 1) % 3
                    l.alpha = floatArrayOf(1f, 0.85f, 0.65f)[alphaIdx]
                    upd(win, l)
                }
            }
        }
        if (add(win, l)) {
            web = win; webLp = l; wv = v; addr = ed; mini = false
            v.loadUrl(url)
        }
    }

    private fun toggleMini() {
        val win = web ?: return
        val l = webLp ?: return
        if (!mini) {
            saveW = l.width; saveH = l.height
            l.width = dp(58f); l.height = dp(30f)
            win.mini = true
            mini = true
            if (typing) webFocus(false)
        } else {
            val s = screen()
            l.width = saveW.coerceAtMost(s[0]); l.height = saveH.coerceAtMost(s[1])
            l.x = l.x.coerceIn(0, max(0, s[0] - l.width)); l.y = l.y.coerceIn(0, max(0, s[1] - l.height))
            win.mini = false
            mini = false
        }
        upd(win, l)
    }

    private fun closeWeb() {
        if (typing) webFocus(false)
        val v = wv
        del(web)
        web = null; webLp = null; wv = null; addr = null; mini = false
        try { v?.stopLoading(); v?.loadUrl("about:blank"); v?.destroy() } catch (t: Throwable) { }
    }

    // =============================================================== app windows

    private class AppWin(val pkg: String, val taskId: Int, val bounds: Rect, val label: String) {
        var bar: CyWin? = null
        var barLp: WindowManager.LayoutParams? = null
        var grip: WinGrip? = null
        var gripLp: WindowManager.LayoutParams? = null
        var baseW = 0
        var baseH = 0
        var sizeIdx = 1
        @Volatile var busy = false
        @Volatile var dirty = false
    }

    private val apps = ArrayList<AppWin>()
    @Volatile private var resizeForm = 0

    private fun defaultBounds(): Rect {
        val sc = screen()
        val sw = sc[0]; val sh = sc[1]
        val bar = dp(30f)
        var w = Prefs.int(ctx, key("app_w"), 0)
        var h = Prefs.int(ctx, key("app_h"), 0)
        if (w <= 0 || h <= 0) {
            if (sw > sh) { h = (sh * 0.72f).toInt(); w = (h * 0.62f).toInt() }
            else { w = (sw * 0.6f).toInt(); h = min((w * 1.75f).toInt(), (sh * 0.68f).toInt()) }
        }
        w = w.coerceIn(dp(140f), sw); h = h.coerceIn(dp(140f), sh - bar)
        val x = Prefs.int(ctx, key("app_x"), sw - w - dp(10f)).coerceIn(0, max(0, sw - w))
        val y = Prefs.int(ctx, key("app_y"), max(dp(64f) + bar, (sh * 0.14f).toInt())).coerceIn(bar, max(bar, sh - h))
        return Rect(x, y, x + w, y + h)
    }

    private fun findTask(pkg: String): Triple<Int, Boolean, String>? {
        val out = FpsClient.shell(ctx, "dumpsys activity activities", 9000)
        var first: Triple<Int, Boolean, String>? = null
        for (line in out.lineSequence()) {
            if (!(line.contains("Task{") || line.contains("TaskRecord{"))) continue
            if (!line.contains(pkg)) continue
            val m = Regex("#(\\d+)").find(line) ?: continue
            val id = m.groupValues[1].toIntOrNull() ?: continue
            val ff = line.contains("mode=freeform") || line.contains("windowingMode=freeform") || line.contains("mWindowingMode=freeform")
            val t = Triple(id, ff, line.trim().take(140))
            if (ff) return t
            if (first == null) first = t
        }
        return first
    }

    private fun bad(o: String) = o.startsWith("ERR:") || o.contains("Error", true) || o.contains("Exception") || o.contains("Usage") || o.contains("Unknown")

    private fun tryResize(id: Int, r: Rect): Boolean {
        val forms = listOf(
            "am task resize $id ${r.left},${r.top},${r.right},${r.bottom}",
            "am task resize $id ${r.left} ${r.top} ${r.right} ${r.bottom}",
            "cmd activity task resize $id ${r.left} ${r.top} ${r.right} ${r.bottom}"
        )
        val start = resizeForm
        for (n in forms.indices) {
            val i = (start + n) % forms.size
            val o = FpsClient.shell(ctx, forms[i], 4000)
            if (!bad(o)) { resizeForm = i; return true }
        }
        return false
    }

    fun launchApp(pkg: String, label: String) {
        val rep = ArrayList<String>()
        fun say(s: String) { rep.add(s); val t = rep.joinToString("\n"); main.post { result?.text = t } }
        result?.text = "working..."
        io.execute {
            if (FpsClient.state(ctx) != FpsClient.St.READY) { say("Shizuku is not ready. Start it and allow Frameline."); return@execute }
            val comp = ctx.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString()
            if (comp == null) { say("Cannot find how to open $label."); return@execute }
            FpsClient.shell(ctx, "settings put global enable_freeform_support 1; settings put global force_resizable_activities 1; settings put global freeform_window_management 1", 6000)
            say("1. freeform switches on")
            val b = defaultBounds()
            val out = FpsClient.shell(ctx, "am start --windowingMode 5 -n $comp", 7000)
            val tail = out.trim().lines().lastOrNull { it.isNotBlank() } ?: ""
            if (bad(out)) { say("2. start failed: ${tail.take(90)}"); return@execute }
            say("2. app started")
            var t: Triple<Int, Boolean, String>? = null
            for (i in 0 until 5) {
                try { Thread.sleep(650) } catch (e: Throwable) { }
                t = findTask(pkg)
                if (t != null && t.second) break
            }
            if (t == null) { say("3. no window found for $label"); return@execute }
            if (!t.second) {
                say("3. your phone opened it full screen, not floating")
                say(t.third)
                return@execute
            }
            say("3. floating mode accepted (task ${t.first})")
            if (!tryResize(t.first, b)) { say("4. floating, but it would not resize"); return@execute }
            say("4. window placed. Done.")
            val aw = AppWin(pkg, t.first, b, label)
            main.post { showApp(aw); closePanel() }
        }
    }

    private fun pushBounds(a: AppWin) {
        if (a.busy) { a.dirty = true; return }
        a.busy = true
        val r = Rect(a.bounds)
        io.execute {
            tryResize(a.taskId, r)
            a.busy = false
            if (a.dirty) { a.dirty = false; main.post { pushBounds(a) } }
        }
    }

    private fun layoutApp(a: AppWin) {
        val bar = a.bar ?: return
        val bl = a.barLp ?: return
        val gl = a.gripLp
        val tb = bar.tb.toInt()
        bl.x = a.bounds.left; bl.y = a.bounds.top - tb; bl.width = a.bounds.width()
        upd(bar, bl)
        if (gl != null) {
            gl.x = a.bounds.right - gl.width; gl.y = a.bounds.bottom - gl.height
            upd(a.grip, gl)
        }
    }

    private fun showApp(a: AppWin) {
        val bar = CyWin(ctx, "APP", true)
        bar.title = a.label
        bar.buttons = listOf("sz" to "SZ", "x" to "X")
        val tb = bar.tb.toInt()
        val bl = lp(a.bounds.width(), tb, a.bounds.left, a.bounds.top - tb)
        val g = WinGrip(ctx)
        val gs = dp(30f)
        val gl = lp(gs, gs, a.bounds.right - gs, a.bounds.bottom - gs)
        a.bar = bar; a.barLp = bl; a.grip = g; a.gripLp = gl
        a.baseW = a.bounds.width(); a.baseH = a.bounds.height()

        bar.onMove = { dx, dy ->
            val s = screen()
            val w = a.bounds.width(); val h = a.bounds.height()
            val nl = (a.bounds.left + dx).coerceIn(0, max(0, s[0] - w))
            val nt = (a.bounds.top + dy).coerceIn(tb, max(tb, s[1] - h))
            a.bounds.set(nl, nt, nl + w, nt + h)
            layoutApp(a); pushBounds(a)
        }
        bar.onEnd = { pushBounds(a); saveApp(a) }
        bar.onBtn = { id ->
            when (id) {
                "x" -> closeApp(a)
                "sz" -> {
                    a.sizeIdx = (a.sizeIdx + 1) % 3
                    val f = floatArrayOf(0.75f, 1f, 1.35f)[a.sizeIdx]
                    val s = screen()
                    val w = (a.baseW * f).toInt().coerceIn(dp(140f), s[0])
                    val h = (a.baseH * f).toInt().coerceIn(dp(140f), s[1] - tb)
                    val nl = a.bounds.left.coerceIn(0, max(0, s[0] - w))
                    val nt = a.bounds.top.coerceIn(tb, max(tb, s[1] - h))
                    a.bounds.set(nl, nt, nl + w, nt + h)
                    layoutApp(a); pushBounds(a); saveApp(a)
                }
            }
        }
        g.onResize = { dw, dh ->
            val s = screen()
            val w = (a.bounds.width() + dw).coerceIn(dp(140f), max(dp(140f), s[0] - a.bounds.left))
            val h = (a.bounds.height() + dh).coerceIn(dp(140f), max(dp(140f), s[1] - a.bounds.top))
            a.bounds.set(a.bounds.left, a.bounds.top, a.bounds.left + w, a.bounds.top + h)
            a.baseW = w; a.baseH = h
            layoutApp(a); pushBounds(a)
        }
        g.onEnd = { pushBounds(a); saveApp(a) }
        if (add(bar, bl) && add(g, gl)) apps.add(a)
    }

    private fun saveApp(a: AppWin) {
        Prefs.putInt(ctx, key("app_x"), a.bounds.left); Prefs.putInt(ctx, key("app_y"), a.bounds.top)
        Prefs.putInt(ctx, key("app_w"), a.bounds.width()); Prefs.putInt(ctx, key("app_h"), a.bounds.height())
    }

    private fun closeApp(a: AppWin) {
        del(a.bar); del(a.grip)
        apps.remove(a)
        io.execute { FpsClient.shell(ctx, "am force-stop ${a.pkg}", 4000) }
        Toast.makeText(ctx, "${a.label} closed", Toast.LENGTH_SHORT).show()
    }

    // =============================================================== lifecycle

    /** Screen turned (or size changed): keep every window on screen. */
    fun onConfig() {
        val s = screen()
        val l = webLp
        if (l != null) {
            l.width = l.width.coerceAtMost(s[0]); l.height = l.height.coerceAtMost(s[1])
            l.x = l.x.coerceIn(0, max(0, s[0] - l.width)); l.y = l.y.coerceIn(0, max(0, s[1] - l.height))
            upd(web, l)
        }
        val pl = panelLp
        if (pl != null) {
            pl.width = pl.width.coerceAtMost(s[0]); pl.height = pl.height.coerceAtMost(s[1])
            pl.x = pl.x.coerceIn(0, max(0, s[0] - pl.width)); pl.y = pl.y.coerceIn(0, max(0, s[1] - pl.height))
            upd(panel, pl)
        }
        for (a in apps) {
            val tb = dp(30f)
            val w = a.bounds.width().coerceAtMost(s[0]); val h = a.bounds.height().coerceAtMost(s[1] - tb)
            val nl = a.bounds.left.coerceIn(0, max(0, s[0] - w)); val nt = a.bounds.top.coerceIn(tb, max(tb, s[1] - h))
            a.bounds.set(nl, nt, nl + w, nt + h)
            layoutApp(a); pushBounds(a)
        }
    }

    fun destroy() {
        closePanel()
        closeWeb()
        for (a in apps.toList()) { del(a.bar); del(a.grip) }
        apps.clear()
        removeTab()
        io.shutdown()
    }
}

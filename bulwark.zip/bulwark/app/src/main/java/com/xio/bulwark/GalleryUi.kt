package com.xio.bulwark

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import kotlin.math.max

/** Small helpers for the angular, hard-edged look of the Gallery tab. Everything here is drawn once, nothing loops. */
object CyUi {
    const val YELLOW = 0xFFFCEE0A.toInt()
    const val INK = 0xFF05080C.toInt()
    const val GREEN = 0xFF3DDC97.toInt()

    /** Rectangle with the top-right and bottom-left corners cut off. */
    fun chamfer(p: Path, l: Float, t: Float, r: Float, b: Float, cut: Float) {
        p.reset()
        p.moveTo(l, t); p.lineTo(r - cut, t); p.lineTo(r, t + cut); p.lineTo(r, b); p.lineTo(l + cut, b); p.lineTo(l, b - cut); p.close()
    }

    fun text(c: Canvas, p: Paint, s: String, x: Float, top: Float, k: Float, col: Int, al: Float, glow: Boolean, align: Int = 0) {
        val w = Cy.twidth(s, k) - 2.2f * k
        var px = when (align) { 1 -> x - w / 2f; 2 -> x - w; else -> x }
        for (ch in s) { Cy.glyph(c, p, ch, px, top, k, col, al, glow); px += Cy.adv(ch, k) }
    }

    fun width(s: String, k: Float) = Cy.twidth(s, k) - 2.2f * k
}

/** Panel with cut corners, a long bright edge on two corners and tick marks. */
class CyPanel(ctx: Context) : LinearLayout(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var fillShader: Shader? = null

    init { setWillNotDraw(false); orientation = VERTICAL }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        fillShader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xF0101820.toInt(), 0xF00A0F15.toInt(), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        CyUi.chamfer(path, d, d, width - d, height - d, 16 * d)
        p.style = Paint.Style.FILL
        p.shader = fillShader
        c.drawPath(path, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = Cy.a(Cy.CYAN, 0.28f)
        c.drawPath(path, p)
    }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val d = Ui.dp(context, 1f)
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.BUTT
        p.strokeWidth = 2.2f * d
        p.color = Cy.PINK
        c.drawLine(d, 22 * d, d, 2 * d, p); c.drawLine(d, 2 * d, 46 * d, 2 * d, p)
        p.color = Cy.CYAN
        c.drawLine(w - 46 * d, h - 2 * d, w - 22 * d, h - 2 * d, p)
        p.strokeWidth = 1f * d
        p.color = Cy.a(Cy.CYAN, 0.45f)
        for (i in 0 until 4) c.drawLine(w - 14 * d - i * 5 * d, 6 * d, w - 14 * d - i * 5 * d, 10 * d, p)
    }
}

/** Section title in the angular font with a tag chip on the right. */
class CyTitle(ctx: Context, private val title: String, var tag: String, private val tagCol: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (38 * Ui.dp(context, 1f)).toInt())
    }

    fun setTagText(t: String) { tag = t; invalidate() }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat()
        CyUi.text(c, p, title, 2 * d, 4 * d, 1.45f * d, 0xFFEAFBFF.toInt(), 1f, true)
        if (tag.isNotEmpty()) {
            val k = 0.62f * d
            val tw = CyUi.width(tag, k)
            val x1 = w - 4 * d
            val x0 = x1 - tw - 18 * d
            CyUi.chamfer(path, x0, 4 * d, x1, 22 * d, 6 * d)
            p.style = Paint.Style.FILL
            p.color = Cy.a(tagCol, 0.14f)
            c.drawPath(path, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f * d
            p.color = Cy.a(tagCol, 0.9f)
            c.drawPath(path, p)
            CyUi.text(c, p, tag, x0 + 9 * d, 10 * d, k, tagCol, 1f, false)
        }
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.BUTT
        p.strokeWidth = 1f * d
        p.color = Cy.a(Cy.CYAN, 0.4f)
        c.drawLine(0f, 31 * d, w - 14 * d, 31 * d, p)
        c.drawLine(w - 14 * d, 31 * d, w - 8 * d, 26 * d, p)
        p.strokeWidth = 2.4f * d
        p.color = tagCol
        c.drawLine(0f, 31 * d, 30 * d, 31 * d, p)
    }
}

/** Hard-edged button with a label in the angular font. */
class CyBtn(ctx: Context, var label: String, private val col: Int) : View(ctx) {
    var onClick: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var down = false

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (46 * Ui.dp(context, 1f)).toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; invalidate() }
            MotionEvent.ACTION_UP -> { val was = down; down = false; invalidate(); if (was) { performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); onClick?.invoke() } }
            MotionEvent.ACTION_CANCEL -> { down = false; invalidate() }
            MotionEvent.ACTION_MOVE -> if (e.x < 0 || e.y < 0 || e.x > width || e.y > height) { down = false; invalidate() }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat(); val h = height.toFloat()
        CyUi.chamfer(path, d, d, w - d, h - d, 12 * d)
        p.style = Paint.Style.FILL
        p.color = Cy.a(col, if (down) 0.38f else 0.16f)
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.4f * d
        p.color = Cy.a(col, 0.95f)
        c.drawPath(path, p)
        val k = 0.95f * d
        CyUi.text(c, p, label, w / 2f, (h - 9.5f * k) / 2f, k, 0xFFEAFBFF.toInt(), 1f, true, 1)
    }
}

/** Segmented choice with hard-edged cells. */
class CySeg(ctx: Context, private val labels: List<String>, private val col: Int) : View(ctx) {
    var selected = 0
        private set
    var onSelect: ((Int) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    fun select(i: Int) { selected = i.coerceIn(0, labels.size - 1); invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (40 * Ui.dp(context, 1f)).toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val i = (e.x / (width.toFloat() / labels.size)).toInt().coerceIn(0, labels.size - 1)
            if (i != selected) { selected = i; invalidate(); performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); onSelect?.invoke(i) }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat(); val h = height.toFloat()
        val cw = w / labels.size
        for (i in labels.indices) {
            val l = i * cw + 1.5f * d
            val r = (i + 1) * cw - 1.5f * d
            CyUi.chamfer(path, l, d, r, h - d, 8 * d)
            val on = i == selected
            p.style = Paint.Style.FILL
            p.color = Cy.a(col, if (on) 0.30f else 0.06f)
            c.drawPath(path, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = (if (on) 1.5f else 1f) * d
            p.color = Cy.a(if (on) col else Cy.CYAN, if (on) 0.95f else 0.25f)
            c.drawPath(path, p)
            val k = 0.8f * d
            CyUi.text(c, p, labels[i], (l + r) / 2f, (h - 8f * k) / 2f, k, if (on) 0xFFFFFFFF.toInt() else 0xFF8B96A3.toInt(), 1f, on, 1)
        }
    }
}

/** One video in the list. It plays (muted) while it is on screen; tap = full screen, "show on status" chip = pick it, hold = options. */
class VideoCard(ctx: Context, val item: GItem, private val index: Int) : FrameLayout(ctx) {
    var onStatus = false
        set(v) { field = v; invalidate() }
    var onOpen: (() -> Unit)? = null
    var onPick: (() -> Unit)? = null
    var onHold: (() -> Unit)? = null
    private val thumb = ImageView(ctx)
    private val tv = TextureView(ctx)
    private var mp: MediaPlayer? = null
    private var want = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val chip = RectF()
    private var held = false
    private var downX = 0f
    private var downY = 0f
    private var press = false
    private var shade: Shader? = null

    init {
        setWillNotDraw(false)
        setBackgroundColor(0xFF05080C.toInt())
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        addView(thumb, LayoutParams(-1, -1))
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { if (want) start() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { release(); return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        addView(tv, LayoutParams(-1, -1))
        tv.alpha = 0f
    }

    fun setThumb(b: Bitmap?) { thumb.setImageBitmap(b) }

    override fun onMeasure(w: Int, h: Int) {
        val ww = MeasureSpec.getSize(w)
        val hh = ww * 9 / 16
        super.onMeasure(MeasureSpec.makeMeasureSpec(ww, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(hh, MeasureSpec.EXACTLY))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        shade = LinearGradient(0f, h * 0.55f, 0f, h.toFloat(), 0x00000000, 0xDD000000.toInt(), Shader.TileMode.CLAMP)
    }

    fun play() { want = true; if (tv.isAvailable) start() }
    fun stop() { want = false; release(); tv.alpha = 0f }

    private fun start() {
        if (mp != null) return
        val st = tv.surfaceTexture ?: return
        try {
            val m = MediaPlayer()
            val s = Gallery.silent(context, item)
            m.setDataSource((if (s.exists()) s else Gallery.file(context, item)).absolutePath)
            m.setSurface(Surface(st))
            m.isLooping = true
            m.setVolume(0f, 0f)
            m.setOnVideoSizeChangedListener { _, vw, vh -> fit(vw, vh) }
            m.setOnErrorListener { _, _, _ -> release(); true }
            m.setOnPreparedListener { pl -> if (want) { pl.start(); tv.alpha = 1f } }
            m.prepareAsync()
            mp = m
        } catch (t: Throwable) { release() }
    }

    private fun fit(vw: Int, vh: Int) {
        tv.post {
            val w = tv.width.toFloat(); val h = tv.height.toFloat()
            if (w <= 0f || h <= 0f || vw <= 0 || vh <= 0) return@post
            val va = vw.toFloat() / vh; val ba = w / h
            val m = Matrix()
            if (va > ba) m.setScale(va / ba, 1f, w / 2f, h / 2f) else m.setScale(1f, ba / va, w / 2f, h / 2f)
            tv.setTransform(m)
        }
    }

    private fun release() {
        val m = mp ?: return
        mp = null
        try { m.setOnPreparedListener(null); m.stop() } catch (t: Throwable) { }
        try { m.release() } catch (t: Throwable) { }
    }

    override fun onDetachedFromWindow() { release(); super.onDetachedFromWindow() }

    private fun chipHit(x: Float, y: Float): Boolean {
        val d = Ui.dp(context, 1f)
        return x > width - 150 * d && y > height - 44 * d
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; held = false; press = true; invalidate(); postDelayed(longRun, 480) }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun); press = false; invalidate()
                if (!held) { if (chipHit(downX, downY)) onPick?.invoke() else onOpen?.invoke() }
            }
            MotionEvent.ACTION_CANCEL -> { removeCallbacks(longRun); press = false; invalidate() }
            MotionEvent.ACTION_MOVE -> if (kotlin.math.abs(e.x - downX) > 24 || kotlin.math.abs(e.y - downY) > 24) { removeCallbacks(longRun); press = false; invalidate() }
        }
        return true
    }

    private val longRun = Runnable {
        held = true; press = false; invalidate()
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        onHold?.invoke()
    }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val d = Ui.dp(context, 1f)
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.shader = shade
        c.drawRect(0f, h * 0.55f, w, h, p)
        p.shader = null
        // the cut corners: painted over in the panel colour (cheaper than clipping a video surface while scrolling)
        val cc = 18 * d
        p.style = Paint.Style.FILL
        p.color = 0xFF0C1219.toInt()
        path.reset(); path.moveTo(w - cc, 0f); path.lineTo(w, 0f); path.lineTo(w, cc); path.close(); c.drawPath(path, p)
        path.reset(); path.moveTo(0f, h - cc); path.lineTo(0f, h); path.lineTo(cc, h); path.close(); c.drawPath(path, p)
        // static scanlines
        p.strokeWidth = 1f
        p.color = 0x12FFFFFF
        var y = 2f * d
        while (y < h) { c.drawLine(0f, y, w, y, p); y += 4f * d }
        // index tag
        val label = String.format("V-%02d", index + 1)
        val k = 0.6f * d
        val tw = CyUi.width(label, k)
        CyUi.chamfer(path, 0f, 0f, tw + 20 * d, 20 * d, 7 * d)
        p.style = Paint.Style.FILL
        p.color = 0xCC05080C.toInt()
        c.drawPath(path, p)
        CyUi.text(c, p, label, 9 * d, 6.5f * d, k, Cy.CYAN, 1f, false)
        // muted mark
        CyUi.text(c, p, "MUTED", 12 * d, h - 18 * d, 0.5f * d, 0xFF9AA7B3.toInt(), 0.9f, false)
        // pick chip
        val ck = 0.6f * d
        val txt = if (onStatus) "ON STATUS" else "SHOW ON STATUS"
        val cw = CyUi.width(txt, ck) + 22 * d
        chip.set(w - cw - 10 * d, h - 30 * d, w - 10 * d, h - 10 * d)
        CyUi.chamfer(path, chip.left, chip.top, chip.right, chip.bottom, 7 * d)
        p.style = Paint.Style.FILL
        p.color = if (onStatus) CyUi.YELLOW else 0xCC05080C.toInt()
        c.drawPath(path, p)
        if (!onStatus) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f * d
            p.color = Cy.a(Cy.CYAN, 0.9f)
            c.drawPath(path, p)
        }
        CyUi.text(c, p, txt, chip.centerX(), chip.top + 6.5f * d, ck, if (onStatus) CyUi.INK else 0xFFEAFBFF.toInt(), 1f, false, 1)
        // frame
        CyUi.chamfer(path, d, d, w - d, h - d, 18 * d)
        p.style = Paint.Style.STROKE
        p.strokeWidth = (if (onStatus) 2.4f else 1.1f) * d
        p.color = if (onStatus) CyUi.YELLOW else if (press) CyUi.GREEN else Cy.a(Cy.CYAN, 0.6f)
        c.drawPath(path, p)
    }

}

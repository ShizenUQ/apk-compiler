package com.xio.bulwark

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Thumbnail card for one library video: picture, name, length and how far you got. */
private class VidCard(ctx: Context, val v: VItem) : LinearLayout(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val img = ImageView(ctx)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val frac = if (v.dur > 0) (VideoLib.pos(ctx, v.id).toFloat() / v.dur).coerceIn(0f, 1f) else 0f
    var onTap: (() -> Unit)? = null

    init {
        orientation = VERTICAL
        setWillNotDraw(false)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.setBackgroundColor(0xFF0B1118.toInt())
        addView(img, LayoutParams(-1, 0))
        val t = TextView(ctx)
        t.text = v.title; t.textSize = 12f; t.maxLines = 2; t.setTextColor(0xFFE8ECF2.toInt())
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (7 * d).toInt())
        addView(t, LayoutParams(-1, -2))
        val b = VThumbs.peek(v)
        if (b != null) img.setImageBitmap(b) else VThumbs.load(ctx, v) { bm -> if (bm != null) img.setImageBitmap(bm) }
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val lpI = img.layoutParams
        lpI.height = (w * 9f / 16f).toInt()
        super.onMeasure(wSpec, hSpec)
    }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val w = width.toFloat(); val ih = img.height.toFloat()
        // length badge
        val s = VideoLib.fmt(v.dur)
        val k = 0.5f * d
        val tw = CyUi.width(s, k)
        p.style = Paint.Style.FILL; p.color = 0xCC000000.toInt()
        c.drawRect(w - tw - 12 * d, ih - 15 * d, w - 3 * d, ih - 3 * d, p)
        CyUi.text(c, p, s, w - tw - 7.5f * d, ih - 12.5f * d, k, 0xFFEAFBFF.toInt(), 1f, false)
        if (frac > 0.02f) {
            p.color = 0xAA000000.toInt(); c.drawRect(0f, ih - 3 * d, w, ih, p)
            p.color = CyUi.YELLOW; c.drawRect(0f, ih - 3 * d, w * frac, ih, p)
        }
        CyUi.chamfer(path, d * 0.6f, d * 0.6f, w - d * 0.6f, height - d * 0.6f, 9 * d)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d; p.color = Cy.a(Cy.CYAN, 0.45f)
        c.drawPath(path, p)
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = true
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}

/** Playlist as a wide strip: a 2x2 mosaic of its videos on the left, name and count on the right. */
private class ListStrip(ctx: Context, val l: VList, val active: Boolean) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val vids = VideoLib.videosOf(ctx, l.id)
    var onTap: (() -> Unit)? = null
    var onMore: (() -> Unit)? = null
    private val more = RectF()

    init {
        for (v in vids.take(4)) if (VThumbs.peek(v) == null) VThumbs.load(ctx, v) { invalidate() }
    }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), (74 * d).toInt()) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val col = if (active) CyUi.YELLOW else Cy.CYAN
        CyUi.chamfer(path, d, d, w - d, h - d, 10 * d)
        p.style = Paint.Style.FILL; p.color = Cy.a(col, if (active) 0.1f else 0.05f); c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = (if (active) 1.6f else 1.1f) * d; p.color = Cy.a(col, if (active) 0.9f else 0.4f); c.drawPath(path, p)
        // mosaic
        val m = 8 * d; val s = h - 2 * m; val half = s / 2f
        c.save()
        c.clipRect(m, m, m + s * 1.6f, m + s)
        for (i in 0 until 4) {
            val x = m + (i % 2) * half * 1.6f; val y = m + (i / 2) * half
            val v = vids.getOrNull(i)
            val b = if (v != null) VThumbs.peek(v) else null
            val r = RectF(x, y, x + half * 1.6f - d, y + half - d)
            if (b != null) c.drawBitmap(b, android.graphics.Rect(0, 0, b.width, b.height), r, p)
            else { p.style = Paint.Style.FILL; p.color = 0xFF0B1118.toInt(); c.drawRect(r, p) }
        }
        c.restore()
        val tx = m + s * 1.6f + 12 * d
        val nm = l.name.uppercase()
        val k = 0.8f * d
        var show = nm
        if (CyUi.supported(show)) {
            while (show.length > 1 && CyUi.width(show, k) > w - tx - 46 * d) show = show.dropLast(1)
            CyUi.text(c, p, show, tx, 16 * d, k, 0xFFEAFBFF.toInt(), 1f, false)
        } else {
            p.style = Paint.Style.FILL; p.color = 0xFFEAFBFF.toInt(); p.textSize = 14 * d; p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            c.drawText(l.name, tx, 27 * d, p)
        }
        val sub = vids.size.toString() + (if (vids.size == 1) " VIDEO" else " VIDEOS")
        CyUi.text(c, p, sub, tx, 40 * d, 0.6f * d, 0xFF9FB0C2.toInt(), 1f, false)
        if (active) CyUi.text(c, p, "ON STATUS", tx, 52 * d, 0.6f * d, CyUi.YELLOW, 1f, false)
        else CyUi.text(c, p, "TAP TO USE", tx, 52 * d, 0.55f * d, Cy.a(Cy.CYAN, 0.7f), 1f, false)
        more.set(w - 40 * d, 0f, w, h)
        p.style = Paint.Style.FILL; p.color = Cy.a(Cy.CYAN, 0.9f)
        for (i in 0..2) c.drawRect(w - 20 * d, h / 2f - 8 * d + i * 7 * d, w - 14 * d, h / 2f - 5 * d + i * 7 * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) { if (more.contains(e.x, e.y)) onMore?.invoke() else onTap?.invoke() }
        return true
    }
}

/** The Player page: your videos, playlists, and how the floating player behaves. */
class PlayerTab(private val act: Activity, private val page: android.widget.ScrollView, private val cards: ArrayList<View>) {
    private val d = act.resources.displayMetrics.density
    private fun dp(v: Float) = (v * d).toInt()
    private val col = LinearLayout(act)
    private lateinit var title: CyTitle
    private lateinit var lib: LinearLayout
    private lateinit var lists: LinearLayout

    private fun tv(s: String, size: Float, color: Int): TextView {
        val t = TextView(act); t.text = s; t.textSize = size; t.setTextColor(color)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); return t
    }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).also { it.topMargin = top }

    fun build() {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        page.addView(col, FrameLayout.LayoutParams(-1, -2))
        page.overScrollMode = View.OVER_SCROLL_NEVER
        title = CyTitle(act, "PLAYER", "", Cy.CYAN)
        col.addView(title, lp(dp(4f))); cards.add(title)

        val lb = CyPanel(act)
        lb.setPadding(dp(14f), dp(12f), dp(14f), dp(14f))
        lb.addView(CyTitle(act, "VIDEOS", "LINKED", Cy.CYAN))
        lb.addView(tv("Long videos, anime and movies. They stay where they are on your phone, so adding is instant and takes no space.", 12f, 0xFF8B96A3.toInt()), lp(dp(6f)))
        val add = CyBtn(act, "+ ADD VIDEOS", Cy.CYAN)
        add.onClick = { act.startActivity(Intent(act, VideoPickActivity::class.java)) }
        lb.addView(add, lp(dp(12f)))
        lib = LinearLayout(act); lib.orientation = LinearLayout.VERTICAL
        lb.addView(lib, lp(dp(12f)))
        col.addView(lb, lp(dp(12f))); cards.add(lb)

        val pb = CyPanel(act)
        pb.setPadding(dp(14f), dp(12f), dp(14f), dp(14f))
        pb.addView(CyTitle(act, "PLAYLISTS", "PICK ONE", Cy.PINK))
        pb.addView(tv("The playlist you tap is the one that opens from the player icon on the status.", 12f, 0xFF8B96A3.toInt()), lp(dp(6f)))
        val np = CyBtn(act, "+ NEW PLAYLIST", Cy.PINK)
        np.onClick = { nameDialog("New playlist", "") { n -> val l = VideoLib.createList(act, n); pickVideos(l) } }
        pb.addView(np, lp(dp(12f)))
        lists = LinearLayout(act); lists.orientation = LinearLayout.VERTICAL
        pb.addView(lists, lp(dp(8f)))
        col.addView(pb, lp(dp(12f))); cards.add(pb)

        val sp = CyPanel(act)
        sp.setPadding(dp(14f), dp(12f), dp(14f), dp(14f))
        sp.addView(CyTitle(act, "FLOATING PLAYER", "16:9", Cy.CYAN))
        sp.addView(tv("Window size", 13f, 0xFFE8ECF2.toInt()), lp(dp(8f)))
        val seg = CySeg(act, listOf("SMALL", "MEDIUM", "LARGE"), Cy.CYAN)
        seg.select(VideoLib.size(act))
        seg.onSelect = { i -> VideoLib.setSize(act, i) }
        sp.addView(seg, lp(dp(6f)))
        fun row(t: String, s: String, key: String, def: Boolean) {
            val r = LinearLayout(act); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(0, dp(9f), 0, dp(3f))
            val c2 = LinearLayout(act); c2.orientation = LinearLayout.VERTICAL
            c2.addView(tv(t, 14f, 0xFFE8ECF2.toInt())); c2.addView(tv(s, 11.5f, 0xFF8B96A3.toInt()))
            r.addView(c2, LinearLayout.LayoutParams(0, -2, 1f))
            val sw = PSwitch(act); sw.setChecked(Prefs.bool(act, key, def)); sw.onChange = { v -> Prefs.putBool(act, key, v) }
            r.addView(sw, LinearLayout.LayoutParams(-2, -2))
            sp.addView(r, lp(dp(4f)))
        }
        row("Shrink when paused", "Turns into a small icon after a few seconds. Tap it to continue.", "vp_shrink", true)
        row("Sound", "Start with sound on", "vp_sound", true)
        col.addView(sp, lp(dp(12f))); cards.add(sp)
        refresh()
    }

    fun refresh() {
        val vids = VideoLib.videos(act)
        title.setTagText(vids.size.toString() + " VIDEOS")
        lib.removeAllViews()
        if (vids.isEmpty()) lib.addView(tv("No videos yet. Tap Add videos.", 12.5f, 0xFF8B96A3.toInt()))
        var i = 0
        while (i < vids.size) {
            val r = LinearLayout(act); r.orientation = LinearLayout.HORIZONTAL
            for (j in 0..1) {
                val v = vids.getOrNull(i + j)
                if (v == null) { r.addView(View(act), LinearLayout.LayoutParams(0, 1, 1f)); continue }
                val cd = VidCard(act, v)
                cd.onTap = { videoMenu(v) }
                val l = LinearLayout.LayoutParams(0, -2, 1f)
                if (j == 1) l.leftMargin = dp(8f)
                r.addView(cd, l)
            }
            lib.addView(r, lp(if (i == 0) 0 else dp(8f)))
            i += 2
        }
        lists.removeAllViews()
        val act0 = VideoLib.activeId(act)
        val all = VList(VideoLib.ALL, "All videos", ArrayList())
        if (vids.isNotEmpty()) {
            val s = ListStrip(act, all, act0 == VideoLib.ALL)
            s.onTap = { VideoLib.setActive(act, VideoLib.ALL); refresh() }
            lists.addView(s, lp(dp(6f)))
        }
        for (l in VideoLib.playlists(act)) {
            val s = ListStrip(act, l, act0 == l.id)
            s.onTap = { VideoLib.setActive(act, l.id); refresh() }
            s.onMore = { listMenu(l) }
            lists.addView(s, lp(dp(8f)))
        }
    }

    private fun videoMenu(v: VItem) {
        val items = arrayOf("Start from beginning", "Remove from library")
        AlertDialog.Builder(act).setTitle(v.title).setItems(items) { _, w ->
            when (w) {
                0 -> { VideoLib.setPos(act, v.id, 0); refresh() }
                1 -> { VideoLib.remove(act, v.id); refresh() }
            }
        }.show()
    }

    private fun listMenu(l: VList) {
        val items = arrayOf("Choose videos", "Rename", "Delete playlist")
        AlertDialog.Builder(act).setTitle(l.name).setItems(items) { _, w ->
            when (w) {
                0 -> pickVideos(l)
                1 -> nameDialog("Rename", l.name) { n -> VideoLib.renameList(act, l.id, n); refresh() }
                2 -> { VideoLib.deleteList(act, l.id); refresh() }
            }
        }.show()
    }

    private fun pickVideos(l: VList) {
        val vids = VideoLib.videos(act)
        if (vids.isEmpty()) { Toast.makeText(act, "Add videos first", Toast.LENGTH_SHORT).show(); refresh(); return }
        val on = BooleanArray(vids.size) { l.ids.contains(vids[it].id) }
        AlertDialog.Builder(act).setTitle(l.name)
            .setMultiChoiceItems(Array(vids.size) { vids[it].title }, on) { _, i, c -> on[i] = c }
            .setPositiveButton("Done") { _, _ ->
                for (i in vids.indices) VideoLib.setInList(act, l.id, vids[i].id, on[i])
                refresh()
            }
            .setOnCancelListener { refresh() }
            .show()
    }

    private fun nameDialog(t: String, cur: String, ok: (String) -> Unit) {
        val e = EditText(act); e.setText(cur); e.setSingleLine(true); e.setSelection(cur.length)
        AlertDialog.Builder(act).setTitle(t).setView(e)
            .setPositiveButton("OK") { _, _ -> val n = e.text.toString().trim(); if (n.isNotEmpty()) ok(n.take(24)) }
            .setNegativeButton("Cancel", null).show()
    }
}

package com.xio.bulwark

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import java.io.File
import java.nio.ByteBuffer
import java.util.Random
import kotlin.math.max

class GItem(val id: String, val type: String, var on: Boolean)

/**
 * The picture / clip collection. Files live in filesDir/gal:
 * g_ID.dat = original, g_ID_s.dat = copy without audio (video), g_ID_t.jpg = thumbnail (also what the status shows for images).
 */
object Gallery {
    const val MAX = Int.MAX_VALUE
    private const val IDX = "gal_idx"
    private const val VER = "gal_ver"
    private const val MIG = "gal_mig"
    const val SLIDE = "gal_slide"
    const val SHUF = "gal_shuf"
    private var cache: ArrayList<GItem>? = null
    private val thumbs = object : LinkedHashMap<String, Bitmap>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Bitmap>?): Boolean = size > 40
    }

    fun dir(c: Context): File = File(c.filesDir, "gal").also { it.mkdirs() }
    fun file(c: Context, it: GItem) = File(dir(c), "g_${it.id}.dat")
    fun silent(c: Context, it: GItem) = File(dir(c), "g_${it.id}_s.dat")
    fun thumbFile(c: Context, it: GItem) = File(dir(c), "g_${it.id}_t.jpg")

    fun ver(c: Context): Int = Prefs.int(c, VER, 0)
    fun bump(c: Context) = Prefs.putInt(c, VER, ver(c) + 1)
    const val VSEL = "gal_vsel"

    fun videos(c: Context): List<GItem> = all(c).filter { it.type == "video" }
    fun images(c: Context): List<GItem> = all(c).filter { it.type != "video" }
    fun enabledImages(c: Context): List<GItem> = images(c).filter { it.on }

    /** The one clip shown on the status: the chosen one, else the first. */
    fun selectedVideo(c: Context): GItem? {
        val v = videos(c)
        val id = Prefs.str(c, VSEL, "")
        return v.firstOrNull { it.id == id } ?: v.firstOrNull()
    }

    fun selectVideo(c: Context, id: String) { Prefs.putStr(c, VSEL, id); bump(c) }

    @Synchronized
    fun all(c: Context): List<GItem> {
        cache?.let { return it }
        migrate(c)
        val l = ArrayList<GItem>()
        for (p in Prefs.str(c, IDX, "").split('|')) {
            val f = p.split(':')
            if (f.size == 3 && f[0].isNotEmpty() && File(dir(c), "g_${f[0]}.dat").exists()) l.add(GItem(f[0], f[1], f[2] == "1"))
        }
        cache = l
        return l
    }

    fun enabled(c: Context): List<GItem> = all(c).filter { it.on }

    private fun save(c: Context) {
        val l = cache ?: return
        Prefs.putStr(c, IDX, l.joinToString("|") { it.id + ":" + it.type + ":" + (if (it.on) "1" else "0") })
        bump(c)
    }

    /** The old single clip becomes the first item. */
    private fun migrate(c: Context) {
        if (Prefs.bool(c, MIG, false)) return
        Prefs.putBool(c, MIG, true)
        val tp = Prefs.str(c, Prefs.MEDIA_TYPE, "")
        val old = File(c.filesDir, "media.dat")
        if (tp.isEmpty() || !old.exists()) return
        val it = GItem("m0", tp, true)
        try {
            old.copyTo(file(c, it), true)
            val s = File(c.filesDir, "media_s.dat")
            if (s.exists()) s.copyTo(silent(c, it), true)
            if (!makeThumb(c, it)) throw RuntimeException("thumb")
            Prefs.putStr(c, IDX, "m0:$tp:1")
            old.delete(); s.delete()
        } catch (t: Throwable) { }
    }

    /** Copies one picked file in. Returns null when ok, else a short reason. Call off the main thread. */
    fun add(c: Context, uri: Uri): String? {
        synchronized(this) { if (all(c).size >= MAX) return "gallery is full ($MAX max)" }
        val mime = c.contentResolver.getType(uri) ?: ""
        val type = when {
            mime.startsWith("video") -> "video"
            mime == "image/gif" || mime == "image/webp" -> "anim"
            mime.startsWith("image") -> "image"
            else -> return "not a picture or video"
        }
        val id = java.lang.Long.toString(System.currentTimeMillis(), 36) + Random().nextInt(99)
        val it = GItem(id, type, true)
        val out = file(c, it)
        try {
            var total = 0L
            c.contentResolver.openInputStream(uri)!!.use { ins ->
                out.outputStream().use { os ->
                    val buf = ByteArray(65536)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        os.write(buf, 0, n)
                    }
                }
            }
            if (type == "video" && !stripAudio(out, silent(c, it))) silent(c, it).delete()
            if (!makeThumb(c, it)) throw RuntimeException("could not read it")
        } catch (t: Throwable) {
            out.delete(); silent(c, it).delete(); thumbFile(c, it).delete()
            return t.message ?: "failed"
        }
        synchronized(this) { all(c); cache!!.add(it); save(c) }
        return null
    }

    @Synchronized
    fun remove(c: Context, id: String) {
        val l = all(c) as ArrayList<GItem>
        val it = l.firstOrNull { it.id == id } ?: return
        l.remove(it)
        file(c, it).delete(); silent(c, it).delete(); thumbFile(c, it).delete()
        thumbs.remove(id)
        save(c)
    }

    @Synchronized
    fun move(c: Context, id: String, d: Int) {
        val l = all(c) as ArrayList<GItem>
        val i = l.indexOfFirst { it.id == id }
        val j = i + d
        if (i < 0 || j < 0 || j >= l.size) return
        val t = l[i]; l[i] = l[j]; l[j] = t
        save(c)
    }

    /** Moves one step among items of the same kind (videos with videos, pictures with pictures). */
    @Synchronized
    fun moveKind(c: Context, id: String, d: Int) {
        val l = all(c) as ArrayList<GItem>
        val i = l.indexOfFirst { it.id == id }
        if (i < 0) return
        val vid = l[i].type == "video"
        var j = i + d
        while (j in l.indices && (l[j].type == "video") != vid) j += d
        if (j !in l.indices) return
        val t = l[i]; l[i] = l[j]; l[j] = t
        save(c)
    }

    @Synchronized
    fun setOn(c: Context, id: String, on: Boolean) {
        all(c).firstOrNull { it.id == id }?.on = on
        save(c)
    }

    fun totalBytes(c: Context): Long = dir(c).listFiles()?.sumOf { it.length() } ?: 0L

    @Synchronized
    fun thumb(c: Context, it: GItem): Bitmap? {
        thumbs[it.id]?.let { return it }
        val b = BitmapFactory.decodeFile(thumbFile(c, it).absolutePath) ?: return null
        thumbs[it.id] = b
        return b
    }

    /** Decodes a picture (EXIF turned) so its longest side is about maxSide. */
    fun decode(f: File, maxSide: Int): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(f)) { dec, info, _ ->
                val s = max(info.size.width, info.size.height)
                if (s > maxSide) dec.setTargetSampleSize(s / maxSide)
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(f.absolutePath, o)
            val s = max(o.outWidth, o.outHeight)
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = max(1, s / maxSide)
            BitmapFactory.decodeFile(f.absolutePath, o2)
        }
    } catch (t: Throwable) { null }

    private fun makeThumb(c: Context, it: GItem): Boolean {
        var b: Bitmap? = null
        try {
            if (it.type == "video") {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(file(c, it).absolutePath)
                    val full = r.getFrameAtTime(400_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        ?: r.getFrameAtTime(0L)
                    if (full != null) {
                        val s = max(full.width, full.height)
                        b = if (s > 480) Bitmap.createScaledBitmap(full, full.width * 480 / s, full.height * 480 / s, true) else full
                    }
                } finally { try { r.release() } catch (t: Throwable) { } }
            } else b = decode(file(c, it), 640)
            if (b == null) return false
            thumbFile(c, it).outputStream().use { os -> b.compress(Bitmap.CompressFormat.JPEG, 86, os) }
            return true
        } catch (t: Throwable) {
            return false
        }
    }

    /** A copy of the video with no audio track at all, so "sound off" is truly silent. */
    private fun stripAudio(src: File, dst: File): Boolean {
        val ex = MediaExtractor()
        var mux: MediaMuxer? = null
        return try {
            ex.setDataSource(src.absolutePath)
            var vi = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (m.startsWith("video/")) { vi = i; break }
            }
            if (vi < 0) return false
            ex.selectTrack(vi)
            mux = MediaMuxer(dst.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val ti = mux.addTrack(ex.getTrackFormat(vi))
            var rot = 0
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(src.absolutePath)
                rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                r.release()
            } catch (t: Throwable) { }
            mux.setOrientationHint(rot)
            mux.start()
            val buf = ByteBuffer.allocate(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                info.offset = 0
                info.size = n
                info.presentationTimeUs = ex.sampleTime
                info.flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                mux.writeSampleData(ti, buf, info)
                ex.advance()
            }
            mux.stop()
            true
        } catch (t: Throwable) {
            false
        } finally {
            try { mux?.release() } catch (t: Throwable) { }
            try { ex.release() } catch (t: Throwable) { }
        }
    }
}

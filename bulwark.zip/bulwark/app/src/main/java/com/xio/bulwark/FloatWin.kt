package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import kotlin.math.hypot

/**
 * Frame of every floating window: cut corners, a title bar with a tag, small buttons on the right and a
 * corner grip. Drawn once, nothing animates. Children go into [content].
 */
class CyWin(ctx: Context, private val tag: String, private val barOnly: Boolean = false) : FrameLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    val tb = 30f * d
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop * 1.2f

    var title = ""
        set(v) { field = v; invalidate() }
    /** id to label, drawn right to left in the title bar. */
    var buttons: List<Pair<String, String>> = emptyList()
        set(v) { field = v; invalidate() }
    var lit: Set<String> = emptySet()
        set(v) { field = v; invalidate() }
    var mini = false
        set(v) { field = v; content.visibility = if (v) GONE else VISIBLE; invalidate() }

    var onBtn: ((String) -> Unit)? = null
    var onMove: ((Int, Int) -> Unit)? = null
    var onResize: ((Int, Int) -> Unit)? = null
    var onEnd: (() -> Unit)? = null
    var onMiniTap: (() -> Unit)? = null

    val content = FrameLayout(ctx)

    init {
        setWillNotDraw(false)
        if (!barOnly) {
            val lp = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            lp.topMargin = (tb + d).toInt()
            lp.leftMargin = d.toInt(); lp.rightMargin = d.toInt(); lp.bottomMargin = d.toInt()
            addView(content, lp)
        }
    }

    private fun btnRect(i: Int, n: Int): RectF {
        val bw = 30f * d
        val right = width - 6f * d - (n - 1 - i) * bw
        return RectF(right - bw + 2f * d, 3f * d, right, tb - 3f * d)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val k = 0.85f * d
        if (mini) {
            CyUi.chamfer(path, 0f, 0f, w, h, 6f * d)
            p.style = Paint.Style.FILL; p.color = 0xF2090C12.toInt(); c.drawPath(path, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = CyUi.YELLOW; c.drawPath(path, p)
            CyUi.text(c, p, tag, w / 2f, (h - 10f * 0.8f * d) / 2f, 0.8f * d, CyUi.YELLOW, 1f, false, 1)
            return
        }
        val bottom = if (barOnly) tb else h
        CyUi.chamfer(path, 0f, 0f, w, bottom, 10f * d)
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xF2090C12.toInt(); c.drawPath(path, p)
        c.save()
        c.clipPath(path)
        p.color = 0xFF111823.toInt()
        c.drawRect(0f, 0f, w, tb, p)
        p.color = Cy.a(Cy.CYAN, 0.25f)
        c.drawRect(0f, tb - d, w, tb, p)
        c.restore()
        p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = Cy.a(Cy.CYAN, 0.55f)
        c.drawPath(path, p)
        p.style = Paint.Style.FILL; p.color = CyUi.YELLOW
        c.drawRect(0f, 0f, 34f * d, 2f * d, p)
        c.drawRect(w - 24f * d, bottom - 2f * d, w, bottom, p)

        // tag
        val tw = CyUi.width(tag, k) + 12f * d
        p.color = CyUi.YELLOW
        c.drawRect(8f * d, 7f * d, 8f * d + tw, tb - 7f * d, p)
        CyUi.text(c, p, tag, 8f * d + 6f * d, (tb - 10f * k) / 2f, k, 0xFF05080C.toInt(), 1f, false)

        // buttons
        val n = buttons.size
        for ((i, b) in buttons.withIndex()) {
            val r = btnRect(i, n)
            val on = lit.contains(b.first)
            val col = if (b.first == "x") CyUi.YELLOW else Cy.CYAN
            if (on) { p.style = Paint.Style.FILL; p.color = Cy.a(Cy.CYAN, 0.9f); c.drawRect(r, p) }
            else { p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = Cy.a(col, 0.5f); c.drawRect(r, p) }
            CyUi.text(c, p, b.second, r.centerX(), (tb - 10f * 0.72f * d) / 2f, 0.72f * d, if (on) 0xFF05080C.toInt() else col, 1f, false, 1)
        }

        // title (as much as fits)
        val left = 8f * d + tw + 8f * d
        val right = if (n > 0) btnRect(0, n).left - 8f * d else w - 8f * d
        var s = title.uppercase()
        while (s.isNotEmpty() && CyUi.width(s, k) > right - left) s = s.dropLast(1)
        CyUi.text(c, p, s, left, (tb - 10f * k) / 2f, k, 0xFFE8ECF2.toInt(), 1f, false)

        if (!barOnly) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.6f * d; p.color = CyUi.YELLOW
            for (i in 1..3) {
                val o = i * 5f * d
                c.drawLine(w - 4f * d, h - 4f * d - o, w - 4f * d - o, h - 4f * d, p)
            }
        }
    }

    // ---- touch ----
    private var mode = 0
    private var moved = false
    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f

    private fun zone(x: Float, y: Float): Int {
        if (mini) return 1
        if (y < tb) return 1
        if (!barOnly && x > width - 30f * d && y > height - 30f * d) return 2
        return 0
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) mode = zone(e.x, e.y)
        return mode != 0
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (mode == 0) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; lastX = downX; lastY = downY; moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.rawX - downX, e.rawY - downY) > slop) moved = true
                if (moved) {
                    val dx = (e.rawX - lastX).toInt()
                    val dy = (e.rawY - lastY).toInt()
                    if (mode == 1) onMove?.invoke(dx, dy) else onResize?.invoke(dx, dy)
                    lastX = e.rawX; lastY = e.rawY
                }
            }
            MotionEvent.ACTION_UP -> {
                if (moved) onEnd?.invoke()
                else if (mode == 1) {
                    if (mini) onMiniTap?.invoke()
                    else {
                        val n = buttons.size
                        for ((i, b) in buttons.withIndex()) {
                            if (btnRect(i, n).contains(e.x, e.y)) { onBtn?.invoke(b.first); break }
                        }
                    }
                }
                mode = 0
            }
            MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }
}

/** Grip that sits on the corner of an app window and resizes it. */
class WinGrip(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var onResize: ((Int, Int) -> Unit)? = null
    var onEnd: (() -> Unit)? = null
    private var lx = 0f
    private var ly = 0f
    private var moved = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL; p.color = 0xCC05080C.toInt()
        val path = Path()
        path.moveTo(w, 0f); path.lineTo(w, h); path.lineTo(0f, h); path.close()
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.6f * d; p.color = CyUi.YELLOW
        for (i in 1..3) {
            val o = i * 5f * d
            c.drawLine(w - 3f * d, h - 3f * d - o, w - 3f * d - o, h - 3f * d, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; moved = false }
            MotionEvent.ACTION_MOVE -> {
                moved = true
                onResize?.invoke((e.rawX - lx).toInt(), (e.rawY - ly).toInt())
                lx = e.rawX; ly = e.rawY
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (moved) onEnd?.invoke()
        }
        return true
    }
}

/** The small WIN tab that hangs under the status. */
class WinTab(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    var onTap: (() -> Unit)? = null
    var open = false
        set(v) { field = v; invalidate() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        CyUi.chamfer(path, 0.5f * d, 0.5f * d, w - 0.5f * d, h - 0.5f * d, 5f * d)
        p.style = Paint.Style.FILL; p.color = if (open) CyUi.YELLOW else 0xE6090C12.toInt(); c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = CyUi.YELLOW; c.drawPath(path, p)
        val k = 0.62f * d
        CyUi.text(c, p, "WIN", w / 2f, (h - 10f * k) / 2f, k, if (open) 0xFF05080C.toInt() else CyUi.YELLOW, 1f, false, 1)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}

/** Small flat label in the cyber font (section titles and chips). */
class CyLabel(ctx: Context, private val text: String, private val color: Int, private val filled: Boolean = false) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    var onTap: (() -> Unit)? = null

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val k = 0.8f * d
        if (filled) {
            CyUi.chamfer(path, 0.5f * d, 0.5f * d, w - 0.5f * d, h - 0.5f * d, 6f * d)
            p.style = Paint.Style.FILL; p.color = Cy.a(color, 0.14f); c.drawPath(path, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = Cy.a(color, 0.8f); c.drawPath(path, p)
            CyUi.text(c, p, text, w / 2f, (h - 10f * k) / 2f, k, color, 1f, false, 1)
        } else {
            p.style = Paint.Style.FILL; p.color = color
            c.drawRect(0f, (h - 12f * d) / 2f, 3f * d, (h + 12f * d) / 2f, p)
            CyUi.text(c, p, text, 10f * d, (h - 10f * k) / 2f, k, 0xFFE8ECF2.toInt(), 1f, false)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (onTap == null) return false
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}

package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.sin

/** One song in the list. */
class SongRow(ctx: Context, private val num: Int, private val title: String) : View(ctx) {
    var current = false
        set(v) { field = v; invalidate() }
    var onPick: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private var down = false

    init {
        isClickable = true
        setOnClickListener { onPick?.invoke() }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, ROW_DP))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { down = false; invalidate() }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = Ui.dp(context, 1f)
        val t = Neon.now()
        r.set(4 * d, 2 * d, w - 4 * d, h - 2 * d)
        p.style = Paint.Style.FILL
        p.color = if (current) Neon.a(Neon.CYAN, 34) else if (down) Neon.a(Neon.CYAN, 22) else 0x0AFFFFFF
        c.drawRoundRect(r, 9 * d, 9 * d, p)
        if (current) {
            p.color = Neon.CYAN
            r.set(4 * d, 8 * d, 6.5f * d, h - 8 * d)
            c.drawRoundRect(r, 2 * d, 2 * d, p)
        }
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        p.textSize = 10 * d
        p.textAlign = Paint.Align.LEFT
        p.letterSpacing = 0f
        p.color = if (current) Neon.CYAN else 0xFF5F6B78.toInt()
        c.drawText(String.format("%02d", num), 14 * d, h / 2f + 3.5f * d, p)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 12.5f * d
        p.color = if (current) 0xFFFFFFFF.toInt() else 0xFFC9D3DD.toInt()
        val maxW = w - 36 * d - 40 * d
        val s = TextUtils.ellipsize(title, android.text.TextPaint(p), maxW, TextUtils.TruncateAt.END).toString()
        c.drawText(s, 38 * d, h / 2f + 4.4f * d, p)
        if (current) {
            val playing = Music.playing
            p.color = Neon.GREEN
            for (i in 0..3) {
                val k = if (playing) 0.35f + 0.65f * (0.5f + 0.5f * sin(t * (5f + i * 1.7f) + i * 1.3f)) else 0.25f
                val bh = 14 * d * k
                val x = w - 28 * d + i * 5 * d
                r.set(x, h / 2f + 7 * d - bh, x + 3 * d, h / 2f + 7 * d)
                c.drawRoundRect(r, 1.2f * d, 1.2f * d, p)
            }
            if (playing) postInvalidateDelayed(40)
        }
    }

    companion object { const val ROW_DP = 38f }
}

/** One playlist in the floating box: animated face, name, song count. */
class PlRow(ctx: Context, private val pl: Playlist) : View(ctx) {
    var onPick: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private var down = false

    init {
        isClickable = true
        setOnClickListener { onPick?.invoke() }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, ROW_DP))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { down = false; invalidate() }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = Ui.dp(context, 1f)
        val t = Neon.now()
        val col = Faces.color(pl.face)
        val act = pl.id == Music.activeId
        val on = act && Music.playing
        Beat.step(Music.playing)
        r.set(4 * d, 2 * d, w - 4 * d, h - 2 * d)
        p.style = Paint.Style.FILL
        p.color = if (act) Neon.a(col, 34) else if (down) Neon.a(col, 22) else 0x0AFFFFFF
        c.drawRoundRect(r, 11 * d, 11 * d, p)
        if (act) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f * d
            p.color = Neon.a(col, 140)
            c.drawRoundRect(r, 11 * d, 11 * d, p)
        }
        // face tile
        val fs = 34 * d
        val fx = 8 * d
        val fy = (h - fs) / 2f
        r.set(fx, fy, fx + fs, fy + fs)
        p.style = Paint.Style.FILL
        p.color = Neon.a(col, 26)
        c.drawRoundRect(r, 10 * d, 10 * d, p)
        Faces.draw(c, p, pl.face, fx + fs / 2f, fy + fs / 2f + 0.5f * d, fs * 0.36f, t, Beat.level, Beat.kick, on)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 13 * d
        p.textAlign = Paint.Align.LEFT
        p.letterSpacing = 0f
        p.color = if (act) 0xFFFFFFFF.toInt() else 0xFFD3DCE5.toInt()
        val s = TextUtils.ellipsize(pl.name, android.text.TextPaint(p), w - 58 * d - 34 * d, TextUtils.TruncateAt.END).toString()
        c.drawText(s, 52 * d, h / 2f - 1.5f * d, p)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 10 * d
        val n = pl.files.size
        p.color = if (on) Neon.GREEN else 0xFF6F7C8A.toInt()
        c.drawText(if (on) "playing" else if (n == 1) "1 song" else "$n songs", 52 * d, h / 2f + 11 * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * d
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0xFF5F6B78.toInt()
        val ax = w - 16 * d
        c.drawLine(ax - 2.5f * d, h / 2f - 4 * d, ax + 1.5f * d, h / 2f, p)
        c.drawLine(ax + 1.5f * d, h / 2f, ax - 2.5f * d, h / 2f + 4 * d, p)
        p.strokeCap = Paint.Cap.BUTT
        postInvalidateDelayed(if (on) 40L else 90L)
    }

    companion object { const val ROW_DP = 46f }
}

/**
 * The floating music box. It hangs off the status overlay and is joined to it by an animated energy wire
 * (top when it is below the status, bottom when above, none when it sits beside it).
 * First view = your playlists (with their faces). Tap one to see and play its songs.
 */
class MusicPanel(ctx: Context) : FrameLayout(ctx) {
    var wireX = 40f
    var wireOnTop = true
    var side = false
    var onPick: ((String, Int) -> Unit)? = null
    var onOutside: (() -> Unit)? = null
    var onResize: ((Int) -> Unit)? = null

    private val d = Ui.dp(ctx, 1f)
    private val wireZone0 = (14 * d).toInt()
    val wireZone: Int get() = if (side) 0 else wireZone0
    private val headH = (28 * d).toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()
    private val seg = Path()
    private val pm = PathMeasure()
    private val rows = ArrayList<SongRow>()
    private val scroll = ScrollView(ctx)
    private val list = LinearLayout(ctx)
    private var running = false
    private var view = 0                 // 0 playlists, 1 songs
    private var plId = ""
    private var headLeft = "PLAYLISTS"
    private var rightText = ""
    private var rowCount = 0
    private var rowDp = PlRow.ROW_DP

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!isShown || windowVisibility != View.VISIBLE) { tickIdle = true; return }
            invalidate()
            postDelayed(this, 33)
        }
    }

    init {
        setWillNotDraw(false)
        list.orientation = LinearLayout.VERTICAL
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(list, FrameLayout.LayoutParams(-1, -2))
        addView(scroll, LayoutParams(-1, -1))
    }

    /** Height in pixels this window wants for what it shows now (about 4 rows visible, then it scrolls). */
    fun desiredHeight(): Int {
        val rowsShown = minOf(maxOf(rowCount, 1), 4)
        return wireZone + headH + (rowsShown * rowDp * d + 10 * d).toInt()
    }

    private fun place() {
        val lpp = scroll.layoutParams as LayoutParams
        lpp.topMargin = (if (wireOnTop) wireZone else 0) + headH
        lpp.bottomMargin = if (wireOnTop) 0 else wireZone
        scroll.setPadding(0, 0, 0, (6 * d).toInt())
        scroll.clipToPadding = true
        scroll.layoutParams = lpp
    }

    private fun fade() {
        scroll.alpha = 0f
        scroll.animate().alpha(1f).setDuration(170).start()
    }

    fun showPlaylists(animate: Boolean = false) {
        view = 0
        rows.clear()
        list.removeAllViews()
        val pls = Music.playlists(context)
        rowCount = pls.size
        rowDp = PlRow.ROW_DP
        headLeft = "PLAYLISTS"
        rightText = if (pls.size == 1) "1 LIST" else "${pls.size} LISTS"
        for (pl in pls) {
            val row = PlRow(context, pl)
            row.onPick = { showSongs(pl.id, true) }
            list.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        place()
        scroll.scrollTo(0, 0)
        if (animate) { fade(); onResize?.invoke(desiredHeight()) }
        invalidate()
    }

    fun showSongs(id: String, animate: Boolean = false) {
        view = 1
        plId = id
        rows.clear()
        list.removeAllViews()
        val pl = Music.playlist(context, id)
        val songs = Music.songsOf(context, id)
        rowCount = songs.size
        rowDp = SongRow.ROW_DP
        val nm = (pl?.name ?: "").uppercase()
        headLeft = "<  " + (if (nm.length > 13) nm.substring(0, 12) + "." else nm)
        rightText = if (songs.size == 1) "1 TRACK" else "${songs.size} TRACKS"
        if (songs.isEmpty()) {
            val tv = android.widget.TextView(context)
            tv.text = "No songs in this playlist yet.\nAdd some in the Frameline app > Music."
            tv.textSize = 11.5f
            tv.setTextColor(0xFF8B96A3.toInt())
            tv.setPadding((14 * d).toInt(), (12 * d).toInt(), (14 * d).toInt(), 0)
            list.addView(tv)
        }
        for ((i, sg) in songs.withIndex()) {
            val row = SongRow(context, i + 1, sg.title)
            row.onPick = { onPick?.invoke(id, i) }
            rows.add(row)
            list.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        refreshCurrent()
        place()
        scroll.scrollTo(0, 0)
        if (animate) { fade(); onResize?.invoke(desiredHeight()) }
        invalidate()
    }

    fun refreshCurrent() {
        val cur = plId == Music.activeId
        for ((i, row) in rows.withIndex()) row.current = cur && i == Music.index
    }

    private var tickIdle = false

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val top = if (wireOnTop) wireZone.toFloat() else 0f
        val bot = if (wireOnTop) h.toFloat() else (h - wireZone).toFloat()
        r.set(d, top + d, w - d, bot - d)
        path.reset()
        path.addRoundRect(r, 16 * d, 16 * d, Path.Direction.CW)
        pm.setPath(path, false)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) { onOutside?.invoke(); return true }
        if (e.actionMasked == MotionEvent.ACTION_UP && view == 1 && e.y >= r.top && e.y <= r.top + headH && e.x < width * 0.65f) {
            showPlaylists(true)
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = Neon.now()
        // body
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, r.top, 0f, r.bottom, 0xF2101A24.toInt(), 0xF2070C12.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 16 * d, 16 * d, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Neon.a(Neon.CYAN, 90)
        c.drawPath(path, p)
        // header
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 9 * d
        p.letterSpacing = 0.2f
        p.textAlign = Paint.Align.LEFT
        p.color = Neon.CYAN
        val hy = r.top + 19 * d
        c.drawText(headLeft, 16 * d, hy, p)
        p.color = 0xFF6A7886.toInt()
        p.textAlign = Paint.Align.RIGHT
        c.drawText(rightText, w - 16 * d, hy, p)
        p.letterSpacing = 0f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = Neon.a(Neon.CYAN, 36)
        c.drawLine(12 * d, r.top + headH - 2 * d, w - 12 * d, r.top + headH - 2 * d, p)
        // running light around the border
        val len = pm.length
        if (len > 0f) {
            val ph = (t * 0.22f) % 1f
            val sl = len * 0.14f
            val st = ph * len
            seg.reset()
            pm.getSegment(st, minOf(st + sl, len), seg, true)
            if (st + sl > len) pm.getSegment(0f, st + sl - len, seg, true)
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = 3.4f * d
            p.color = Neon.a(Neon.CYAN, 40)
            c.drawPath(seg, p)
            p.strokeWidth = 1.4f * d
            p.color = Neon.a(Neon.CYAN, 230)
            c.drawPath(seg, p)
            p.strokeCap = Paint.Cap.BUTT
        }
        if (side) return
        // energy wire from the status to the list
        val y0 = if (wireOnTop) 0f else h
        val y1 = if (wireOnTop) wireZone.toFloat() else (h - wireZone)
        p.strokeWidth = 5f * d
        p.color = Neon.a(Neon.CYAN, 34)
        c.drawLine(wireX, y0, wireX, y1, p)
        p.strokeWidth = 1.6f * d
        p.color = Neon.a(Neon.CYAN, 200)
        // slightly crackling line
        val steps = 5
        var py = y0
        var px = wireX
        for (i in 1..steps) {
            val fy = y0 + (y1 - y0) * i / steps
            val jitter = if (i == steps) 0f else sin(t * 23f + i * 2.1f) * 1.8f * d
            c.drawLine(px, py, wireX + jitter, fy, p)
            px = wireX + jitter; py = fy
        }
        // travelling pulses
        p.style = Paint.Style.FILL
        for (k in 0..1) {
            val f = ((t * 1.3f + k * 0.5f) % 1f)
            val yy = y0 + (y1 - y0) * f
            p.color = Neon.a(Neon.GREEN, 230)
            c.drawCircle(wireX, yy, 2.2f * d, p)
            p.color = Neon.a(Neon.GREEN, 60)
            c.drawCircle(wireX, yy, 5f * d, p)
        }
        // end nodes
        p.color = Neon.CYAN
        c.drawCircle(wireX, y0, 2.6f * d, p)
        p.color = Neon.a(Neon.CYAN, 70)
        c.drawCircle(wireX, y1, 5f * d, p)
        p.color = Neon.CYAN
        c.drawCircle(wireX, y1, 2.4f * d, p)
    }
}

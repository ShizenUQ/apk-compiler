package com.xio.bulwark

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Resources
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import kotlin.math.min

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.xio.bulwark.STOP"
        const val ACTION_TOGGLE_LOCK = "com.xio.bulwark.TOGGLE_LOCK"
        const val ACTION_TOGGLE_SOUND = "com.xio.bulwark.TOGGLE_SOUND"
        private const val CHANNEL = "bulwark_watch"
        private const val NOTIF_ID = 7
        private const val BASE_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

        const val ACTION_REFRESH_WIN = "com.xio.bulwark.REFRESH_WIN"
        const val ACTION_MUSIC_PREV = "com.xio.bulwark.MUSIC_PREV"
        const val ACTION_MUSIC_TOGGLE = "com.xio.bulwark.MUSIC_TOGGLE"
        const val ACTION_MUSIC_NEXT = "com.xio.bulwark.MUSIC_NEXT"

        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private var root: HudRoot? = null
    private lateinit var lp: WindowManager.LayoutParams
    private class Spot(val v: TapSpot, val lp: WindowManager.LayoutParams)
    private val spots = HashMap<String, Spot>()
    private var fw: FloatMgr? = null

    private fun placeTab() {
        val r = root ?: return
        if (r.width > 0) fw?.placeTab(lp.x, lp.y, r.width, r.height)
    }
    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var wh: Handler? = null
    private var t0 = 0L
    private var screenOn = true

    private val loop = object : Runnable {
        override fun run() {
            try {
                val c = applicationContext
                val raw = try { FpsClient.sample(c) } catch (t: Throwable) { null }
                val data = FpsData.parse(raw)
                val sys = StatsReader.read(c, t0)
                try { Tracker.feed(c, data, sys) } catch (t: Throwable) { }
                main.post {
                    try {
                        root?.applyPrefs()
                        applyWindowState()
                        root?.update(data, sys)
                    } catch (t: Throwable) { }
                }
            } catch (t: Throwable) {
            }
            if (screenOn) wh?.postDelayed(this, 500)
        }
    }

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> { screenOn = false; wh?.removeCallbacks(loop) }
                Intent.ACTION_SCREEN_ON -> { screenOn = true; wh?.removeCallbacks(loop); wh?.post(loop) }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        t0 = SystemClock.elapsedRealtime()
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        running = true
        registerReceiver(screenRx, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        showOverlay()
        Music.onChange = {
            main.post {
                root?.hud?.poke()
                panel?.refreshCurrent()
                try {
                    (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
                } catch (t: Throwable) { }
            }
        }
        worker = HandlerThread("bulwark-sampler").also { it.start() }
        wh = Handler(worker!!.looper)
        wh?.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_TOGGLE_LOCK -> toggleLock()
            ACTION_TOGGLE_SOUND -> toggleSound()
            ACTION_REFRESH_WIN -> placeTab()
            ACTION_MUSIC_PREV -> Music.prev(applicationContext)
            ACTION_MUSIC_TOGGLE -> Music.toggle(applicationContext)
            ACTION_MUSIC_NEXT -> Music.next(applicationContext)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        wh?.removeCallbacksAndMessages(null)
        worker?.quitSafely()
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(screenRx) } catch (t: Throwable) { }
        Music.onChange = null
        hidePanel()
        fw?.destroy()
        fw = null
        Music.stop()
        try { Tracker.flush(applicationContext) } catch (t: Throwable) { }
        clearSpots()
        root?.let { try { wm.removeView(it) } catch (t: Throwable) { } }
        root = null
        FpsClient.unbind(applicationContext)
        super.onDestroy()
    }

    // ---------- overlay window ----------

    private fun showOverlay() {
        val dm = Resources.getSystem().displayMetrics
        val v = HudRoot(this)
        v.applyPrefs()
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        edge(lp)
        lp.x = Prefs.int(this, kx(), Prefs.int(this, Prefs.X, (24 * dm.density).toInt()))
        lp.y = Prefs.int(this, ky(), Prefs.int(this, Prefs.Y, (24 * dm.density).toInt()))
        lp.alpha = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        v.onMusic = { i -> onMusicTap(i) }
        v.onDrag = { dx, dy ->
            if (panel != null) hidePanel()
            lp.x += dx
            lp.y += dy
            clamp(v)
            try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
            placeTab()
        }
        v.onDragEnd = { snap(v) }
        v.onToggleLock = { toggleLock() }
        v.onToggleSound = { toggleSound() }
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> syncSpots(); placeTab() }
        try {
            wm.addView(v, lp)
            root = v
            fw = FloatMgr(this, wm, { screen() }, { edge(it) })
            main.post { placeTab() }
        } catch (t: Throwable) {
            stopSelf()
        }
    }

    /**
     * Lets a window use the whole screen, notch side included. Without this, in landscape the system pushes the big
     * overlay away from the notch but not the tiny tap windows, so taps land beside the icons.
     */
    private fun edge(l: WindowManager.LayoutParams) {
        if (Build.VERSION.SDK_INT >= 30) l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else if (Build.VERSION.SDK_INT >= 28) l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    /** Real current screen size (follows rotation). Resources.getSystem() goes stale after a rotation. */
    @Suppress("DEPRECATION")
    private fun screen(): IntArray {
        return try {
            val m = android.util.DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            intArrayOf(m.widthPixels, m.heightPixels)
        } catch (t: Throwable) {
            val m = Resources.getSystem().displayMetrics
            intArrayOf(m.widthPixels, m.heightPixels)
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        hidePanel()
        val v = root ?: return
        main.postDelayed({
            try {
                lp.x = Prefs.int(this, kx(), lp.x)
                lp.y = Prefs.int(this, ky(), lp.y)
                clamp(v)
                wm.updateViewLayout(v, lp)
                clearSpots()
                syncSpots()
                fw?.onConfig()
                placeTab()
            } catch (t: Throwable) { }
        }, 350)
    }

    private fun clamp(v: View) {
        val sc = screen()
        val w = if (v.width > 0) v.width else 1
        val h = if (v.height > 0) v.height else 1
        lp.x = lp.x.coerceIn(0, maxOf(0, sc[0] - w))
        lp.y = lp.y.coerceIn(0, maxOf(0, sc[1] - h))
    }

    private fun land(): Boolean { val sc = screen(); return sc[0] > sc[1] }
    private fun kx() = if (land()) "x_land" else Prefs.X
    private fun ky() = if (land()) "y_land" else Prefs.Y

    /** The overlay stays exactly where you drop it. Portrait and landscape remember their own spot. */
    private fun snap(v: View) {
        clamp(v)
        Prefs.putInt(this, kx(), lp.x)
        Prefs.putInt(this, ky(), lp.y)
    }

    // ---------- lock ----------

    private fun toggleLock() {
        val now = !Prefs.bool(this, Prefs.LOCKED, false)
        Prefs.putBool(this, Prefs.LOCKED, now)
        root?.applyPrefs()
        applyWindowState()
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (t: Throwable) { }
    }

    /** Locked = every touch passes through to the game (window opacity must stay at 80% or less on Android 12+). */
    private fun applyWindowState() {
        val v = root ?: return
        val locked = Prefs.bool(this, Prefs.LOCKED, false)
        val op = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        val flags = if (locked) BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else BASE_FLAGS
        val a = if (locked) min(op, 0.8f) else op
        if (lp.flags != flags || lp.alpha != a) {
            lp.flags = flags
            lp.alpha = a
            try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
        }
        if (locked) syncSpots() else clearSpots()
    }

    private fun toggleSound() {
        Prefs.putBool(this, Prefs.SOUND, !Prefs.bool(this, Prefs.SOUND, false))
        root?.applyPrefs()
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (t: Throwable) { }
    }

    /**
     * While locked the overlay lets every touch through. The only exceptions are two tiny invisible
     * windows placed exactly over the lock icon (to unlock) and the sound icon (to mute / unmute).
     */
    private fun syncSpots() {
        val r = root ?: return
        if (!Prefs.bool(this, Prefs.LOCKED, false)) return
        spot("lock", r.lockRectPx()) { toggleLock() }
        spot("vid", r.videoTapRectPx()) { toggleSound() }
        spot("img", r.imageTapRectPx()) { r.nextImage() }
        val mr = r.musicRectsPx()
        for (i in 0..3) spot("m$i", mr.getOrNull(i)) { onMusicTap(i) }
    }

    // ---------- music ----------

    private var panel: MusicPanel? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelClosedAt = 0L
    private var panelSide = false
    private var panelMode = 0
    private var panelMax = 0

    private fun onMusicTap(i: Int) {
        val c = applicationContext
        when (i) {
            0 -> if (panel != null) hidePanel()
                 else if (SystemClock.uptimeMillis() - panelClosedAt > 450) showPanel()
            1 -> Music.prev(c)
            2 -> Music.toggle(c)
            3 -> Music.next(c)
        }
        root?.hud?.poke()
    }

    private fun hidePanel() {
        val p = panel ?: return
        panel = null
        panelLp = null
        panelClosedAt = SystemClock.uptimeMillis()
        Music.panelOpen = false
        root?.hud?.poke()
        val a = p.animate().alpha(0f).setDuration(140)
        if (panelSide) a.scaleX(0.85f) else a.scaleY(0.85f)
        a.withEndAction {
            try { wm.removeView(p) } catch (t: Throwable) { }
        }.start()
    }

    private fun showPanel() {
        val r = root ?: return
        val c = applicationContext
        if (Music.playlists(c).isEmpty()) {
            android.widget.Toast.makeText(c, "Create a playlist first: Frameline app > Music", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val dm = Resources.getSystem().displayMetrics
        val sc = screen()
        val sw = sc[0]
        val sh = sc[1]
        val hits = r.hud.musicHits()
        val s = r.hud.scalePx()
        val iconCx = if (hits != null) (hits[0].left + hits[0].right) / 2f * s else 40f * s
        val p = MusicPanel(this)
        val pad = (8 * dm.density).toInt()
        val gap = (2 * dm.density).toInt()
        val pw = maxOf(r.width, (200 * dm.density).toInt()).coerceAtMost(sw - 2 * pad)
        val minH = (130 * dm.density).toInt()
        val spaceBelow = sh - (lp.y + r.height) - pad
        val spaceAbove = lp.y - pad
        // where does it go? below the status, above it, or beside it (never on top of it)
        var mode = 0   // 0 below, 1 above, 2 right, 3 left
        p.side = false
        p.showPlaylists()
        var ph = p.desiredHeight()
        if (spaceBelow >= ph) mode = 0
        else if (spaceAbove >= ph) mode = 1
        else if (lp.x + r.width + pad + pw <= sw) { mode = 2 }
        else if (lp.x - pad - pw >= 0) { mode = 3 }
        else if (spaceBelow >= spaceAbove) { mode = 0; ph = maxOf(minH, spaceBelow) }
        else { mode = 1; ph = maxOf(minH, spaceAbove) }
        val side = mode >= 2
        p.side = side
        if (side) { p.showPlaylists(); ph = minOf(p.desiredHeight(), sh - 2 * pad) }
        val below = mode == 0
        p.wireOnTop = below
        p.showPlaylists()
        p.onPick = { id, i -> Music.playIn(c, id, i); hidePanel() }
        p.onResize = { h -> resizePanel(h) }
        panelMode = mode
        panelMax = when (mode) { 0 -> maxOf(minH, spaceBelow); 1 -> maxOf(minH, spaceAbove); else -> sh - 2 * pad }
        p.onOutside = { hidePanel() }
        val l = WindowManager.LayoutParams(
            pw, ph, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        when (mode) {
            0 -> { l.x = lp.x.coerceIn(0, maxOf(0, sw - pw)); l.y = lp.y + r.height - gap }
            1 -> { l.x = lp.x.coerceIn(0, maxOf(0, sw - pw)); l.y = lp.y - ph + gap }
            2 -> { l.x = lp.x + r.width + pad / 2; l.y = lp.y.coerceIn(pad, maxOf(pad, sh - ph - pad)) }
            else -> { l.x = lp.x - pw - pad / 2; l.y = lp.y.coerceIn(pad, maxOf(pad, sh - ph - pad)) }
        }
        p.wireX = (iconCx + (lp.x - l.x)).coerceIn(12f * dm.density, pw - 12f * dm.density)
        panelSide = side
        p.alpha = 0f
        if (side) {
            p.scaleX = 0.85f
            p.pivotX = if (mode == 2) 0f else pw.toFloat()
            p.pivotY = ph / 2f
        } else {
            p.scaleY = 0.85f
            p.pivotX = p.wireX
            p.pivotY = if (below) 0f else ph.toFloat()
        }
        try {
            wm.addView(p, l)
            panel = p
            panelLp = l
            Music.panelOpen = true
            val an = p.animate().alpha(1f).setDuration(220)
            if (side) an.scaleX(1f) else an.scaleY(1f)
            an.start()
            r.hud.poke()
        } catch (t: Throwable) { }
    }

    /** The box switched between playlists and songs: resize it and keep it attached to the status. */
    private fun resizePanel(want: Int) {
        val p = panel ?: return
        val l = panelLp ?: return
        val r = root ?: return
        val dm = Resources.getSystem().displayMetrics
        val sh = screen()[1]
        val pad = (8 * dm.density).toInt()
        val gap = (2 * dm.density).toInt()
        val h = want.coerceAtMost(maxOf(panelMax, (100 * dm.density).toInt()))
        l.height = h
        when (panelMode) {
            1 -> { l.y = lp.y - h + gap; p.pivotY = h.toFloat() }
            2, 3 -> { l.y = lp.y.coerceIn(pad, maxOf(pad, sh - h - pad)); p.pivotY = h / 2f }
            else -> l.y = lp.y + r.height - gap
        }
        try { wm.updateViewLayout(p, l) } catch (t: Throwable) { }
    }

    private fun spot(name: String, rect: Rect?, onTap: () -> Unit) {
        val old = spots[name]
        if (rect == null || rect.width() <= 0 || rect.height() <= 0) {
            if (old != null) { try { wm.removeView(old.v) } catch (t: Throwable) { }; spots.remove(name) }
            return
        }
        val sc = screen()
        val x = (lp.x + rect.left).coerceIn(0, maxOf(0, sc[0] - rect.width()))
        val y = (lp.y + rect.top).coerceIn(0, maxOf(0, sc[1] - rect.height()))
        if (old != null) {
            if (old.lp.x == x && old.lp.y == y && old.lp.width == rect.width() && old.lp.height == rect.height()) return
            old.lp.x = x; old.lp.y = y; old.lp.width = rect.width(); old.lp.height = rect.height()
            try { wm.updateViewLayout(old.v, old.lp) } catch (t: Throwable) { }
            return
        }
        val v = TapSpot(this)
        v.onTap = onTap
        val l = WindowManager.LayoutParams(rect.width(), rect.height(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, BASE_FLAGS, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.START
        edge(l)
        l.x = x; l.y = y
        try {
            wm.addView(v, l)
            spots[name] = Spot(v, l)
        } catch (t: Throwable) { }
    }

    private fun clearSpots() {
        for (sp in spots.values) { try { wm.removeView(sp.v) } catch (t: Throwable) { } }
        spots.clear()
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Overlay watch", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val lock = PendingIntent.getService(
            this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_TOGGLE_LOCK), PendingIntent.FLAG_IMMUTABLE
        )
        val snd = PendingIntent.getService(
            this, 3, Intent(this, OverlayService::class.java).setAction(ACTION_TOGGLE_SOUND), PendingIntent.FLAG_IMMUTABLE
        )
        val locked = Prefs.bool(this, Prefs.LOCKED, false)
        val soundOn = Prefs.bool(this, Prefs.SOUND, false)
        val hasVideo = Prefs.str(this, Prefs.MEDIA_TYPE, "") == "video"
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Frameline is running")
            .setContentText(if (locked) "Locked - touches pass through to the game." else "Unlocked - drag the overlay anywhere.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, if (locked) "Unlock" else "Lock", lock).build())
        if (hasVideo) b.addAction(Notification.Action.Builder(icon, if (soundOn) "Sound off" else "Sound on", snd).build())
        if (Music.count(this) > 0) {
            val pv = PendingIntent.getService(this, 4, Intent(this, OverlayService::class.java).setAction(ACTION_MUSIC_PREV), PendingIntent.FLAG_IMMUTABLE)
            val pt = PendingIntent.getService(this, 5, Intent(this, OverlayService::class.java).setAction(ACTION_MUSIC_TOGGLE), PendingIntent.FLAG_IMMUTABLE)
            val pn = PendingIntent.getService(this, 6, Intent(this, OverlayService::class.java).setAction(ACTION_MUSIC_NEXT), PendingIntent.FLAG_IMMUTABLE)
            b.addAction(Notification.Action.Builder(icon, "Prev", pv).build())
            b.addAction(Notification.Action.Builder(icon, if (Music.playing) "Pause" else "Play", pt).build())
            b.addAction(Notification.Action.Builder(icon, "Next", pn).build())
        }
        b.addAction(Notification.Action.Builder(icon, "Stop", stop).build())
        return b.build()
    }
}

/** Invisible touch area. Sits over an icon of a locked overlay so only that spot catches taps. */
class TapSpot(ctx: Context) : View(ctx) {
    var onTap: (() -> Unit)? = null

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}

package com.xio.bulwark

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.VelocityTracker
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.OverScroller
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** One row of the timeline. kind: 1 = effect, 2 = picture, 3 = sound. */
private class TlRow(val kind: Int, val idx: Int)

/**
 * The timeline. One bar per picture, effect and sound.
 * Drag a bar to move it, drag its ends to trim or cut it, drag along the numbers to move the playhead,
 * drag on empty space to scroll, pinch to zoom.
 */
class TimelineView(ctx: Context, private val ed: FxEditorActivity) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val d = Ui.dp(ctx, 1f)
    private val rulerH = 22 * d
    private val rowH = 27 * d
    private val padL = 14 * d
    private var rows = ArrayList<TlRow>()
    private var ppm = 0.075f * d          // pixels per millisecond
    private var offX = 0f
    private var offY = 0f
    private val scroller = OverScroller(ctx)
    private var vt: VelocityTracker? = null
    private var scaling = false
    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(g: ScaleGestureDetector): Boolean { scaling = true; mode = 0; return true }
        override fun onScale(g: ScaleGestureDetector): Boolean {
            val msAtFocus = (offX + g.focusX - padL) / ppm
            ppm = (ppm * g.scaleFactor).coerceIn(0.02f * d, 0.35f * d)
            offX = (msAtFocus * ppm + padL - g.focusX).coerceAtLeast(0f)
            clampScroll()
            invalidate()
            return true
        }
        override fun onScaleEnd(g: ScaleGestureDetector) { scaling = false }
    })

    private var mode = 0           // 0 none, 1 scrub, 2 move, 3 trim start, 4 trim end, 5 pan
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var s0 = 0
    private var d0 = 0
    private var in0 = 0
    private var rowSel = -1

    private fun xOf(ms: Int) = padL + ms * ppm - offX
    private fun msOf(x: Float) = ((x + offX - padL) / ppm).toInt()

    private fun contentMs(): Int = max(ed.work.totalMs() + 3000, 6000)

    private fun clampScroll() {
        val maxX = max(0f, padL + contentMs() * ppm - width + 40 * d)
        offX = offX.coerceIn(0f, maxX)
        val maxY = max(0f, rows.size * rowH + 6 * d - (height - rulerH))
        offY = offY.coerceIn(0f, maxY)
    }

    fun rebuild() {
        val a = ed.work
        rows.clear()
        for (i in a.layers.indices) rows.add(TlRow(2, i))
        for (i in a.effects.indices) rows.add(TlRow(1, i))
        if (a.audio.isNotEmpty()) {
            rows.add(TlRow(3, 0))
            AudioWave.load(a.audio) { invalidate() }
        }
        clampScroll()
        invalidate()
    }

    fun zoom(f: Float) {
        val cx = width / 2f
        val msAtFocus = (offX + cx - padL) / ppm
        ppm = (ppm * f).coerceIn(0.02f * d, 0.35f * d)
        offX = (msAtFocus * ppm + padL - cx).coerceAtLeast(0f)
        clampScroll()
        invalidate()
    }

    /** Keeps the playhead on screen while playing. */
    fun follow() {
        val x = xOf(ed.head)
        if (x > width - 30 * d) offX += x - (width - 30 * d)
        if (x < 10 * d) offX -= 10 * d - x
        clampScroll()
        invalidate()
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            offX = scroller.currX.toFloat()
            clampScroll()
            postInvalidateOnAnimation()
        }
    }

    private fun rowStart(k: TlRow): Int = when (k.kind) {
        1 -> ed.work.effects[k.idx].startMs
        2 -> ed.work.layers[k.idx].startMs
        else -> ed.work.audioStart
    }

    private fun rowDur(k: TlRow): Int = when (k.kind) {
        1 -> ed.work.effects[k.idx].durMs
        2 -> ed.work.layers[k.idx].durMs
        else -> ed.work.audioDur
    }

    private fun scrub(x: Float) {
        ed.seek(msOf(x).coerceIn(0, 600000))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        if (scaling || e.pointerCount > 1) return true
        if (vt == null) vt = VelocityTracker.obtain()
        vt?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                scroller.forceFinished(true)
                downX = e.x
                downY = e.y
                lastX = e.x
                lastY = e.y
                mode = 0
                rowSel = -1
                parent?.requestDisallowInterceptTouchEvent(true)
                if (e.y < rulerH) {
                    mode = 1
                    ed.pause()
                    scrub(e.x)
                    return true
                }
                val ri = ((e.y - rulerH + offY) / rowH).toInt()
                if (ri in rows.indices) {
                    val k = rows[ri]
                    val s = rowStart(k)
                    val du = rowDur(k)
                    val x0 = xOf(s)
                    val x1 = xOf(s + du)
                    if (e.x >= x0 - 8 * d && e.x <= x1 + 8 * d) {
                        rowSel = ri
                        s0 = s
                        d0 = du
                        in0 = ed.work.audioIn
                        ed.select(k.kind, k.idx)
                        val edge = min(20 * d, max(10 * d, (x1 - x0) / 3f))
                        mode = if (e.x <= x0 + edge) 3 else if (e.x >= x1 - edge) 4 else 2
                        return true
                    }
                }
                mode = 5
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    1 -> scrub(e.x)
                    5 -> {
                        offX -= e.x - lastX
                        offY -= e.y - lastY
                        clampScroll()
                        invalidate()
                    }
                    2, 3, 4 -> if (rowSel in rows.indices) {
                        val k = rows[rowSel]
                        val dms = (((e.x - downX) / ppm) / 50f).toInt() * 50
                        edit(k, dms)
                        ed.timesChanged()
                    }
                }
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode == 5) {
                    if (abs(e.x - downX) < 8 * d && abs(e.y - downY) < 8 * d) ed.select(0, -1)
                    else {
                        vt?.computeCurrentVelocity(1000)
                        val vx = vt?.xVelocity ?: 0f
                        scroller.fling(offX.toInt(), 0, (-vx).toInt(), 0, 0, max(0f, padL + contentMs() * ppm - width + 40 * d).toInt(), 0, 0)
                        postInvalidateOnAnimation()
                    }
                }
                vt?.recycle()
                vt = null
                mode = 0
                performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    /** Moves or trims the bar being dragged. dms is how far it has been dragged, in ms. */
    private fun edit(k: TlRow, dms: Int) {
        val a = ed.work
        val srcMs = ed.srcMs()
        when (mode) {
            2 -> {
                val ns = (s0 + dms).coerceIn(0, 600000)
                when (k.kind) { 1 -> a.effects[k.idx].startMs = ns; 2 -> a.layers[k.idx].startMs = ns; else -> a.audioStart = ns }
            }
            3 -> {
                var ns = (s0 + dms).coerceIn(0, s0 + d0 - 100)
                if (k.kind == 3) ns = max(ns, s0 - in0)       // cannot reveal before the start of the file
                val nd = d0 - (ns - s0)
                when (k.kind) {
                    1 -> { a.effects[k.idx].startMs = ns; a.effects[k.idx].durMs = nd }
                    2 -> { a.layers[k.idx].startMs = ns; a.layers[k.idx].durMs = nd }
                    else -> { a.audioStart = ns; a.audioIn = in0 + (ns - s0); a.audioDur = nd }
                }
            }
            4 -> {
                var nd = (d0 + dms).coerceIn(100, 600000)
                if (k.kind == 3 && srcMs > 0) nd = min(nd, max(100, srcMs - in0))   // cannot run past the end of the file
                when (k.kind) { 1 -> a.effects[k.idx].durMs = nd; 2 -> a.layers[k.idx].durMs = nd; else -> a.audioDur = nd }
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        clampScroll()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val a = ed.work
        p.style = Paint.Style.FILL
        p.color = 0xFF0C1117.toInt()
        c.drawRect(0f, 0f, w, h, p)

        // rows
        c.save()
        c.clipRect(0f, rulerH, w, h)
        for ((i, k) in rows.withIndex()) {
            val top = rulerH + i * rowH - offY
            if (top + rowH < rulerH || top > h) continue
            if (i % 2 == 0) {
                p.color = 0x08FFFFFF
                c.drawRect(0f, top, w, top + rowH, p)
            }
            val s = rowStart(k)
            val du = rowDur(k)
            val x0 = xOf(s)
            val x1 = max(xOf(s + du), x0 + 10 * d)
            val sel = ed.selKind == k.kind && ed.selIdx == k.idx
            var col = 0xFF8C7BFF.toInt()
            var label = ""
            when (k.kind) {
                1 -> {
                    val ef = a.effects[k.idx]
                    col = if (ef.type == FxType.SHAKE) 0xFF8B96A3.toInt() else ef.color
                    label = if (ef.type == FxType.TEXT) "Text: " + ef.text else FxType.names[ef.type]
                }
                2 -> { col = 0xFF4C9BFF.toInt(); label = "Picture " + (k.idx + 1) }
                3 -> { col = 0xFF3DDC97.toInt(); label = "Sound" }
            }
            r.set(x0, top + 3 * d, x1, top + rowH - 3 * d)
            p.style = Paint.Style.FILL
            p.color = Cy.a(col, if (sel) 0.7f else 0.4f)
            c.drawRoundRect(r, 6 * d, 6 * d, p)

            if (k.kind == 3) drawWave(c, x0, x1, top)

            // handles
            p.color = Cy.a(0xFFFFFFFF.toInt(), if (sel) 0.95f else 0.4f)
            c.drawRoundRect(x0 + 2 * d, top + 8 * d, x0 + 4.5f * d, top + rowH - 8 * d, 2 * d, 2 * d, p)
            c.drawRoundRect(x1 - 4.5f * d, top + 8 * d, x1 - 2 * d, top + rowH - 8 * d, 2 * d, 2 * d, p)
            if (sel) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.6f * d
                p.color = 0xFFFFFFFF.toInt()
                c.drawRoundRect(r, 6 * d, 6 * d, p)
            }
            c.save()
            c.clipRect(x0 + 8 * d, top, x1 - 6 * d, top + rowH)
            p.style = Paint.Style.FILL
            p.color = 0xFFFFFFFF.toInt()
            p.textSize = 10.5f * d
            p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.textAlign = Paint.Align.LEFT
            c.drawText(label, x0 + 9 * d, top + rowH / 2f + 3.8f * d, p)
            c.restore()
        }
        if (rows.isEmpty()) {
            p.color = FxC.DIM
            p.textSize = 11.5f * d
            p.textAlign = Paint.Align.LEFT
            c.drawText("Empty. Add a picture, effect, text or sound with the buttons below.", padL, rulerH + rowH * 0.75f, p)
        }
        c.restore()

        // ruler
        p.style = Paint.Style.FILL
        p.color = 0xFF111922.toInt()
        c.drawRect(0f, 0f, w, rulerH, p)
        p.textSize = 9.5f * d
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textAlign = Paint.Align.LEFT
        val pxSec = ppm * 1000f
        val step = if (pxSec >= 46 * d) 1 else if (pxSec >= 22 * d) 2 else if (pxSec >= 9 * d) 5 else 10
        var sec = (max(0f, (offX - padL) / pxSec).toInt() / step) * step
        while (true) {
            val x = xOf(sec * 1000)
            if (x > w) break
            if (x > -40 * d) {
                p.color = 0x55FFFFFF
                c.drawRect(x - 0.5f * d, rulerH - 7 * d, x + 0.5f * d, rulerH, p)
                p.color = FxC.MID
                c.drawText(sec.toString() + "s", x + 3 * d, rulerH - 9 * d, p)
                if (step == 1 && pxSec > 60 * d) {
                    val xm = x + pxSec / 2f
                    p.color = 0x33FFFFFF
                    c.drawRect(xm - 0.5f * d, rulerH - 4 * d, xm + 0.5f * d, rulerH, p)
                }
            }
            sec += step
        }

        // playhead
        val hx = xOf(ed.head)
        if (hx >= -4 * d && hx <= w + 4 * d) {
            p.style = Paint.Style.FILL
            p.color = FxC.ACCENT2
            c.drawRect(hx - 1 * d, 0f, hx + 1 * d, h, p)
            c.drawCircle(hx, 6 * d, 6 * d, p)
        }
    }

    /** Waveform inside the sound bar. Only the part that is kept (after cutting) is drawn. */
    private fun drawWave(c: Canvas, x0: Float, x1: Float, top: Float) {
        val a = ed.work
        val info = AudioWave.cached(a.audio) ?: return
        if (info.peaks.isEmpty()) return
        p.style = Paint.Style.FILL
        p.color = 0xCCFFFFFF.toInt()
        val mid = top + rowH / 2f
        val maxH = rowH - 10 * d
        val from = max(x0, 0f)
        val to = min(x1, width.toFloat())
        var x = from
        val step = max(1.5f * d, 2f)
        while (x < to) {
            val ms = msOf(x) - a.audioStart + a.audioIn
            val i = ms / 20
            if (i >= 0 && i < info.peaks.size) {
                val bh = max(1.5f * d, info.peaks[i] * maxH)
                c.drawRect(x, mid - bh / 2f, x + step * 0.6f, mid + bh / 2f, p)
            }
            x += step
        }
    }
}

/** A small picture of an effect for the effect chooser. */
private class EffectTile(ctx: Context, private val type: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()
    private val d = Ui.dp(ctx, 1f)
    private val col = if (type == FxType.SHAKE) 0xFFB0BAC6.toInt() else 0xFF8C7BFF.toInt()
    private val ac = 0xFFFF6B9A.toInt()
    var onPick: (() -> Unit)? = null

    init {
        isClickable = true
        setOnClickListener { onPick?.invoke() }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (86 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = if (isPressed) 0xFF2C3646.toInt() else 0xFF1B2230.toInt()
        r.set(0f, 0f, w, h)
        c.drawRoundRect(r, 14 * d, 14 * d, p)
        val cx = w / 2f
        val cy = 32 * d
        val s = 17 * d
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = 2.4f * d
        p.style = Paint.Style.STROKE
        p.color = col
        when (type) {
            FxType.COMET -> { r.set(cx - s, cy - s, cx + s, cy + s); c.drawArc(r, 200f, 250f, false, p); p.style = Paint.Style.FILL; p.color = ac; c.drawCircle(cx + s * 0.7f, cy - s * 0.75f, 3.5f * d, p) }
            FxType.GLOW -> { for (i in 1..3) { p.color = Cy.a(col, 0.9f - i * 0.22f); c.drawCircle(cx, cy, s * i / 2.2f, p) } }
            FxType.GLITCH -> { p.style = Paint.Style.FILL; for (i in 0..3) { p.color = if (i % 2 == 0) col else ac; val o = (if (i % 2 == 0) -5 else 6) * d; c.drawRect(cx - s + o, cy - s + i * s / 1.9f, cx + s * 0.4f + o, cy - s + i * s / 1.9f + 4 * d, p) } }
            FxType.SCAN -> { c.drawLine(cx - s, cy, cx + s, cy, p); p.color = Cy.a(col, 0.35f); c.drawLine(cx - s, cy - 7 * d, cx + s, cy - 7 * d, p); c.drawLine(cx - s, cy + 7 * d, cx + s, cy + 7 * d, p) }
            FxType.FLASH -> { p.style = Paint.Style.FILL; p.color = ac; c.drawCircle(cx, cy, 7 * d, p); p.style = Paint.Style.STROKE; p.color = col; for (i in 0 until 8) { val a = i * Math.PI / 4; c.drawLine(cx + (11 * d * Math.cos(a)).toFloat(), cy + (11 * d * Math.sin(a)).toFloat(), cx + (s * Math.cos(a)).toFloat(), cy + (s * Math.sin(a)).toFloat(), p) } }
            FxType.WAVE -> { c.drawCircle(cx, cy, s * 0.5f, p); p.color = Cy.a(col, 0.5f); c.drawCircle(cx, cy, s, p) }
            FxType.TEXT -> { p.style = Paint.Style.FILL; p.color = col; p.textSize = 24 * d; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); c.drawText("Aa", cx, cy + 8 * d, p) }
            FxType.SHAKE -> { r.set(cx - 9 * d, cy - 9 * d, cx + 9 * d, cy + 9 * d); c.drawRoundRect(r, 3 * d, 3 * d, p); p.color = ac; c.drawLine(cx - 17 * d, cy - 6 * d, cx - 17 * d, cy + 6 * d, p); c.drawLine(cx + 17 * d, cy - 6 * d, cx + 17 * d, cy + 6 * d, p) }
            FxType.SPARKS -> { p.style = Paint.Style.FILL; for (i in 0 until 9) { val a = i * 0.7; val rr = (6 + (i * 5) % 11) * d; p.color = if (i % 3 == 0) ac else col; c.drawCircle(cx + (rr * Math.cos(a)).toFloat() * 1.3f, cy + (rr * Math.sin(a)).toFloat() * 1.3f, (1.4f + (i % 3)) * d, p) } }
            FxType.RAYS -> { for (i in 0 until 10) { val a = i * Math.PI / 5; c.drawLine(cx + (5 * d * Math.cos(a)).toFloat(), cy + (5 * d * Math.sin(a)).toFloat(), cx + (s * Math.cos(a)).toFloat(), cy + (s * Math.sin(a)).toFloat(), p) } }
            FxType.SPEED -> { for (i in 0 until 8) { val a = i * Math.PI / 4 + 0.2; c.drawLine(cx + (s * 0.45f * Math.cos(a)).toFloat(), cy + (s * 0.45f * Math.sin(a)).toFloat(), cx + (s * 1.1f * Math.cos(a)).toFloat(), cy + (s * 1.1f * Math.sin(a)).toFloat(), p) } }
            FxType.CONFETTI -> { p.style = Paint.Style.FILL; for (i in 0 until 7) { c.save(); c.translate(cx - 15 * d + i * 5 * d, cy - 12 * d + ((i * 7) % 5) * 6 * d); c.rotate(i * 37f); p.color = if (i % 2 == 0) col else ac; c.drawRect(-3 * d, -1.6f * d, 3 * d, 1.6f * d, p); c.restore() } }
            FxType.BOLT -> { path.reset(); path.moveTo(cx + 4 * d, cy - s); path.lineTo(cx - 6 * d, cy + 1 * d); path.lineTo(cx + 2 * d, cy + 1 * d); path.lineTo(cx - 5 * d, cy + s); p.color = ac; c.drawPath(path, p) }
            FxType.VIGNETTE -> { c.drawCircle(cx, cy, s, p); p.color = Cy.a(col, 0.4f); c.drawCircle(cx, cy, s * 0.6f, p) }
        }
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.textSize = 11.5f * d
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.color = FxC.TEXT
        c.drawText(FxType.names[type], cx, h - 12 * d, p)
    }
}

/**
 * The animation editor. A full landscape screen: preview on the left, settings of the selected item on the
 * right, the timeline underneath and the add buttons at the bottom. Save writes it back and returns.
 */
class FxEditorActivity : Activity() {
    companion object {
        const val EX_ID = "id"
        const val EX_NEW = "new"
        const val REQ = 75

        fun open(a: Activity, id: String, isNew: Boolean) {
            a.startActivityForResult(Intent(a, FxEditorActivity::class.java).putExtra(EX_ID, id).putExtra(EX_NEW, isNew), REQ)
        }
    }

    lateinit var work: FxAnim
    private var animId = ""
    private var dirty = false
    var selKind = -1
    var selIdx = -1
    var head = 0
        private set
    private var playing = false
    private var t0 = 0L
    private var inspTab = 0

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var stage: FxStage
    private lateinit var tl: TimelineView
    private lateinit var inspector: LinearLayout
    private lateinit var nameView: TextView
    private lateinit var timeView: TextView
    private lateinit var playBtn: FBtn
    private lateinit var ux: FxUi
    private val sync = ArrayList<() -> Unit>()
    private val dummy = ArrayList<View>()
    private var srcCache = 0
    private var srcPath = ""

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    /** Length of the attached sound file in ms (0 if unknown). */
    fun srcMs(): Int {
        if (work.audio.isEmpty()) return 0
        if (srcPath != work.audio) {
            srcPath = work.audio
            srcCache = AudioWave.cached(work.audio)?.durMs ?: AudioWave.duration(work.audio)
        }
        return srcCache
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        animId = intent.getStringExtra(EX_ID) ?: FxStore.newId()
        val orig = FxStore.get(this, animId)
        work = if (orig != null) FxAnim.from(JSONObject(orig.toJson().toString()))
        else {
            val all = FxStore.all(this)
            var n = 1
            while (all.any { it.name == "My animation $n" }) n++
            FxAnim(animId, "My animation $n", false)
        }
        // old animations with a sound but no cut: give them a sensible length so they stop by themselves
        if (work.audio.isNotEmpty() && work.audioDur <= 0) {
            val full = srcMs()
            work.audioDur = if (full > 0) min(full, 8000) else 4000
        }
        ux = FxUi(this, dummy)
        build()
        tl.rebuild()
        renderInspector()
        refreshTime()
    }

    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onPause() {
        pause()
        super.onPause()
    }

    override fun onDestroy() {
        FxAudio.stop()
        super.onDestroy()
    }

    // ---------- layout ----------

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false) = ux.tv(s, size, color, bold)

    private fun build() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(FxC.ROOT)

        // top bar
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(10f), dp(4f), dp(10f), dp(4f))
        val back = FBtn(this, "Back", 1, 36f)
        back.onClick = { onBackPressed() }
        top.addView(back, LinearLayout.LayoutParams(dp(72f), -2))
        nameView = tv(work.name, 15f, 0xFFFFFFFF.toInt(), true)
        nameView.setPadding(dp(14f), 0, dp(8f), 0)
        nameView.setSingleLine(true)
        nameView.ellipsize = android.text.TextUtils.TruncateAt.END
        nameView.setOnClickListener {
            ux.ask("Name", work.name) { s -> if (s.isNotEmpty()) { work.name = s; nameView.text = s; dirty = true } }
        }
        top.addView(nameView, LinearLayout.LayoutParams(0, -2, 1f))
        timeView = tv("", 12f, FxC.MID)
        timeView.setPadding(0, 0, dp(12f), 0)
        top.addView(timeView)
        playBtn = FBtn(this, "Play", 1, 36f)
        playBtn.onClick = { if (playing) pause() else play() }
        top.addView(playBtn, LinearLayout.LayoutParams(dp(80f), -2))
        val save = FBtn(this, "Save", 0, 36f)
        save.onClick = { save() }
        val sl = LinearLayout.LayoutParams(dp(84f), -2)
        sl.leftMargin = dp(8f)
        top.addView(save, sl)
        root.addView(top, LinearLayout.LayoutParams(-1, dp(46f)))

        // middle: preview + settings
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.HORIZONTAL
        val holder = FrameLayout(this)
        stage = FxStage(this)
        stage.fit = true
        stage.editorMode = true
        stage.anim = work
        stage.onLayerSelect = { i -> select(2, i) }
        stage.onLayerMoved = { dirty = true; sync.forEach { it() }; tl.invalidate() }
        val stl = FrameLayout.LayoutParams(-1, -1)
        stl.gravity = Gravity.CENTER
        stl.setMargins(dp(10f), dp(2f), dp(10f), dp(6f))
        holder.addView(stage, stl)
        mid.addView(holder, LinearLayout.LayoutParams(0, -1, 1f))

        val side = ScrollView(this)
        side.overScrollMode = View.OVER_SCROLL_NEVER
        side.background = softBg(FxC.PANEL, FxC.LINE, 1f * resources.displayMetrics.density, 16 * resources.displayMetrics.density)
        inspector = LinearLayout(this)
        inspector.orientation = LinearLayout.VERTICAL
        inspector.setPadding(dp(14f), dp(10f), dp(14f), dp(14f))
        side.addView(inspector, FrameLayout.LayoutParams(-1, -2))
        val sidelp = LinearLayout.LayoutParams(dp(300f), -1)
        sidelp.setMargins(0, dp(2f), dp(10f), dp(6f))
        mid.addView(side, sidelp)
        root.addView(mid, LinearLayout.LayoutParams(-1, 0, 1f))

        // timeline
        tl = TimelineView(this, this)
        root.addView(tl, LinearLayout.LayoutParams(-1, dp(112f)))

        // bottom tools
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(10f), dp(4f), dp(10f), dp(4f))
        fun tool(label: String, kind: Int, f: () -> Unit): FBtn {
            val bb = FBtn(this, label, kind, 36f)
            bb.onClick = f
            return bb
        }
        val tools = ux.buttons(
            tool("+ Picture", 0) { pickImage() },
            tool("+ Effect", 0) { addEffectDialog(null) },
            tool("+ Text", 0) { addText() },
            tool("+ Sound", 0) { pickAudio() },
            tool("Copy", 1) { copySel() },
            tool("Delete", 2) { deleteSel() },
            tool("-", 1) { tl.zoom(0.7f) },
            tool("+", 1) { tl.zoom(1.4f) }
        )
        bar.addView(tools, LinearLayout.LayoutParams(-1, -2))
        root.addView(bar, LinearLayout.LayoutParams(-1, dp(46f)))
        setContentView(root)
    }

    // ---------- playback ----------

    private val frame = object : Runnable {
        override fun run() {
            if (!playing) return
            head = (SystemClock.uptimeMillis() - t0).toInt()
            if (head > work.totalMs() + 300) {
                pause()
                head = 0
            }
            stage.headMs = head
            stage.invalidate()
            tl.follow()
            refreshTime()
            if (playing) ui.postDelayed(this, 16)
        }
    }

    fun play() {
        if (playing) return
        if (head >= work.totalMs()) head = 0
        playing = true
        t0 = SystemClock.uptimeMillis() - head
        playBtn.set("Pause", 0)
        FxAudio.playAnim(work, head)
        ui.post(frame)
    }

    fun pause() {
        FxAudio.stop()
        if (!playing) return
        playing = false
        ui.removeCallbacks(frame)
        if (::playBtn.isInitialized) playBtn.set("Play", 1)
    }

    fun seek(ms: Int) {
        head = ms
        stage.headMs = ms
        stage.invalidate()
        tl.invalidate()
        refreshTime()
    }

    private fun refreshTime() {
        timeView.text = String.format(Locale.US, "%.1f / %.1f s", head / 1000f, work.totalMs() / 1000f)
    }

    // ---------- selection and changes ----------

    fun select(kind: Int, idx: Int) {
        if (kind == selKind && idx == selIdx) { tl.invalidate(); return }
        selKind = kind
        selIdx = idx
        stage.selLayer = if (kind == 2) idx else -1
        stage.invalidate()
        tl.invalidate()
        renderInspector()
    }

    /** Called while a bar is dragged on the timeline. */
    fun timesChanged() {
        dirty = true
        sync.forEach { it() }
        stage.invalidate()
        tl.invalidate()
        refreshTime()
    }

    private fun changed(rebuildTl: Boolean = false) {
        dirty = true
        stage.invalidate()
        if (rebuildTl) tl.rebuild() else tl.invalidate()
        refreshTime()
    }

    private fun secs(ms: Int) = String.format(Locale.US, "%.2f s", ms / 1000f)

    // ---------- inspector ----------

    private fun slider(title: (Int) -> String, lo: Int, hi: Int, get: () -> Int, put: (Int) -> Unit) {
        val lab = ux.label(title(get()))
        inspector.addView(lab)
        val s = FSlider(this, lo, hi)
        s.setValue(get())
        s.onValue = { x -> put(x); lab.text = title(x); changed() }
        sync.add { s.setValue(get()); lab.text = title(get()) }
        inspector.addView(s, LinearLayout.LayoutParams(-1, -2))
    }

    private fun section(s: String) {
        val t = tv(s.uppercase(), 10.5f, FxC.DIM, true)
        t.letterSpacing = 0.14f
        t.setPadding(0, dp(14f), 0, dp(2f))
        inspector.addView(t)
    }

    private fun chips(names: List<String>, cols: Int, get: () -> Int, put: (Int) -> Unit) {
        inspector.addView(ChipGrid(this, names, cols, get) { v -> put(v); changed() })
    }

    private fun header(s: String) {
        inspector.addView(tv(s, 16f, 0xFFFFFFFF.toInt(), true))
    }

    private fun renderInspector() {
        inspector.removeAllViews()
        sync.clear()
        val a = work
        when (selKind) {
            2 -> layerInspector(a)
            1 -> effectInspector(a)
            3 -> soundInspector(a)
            else -> {
                header("Nothing selected")
                inspector.addView(tv("Tap a bar on the timeline, or a picture on the preview, to change it.", 13f, FxC.MID).also { it.setPadding(0, dp(8f), 0, 0) })
                inspector.addView(tv("Drag a bar to move it in time. Drag its ends to shorten or cut it. Drag on empty space to scroll the timeline, pinch to zoom, and drag along the numbers to move the playhead.", 12f, FxC.DIM).also { it.setPadding(0, dp(10f), 0, 0) })
            }
        }
    }

    private fun layerInspector(a: FxAnim) {
        val l = a.layers.getOrNull(selIdx) ?: return
        header("Picture " + (selIdx + 1))
        val tabs = Seg(this, listOf("Place", "Motion", "Time"), 34f)
        tabs.select(inspTab)
        tabs.onSelect = { i -> inspTab = i; renderInspector() }
        inspector.addView(tabs, ux.top(tabs, 10f))
        when (inspTab) {
            0 -> {
                slider({ "Size  $it %" }, 10, 400, { (l.scale * 100).toInt() }) { l.scale = it / 100f }
                slider({ "Rotate  $it deg" }, -180, 180, { l.rot.toInt() }) { l.rot = it.toFloat() }
                slider({ "Opacity  $it %" }, 5, 100, { (l.alpha * 100).toInt() }) { l.alpha = it / 100f }
                val bc = FBtn(this, "Centre on stage", 1, 36f)
                bc.onClick = { l.x = 0.5f; l.y = 0.5f; changed() }
                inspector.addView(bc, ux.top(bc, 12f))
                inspector.addView(tv("Drag the picture on the preview to move it. Pinch with two fingers to resize and turn it.", 11.5f, FxC.DIM).also { it.setPadding(0, dp(10f), 0, 0) })
            }
            1 -> {
                section("Enter")
                chips(FxLayer.intros, 4, { l.intro }) { l.intro = it }
                section("While it is on screen")
                chips(FxLayer.loops, 4, { l.loop }) { l.loop = it; renderInspector() }
                if (l.loop != 0) {
                    slider({ "Power  $it" }, 0, 100, { l.lpow }) { l.lpow = it }
                    slider({ "Speed  $it" }, 0, 100, { l.lspd }) { l.lspd = it }
                }
                section("Exit")
                chips(FxLayer.outros, 4, { l.outro }) { l.outro = it }
            }
            else -> {
                slider({ "Starts at  " + secs(it * 50) }, 0, 400, { l.startMs / 50 }) { l.startMs = it * 50 }
                slider({ "Lasts  " + secs(it * 50) }, 2, 400, { (l.durMs / 50).coerceIn(2, 400) }) { l.durMs = it * 50; tl.rebuild() }
                inspector.addView(tv("You can also drag the bar on the timeline.", 11.5f, FxC.DIM).also { it.setPadding(0, dp(10f), 0, 0) })
            }
        }
    }

    private fun effectInspector(a: FxAnim) {
        val e = a.effects.getOrNull(selIdx) ?: return
        val hr = LinearLayout(this)
        hr.orientation = LinearLayout.HORIZONTAL
        hr.gravity = Gravity.CENTER_VERTICAL
        val nm = tv(FxType.names[e.type], 16f, 0xFFFFFFFF.toInt(), true)
        hr.addView(nm, LinearLayout.LayoutParams(0, -2, 1f))
        val ch = FBtn(this, "Change", 1, 34f)
        ch.onClick = {
            addEffectDialog { t ->
                e.type = t
                if (t == FxType.TEXT && e.text.isEmpty()) e.text = "WIN"
                changed(true)
                renderInspector()
            }
        }
        hr.addView(ch, LinearLayout.LayoutParams(dp(92f), -2))
        inspector.addView(hr)
        inspector.addView(tv(FxType.hints[e.type], 11.5f, FxC.DIM).also { it.setPadding(0, dp(4f), 0, 0) })
        if (e.type != FxType.SHAKE) {
            section("Colour")
            val sw = SwatchRow(this)
            sw.selected = FxStore.swatches.indexOfFirst { it == e.color }
            sw.onPick = { cc -> e.color = cc; changed(true) }
            inspector.addView(sw, LinearLayout.LayoutParams(-1, -2))
        }
        if (e.type == FxType.TEXT) {
            val tl2 = tv("Word:  " + e.text, 14f, FxC.TEXT)
            val tb = FBtn(this, "Change", 1, 34f)
            tb.onClick = { ux.ask("Word to show", e.text) { s -> if (s.isNotEmpty()) { e.text = s.take(16); tl2.text = "Word:  " + e.text; changed(true) } } }
            val wr = LinearLayout(this)
            wr.orientation = LinearLayout.HORIZONTAL
            wr.gravity = Gravity.CENTER_VERTICAL
            wr.setPadding(0, dp(8f), 0, 0)
            wr.addView(tl2, LinearLayout.LayoutParams(0, -2, 1f))
            wr.addView(tb, LinearLayout.LayoutParams(dp(92f), -2))
            inspector.addView(wr)
        }
        val pn = when (e.type) {
            FxType.SHAKE -> "Strength"
            FxType.TEXT -> "Size"
            FxType.FLASH -> "Brightness"
            FxType.SPARKS, FxType.CONFETTI -> "Amount"
            else -> "Power"
        }
        section("Look")
        slider({ "$pn  $it" }, 0, 100, { e.power }) { e.power = it }
        slider({ "Speed  $it" }, 0, 100, { e.speed }) { e.speed = it }
        section("Time")
        slider({ "Starts at  " + secs(it * 50) }, 0, 400, { e.startMs / 50 }) { e.startMs = it * 50 }
        slider({ "Lasts  " + secs(it * 50) }, 2, 400, { (e.durMs / 50).coerceIn(2, 400) }) { e.durMs = it * 50; tl.rebuild() }
    }

    private fun soundInspector(a: FxAnim) {
        header("Sound")
        val full = srcMs()
        inspector.addView(tv(
            "Playing " + secs(a.audioDur) + (if (full > 0) " of " + secs(full) else ""), 12f, FxC.MID
        ).also { it.setPadding(0, dp(4f), 0, 0) })
        slider({ "Volume  $it %" }, 0, 100, { a.volume }) { a.volume = it }
        slider({ "Starts at  " + secs(it * 50) }, 0, 400, { a.audioStart / 50 }) { a.audioStart = it * 50 }

        section("Cut")
        inspector.addView(tv("Move the playhead (drag along the numbers) to where you want to cut, then tap:", 11.5f, FxC.DIM))
        val cut1 = FBtn(this, "Cut before playhead", 1, 36f)
        cut1.onClick = {
            val end = a.audioStart + a.audioDur
            if (head > a.audioStart + 100 && head < end - 100) {
                val delta = head - a.audioStart
                a.audioIn += delta
                a.audioStart = head
                a.audioDur -= delta
                dirty = true
                tl.rebuild(); renderInspector(); changed()
            } else ux.toast("Put the playhead inside the sound first")
        }
        val cut2 = FBtn(this, "Cut after playhead", 1, 36f)
        cut2.onClick = {
            val end = a.audioStart + a.audioDur
            if (head > a.audioStart + 100 && head < end - 100) {
                a.audioDur = head - a.audioStart
                dirty = true
                tl.rebuild(); renderInspector(); changed()
            } else ux.toast("Put the playhead inside the sound first")
        }
        inspector.addView(cut1, ux.top(cut1, 8f))
        inspector.addView(cut2, ux.top(cut2, 6f))
        val reset = FBtn(this, "Use the whole file", 1, 36f)
        reset.onClick = {
            val f = srcMs()
            if (f > 0) { a.audioIn = 0; a.audioDur = f; dirty = true; tl.rebuild(); renderInspector(); changed() }
        }
        inspector.addView(reset, ux.top(reset, 6f))

        section("Try it")
        val bt = FBtn(this, "Test", 1, 36f)
        bt.onClick = { FxAudio.playClip(a.audio, a.volume, a.audioIn, a.audioDur, 0) }
        val bs = FBtn(this, "Stop", 1, 36f)
        bs.onClick = { FxAudio.stop() }
        val br = FBtn(this, "Replace", 1, 36f)
        br.onClick = { pickAudio() }
        inspector.addView(ux.buttons(bt, bs, br), ux.top(bt, 6f))
    }

    // ---------- adding things ----------

    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
        try { startActivityForResult(i, 73) } catch (t: Throwable) { ux.toast("No picker found") }
    }

    private fun pickAudio() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*")
        try { startActivityForResult(i, 74) } catch (t: Throwable) { ux.toast("No picker found") }
    }

    private fun copyIn(uri: android.net.Uri, prefix: String): File? {
        return try {
            val dir = File(filesDir, "fx")
            dir.mkdirs()
            val f = File(dir, prefix + System.currentTimeMillis().toString(36))
            contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } } ?: return null
            if (f.length() == 0L) null else f
        } catch (t: Throwable) { null }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(code: Int, res: Int, data: Intent?) {
        super.onActivityResult(code, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        try {
            if (code == 73) {
                val f = copyIn(uri, "img_")
                if (f == null) { ux.toast("Could not read that picture"); return }
                val l = FxLayer(f.absolutePath, 0.5f, 0.5f, 1f)
                l.startMs = head
                l.durMs = 2000
                work.layers.add(l)
                dirty = true
                tl.rebuild()
                inspTab = 0
                selKind = -2
                select(2, work.layers.size - 1)
                stage.invalidate()
            } else if (code == 74) {
                val f = copyIn(uri, "a_")
                if (f == null) { ux.toast("Could not read that audio"); return }
                work.audio = f.absolutePath
                srcPath = ""
                val full = srcMs()
                work.audioStart = 0
                work.audioIn = 0
                work.audioDur = if (full > 0) min(full, 8000) else 4000
                dirty = true
                tl.rebuild()
                selKind = -2
                select(3, 0)
                changed(true)
                ux.toast("Drag the ends of the green bar to cut the sound")
            }
        } catch (t: Throwable) {
            ux.toast("Could not add that")
        }
    }

    /** A chooser with a tile for every effect. pick = null adds a new effect at the playhead. */
    private fun addEffectDialog(pick: ((Int) -> Unit)?) {
        val dlg = Dialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        val dd = resources.displayMetrics.density
        panel.background = softBg(0xFF111720.toInt(), FxC.LINE, 1f * dd, 22 * dd)
        panel.setPadding(dp(18f), dp(14f), dp(18f), dp(14f))
        val hd = LinearLayout(this)
        hd.orientation = LinearLayout.HORIZONTAL
        hd.gravity = Gravity.CENTER_VERTICAL
        hd.addView(tv("Choose an effect", 17f, 0xFFFFFFFF.toInt(), true), LinearLayout.LayoutParams(0, -2, 1f))
        val close = FBtn(this, "Close", 1, 34f)
        close.onClick = { dlg.dismiss() }
        hd.addView(close, LinearLayout.LayoutParams(dp(80f), -2))
        panel.addView(hd)
        val sv = ScrollView(this)
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        sv.addView(body, FrameLayout.LayoutParams(-1, -2))
        panel.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        for (g in listOf("Screen", "Text", "Scene")) {
            val ids = FxType.groups.indices.filter { FxType.groups[it] == g }
            if (ids.isEmpty()) continue
            val gl = tv(g.uppercase(), 10.5f, FxC.DIM, true)
            gl.letterSpacing = 0.14f
            gl.setPadding(0, dp(12f), 0, dp(6f))
            body.addView(gl)
            var row: LinearLayout? = null
            for ((n, id) in ids.withIndex()) {
                if (n % 4 == 0) {
                    row = LinearLayout(this)
                    row.orientation = LinearLayout.HORIZONTAL
                    val lp = LinearLayout.LayoutParams(-1, -2)
                    lp.bottomMargin = dp(8f)
                    body.addView(row, lp)
                }
                val tile = EffectTile(this, id)
                tile.onPick = {
                    dlg.dismiss()
                    if (pick != null) pick(id) else addEffect(id)
                }
                val lp = LinearLayout.LayoutParams(0, -2, 1f)
                lp.rightMargin = dp(8f)
                row!!.addView(tile, lp)
            }
            // keep tiles the same width on a short last row
            val rest = ids.size % 4
            if (rest != 0) for (k in rest until 4) row!!.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        }
        dlg.setContentView(panel)
        val dm = resources.displayMetrics
        dlg.window?.setLayout((dm.widthPixels * 0.7f).toInt(), (dm.heightPixels * 0.88f).toInt())
        dlg.show()
    }

    private fun addEffect(type: Int) {
        val e = FxEffect(type, FxStore.swatches[(work.effects.size + 1) % FxStore.swatches.size], 70, 50, head, 1500)
        if (type == FxType.TEXT) e.text = "WIN"
        if (type == FxType.SHAKE) e.color = FxStore.WHITE
        work.effects.add(e)
        dirty = true
        tl.rebuild()
        selKind = -2
        select(1, work.effects.size - 1)
        stage.invalidate()
    }

    private fun addText() {
        ux.ask("Word to show", "WIN") { s ->
            if (s.isNotEmpty()) {
                val e = FxEffect(FxType.TEXT, FxStore.GOLD, 80, 50, head, 1800, s.take(16))
                work.effects.add(e)
                dirty = true
                tl.rebuild()
                selKind = -2
                select(1, work.effects.size - 1)
                stage.invalidate()
            }
        }
    }

    private fun copySel() {
        if (selKind == 1) {
            val e = work.effects.getOrNull(selIdx) ?: return
            val c = e.copy(); c.startMs += 200
            work.effects.add(c)
            dirty = true
            tl.rebuild()
            selKind = -2
            select(1, work.effects.size - 1)
        } else if (selKind == 2) {
            val l = work.layers.getOrNull(selIdx) ?: return
            val c = l.copy(); c.startMs += 200; c.x = (c.x + 0.05f).coerceAtMost(1f); c.y = (c.y + 0.05f).coerceAtMost(1f)
            work.layers.add(c)
            dirty = true
            tl.rebuild()
            selKind = -2
            select(2, work.layers.size - 1)
        } else {
            ux.toast("Select a picture or an effect first")
        }
        stage.invalidate()
    }

    private fun deleteSel() {
        when (selKind) {
            1 -> if (selIdx in work.effects.indices) work.effects.removeAt(selIdx) else return
            2 -> if (selIdx in work.layers.indices) work.layers.removeAt(selIdx) else return
            3 -> { work.audio = ""; work.audioDur = 0; work.audioIn = 0; work.audioStart = 0; FxAudio.stop() }
            else -> { ux.toast("Select something first"); return }
        }
        dirty = true
        selKind = -2
        tl.rebuild()
        select(-1, -1)
        stage.invalidate()
        refreshTime()
    }

    // ---------- save / leave ----------

    private fun save() {
        pause()
        val orig = FxStore.get(this, animId)
        if (orig == null) {
            FxStore.add(this, work)
        } else {
            orig.name = work.name
            orig.effects.clear()
            orig.effects.addAll(work.effects)
            orig.layers.clear()
            orig.layers.addAll(work.layers)
            orig.audio = work.audio
            orig.volume = work.volume
            orig.audioStart = work.audioStart
            orig.audioIn = work.audioIn
            orig.audioDur = work.audioDur
            FxStore.save(this)
        }
        setResult(RESULT_OK, Intent().putExtra(EX_ID, animId))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        pause()
        if (!dirty) { finish(); return }
        AlertDialog.Builder(this).setTitle("Leave without saving?")
            .setMessage("Your changes to this animation will be lost.")
            .setPositiveButton("Save") { _, _ -> save() }
            .setNegativeButton("Discard") { _, _ -> finish() }
            .setNeutralButton("Keep editing", null).show()
    }
}

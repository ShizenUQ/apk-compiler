package com.xio.bulwark

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Shader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** The kinds of effect an animation can be built from. */
object FxType {
    const val COMET = 0
    const val GLOW = 1
    const val GLITCH = 2
    const val SCAN = 3
    const val FLASH = 4
    const val WAVE = 5
    const val TEXT = 6
    const val SHAKE = 7
    const val SPARKS = 8
    const val RAYS = 9
    const val SPEED = 10
    const val CONFETTI = 11
    const val BOLT = 12
    const val VIGNETTE = 13
    val names = listOf(
        "Comet sweep", "Glow pulse", "Glitch", "Scan line", "Flash", "Shockwave", "Text", "Screen shake",
        "Sparks", "Light rays", "Speed lines", "Confetti", "Lightning", "Vignette"
    )
    val hints = listOf(
        "A light races around the screen edge",
        "The edge glows and pulses",
        "Torn lines and colour splits",
        "A bright line sweeps down the screen",
        "A quick flash of colour",
        "A ring expands from the centre",
        "A word pops up in the middle",
        "Shakes the whole scene: text and your pictures",
        "Sparks burst out from the middle",
        "Rotating beams of light from the centre",
        "Anime speed lines rush at the screen",
        "Colourful confetti falls from the top",
        "A jagged bolt strikes with a white flash",
        "The edges of the screen pulse with colour"
    )
    val groups = listOf("Screen", "Screen", "Screen", "Screen", "Screen", "Screen", "Text", "Scene", "Screen", "Screen", "Screen", "Screen", "Screen", "Screen")
}

/** One step of an animation. Times are in milliseconds from the start. */
class FxEffect(
    var type: Int,
    var color: Int,
    var power: Int = 70,
    var speed: Int = 50,
    var startMs: Int = 0,
    var durMs: Int = 1500,
    var text: String = ""
) {
    fun copy() = FxEffect(type, color, power, speed, startMs, durMs, text)

    fun toJson(): JSONObject = JSONObject()
        .put("t", type).put("c", color).put("p", power).put("s", speed)
        .put("a", startMs).put("d", durMs).put("x", text)

    companion object {
        fun from(o: JSONObject) = FxEffect(
            o.optInt("t", 0), o.optInt("c", 0xFF19E6F2.toInt()), o.optInt("p", 70), o.optInt("s", 50),
            o.optInt("a", 0), o.optInt("d", 1500), o.optString("x", "")
        )
    }
}

/** A picture placed on the screen. x and y are 0..1 across the screen, scale 1 = a quarter of the screen height. */
class FxLayer(
    var path: String,
    var x: Float = 0.5f,
    var y: Float = 0.5f,
    var scale: Float = 1f,
    var rot: Float = 0f,
    var alpha: Float = 1f,
    var startMs: Int = 0,
    var durMs: Int = 1500,
    var intro: Int = 1,
    var outro: Int = 1,
    var loop: Int = 0,
    var lpow: Int = 60,
    var lspd: Int = 50
) {
    fun copy() = FxLayer(path, x, y, scale, rot, alpha, startMs, durMs, intro, outro, loop, lpow, lspd)

    companion object Names {
        val loops = listOf("None", "Shake", "Pulse", "Float", "Spin", "Wobble", "Bounce", "Flicker", "Glow aura", "Glitch", "Shine", "Slow zoom")
        val intros = listOf("None", "Fade", "Pop", "Slide in", "Zoom in", "Spin in", "Drop", "Flash in")
        val outros = listOf("None", "Fade", "Shrink", "Slide out", "Fly up", "Spin out", "Zoom out")
    }

    fun toJson(): JSONObject = JSONObject()
        .put("f", path).put("x", x.toDouble()).put("y", y.toDouble()).put("k", scale.toDouble())
        .put("r", rot.toDouble()).put("o", alpha.toDouble()).put("a", startMs).put("d", durMs)
        .put("i", intro).put("u", outro).put("lp", loop).put("lw", lpow).put("ls", lspd)
}

fun layerFrom(o: JSONObject) = FxLayer(
    o.optString("f", ""), o.optDouble("x", 0.5).toFloat(), o.optDouble("y", 0.5).toFloat(),
    o.optDouble("k", 1.0).toFloat(), o.optDouble("r", 0.0).toFloat(), o.optDouble("o", 1.0).toFloat(),
    o.optInt("a", 0), o.optInt("d", 1500), o.optInt("i", 1), o.optInt("u", 1),
    o.optInt("lp", 0), o.optInt("lw", 60), o.optInt("ls", 50)
)

class FxAnim(val id: String, var name: String, val builtIn: Boolean) {
    val effects = ArrayList<FxEffect>()
    val layers = ArrayList<FxLayer>()
    var audio = ""
    var volume = 80
    var audioStart = 0      // where the sound begins on the timeline, ms
    var audioIn = 0         // how far into the sound file it starts, ms
    var audioDur = 0        // how long it plays, ms (0 = whole file)

    fun totalMs(): Int {
        var m = 600
        if (audio.isNotEmpty() && audioDur > 0) m = max(m, audioStart + audioDur)
        for (e in effects) m = max(m, e.startMs + e.durMs)
        for (l in layers) m = max(m, l.startMs + l.durMs)
        return m
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id).put("name", name).put("b", builtIn).put("au", audio).put("vol", volume).put("as", audioStart).put("ai", audioIn).put("ad", audioDur)
        val e = JSONArray()
        for (x in effects) e.put(x.toJson())
        o.put("e", e)
        val l = JSONArray()
        for (x in layers) l.put(x.toJson())
        o.put("l", l)
        return o
    }

    fun copyAs(newId: String, newName: String): FxAnim {
        val a = FxAnim(newId, newName, false)
        for (e in effects) a.effects.add(e.copy())
        for (l in layers) a.layers.add(l.copy())
        a.audio = audio
        a.volume = volume
        a.audioStart = audioStart
        a.audioIn = audioIn
        a.audioDur = audioDur
        return a
    }

    companion object {
        fun from(o: JSONObject): FxAnim {
            val a = FxAnim(o.getString("id"), o.optString("name", "Animation"), o.optBoolean("b", false))
            a.audio = o.optString("au", "")
            a.volume = o.optInt("vol", 80)
            a.audioStart = o.optInt("as", 0)
            a.audioIn = o.optInt("ai", 0)
            a.audioDur = o.optInt("ad", 0)
            val e = o.optJSONArray("e")
            if (e != null) for (i in 0 until e.length()) a.effects.add(FxEffect.from(e.getJSONObject(i)))
            val l = o.optJSONArray("l")
            if (l != null) for (i in 0 until l.length()) a.layers.add(layerFrom(l.getJSONObject(i)))
            return a
        }
    }
}

/** All animations: the built-in ones plus the ones you make. Saved as one small json file. */
object FxStore {
    private val list = ArrayList<FxAnim>()
    private var loaded = false

    val GOLD = 0xFFFFC94A.toInt()
    val RED = 0xFFFF3B30.toInt()
    val CYAN = 0xFF19E6F2.toInt()
    val PINK = 0xFFFF2E93.toInt()
    val GREEN = 0xFF3DDC97.toInt()
    val VIOLET = 0xFF8F6BFF.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val ORANGE = 0xFFFF8A2B.toInt()
    val swatches = intArrayOf(CYAN, GOLD, RED, PINK, GREEN, VIOLET, ORANGE, WHITE)

    private fun file(c: Context) = File(c.filesDir, "fx_anims.json")

    fun newId(): String = "u" + System.currentTimeMillis().toString(36)

    private fun defaults(): List<FxAnim> {
        val out = ArrayList<FxAnim>()

        val v = FxAnim("b_victory", "Victory", true)
        v.effects.add(FxEffect(FxType.FLASH, GOLD, 55, 50, 0, 500))
        v.effects.add(FxEffect(FxType.WAVE, GOLD, 80, 55, 0, 1200))
        v.effects.add(FxEffect(FxType.COMET, CYAN, 80, 60, 100, 2200))
        v.effects.add(FxEffect(FxType.GLOW, GOLD, 70, 50, 250, 2300))
        v.effects.add(FxEffect(FxType.TEXT, GOLD, 80, 50, 150, 2500, "VICTORY"))
        out.add(v)

        val d = FxAnim("b_defeat", "Defeat", true)
        d.effects.add(FxEffect(FxType.GLITCH, RED, 85, 60, 0, 1500))
        d.effects.add(FxEffect(FxType.SHAKE, WHITE, 60, 60, 0, 900))
        d.effects.add(FxEffect(FxType.TEXT, RED, 80, 50, 100, 2300, "DEFEAT"))
        d.effects.add(FxEffect(FxType.SCAN, RED, 60, 50, 300, 1600))
        d.effects.add(FxEffect(FxType.GLOW, RED, 50, 40, 300, 1900))
        out.add(d)

        val f = FxAnim("b_firstblood", "First blood", true)
        f.effects.add(FxEffect(FxType.FLASH, RED, 60, 50, 0, 380))
        f.effects.add(FxEffect(FxType.COMET, RED, 90, 80, 0, 1500))
        f.effects.add(FxEffect(FxType.SHAKE, WHITE, 70, 70, 0, 550))
        f.effects.add(FxEffect(FxType.WAVE, RED, 60, 60, 0, 900))
        f.effects.add(FxEffect(FxType.TEXT, RED, 70, 50, 100, 1900, "FIRST BLOOD"))
        out.add(f)

        val s = FxAnim("b_savage", "Savage", true)
        s.effects.add(FxEffect(FxType.GLITCH, PINK, 75, 70, 0, 1300))
        s.effects.add(FxEffect(FxType.WAVE, PINK, 85, 65, 0, 1100))
        s.effects.add(FxEffect(FxType.COMET, CYAN, 85, 85, 150, 1900))
        s.effects.add(FxEffect(FxType.SHAKE, WHITE, 55, 70, 100, 700))
        s.effects.add(FxEffect(FxType.TEXT, PINK, 80, 50, 150, 2300, "SAVAGE"))
        out.add(s)
        return out
    }

    @Synchronized
    private fun load(c: Context) {
        if (loaded) return
        loaded = true
        list.clear()
        try {
            val f = file(c)
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) list.add(FxAnim.from(a.getJSONObject(i)))
            }
        } catch (t: Throwable) { }
        val have = HashSet<String>()
        for (x in list) have.add(x.id)
        var changed = false
        val ds = defaults()
        for ((i, d) in ds.withIndex()) {
            if (!have.contains(d.id)) { list.add(minOf(i, list.size), d); changed = true }
        }
        if (changed) save(c)
    }

    @Synchronized
    fun all(c: Context): List<FxAnim> { load(c); return ArrayList(list) }

    fun get(c: Context, id: String): FxAnim? { load(c); return list.firstOrNull { it.id == id } }

    @Synchronized
    fun save(c: Context) {
        try {
            val a = JSONArray()
            for (x in list) a.put(x.toJson())
            file(c).writeText(a.toString())
        } catch (t: Throwable) { }
    }

    @Synchronized
    fun add(c: Context, a: FxAnim) { load(c); list.add(a); save(c) }

    @Synchronized
    fun remove(c: Context, id: String) {
        load(c)
        list.removeAll { it.id == id && !it.builtIn }
        save(c)
    }

    /** Puts a built-in animation back to how it came. */
    @Synchronized
    fun reset(c: Context, id: String) {
        load(c)
        val d = defaults().firstOrNull { it.id == id } ?: return
        val i = list.indexOfFirst { it.id == id }
        if (i >= 0) list[i] = d else list.add(d)
        save(c)
    }
}

/** Draws one animation at one moment. The same code is used by the stage in the app and, later, by the game overlay. */
class FxRender(private val ctx: Context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val seg = Path()
    private val rect = RectF()
    private val pm = PathMeasure()
    private val bmps = HashMap<String, Bitmap?>()

    private fun env(k: Float): Float = min(1f, min(k / 0.12f, (1f - k) / 0.3f)).coerceIn(0f, 1f)

    private fun col(c: Int, a: Float): Int = (c and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24)

    fun draw(c: Canvas, w: Float, h: Float, a: FxAnim, t: Int) {
        val u = h / 360f
        var sx = 0f
        var sy = 0f
        for (e in a.effects) {
            if (e.type != FxType.SHAKE || t < e.startMs || t >= e.startMs + e.durMs) continue
            val k = (t - e.startMs).toFloat() / max(1, e.durMs)
            val amp = e.power / 100f * 16f * u * (1f - k)
            val fr = 0.05f + e.speed * 0.002f
            sx += (sin(t * fr * 1.3f) + sin(t * fr * 2.9f + 1.7f)) * 0.5f * amp
            sy += (sin(t * fr * 1.7f + 0.6f) + sin(t * fr * 3.3f + 2.4f)) * 0.5f * amp
        }

        // pictures first, so effects sit on top of them
        c.save()
        c.translate(sx, sy)
        for (l in a.layers) drawLayer(c, w, h, u, l, t)
        c.restore()

        for (e in a.effects) {
            if (t < e.startMs || t > e.startMs + e.durMs) continue
            val k = ((t - e.startMs).toFloat() / max(1, e.durMs)).coerceIn(0f, 1f)
            when (e.type) {
                FxType.COMET -> comet(c, w, h, u, e, k)
                FxType.GLOW -> glow(c, w, h, u, e, k)
                FxType.GLITCH -> glitch(c, w, h, u, e, k, t)
                FxType.SCAN -> scan(c, w, h, u, e, k)
                FxType.FLASH -> flash(c, w, h, e, k)
                FxType.WAVE -> wave(c, w, h, u, e, k)
                FxType.TEXT -> text(c, w, h, u, e, k, sx, sy)
                FxType.SPARKS -> sparks(c, w, h, u, e, k)
                FxType.RAYS -> rays(c, w, h, u, e, k)
                FxType.SPEED -> speed(c, w, h, u, e, k, t)
                FxType.CONFETTI -> confetti(c, w, h, u, e, k)
                FxType.BOLT -> bolt(c, w, h, u, e, k, t)
                FxType.VIGNETTE -> vignette(c, w, h, u, e, k)
            }
        }
    }

    private fun bitmapFor(path: String): Bitmap? {
        if (path.isEmpty()) return null
        if (bmps.containsKey(path)) return bmps[path]
        var b: Bitmap? = null
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, o)
            var s = 1
            while (o.outWidth / (s * 2) >= 1024 && o.outWidth > 0) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            b = BitmapFactory.decodeFile(path, o2)
        } catch (t: Throwable) { }
        bmps[path] = b
        return b
    }

    /** Width and height in pixels of a picture on a screen of the given height, or null if it cannot be loaded. */
    fun layerDims(h: Float, l: FxLayer, scale: Float = l.scale): FloatArray? {
        val bmp = bitmapFor(l.path) ?: return null
        val target = h * 0.25f * scale
        val ratio = bmp.width.toFloat() / max(1, bmp.height).toFloat()
        return floatArrayOf(target * ratio, target)
    }

    /** Draws a picture as it will look at its best, for placing it. selected gets an outline. */
    fun drawLayerStatic(c: Canvas, w: Float, h: Float, l: FxLayer, selected: Boolean) {
        val bmp = bitmapFor(l.path) ?: return
        val dm = layerDims(h, l) ?: return
        c.save()
        c.translate(w * l.x, h * l.y)
        c.rotate(l.rot)
        p.style = Paint.Style.FILL
        p.shader = null
        p.alpha = (l.alpha.coerceIn(0f, 1f) * 255f).toInt()
        rect.set(-dm[0] / 2f, -dm[1] / 2f, dm[0] / 2f, dm[1] / 2f)
        c.drawBitmap(bmp, null, rect, p)
        p.alpha = 255
        if (selected) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = max(1.5f, h / 180f)
            p.color = 0xFF19E6F2.toInt()
            c.drawRect(rect, p)
            p.style = Paint.Style.FILL
            val s = max(3f, h / 70f)
            for (sx in floatArrayOf(-1f, 1f)) for (sy in floatArrayOf(-1f, 1f)) c.drawCircle(sx * dm[0] / 2f, sy * dm[1] / 2f, s, p)
        }
        c.restore()
    }

    /** Just the selection frame of a picture (used by the editor, which draws the picture itself). */
    fun drawLayerOutline(c: Canvas, w: Float, h: Float, l: FxLayer) {
        val dm = layerDims(h, l) ?: return
        c.save()
        c.translate(w * l.x, h * l.y)
        c.rotate(l.rot)
        rect.set(-dm[0] / 2f, -dm[1] / 2f, dm[0] / 2f, dm[1] / 2f)
        p.style = Paint.Style.STROKE
        p.shader = null
        p.strokeWidth = max(1.5f, h / 180f)
        p.color = 0xFF19E6F2.toInt()
        c.drawRect(rect, p)
        p.style = Paint.Style.FILL
        val s = max(3f, h / 70f)
        for (sx in floatArrayOf(-1f, 1f)) for (sy in floatArrayOf(-1f, 1f)) c.drawCircle(sx * dm[0] / 2f, sy * dm[1] / 2f, s, p)
        c.restore()
    }

    /** True when the point (px, py) on a stage of w x h lands on this picture. */
    fun hitLayer(w: Float, h: Float, l: FxLayer, px: Float, py: Float): Boolean {
        val dm = layerDims(h, l) ?: return false
        val dx = px - w * l.x
        val dy = py - h * l.y
        val a = Math.toRadians(-l.rot.toDouble())
        val rx = (dx * kotlin.math.cos(a) - dy * kotlin.math.sin(a)).toFloat()
        val ry = (dx * kotlin.math.sin(a) + dy * kotlin.math.cos(a)).toFloat()
        return kotlin.math.abs(rx) <= dm[0] / 2f && kotlin.math.abs(ry) <= dm[1] / 2f
    }

    private fun fr(x: Float): Float { val v = kotlin.math.abs(sin(x) * 43758.547f); return v - kotlin.math.floor(v) }

    private fun drawLayer(c: Canvas, w: Float, h: Float, u: Float, l: FxLayer, t: Int) {
        if (t < l.startMs || t > l.startMs + l.durMs) return
        val bmp = bitmapFor(l.path) ?: return
        val el = (t - l.startMs).toFloat()
        val left = l.startMs + l.durMs - t
        val inLen = min(650f, l.durMs / 2f).coerceAtLeast(60f)
        val outLen = min(650f, l.durMs / 2f).coerceAtLeast(60f)
        val inK = (el / inLen).coerceIn(0f, 1f)
        val outK = (left / outLen).coerceIn(0f, 1f)
        val k = (el / max(1, l.durMs)).coerceIn(0f, 1f)
        var al = l.alpha
        var sc = l.scale
        var dx = 0f
        var dy = 0f
        var rot = l.rot
        val easeIn = 1f - (1f - inK).pow(3)
        val easeOut = 1f - outK
        when (l.intro) {
            1 -> al *= inK
            2 -> { al *= inK; sc *= 0.4f + 0.6f * easeIn + 0.12f * sin(inK * PI.toFloat()) }
            3 -> { al *= inK; dx = -(1f - easeIn) * 90f * u }
            4 -> { al *= inK; sc *= 1f + 1.6f * (1f - easeIn) }
            5 -> { al *= inK; sc *= 0.3f + 0.7f * easeIn; rot -= 360f * (1f - easeIn) }
            6 -> { al *= min(1f, inK * 4f); val b = if (inK < 1f) (1f - inK).pow(2) * kotlin.math.cos(inK * 9f) else 0f; dy = -b * 120f * u }
            7 -> { al *= if (inK < 1f && fr(el * 0.09f) < 0.5f) 0.15f else 1f }
        }
        when (l.outro) {
            1 -> al *= outK
            2 -> { al *= outK; sc *= 0.6f + 0.4f * outK }
            3 -> { al *= outK; dx += easeOut * 110f * u }
            4 -> { al *= outK; dy -= easeOut * 90f * u }
            5 -> { al *= outK; sc *= 0.5f + 0.5f * outK; rot += 360f * easeOut }
            6 -> { al *= outK; sc *= 1f + 0.8f * easeOut }
        }
        val pw = l.lpow / 100f
        val tt = el / 1000f * (0.5f + l.lspd / 100f * 3.5f)
        val tau = (2.0 * PI).toFloat()
        var glow = 0f
        var glitch = false
        var shine = -1f
        when (l.loop) {
            1 -> {
                val amp = pw * 9f * u
                dx += (sin(tt * 53f) + sin(tt * 91f + 1.3f)) * 0.5f * amp
                dy += (sin(tt * 61f + 0.7f) + sin(tt * 97f + 2.1f)) * 0.5f * amp
                rot += sin(tt * 47f) * pw * 2f
            }
            2 -> sc *= 1f + 0.22f * pw * (0.5f + 0.5f * sin(tt * tau * 0.9f))
            3 -> { dy += sin(tt * tau * 0.45f) * pw * 12f * u; dx += sin(tt * tau * 0.3f + 1f) * pw * 4f * u }
            4 -> rot += el / 1000f * (40f + l.lspd * 3.2f)
            5 -> rot += sin(tt * tau * 0.8f) * pw * 16f
            6 -> dy -= kotlin.math.abs(sin(tt * PI.toFloat() * 1.1f)) * pw * 30f * u
            7 -> { if (fr(kotlin.math.floor(tt * 14f)) < pw * 0.5f) al *= 0.2f }
            8 -> glow = pw * (0.6f + 0.4f * sin(tt * tau * 0.7f))
            9 -> glitch = true
            10 -> shine = ((tt * 0.35f) % 1.6f) - 0.3f
            11 -> sc *= 1f + 0.5f * pw * k
        }
        val target = h * 0.25f * sc
        val ratio = bmp.width.toFloat() / max(1, bmp.height).toFloat()
        val bw = target * ratio
        val bh = target
        c.save()
        c.translate(w * l.x + dx, h * l.y + dy)
        c.rotate(rot)
        p.style = Paint.Style.FILL
        p.shader = null
        val a255 = (al.coerceIn(0f, 1f) * 255f).toInt()
        if (glow > 0.01f) {
            p.colorFilter = android.graphics.PorterDuffColorFilter(0xFF7FE9FF.toInt(), android.graphics.PorterDuff.Mode.SRC_IN)
            for (i in 1..4) {
                val g = 1f + i * 0.06f * glow
                p.alpha = (a255 * 0.2f * glow / i).toInt()
                rect.set(-bw * g / 2f, -bh * g / 2f, bw * g / 2f, bh * g / 2f)
                c.drawBitmap(bmp, null, rect, p)
            }
            p.colorFilter = null
        }
        p.alpha = a255
        if (glitch) {
            val bands = 7
            val seed = kotlin.math.floor(el / 70f)
            for (i in 0 until bands) {
                val on = fr(seed * 3.1f + i) < pw * 0.55f
                val off = if (on) (fr(seed + i * 7.7f) - 0.5f) * bw * 0.35f * pw else 0f
                c.save()
                c.clipRect(-bw / 2f - bw, -bh / 2f + bh * i / bands, bw / 2f + bw, -bh / 2f + bh * (i + 1) / bands + 1f)
                rect.set(-bw / 2f + off, -bh / 2f, bw / 2f + off, bh / 2f)
                c.drawBitmap(bmp, null, rect, p)
                c.restore()
            }
        } else if (shine >= 0f) {
            val sl = c.saveLayer(-bw / 2f, -bh / 2f, bw / 2f, bh / 2f, null)
            rect.set(-bw / 2f, -bh / 2f, bw / 2f, bh / 2f)
            c.drawBitmap(bmp, null, rect, p)
            val x0 = -bw / 2f + bw * shine
            val sh = LinearGradient(x0 - bw * 0.15f, -bh / 2f, x0 + bw * 0.15f, bh / 2f, intArrayOf(0x00FFFFFF, 0xCCFFFFFF.toInt(), 0x00FFFFFF), null, Shader.TileMode.CLAMP)
            val q = Paint(Paint.ANTI_ALIAS_FLAG)
            q.shader = sh
            q.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC_ATOP)
            q.alpha = a255
            c.drawRect(rect, q)
            c.restoreToCount(sl)
        } else {
            rect.set(-bw / 2f, -bh / 2f, bw / 2f, bh / 2f)
            c.drawBitmap(bmp, null, rect, p)
        }
        p.alpha = 255
        c.restore()
    }

    // ---- more screen effects ----

    private fun sparks(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val n = 24 + (e.power * 0.6f).toInt()
        val en = (1f - k).coerceIn(0f, 1f)
        val ease = 1f - (1f - k).pow(2.2f)
        val reach = (80f + e.speed * 1.6f) * u
        p.style = Paint.Style.FILL
        p.shader = null
        for (i in 0 until n) {
            val ang = fr(i * 1.7f) * 2f * PI.toFloat()
            val sp = 0.35f + fr(i * 3.3f + 9f) * 0.9f
            val dist = reach * sp * ease * 2.2f
            val gx = w / 2f + kotlin.math.cos(ang) * dist
            val gy = h / 2f + sin(ang) * dist + 70f * u * k * k * sp
            val sz = (1.4f + fr(i * 5.1f) * 3.2f) * u * (0.4f + en)
            p.color = col(if (i % 5 == 0) 0xFFFFFFFF.toInt() else e.color, en * 0.95f)
            c.drawCircle(gx, gy, sz, p)
            p.color = col(e.color, en * 0.25f)
            c.drawCircle(gx, gy, sz * 2.6f, p)
        }
    }

    private fun rays(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val en = env(k)
        val n = 16
        val step = 2f * PI.toFloat() / n
        val rot = k * (0.6f + e.speed / 100f * 2.4f)
        val r = hypot(w, h)
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = col(e.color, 0.3f * en * (0.35f + e.power / 100f * 0.65f))
        for (i in 0 until n) {
            val a0 = rot + i * step
            val a1 = a0 + step * 0.4f
            path.reset()
            path.moveTo(w / 2f, h / 2f)
            path.lineTo(w / 2f + kotlin.math.cos(a0) * r, h / 2f + sin(a0) * r)
            path.lineTo(w / 2f + kotlin.math.cos(a1) * r, h / 2f + sin(a1) * r)
            path.close()
            c.drawPath(path, p)
        }
        p.shader = android.graphics.RadialGradient(w / 2f, h / 2f, r * 0.5f, col(e.color, 0.5f * en), 0x00000000, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }

    private fun speed(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float, t: Int) {
        val en = env(k)
        val seed = kotlin.math.floor(t / (110f - e.speed * 0.8f))
        val n = 40 + (e.power * 0.5f).toInt()
        val r = hypot(w, h) / 2f
        p.style = Paint.Style.STROKE
        p.shader = null
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until n) {
            val ang = fr(i * 2.3f + seed * 1.9f) * 2f * PI.toFloat()
            val r0 = r * (0.42f + fr(i * 4.1f + seed) * 0.3f)
            val r1 = r * (0.85f + fr(i * 6.7f + seed * 0.3f) * 0.3f)
            p.strokeWidth = (0.8f + fr(i * 8.8f) * 2.4f) * u
            p.color = col(if (i % 4 == 0) e.color else 0xFFFFFFFF.toInt(), 0.7f * en)
            c.drawLine(w / 2f + kotlin.math.cos(ang) * r0, h / 2f + sin(ang) * r0, w / 2f + kotlin.math.cos(ang) * r1, h / 2f + sin(ang) * r1, p)
        }
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL
    }

    private fun confetti(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val n = 40 + (e.power * 0.8f).toInt()
        val sw = FxStore.swatches
        p.style = Paint.Style.FILL
        p.shader = null
        for (i in 0 until n) {
            val delay = fr(i * 2.9f) * 0.35f
            val kk = ((k - delay) / (1f - delay)).coerceIn(0f, 1f)
            if (kk <= 0f || kk >= 1f) continue
            val x = w * fr(i * 1.3f + 4f) + sin(kk * 7f + i) * 14f * u
            val y = -20f * u + kk * (h + 40f * u) * (0.75f + fr(i * 7.1f) * 0.5f + e.speed / 250f)
            c.save()
            c.translate(x, y)
            c.rotate(kk * (260f + fr(i * 3.7f) * 500f))
            p.color = col(sw[i % sw.size], 0.95f * (1f - kk * kk))
            val s = (3f + fr(i * 9.1f) * 4f) * u
            c.drawRect(-s, -s * 0.5f, s, s * 0.5f, p)
            c.restore()
        }
    }

    private fun bolt(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float, t: Int) {
        val seed = kotlin.math.floor((k * (3f + e.speed / 25f)) * 1.0f)
        val on = fr(seed * 5.3f + 1f) < 0.8f
        val phase = (k * (3f + e.speed / 25f)) % 1f
        if (on && phase < 0.55f) {
            val x0 = w * (0.2f + fr(seed * 3.7f) * 0.6f)
            path.reset()
            var x = x0
            var y = 0f
            path.moveTo(x, y)
            val steps = 10
            for (i in 1..steps) {
                y = h * i / steps
                x += (fr(seed * 11f + i * 2.7f) - 0.5f) * 70f * u
                path.lineTo(x, y)
            }
            p.style = Paint.Style.STROKE
            p.shader = null
            p.strokeJoin = Paint.Join.ROUND
            p.strokeWidth = (10f + e.power * 0.1f) * u
            p.color = col(e.color, 0.25f)
            c.drawPath(path, p)
            p.strokeWidth = 4f * u
            p.color = col(e.color, 0.7f)
            c.drawPath(path, p)
            p.strokeWidth = 1.6f * u
            p.color = 0xFFFFFFFF.toInt()
            c.drawPath(path, p)
            p.strokeJoin = Paint.Join.MITER
            p.style = Paint.Style.FILL
            p.color = col(0xFFFFFFFF.toInt(), 0.35f * (1f - phase / 0.55f) * (0.3f + e.power / 100f * 0.7f))
            c.drawRect(0f, 0f, w, h, p)
        }
    }

    private fun vignette(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val en = env(k)
        val pulse = 0.65f + 0.35f * sin(k * (2f + e.speed / 100f * 8f) * 2f * PI.toFloat())
        val r = hypot(w, h) / 2f
        p.style = Paint.Style.FILL
        p.shader = android.graphics.RadialGradient(
            w / 2f, h / 2f, r, intArrayOf(0x00000000, 0x00000000, col(e.color, 0.8f * en * pulse * (0.3f + e.power / 100f * 0.7f))),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }

    private fun frame(w: Float, h: Float, u: Float): Float {
        val inset = 6f * u
        rect.set(inset, inset, w - inset, h - inset)
        return 18f * u
    }

    private fun comet(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val rad = frame(w, h, u)
        path.reset()
        path.addRoundRect(rect, rad, rad, Path.Direction.CW)
        pm.setPath(path, true)
        val len = pm.length
        val laps = 1f + e.speed / 100f * 1.5f
        val ease = k * k * (3f - 2f * k)
        val head = ease * laps * len
        val trail = len * (0.12f + e.power / 100f * 0.12f)
        val en = env(k)
        val width = (2.2f + e.power / 100f * 3.8f) * u
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.shader = null
        val n = 14
        for (i in 0 until n) {
            val from = head - trail * (i + 1) / n
            val to = head - trail * i / n
            val f = ((from % len) + len) % len
            val tt = ((to % len) + len) % len
            seg.rewind()
            if (tt >= f) pm.getSegment(f, tt, seg, true)
            else { pm.getSegment(f, len, seg, true); pm.getSegment(0f, tt, seg, true) }
            val fade = 1f - i.toFloat() / n
            p.strokeWidth = width * (0.35f + 0.65f * fade)
            p.color = col(e.color, 0.9f * fade * fade * en)
            c.drawPath(seg, p)
        }
        val pos = FloatArray(2)
        pm.getPosTan(((head % len) + len) % len, pos, null)
        p.style = Paint.Style.FILL
        p.color = col(e.color, 0.18f * en)
        c.drawCircle(pos[0], pos[1], width * 4.5f, p)
        p.color = col(e.color, 0.4f * en)
        c.drawCircle(pos[0], pos[1], width * 2.4f, p)
        p.color = col(0xFFFFFFFF.toInt(), 0.95f * en)
        c.drawCircle(pos[0], pos[1], width * 0.9f, p)
        p.strokeCap = Paint.Cap.BUTT
    }

    private fun glow(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val rad = frame(w, h, u)
        val pulses = 2f + e.speed / 100f * 4f
        val a = env(k) * (0.55f + 0.45f * sin(k * pulses * 2f * PI.toFloat() - 1.2f)) * (e.power / 100f)
        p.style = Paint.Style.STROKE
        p.shader = null
        for (j in 0..4) {
            p.strokeWidth = (2f + j * 6f) * u
            p.color = col(e.color, a * (if (j == 0) 0.95f else 0.5f / j))
            c.drawRoundRect(rect, rad, rad, p)
        }
    }

    private fun glitch(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float, t: Int) {
        val seed = t / max(30, 90 - e.speed / 2)
        val en = env(k)
        val pw = e.power / 100f
        p.style = Paint.Style.FILL
        p.shader = null
        val n = 4 + (pw * 10f).toInt()
        for (i in 0 until n) {
            val y = Cy.rnd(seed * 31 + i * 7) * h
            val bh = (2f + Cy.rnd(seed * 17 + i * 3) * 10f) * u
            val x0 = Cy.rnd(seed * 13 + i * 5) * w * 0.6f
            val bw = w * (0.15f + Cy.rnd(seed * 19 + i * 11) * 0.4f)
            val off = (Cy.rnd(seed * 23 + i * 2) - 0.5f) * 40f * u * pw
            p.color = col(e.color, (0.18f + 0.3f * Cy.rnd(seed * 5 + i)) * en)
            c.drawRect(x0 + off, y, x0 + off + bw, y + bh, p)
            if (i % 3 == 0) {
                p.color = col(FxStore.CYAN, 0.22f * en)
                c.drawRect(x0 + off - 6f * u, y, x0 + off + bw * 0.6f, y + bh * 0.5f, p)
            }
        }
        if (Cy.rnd(seed * 7) > 0.78f) {
            p.color = col(e.color, 0.08f * pw * en)
            c.drawRect(0f, 0f, w, h, p)
        }
        val sw = (10f + 22f * pw) * u
        p.color = col(FxStore.PINK, 0.3f * en * Cy.rnd(seed * 3 + 1))
        c.drawRect(0f, 0f, sw, h, p)
        p.color = col(FxStore.CYAN, 0.3f * en * Cy.rnd(seed * 3 + 2))
        c.drawRect(w - sw, 0f, w, h, p)
    }

    private fun scan(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val en = env(k)
        val y = (k * k * (3f - 2f * k)) * (h + 80f * u) - 40f * u
        val tr = (40f + e.power / 100f * 90f) * u
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, y - tr, 0f, y, col(e.color, 0f), col(e.color, 0.35f * en), Shader.TileMode.CLAMP)
        c.drawRect(0f, y - tr, w, y, p)
        p.shader = null
        p.color = col(e.color, 0.95f * en)
        c.drawRect(0f, y - 1.5f * u, w, y + 1.5f * u, p)
        p.color = col(0xFFFFFFFF.toInt(), 0.7f * en)
        c.drawRect(0f, y - 0.5f * u, w, y + 0.5f * u, p)
    }

    private fun flash(c: Canvas, w: Float, h: Float, e: FxEffect, k: Float) {
        val a = (1f - k).pow(2f) * (e.power / 100f) * 0.85f
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = col(e.color, a)
        c.drawRect(0f, 0f, w, h, p)
    }

    private fun wave(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val maxR = hypot(w, h) / 2f * (0.55f + e.speed / 100f * 0.6f)
        p.style = Paint.Style.STROKE
        p.shader = null
        for (j in 0..1) {
            val kk = ((k - j * 0.14f) / (1f - j * 0.14f)).coerceIn(0f, 1f)
            if (kk <= 0f) continue
            val r = (1f - (1f - kk).pow(3)) * maxR
            p.strokeWidth = (3f + e.power / 100f * 11f) * u * (1f - kk) * (if (j == 0) 1f else 0.6f)
            p.color = col(e.color, (1f - kk) * 0.9f)
            c.drawCircle(w / 2f, h / 2f, r, p)
        }
    }

    private fun text(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float, sx: Float, sy: Float) {
        val s = e.text.uppercase()
        if (s.isEmpty()) return
        val en = env(k)
        val pop = if (k < 0.15f) 1.5f - 0.5f * (k / 0.15f).pow(0.6f) else 1f
        val height = (34f + e.power / 100f * 40f) * u * pop
        val kk = height / 10f
        val spread = 1f + (1f - en) * 0.25f
        p.style = Paint.Style.STROKE
        c.save()
        c.translate(sx, sy)
        c.scale(spread, 1f, w / 2f, h / 2f)
        CyUi.text(c, p, s, w / 2f, h / 2f - height / 2f, kk, e.color, en, true, 1)
        c.restore()
        p.style = Paint.Style.FILL
    }
}

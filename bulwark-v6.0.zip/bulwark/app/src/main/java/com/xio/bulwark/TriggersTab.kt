package com.xio.bulwark

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

/** The header of the Triggers tab: a plain title, a status pill and two counters. */
private class FxHero(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    var animCount = 0
    var soundCount = 0

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 112f))
    }

    private fun pill(c: Canvas, x: Float, y: Float, text: String, col: Int, dot: Boolean): Float {
        val d = Ui.dp(context, 1f)
        p.textSize = 12.5f * d
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val tw = p.measureText(text)
        val w = tw + 24 * d + (if (dot) 14 * d else 0f)
        r.set(x, y, x + w, y + 30 * d)
        p.style = Paint.Style.FILL
        p.color = Cy.a(col, 0.16f)
        c.drawRoundRect(r, 15 * d, 15 * d, p)
        var tx = x + 12 * d
        if (dot) {
            p.color = col
            c.drawCircle(x + 15 * d, y + 15 * d, 4 * d, p)
            tx += 14 * d
        }
        p.color = 0xFFEAF0F7.toInt()
        p.textAlign = Paint.Align.LEFT
        c.drawText(text, tx, y + 20 * d, p)
        return w
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 32f * d
        p.textAlign = Paint.Align.LEFT
        p.color = 0xFFFFFFFF.toInt()
        c.drawText("Triggers", 4 * d, 38 * d, p)
        p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        p.textSize = 13.5f * d
        p.color = FxC.MID
        c.drawText("Make animations. Let sounds play them.", 4 * d, 60 * d, p)
        var x = 4f * d
        x += pill(c, x, 72 * d, animCount.toString() + " animations", FxC.ACCENT, false) + 8 * d
        x += pill(c, x, 72 * d, soundCount.toString() + " sounds", FxC.ACCENT, false) + 8 * d
        val on = CaptureBus.running
        pill(c, x, 72 * d, if (on) "Listening" else "Not listening", if (on) FxC.ACCENT2 else FxC.DIM, true)
    }
}

/** A row of round colour choices. */
internal class SwatchRow(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var selected = -1
    var onPick: ((Int) -> Unit)? = null

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 46f))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val n = FxStore.swatches.size
            val i = (e.x / (width.toFloat() / n)).toInt().coerceIn(0, n - 1)
            selected = i
            invalidate()
            onPick?.invoke(FxStore.swatches[i])
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val n = FxStore.swatches.size
        val cw = width.toFloat() / n
        for (i in 0 until n) {
            val cx = cw * i + cw / 2f
            val cy = height / 2f
            p.style = Paint.Style.FILL
            p.color = FxStore.swatches[i]
            c.drawCircle(cx, cy, (if (i == selected) 13f else 11f) * d, p)
            if (i == selected) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f * d
                p.color = 0xFFFFFFFF.toInt()
                c.drawCircle(cx, cy, 17f * d, p)
            }
        }
    }
}

class TriggersTab(private val act: Activity, private val page: ScrollView, private val cards: ArrayList<View>) {
    private val d = act.resources.displayMetrics.density
    private fun dp(v: Float) = (v * d).toInt()
    private val ui = Handler(Looper.getMainLooper())
    private val col = LinearLayout(act)

    private lateinit var hero: FxHero
    private lateinit var stage: FxStage
    private lateinit var animBox: LinearLayout
    private val groupA = LinearLayout(act)
    private val groupB = LinearLayout(act)
    private lateinit var seg: Seg
    private lateinit var snd: SoundSection
    private val ux = FxUi(act, cards)

    private var selId = "b_victory"
    private var selStep = 0
    private var building = false
    private val tick = object : Runnable {
        override fun run() {
            if (page.visibility != View.VISIBLE) return
            if (groupB.visibility == View.VISIBLE) snd.tick()
            hero.soundCount = TriggerStore.all(act).size
            hero.invalidate()
            ui.postDelayed(this, 300)
        }
    }

    // ---------- small builders ----------

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(act)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        t.typeface = Typeface.create("sans-serif-medium", if (bold) Typeface.BOLD else Typeface.NORMAL)
        return t
    }

    private fun label(s: String): TextView {
        val t = tv(s, 12f, FxC.DIM)
        t.setPadding(0, dp(12f), 0, dp(4f))
        return t
    }

    private fun card(title: String): LinearLayout = ux.card(title, if (building) groupA else col)

    private fun row(title: String, sub: String?, ctl: View): LinearLayout {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(9f), 0, dp(9f))
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.addView(tv(title, 15f, FxC.TEXT))
        if (sub != null) c.addView(tv(sub, 11.5f, FxC.DIM))
        r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(ctl, LinearLayout.LayoutParams(-2, -2))
        return r
    }

    private fun toast(s: String) { Toast.makeText(act, s, Toast.LENGTH_SHORT).show() }

    private fun ask(title: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(act)
        et.setText(initial)
        et.setSelection(et.text.length)
        et.setSingleLine(true)
        AlertDialog.Builder(act).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> ok(et.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun cur(): FxAnim? = FxStore.get(act, selId) ?: FxStore.all(act).firstOrNull()

    private fun secs(ms: Int) = String.format(Locale.US, "%.1f s", ms / 1000f)

    // ---------- build ----------

    fun build() {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        page.addView(col, FrameLayout.LayoutParams(-1, -2))
        page.overScrollMode = View.OVER_SCROLL_NEVER

        val all = FxStore.all(act)
        selId = Prefs.str(act, "fx_sel", "b_victory")
        if (all.none { it.id == selId }) selId = all.first().id

        hero = FxHero(act)
        val hl = LinearLayout.LayoutParams(-1, -2)
        hl.topMargin = dp(8f)
        col.addView(hero, hl)
        cards.add(hero)

        seg = Seg(act, listOf("Animations", "Sounds"))
        seg.onSelect = { i -> showGroup(i == 1) }
        col.addView(seg, ux.top(seg, 14f))
        groupA.orientation = LinearLayout.VERTICAL
        groupB.orientation = LinearLayout.VERTICAL
        col.addView(groupA, LinearLayout.LayoutParams(-1, -2))
        col.addView(groupB, LinearLayout.LayoutParams(-1, -2))
        building = true

        // --- stage ---
        val sc = card("Stage")
        stage = FxStage(act)
        stage.loop = Prefs.bool(act, "fx_loop", false)
        stage.onTap = { stage.anim = cur(); stage.play() }
        stage.onStart = { cur()?.let { FxAudio.playAnim(it) } }
        val sl = LinearLayout.LayoutParams(-1, -2)
        sl.topMargin = dp(6f)
        sc.addView(stage, sl)
        val br = LinearLayout(act)
        br.orientation = LinearLayout.HORIZONTAL
        val bPlay = FBtn(act, "Play", 0, 44f)
        bPlay.onClick = { stage.anim = cur(); stage.play() }
        val bStop = FBtn(act, "Stop", 1, 44f)
        bStop.onClick = { stage.stop() }
        val l1 = LinearLayout.LayoutParams(0, -2, 1f)
        l1.rightMargin = dp(8f)
        br.addView(bPlay, l1)
        br.addView(bStop, LinearLayout.LayoutParams(0, -2, 1f))
        val bl = LinearLayout.LayoutParams(-1, -2)
        bl.topMargin = dp(12f)
        sc.addView(br, bl)
        val swLoop = FSwitch(act)
        swLoop.setChecked(stage.loop)
        swLoop.onChange = { v ->
            Prefs.putBool(act, "fx_loop", v)
            stage.loop = v
            if (v) { stage.anim = cur(); stage.play() }
        }
        sc.addView(row("Loop", "Keep replaying the preview", swLoop))

        // --- animations list ---
        val ac = card("Animations")
        animBox = LinearLayout(act)
        animBox.orientation = LinearLayout.VERTICAL
        ac.addView(animBox)
        val bNew = FBtn(act, "Create", 0, 46f)
        bNew.onClick = { createAnim() }
        val bEdit = FBtn(act, "Edit", 0, 46f)
        bEdit.onClick = { editAnim() }
        val bDup = FBtn(act, "Duplicate", 1, 44f)
        bDup.onClick = { dupAnim() }
        val bDel = FBtn(act, "Delete", 2, 44f)
        bDel.onClick = { delAnim() }
        ac.addView(ux.buttons(bNew, bEdit), ux.top(bNew, 12f))
        ac.addView(ux.buttons(bDup, bDel), ux.top(bDup, 8f))
        delBtn = bDel

        building = false
        // --- group B: sounds ---
        snd = SoundSection(ux, groupB)
        groupB.visibility = View.GONE
        showGroup(Prefs.str(act, "fx_group", "a") == "b")
    }

    private fun showGroup(b: Boolean) {
        Prefs.putStr(act, "fx_group", if (b) "b" else "a")
        groupA.visibility = if (b) View.GONE else View.VISIBLE
        groupB.visibility = if (b) View.VISIBLE else View.GONE
        seg.select(if (b) 1 else 0)
        if (b) { stage.stop(); snd.refresh() }
        hero.invalidate()
    }

    private lateinit var delBtn: FBtn

    // ---------- animations ----------

    private fun renderAnims() {
        animBox.removeAllViews()
        val all = FxStore.all(act)
        animBox.addView(label("Built-in"))
        for (a in all) if (a.builtIn) animBox.addView(animRow(a))
        animBox.addView(label("My animations"))
        var mine = 0
        for (a in all) if (!a.builtIn) { animBox.addView(animRow(a)); mine++ }
        if (mine == 0) {
            val t = tv("Nothing here yet. Tap Create to make your own.", 12.5f, FxC.DIM)
            t.setPadding(0, dp(4f), 0, dp(4f))
            animBox.addView(t)
        }
        val a = cur()
        delBtn.set(if (a != null && a.builtIn) "Reset" else "Delete", if (a != null && a.builtIn) 1 else 2)
        hero.animCount = all.size
        hero.soundCount = TriggerStore.all(act).size
    }

    private fun animRow(a: FxAnim): View {
        val on = a.id == selId
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = softBg(
            if (on) 0x338C7BFF else 0x0FFFFFFF,
            if (on) 0xCC8C7BFF.toInt() else 0x33FFFFFF,
            dp(1f).toFloat(), dp(10f).toFloat()
        )
        r.setPadding(dp(14f), dp(10f), dp(12f), dp(10f))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(6f)
        r.layoutParams = lp
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.addView(tv(a.name, 15f, if (on) 0xFFFFFFFF.toInt() else FxC.TEXT, on))
        c.addView(tv(a.effects.size.toString() + " steps  -  " + secs(a.totalMs()) + (if (a.layers.isNotEmpty()) "  -  " + a.layers.size + " pictures" else ""), 11.5f, FxC.DIM))
        r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        val tag = tv(if (a.builtIn) "BUILT-IN" else "MINE", 9.5f, if (on) FxC.ACCENT else FxC.DIM)
        tag.letterSpacing = 0.12f
        r.addView(tag)
        r.setOnClickListener { select(a.id, true) }
        return r
    }

    private fun select(id: String, play: Boolean) {
        selId = id
        selStep = 0
        Prefs.putStr(act, "fx_sel", id)
        renderAnims()
        stage.anim = cur()
        if (play) stage.play()
    }

    private fun createAnim() {
        FxEditorActivity.open(act, FxStore.newId(), true)
    }

    private fun editAnim() {
        val a = cur() ?: return
        FxEditorActivity.open(act, a.id, false)
    }

    private fun dupAnim() {
        val a = cur() ?: return
        val b = a.copyAs(FxStore.newId(), a.name + " copy")
        FxStore.add(act, b)
        select(b.id, true)
    }

    private fun delAnim() {
        val a = cur() ?: return
        if (a.builtIn) {
            FxStore.reset(act, a.id)
            select(a.id, true)
            toast("Back to how it came")
            return
        }
        AlertDialog.Builder(act).setTitle("Delete \"" + a.name + "\"?")
            .setPositiveButton("Delete") { _, _ ->
                FxStore.remove(act, a.id)
                select(FxStore.all(act).first().id, false)
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- lifecycle ----------

    fun refresh() {
        renderAnims()
        stage.anim = cur()
        ui.removeCallbacks(tick)
        ui.post(tick)
        if (groupB.visibility == View.VISIBLE) snd.refresh()
    }

    fun onResult(code: Int, res: Int, data: Intent?): Boolean {
        if (snd.onResult(code, res, data)) { ui.removeCallbacks(tick); ui.post(tick); return true }
        if (code == FxEditorActivity.REQ) {
            if (res == Activity.RESULT_OK) {
                val id = data?.getStringExtra(FxEditorActivity.EX_ID)
                if (id != null) { selId = id; Prefs.putStr(act, "fx_sel", id) }
                refresh()
                stage.anim = cur()
                stage.play()
            }
            return true
        }
        return false
    }

    fun onPermission(granted: Boolean) { snd.onPermission(granted) }
}

package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import java.io.File
import kotlin.math.max

/** Plays the sound that belongs to an animation: starts where the timeline says, plays only the cut part, then stops. */
object FxAudio {
    private var mp: MediaPlayer? = null
    private val ui = Handler(Looper.getMainLooper())
    private var starter: Runnable? = null
    private var stopper: Runnable? = null

    /** Plays the animation's sound as if the timeline is at fromMs. */
    fun playAnim(a: FxAnim, fromMs: Int = 0) {
        if (a.audio.isEmpty()) return
        val dur = if (a.audioDur > 0) a.audioDur else 600000
        var inMs = a.audioIn
        var d = dur
        var delay = a.audioStart - fromMs
        if (delay < 0) {
            inMs += -delay
            d += delay
            delay = 0
        }
        if (d <= 40) return
        playClip(a.audio, a.volume, inMs, d, delay)
    }

    /** Plays a file from inMs for durMs (0 = to the end), after delayMs. */
    fun playClip(path: String, volume: Int, inMs: Int, durMs: Int, delayMs: Int) {
        if (path.isEmpty() || !File(path).exists()) return
        stop()
        synchronized(this) {
            try {
                val m = MediaPlayer()
                m.setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                )
                m.setDataSource(path)
                val v = (volume / 100f).coerceIn(0f, 1f)
                m.setVolume(v, v)
                m.setOnCompletionListener { x -> try { x.release() } catch (t: Throwable) { }; if (mp === x) mp = null }
                m.setOnErrorListener { x, _, _ -> try { x.release() } catch (t: Throwable) { }; if (mp === x) mp = null; true }
                m.prepare()
                mp = m
                val go = Runnable {
                    if (mp === m) {
                        try {
                            if (inMs > 0) {
                                m.setOnSeekCompleteListener { y -> try { if (mp === y) y.start() } catch (t: Throwable) { } }
                                m.seekTo(inMs)
                            } else {
                                m.start()
                            }
                        } catch (t: Throwable) { }
                    }
                }
                starter = go
                if (delayMs > 0) ui.postDelayed(go, delayMs.toLong()) else go.run()
                if (durMs > 0) {
                    val st = Runnable { if (mp === m) stop() }
                    stopper = st
                    ui.postDelayed(st, (delayMs + durMs).toLong())
                }
            } catch (t: Throwable) { mp = null }
        }
    }

    /** Whole file, for the quick "test" buttons. */
    fun play(path: String, volume: Int) = playClip(path, volume, 0, 0, 0)

    @Synchronized
    fun stop() {
        starter?.let { ui.removeCallbacks(it) }
        stopper?.let { ui.removeCallbacks(it) }
        starter = null
        stopper = null
        val m = mp
        mp = null
        try { m?.stop() } catch (t: Throwable) { }
        try { m?.release() } catch (t: Throwable) { }
    }
}

/** Reads a sound file once to find out how long it is and what its waveform looks like (50 values per second). */
object AudioWave {
    class Info(val durMs: Int, val peaks: FloatArray)

    private val cache = HashMap<String, Info>()
    private val ui = Handler(Looper.getMainLooper())

    fun cached(path: String): Info? = synchronized(cache) { cache[path] }

    fun duration(path: String): Int = try {
        val m = android.media.MediaMetadataRetriever()
        m.setDataSource(path)
        val v = m.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toInt() ?: 0
        m.release()
        v
    } catch (t: Throwable) { 0 }

    fun load(path: String, done: (Info) -> Unit) {
        cached(path)?.let { done(it); return }
        Thread {
            val info = decode(path)
            synchronized(cache) { cache[path] = info }
            ui.post { done(info) }
        }.also { it.isDaemon = true }.start()
    }

    private fun decode(path: String): Info {
        val fallback = duration(path)
        var ex: android.media.MediaExtractor? = null
        var codec: android.media.MediaCodec? = null
        try {
            ex = android.media.MediaExtractor()
            ex.setDataSource(path)
            var idx = -1
            var fmt: android.media.MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(android.media.MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { idx = i; fmt = f; break }
            }
            if (idx < 0 || fmt == null) return Info(fallback, FloatArray(0))
            ex.selectTrack(idx)
            val mime = fmt.getString(android.media.MediaFormat.KEY_MIME) ?: return Info(fallback, FloatArray(0))
            val sr = fmt.getInteger(android.media.MediaFormat.KEY_SAMPLE_RATE)
            val ch = max(1, fmt.getInteger(android.media.MediaFormat.KEY_CHANNEL_COUNT))
            codec = android.media.MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()
            val bucket = max(1, sr / 50)
            val peaks = ArrayList<Float>()
            var curMax = 0
            var inBucket = 0
            var frames = 0L
            val bi = android.media.MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var guard = 0
            while (!outDone && guard < 400000) {
                guard++
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(8000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(bi, 8000)
                if (oi >= 0) {
                    val ob = codec.getOutputBuffer(oi)
                    if (ob != null && bi.size > 0) {
                        ob.position(bi.offset)
                        ob.limit(bi.offset + bi.size)
                        val sb = ob.order(java.nio.ByteOrder.nativeOrder()).asShortBuffer()
                        val cnt = sb.remaining()
                        var j = 0
                        while (j + ch <= cnt) {
                            var v = 0
                            for (q in 0 until ch) v = max(v, kotlin.math.abs(sb.get(j + q).toInt()))
                            if (v > curMax) curMax = v
                            inBucket++
                            frames++
                            if (inBucket >= bucket) { peaks.add(curMax / 32768f); curMax = 0; inBucket = 0 }
                            j += ch
                        }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((bi.flags and android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                }
            }
            var mx = 0.0001f
            for (v in peaks) if (v > mx) mx = v
            val out = FloatArray(peaks.size) { kotlin.math.sqrt(peaks[it] / mx) }
            val dur = if (frames > 0) (frames * 1000L / sr).toInt() else fallback
            return Info(dur, out)
        } catch (t: Throwable) {
            return Info(fallback, FloatArray(0))
        } finally {
            try { codec?.stop() } catch (t: Throwable) { }
            try { codec?.release() } catch (t: Throwable) { }
            try { ex?.release() } catch (t: Throwable) { }
        }
    }
}

/** Full-screen view that plays one animation over everything, then removes itself. */
class FxPlayView(ctx: Context, private val anim: FxAnim) : View(ctx) {
    private val render = FxRender(ctx)
    private var t0 = 0L
    var onDone: (() -> Unit)? = null
    private var done = false

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        t0 = SystemClock.uptimeMillis()
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val el = (SystemClock.uptimeMillis() - t0).toInt()
        if (el > anim.totalMs() + 250) {
            if (!done) { done = true; post { onDone?.invoke() } }
            return
        }
        render.draw(c, width.toFloat(), height.toFloat(), anim, el)
        postInvalidateOnAnimation()
    }
}

/** Shows an animation on top of the game. Needs the "display over other apps" permission Frameline already uses. */
object FxOverlay {
    private val ui = Handler(Looper.getMainLooper())
    private var view: FxPlayView? = null

    fun play(ctx: Context, a: FxAnim) {
        val app = ctx.applicationContext
        ui.post {
            if (!Settings.canDrawOverlays(app)) return@post
            removeNow(app)
            val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = FxPlayView(app, a)
            val l = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            l.gravity = Gravity.TOP or Gravity.START
            l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            v.onDone = { removeNow(app) }
            try {
                wm.addView(v, l)
                view = v
                FxAudio.playAnim(a)
            } catch (t: Throwable) { view = null }
        }
    }

    private fun removeNow(app: Context) {
        FxAudio.stop()
        val v = view ?: return
        view = null
        try { (app.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (t: Throwable) { }
    }
}

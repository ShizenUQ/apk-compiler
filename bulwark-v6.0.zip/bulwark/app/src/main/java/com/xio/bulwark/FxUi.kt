package com.xio.bulwark

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Small building blocks shared by the Triggers tab. */
class FxUi(val act: Activity, private val cards: ArrayList<View>) {
    private val d = act.resources.displayMetrics.density
    fun dp(v: Float) = (v * d).toInt()

    fun tv(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(act)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        t.typeface = Typeface.create("sans-serif-medium", if (bold) Typeface.BOLD else Typeface.NORMAL)
        return t
    }

    fun label(s: String): TextView {
        val t = tv(s, 12f, FxC.DIM)
        t.setPadding(0, dp(12f), 0, dp(4f))
        return t
    }

    fun card(title: String, into: LinearLayout): LinearLayout {
        val c = SoftCard(act)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(14f)
        c.layoutParams = lp
        val t = tv(title.uppercase(), 11.5f, FxC.DIM, true)
        t.letterSpacing = 0.14f
        t.setPadding(0, 0, 0, dp(10f))
        c.addView(t)
        into.addView(c)
        cards.add(c)
        return c
    }

    fun row(title: String, sub: String?, ctl: View): LinearLayout {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(9f), 0, dp(9f))
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.addView(tv(title, 15f, FxC.TEXT))
        if (sub != null) c.addView(tv(sub, 11.5f, FxC.DIM))
        r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(ctl, LinearLayout.LayoutParams(-2, -2))
        return r
    }

    fun toast(s: String) { Toast.makeText(act, s, Toast.LENGTH_SHORT).show() }

    fun ask(title: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(act)
        et.setText(initial)
        et.setSelection(et.text.length)
        et.setSingleLine(true)
        AlertDialog.Builder(act).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> ok(et.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    /** A horizontal row of equal-width buttons. */
    fun buttons(vararg b: View): LinearLayout {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        for ((i, v) in b.withIndex()) {
            val lp = LinearLayout.LayoutParams(0, -2, 1f)
            if (i < b.size - 1) lp.rightMargin = dp(6f)
            r.addView(v, lp)
        }
        return r
    }

    fun top(v: View, dpTop: Float, w: Int = -1, h: Int = -2): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(w, h)
        lp.topMargin = dp(dpTop)
        return lp
    }
}

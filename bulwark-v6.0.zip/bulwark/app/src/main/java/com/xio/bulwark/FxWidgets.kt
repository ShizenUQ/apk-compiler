package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import kotlin.math.max
import kotlin.math.min

/** Colours of the Triggers tab and the animation editor. Soft and flat, on purpose unlike the Live tab. */
object FxC {
    const val ACCENT = 0xFF8C7BFF.toInt()
    const val ACCENT2 = 0xFFFF6B9A.toInt()
    const val TONAL = 0xFF232C3A.toInt()
    const val DANGER = 0xFFFF6F86.toInt()
    const val TEXT = 0xFFF1F4F9.toInt()
    const val MID = 0xFFB4BDC9.toInt()
    const val DIM = 0xFF7F8A99.toInt()
    const val CARD = 0xE8121820.toInt()
    const val LINE = 0x24FFFFFF
    const val PANEL = 0xFF0F141B.toInt()
    const val ROOT = 0xFF0A0D12.toInt()
}

fun softBg(fill: Int, stroke: Int, strokeW: Float, radius: Float): Drawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = radius
    g.setStroke(max(1, strokeW.toInt()), stroke)
    return g
}

/** Rounded button. kind: 0 = main (violet), 1 = quiet, 2 = remove (red text). */
class FBtn(ctx: Context, var text: String, var kind: Int = 0, private val heightDp: Float = 44f) : View(ctx) {
    var onClick: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private var down = false
    private val d = ctx.resources.displayMetrics.density

    init {
        isClickable = true
        setOnClickListener {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onClick?.invoke()
        }
    }

    fun set(t: String, k: Int) {
        text = t
        kind = k
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        p.textSize = (if (heightDp < 40f) 12f else 13.5f) * d
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val want = (p.measureText(text) + 28 * d).toInt()
        val mode = MeasureSpec.getMode(w)
        val size = MeasureSpec.getSize(w)
        val ww = if (mode == MeasureSpec.EXACTLY) size else if (mode == MeasureSpec.AT_MOST) min(size, want) else want
        setMeasuredDimension(ww, (heightDp * d).toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { down = false; invalidate() }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val fill = when (kind) {
            0 -> FxC.ACCENT
            2 -> 0x33FF6F86
            else -> FxC.TONAL
        }
        p.style = Paint.Style.FILL
        p.color = fill
        p.alpha = if (down) 190 else 255
        r.set(0f, 0f, w, h)
        c.drawRoundRect(r, 12 * d, 12 * d, p)
        p.alpha = 255
        var ts = (if (heightDp < 40f) 12f else 13.5f) * d
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = ts
        val tw = p.measureText(text)
        if (tw > w - 10 * d) { ts *= (w - 10 * d) / tw; p.textSize = ts }
        p.textAlign = Paint.Align.CENTER
        p.color = when (kind) { 0 -> 0xFFFFFFFF.toInt(); 2 -> FxC.DANGER; else -> FxC.TEXT }
        c.drawText(text, w / 2f, h / 2f + 5 * d, p)
    }
}

/** Slim slider with a round handle. */
class FSlider(ctx: Context, private val lo: Int, private val hi: Int) : View(ctx) {
    var value = lo
        private set
    var onValue: ((Int) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val d = ctx.resources.displayMetrics.density

    fun setValue(v: Int) {
        value = v.coerceIn(lo, hi)
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (34 * d).toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            val pad = 12 * d
            val f = ((e.x - pad) / max(1f, width - 2 * pad)).coerceIn(0f, 1f)
            val v = lo + (f * (hi - lo)).toInt().let { q -> if (f * (hi - lo) - q >= 0.5f) q + 1 else q }
            if (v != value) { value = v; onValue?.invoke(v); invalidate() }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = 12 * d
        val f = (value - lo).toFloat() / max(1, hi - lo)
        val x = pad + f * (w - 2 * pad)
        p.style = Paint.Style.FILL
        p.color = 0x33FFFFFF
        r.set(pad, h / 2f - 2 * d, w - pad, h / 2f + 2 * d)
        c.drawRoundRect(r, 2 * d, 2 * d, p)
        p.color = FxC.ACCENT
        r.set(pad, h / 2f - 2 * d, x, h / 2f + 2 * d)
        c.drawRoundRect(r, 2 * d, 2 * d, p)
        p.color = 0x338C7BFF
        c.drawCircle(x, h / 2f, 12 * d, p)
        p.color = 0xFFFFFFFF.toInt()
        c.drawCircle(x, h / 2f, 8 * d, p)
    }
}

/** On/off switch. */
class FSwitch(ctx: Context) : View(ctx) {
    var onChange: ((Boolean) -> Unit)? = null
    private var on = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val d = ctx.resources.displayMetrics.density

    init {
        isClickable = true
        setOnClickListener {
            on = !on
            invalidate()
            onChange?.invoke(on)
        }
    }

    fun setChecked(v: Boolean) { on = v; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((50 * d).toInt(), (30 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = if (on) FxC.ACCENT else 0x44FFFFFF
        r.set(0f, 2 * d, w, h - 2 * d)
        c.drawRoundRect(r, (h - 4 * d) / 2f, (h - 4 * d) / 2f, p)
        p.color = 0xFFFFFFFF.toInt()
        val cx = if (on) w - h / 2f else h / 2f
        c.drawCircle(cx, h / 2f, h / 2f - 5 * d, p)
    }
}

/** Two or three choices in one pill. */
class Seg(ctx: Context, private val labels: List<String>, private val heightDp: Float = 46f) : View(ctx) {
    var onSelect: ((Int) -> Unit)? = null
    private var sel = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val d = ctx.resources.displayMetrics.density

    fun select(i: Int) { sel = i; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (heightDp * d).toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val i = (e.x / (width.toFloat() / labels.size)).toInt().coerceIn(0, labels.size - 1)
            if (i != sel) {
                sel = i
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                invalidate()
                onSelect?.invoke(i)
            }
            performClick()
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = 0xCC0E131A.toInt()
        r.set(0f, 0f, w, h)
        c.drawRoundRect(r, h / 2f, h / 2f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = FxC.LINE
        r.set(0.5f * d, 0.5f * d, w - 0.5f * d, h - 0.5f * d)
        c.drawRoundRect(r, h / 2f, h / 2f, p)
        val cw = w / labels.size
        p.style = Paint.Style.FILL
        p.color = FxC.ACCENT
        r.set(sel * cw + 4 * d, 4 * d, (sel + 1) * cw - 4 * d, h - 4 * d)
        c.drawRoundRect(r, (h - 8 * d) / 2f, (h - 8 * d) / 2f, p)
        p.textSize = (if (heightDp < 40f) 12.5f else 14.5f) * d
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textAlign = Paint.Align.CENTER
        for ((i, s) in labels.withIndex()) {
            p.color = if (i == sel) 0xFFFFFFFF.toInt() else FxC.MID
            c.drawText(s, cw * i + cw / 2f, h / 2f + 5 * d, p)
        }
    }
}

/** A card with a small title, used on the Triggers tab. */
class SoftCard(ctx: Context) : LinearLayout(ctx) {
    init {
        orientation = VERTICAL
        val d = ctx.resources.displayMetrics.density
        background = softBg(FxC.CARD, FxC.LINE, 1f * d, 20 * d)
        setPadding((18 * d).toInt(), (16 * d).toInt(), (18 * d).toInt(), (18 * d).toInt())
    }
}

/** Wrapping grid of small choices (used for motions and enter / exit). */
class ChipGrid(ctx: Context, names: List<String>, private val cols: Int, private val get: () -> Int, private val put: (Int) -> Unit) : LinearLayout(ctx) {
    private val chips = ArrayList<FBtn>()

    init {
        orientation = VERTICAL
        val d = ctx.resources.displayMetrics.density
        var row: LinearLayout? = null
        for ((i, n) in names.withIndex()) {
            if (i % cols == 0) {
                row = LinearLayout(ctx)
                row.orientation = HORIZONTAL
                val lp = LayoutParams(-1, -2)
                lp.topMargin = (6 * d).toInt()
                addView(row, lp)
            }
            val b = FBtn(ctx, n, 1, 36f)
            b.onClick = { put(i); paint() }
            chips.add(b)
            val lp = LayoutParams(0, -2, 1f)
            lp.rightMargin = (6 * d).toInt()
            row!!.addView(b, lp)
            if (i == names.size - 1) {
                var k = i + 1
                while (k % cols != 0) {
                    val sp = View(ctx)
                    row.addView(sp, LayoutParams(0, 1, 1f))
                    k++
                }
            }
        }
        paint()
    }

    private fun paint() {
        for ((i, b) in chips.withIndex()) b.set(b.text, if (get() == i) 0 else 1)
    }
}

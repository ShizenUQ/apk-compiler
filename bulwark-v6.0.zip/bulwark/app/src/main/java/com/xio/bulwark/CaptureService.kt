package com.xio.bulwark

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

/** What the listener hears right now. The Triggers tab reads this to draw its meter. */
object CaptureBus {
    @Volatile var running = false
    @Volatile var mode = 0            // 1 = game audio, 2 = microphone
    @Volatile var level = 0f          // 0..1, smoothed, from -60 dB to 0 dB
    @Volatile var peak = 0f           // highest level since start
    @Volatile var lastLoudMs = 0L     // uptime when something audible was last heard
    @Volatile var startedMs = 0L
    @Volatile var error = ""
    /** How many ms of sound the 40 s buffer holds right now. */
    @Volatile var bufferedMs = 0
    /** Raw audio (16-bit mono, 44100 Hz) for the sound matching in a later update. */
    @Volatile var sink: ((ShortArray, Int) -> Unit)? = null
}

/** Listens to the audio other apps play (or the microphone) while the app is in the background. */
class CaptureService : Service() {
    companion object {
        const val ACT_START = "com.xio.bulwark.CAPTURE_START"
        const val ACT_STOP = "com.xio.bulwark.CAPTURE_STOP"
        const val ACT_SAVE = "com.xio.bulwark.CAPTURE_SAVE"
        const val KEEP_SECONDS = 40
        const val EX_MODE = "mode"
        const val EX_CODE = "code"
        const val EX_DATA = "data"
        private const val CHANNEL = "capture"
        private const val NOTIF_ID = 7711
        private const val RATE = 44100

        fun stop(c: Context) {
            c.startService(Intent(c, CaptureService::class.java).setAction(ACT_STOP))
        }

        fun save(c: Context) {
            c.startService(Intent(c, CaptureService::class.java).setAction(ACT_SAVE))
        }
    }

    @Volatile private var run = false
    private var worker: Thread? = null
    private var proj: MediaProjection? = null
    private var rec: AudioRecord? = null
    private val ui = Handler(Looper.getMainLooper())
    private val ring = ShortArray(RATE * KEEP_SECONDS)
    private var ringPos = 0
    private var ringFill = 0
    private val ringLock = Any()
    private var matcher: Matcher? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null || i.action == ACT_STOP) {
            halt()
            return START_NOT_STICKY
        }
        if (i.action == ACT_SAVE) {
            saveClip()
            return START_NOT_STICKY
        }
        val mode = i.getIntExtra(EX_MODE, 1)
        goForeground(mode)
        releaseAudio()
        CaptureBus.error = ""
        try {
            if (mode == 1) {
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(EX_DATA, Intent::class.java)
                else @Suppress("DEPRECATION") i.getParcelableExtra(EX_DATA)
                startPlayback(i.getIntExtra(EX_CODE, 0), data)
            } else {
                startMic()
            }
        } catch (t: Throwable) {
            CaptureBus.error = t.message ?: t.toString()
            halt()
        }
        return START_NOT_STICKY
    }

    private fun goForeground(mode: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Sound listening", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(
            this, 9, Intent(this, CaptureService::class.java).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val saveIntent = PendingIntent.getService(
            this, 10, Intent(this, CaptureService::class.java).setAction(ACT_SAVE), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Frameline is listening")
            .setContentText(if (mode == 1) "Listening to game audio" else "Listening with the microphone")
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_stat), "Save clip", saveIntent
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_stat), "Stop", stopIntent
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            val type = if (mode == 1) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(NOTIF_ID, n, type)
        } else if (Build.VERSION.SDK_INT >= 29 && mode == 1) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun startPlayback(code: Int, data: Intent?) {
        if (Build.VERSION.SDK_INT < 29) throw IllegalStateException("Game audio capture needs Android 10 or newer")
        if (data == null) throw IllegalStateException("No permission from the system prompt")
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { halt() }
        }, null)
        proj = mp
        val cfg = AudioPlaybackCaptureConfiguration.Builder(mp)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .excludeUid(android.os.Process.myUid())
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord.Builder()
            .setAudioFormat(fmt)
            .setBufferSizeInBytes(max(min, 8192) * 2)
            .setAudioPlaybackCaptureConfig(cfg)
            .build()
        begin(r, 1)
    }

    @Suppress("MissingPermission")
    private fun startMic() {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(
            MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, max(min, 8192) * 2
        )
        begin(r, 2)
    }

    private fun begin(r: AudioRecord, mode: Int) {
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            throw IllegalStateException("The audio input could not start")
        }
        rec = r
        synchronized(ringLock) { ringPos = 0; ringFill = 0 }
        CaptureBus.bufferedMs = 0
        val m = Matcher(this)
        matcher = m
        MatchBus.onFire = { t, score ->
            val a = FxStore.get(this, t.animId)
            if (a != null) FxOverlay.play(this, a)
        }
        r.startRecording()
        CaptureBus.running = true
        CaptureBus.mode = mode
        CaptureBus.level = 0f
        CaptureBus.peak = 0f
        CaptureBus.lastLoudMs = 0L
        CaptureBus.startedMs = SystemClock.uptimeMillis()
        run = true
        val t = Thread {
            val buf = ShortArray(2048)
            var sm = 0f
            while (run) {
                val n = try { r.read(buf, 0, buf.size) } catch (e: Throwable) { -1 }
                if (n <= 0) {
                    if (n < 0) break
                    continue
                }
                var sum = 0.0
                for (k in 0 until n) { val v = buf[k] / 32768.0; sum += v * v }
                val rms = sqrt(sum / n).toFloat()
                val db = 20f * log10(rms + 1e-6f)
                val lv = ((db + 60f) / 60f).coerceIn(0f, 1f)
                sm = if (lv > sm) lv else sm * 0.88f + lv * 0.12f
                CaptureBus.level = sm
                if (sm > CaptureBus.peak) CaptureBus.peak = sm
                if (lv > 0.18f) CaptureBus.lastLoudMs = SystemClock.uptimeMillis()
                ringWrite(buf, n)
                m.feed(buf, n)
                CaptureBus.sink?.invoke(buf, n)
            }
        }
        t.isDaemon = true
        worker = t
        t.start()
    }

    private fun ringWrite(buf: ShortArray, n: Int) {
        synchronized(ringLock) {
            var i = 0
            while (i < n) {
                val k = minOf(n - i, ring.size - ringPos)
                System.arraycopy(buf, i, ring, ringPos, k)
                ringPos = (ringPos + k) % ring.size
                i += k
            }
            ringFill = minOf(ring.size, ringFill + n)
            CaptureBus.bufferedMs = (ringFill.toLong() * 1000L / RATE).toInt()
        }
    }

    private fun toast(s: String) { ui.post { Toast.makeText(applicationContext, s, Toast.LENGTH_LONG).show() } }

    private fun saveClip() {
        if (!CaptureBus.running) { toast("Frameline is not listening"); return }
        var n = 0
        var out = ShortArray(0)
        synchronized(ringLock) {
            n = ringFill
            out = ShortArray(n)
            val start = ((ringPos - n) % ring.size + ring.size) % ring.size
            val first = minOf(n, ring.size - start)
            System.arraycopy(ring, start, out, 0, first)
            if (n > first) System.arraycopy(ring, 0, out, first, n - first)
        }
        if (n < RATE) { toast("Not enough sound yet"); return }
        try {
            Wav.write(Recordings.newFile(this), out, n)
            toast("Saved the last " + (n / RATE) + " s. Open Triggers > Sounds in Frameline to trim it.")
        } catch (t: Throwable) {
            toast("Could not save: " + (t.message ?: t.toString()))
        }
    }

    private fun releaseAudio() {
        run = false
        try { worker?.join(400) } catch (t: Throwable) { }
        worker = null
        try { rec?.stop() } catch (t: Throwable) { }
        try { rec?.release() } catch (t: Throwable) { }
        rec = null
        try { proj?.stop() } catch (t: Throwable) { }
        proj = null
    }

    private fun halt() {
        MatchBus.onFire = null
        matcher = null
        releaseAudio()
        CaptureBus.running = false
        CaptureBus.level = 0f
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (t: Throwable) { }
        stopSelf()
    }

    override fun onDestroy() {
        releaseAudio()
        CaptureBus.running = false
        super.onDestroy()
    }
}

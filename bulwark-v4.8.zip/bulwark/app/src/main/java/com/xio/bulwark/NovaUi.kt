package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Frameline's own letter shapes: every character is a few straight neon strokes with chamfered corners, drawn by
 * hand in code (no font file). Capitals only, which suits a HUD. A letter is 4 units wide and 6 tall.
 */
object VFont {
    private class G(val w: Float, val strokes: List<FloatArray>)

    private val g = HashMap<Char, G>()
    private val path = Path()

    private fun f(vararg v: Number) = FloatArray(v.size) { v[it].toFloat() }
    private fun def(ch: Char, w: Number, vararg st: FloatArray) { g[ch] = G(w.toFloat(), st.toList()) }

    init {
        def('A', 4, f(0, 6, 0, 2, 1, 0, 3, 0, 4, 2, 4, 6), f(0, 3.4, 4, 3.4))
        def('B', 4, f(0, 6, 0, 0, 3, 0, 4, 1, 4, 2, 3, 3, 0, 3), f(3, 3, 4, 4, 4, 5, 3, 6, 0, 6))
        def('C', 4, f(4, 1, 3, 0, 1, 0, 0, 1, 0, 5, 1, 6, 3, 6, 4, 5))
        def('D', 4, f(0, 0, 0, 6, 2, 6, 4, 4, 4, 2, 2, 0, 0, 0))
        def('E', 4, f(4, 0, 0, 0, 0, 6, 4, 6), f(0, 3, 3, 3))
        def('F', 4, f(4, 0, 0, 0, 0, 6), f(0, 3, 3, 3))
        def('G', 4, f(4, 1, 3, 0, 1, 0, 0, 1, 0, 5, 1, 6, 3, 6, 4, 5, 4, 3, 2, 3))
        def('H', 4, f(0, 0, 0, 6), f(4, 0, 4, 6), f(0, 3, 4, 3))
        def('I', 2, f(0, 0, 2, 0), f(1, 0, 1, 6), f(0, 6, 2, 6))
        def('J', 4, f(4, 0, 4, 5, 3, 6, 1, 6, 0, 5))
        def('K', 4, f(0, 0, 0, 6), f(4, 0, 0, 3, 4, 6))
        def('L', 4, f(0, 0, 0, 6, 4, 6))
        def('M', 4, f(0, 6, 0, 0, 2, 3, 4, 0, 4, 6))
        def('N', 4, f(0, 6, 0, 0, 4, 6, 4, 0))
        def('O', 4, f(1, 0, 3, 0, 4, 1, 4, 5, 3, 6, 1, 6, 0, 5, 0, 1, 1, 0))
        def('P', 4, f(0, 6, 0, 0, 3, 0, 4, 1, 4, 2, 3, 3, 0, 3))
        def('Q', 4, f(1, 0, 3, 0, 4, 1, 4, 5, 3, 6, 1, 6, 0, 5, 0, 1, 1, 0), f(2, 4, 4, 6.4))
        def('R', 4, f(0, 6, 0, 0, 3, 0, 4, 1, 4, 2, 3, 3, 0, 3), f(2, 3, 4, 6))
        def('S', 4, f(4, 1, 3, 0, 1, 0, 0, 1, 0, 2, 1, 3, 3, 3, 4, 4, 4, 5, 3, 6, 1, 6, 0, 5))
        def('T', 4, f(0, 0, 4, 0), f(2, 0, 2, 6))
        def('U', 4, f(0, 0, 0, 5, 1, 6, 3, 6, 4, 5, 4, 0))
        def('V', 4, f(0, 0, 2, 6, 4, 0))
        def('W', 4, f(0, 0, 1, 6, 2, 3, 3, 6, 4, 0))
        def('X', 4, f(0, 0, 4, 6), f(4, 0, 0, 6))
        def('Y', 4, f(0, 0, 2, 3, 4, 0), f(2, 3, 2, 6))
        def('Z', 4, f(0, 0, 4, 0, 0, 6, 4, 6))
        def('0', 4, f(1, 0, 3, 0, 4, 1, 4, 5, 3, 6, 1, 6, 0, 5, 0, 1, 1, 0), f(1, 5, 3, 1))
        def('1', 3, f(0, 1.5, 2, 0, 2, 6), f(0.5, 6, 3.5, 6))
        def('2', 4, f(0, 1, 1, 0, 3, 0, 4, 1, 4, 2, 0, 6, 4, 6))
        def('3', 4, f(0, 0, 4, 0, 4, 2, 2, 3, 4, 4, 4, 6, 0, 6))
        def('4', 4, f(3, 6, 3, 0, 0, 4, 4, 4))
        def('5', 4, f(4, 0, 0, 0, 0, 3, 3, 3, 4, 4, 4, 5, 3, 6, 0, 6))
        def('6', 4, f(4, 0, 1, 0, 0, 1, 0, 5, 1, 6, 3, 6, 4, 5, 4, 4, 3, 3, 0, 3))
        def('7', 4, f(0, 0, 4, 0, 1, 6))
        def('8', 4, f(1, 0, 3, 0, 4, 1, 4, 2, 3, 3, 1, 3, 0, 4, 0, 5, 1, 6, 3, 6, 4, 5, 4, 4, 3, 3), f(1, 3, 0, 2, 0, 1, 1, 0))
        def('9', 4, f(0, 6, 3, 6, 4, 5, 4, 1, 3, 0, 1, 0, 0, 1, 0, 2, 1, 3, 4, 3))
        def('.', 1, f(0.5, 5.7, 0.5, 6))
        def(',', 1, f(0.5, 5.2, 0.2, 6.8))
        def('!', 1, f(0.5, 0, 0.5, 4), f(0.5, 5.7, 0.5, 6))
        def('?', 4, f(0, 1, 1, 0, 3, 0, 4, 1, 4, 2, 2, 3, 2, 4), f(2, 5.7, 2, 6))
        def('\'', 1, f(0.5, 0, 0.5, 2))
        def(':', 1, f(0.5, 1.7, 0.5, 2), f(0.5, 5.7, 0.5, 6))
        def('-', 3, f(0, 3, 3, 3))
        def('+', 4, f(0, 3, 4, 3), f(2, 1, 2, 5))
        def('%', 4, f(4, 0, 0, 6), f(0.5, 0.3, 0.5, 1.3), f(3.5, 4.7, 3.5, 5.7))
        def('/', 4, f(4, 0, 0, 6))
        def('>', 4, f(0, 0, 4, 3, 0, 6))
        def('*', 4, f(2, 0, 2, 6), f(0, 3, 4, 3), f(0.5, 0.8, 3.5, 5.2), f(3.5, 0.8, 0.5, 5.2))
        def('★', 4, f(2, 0, 2, 6), f(0, 3, 4, 3), f(0.5, 0.8, 3.5, 5.2), f(3.5, 0.8, 0.5, 5.2))
        def('°', 2, f(0, 0, 2, 0, 2, 2, 0, 2, 0, 0))
    }

    private const val GAP = 1.7f

    private fun adv(ch: Char, s: Float): Float {
        if (ch == ' ') return 3f * s
        val gl = g[ch] ?: return 0f
        return (gl.w + GAP) * s
    }

    fun width(text: String, h: Float): Float {
        val s = h / 6f
        var w = 0f
        for (ch in text) w += adv(ch.uppercaseChar(), s)
        return max(0f, w - GAP * s)
    }

    fun fit(text: String, h: Float, maxW: Float): String {
        var t = text
        while (t.length > 1 && width(t, h) > maxW) t = t.substring(0, t.length - 1)
        return t
    }

    fun wrap(text: String, h: Float, maxW: Float): List<String> {
        val out = ArrayList<String>()
        var line = ""
        for (word in text.split(' ')) {
            if (word.isEmpty()) continue
            val tryLine = if (line.isEmpty()) word else "$line $word"
            if (width(tryLine, h) <= maxW) { line = tryLine; continue }
            if (line.isNotEmpty()) out.add(line)
            line = word
            while (width(line, h) > maxW && line.length > 1) {
                var cut = line.length - 1
                while (cut > 1 && width(line.substring(0, cut), h) > maxW) cut--
                out.add(line.substring(0, cut))
                line = line.substring(cut)
            }
        }
        if (line.isNotEmpty()) out.add(line)
        return out
    }

    /** Draws [count] letters of [text] with its top-left at (x, y). Returns where the next letter would start. */
    fun draw(c: Canvas, p: Paint, text: String, x: Float, y: Float, h: Float, color: Int, glow: Boolean = true, count: Int = Int.MAX_VALUE): Float {
        val s = h / 6f
        var cx = x
        path.reset()
        val n = min(count, text.length)
        for (i in 0 until n) {
            val ch = text[i].uppercaseChar()
            val gl = g[ch]
            if (gl != null) {
                for (st in gl.strokes) {
                    path.moveTo(cx + st[0] * s, y + st[1] * s)
                    var k = 2
                    while (k < st.size) { path.lineTo(cx + st[k] * s, y + st[k + 1] * s); k += 2 }
                }
            }
            cx += adv(ch, s)
        }
        val oldStyle = p.style
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        if (glow) {
            p.strokeWidth = max(2f, h * 0.36f)
            p.color = Cy.a(color, 0.2f)
            c.drawPath(path, p)
        }
        p.strokeWidth = max(1f, h * 0.15f)
        p.color = color
        c.drawPath(path, p)
        p.style = oldStyle
        return cx
    }
}

/** The shared "floating screen" look: a dark glass panel with chamfered corners, a thin glowing edge and faint scan lines. */
object Glass {
    private val grad = Paint(Paint.ANTI_ALIAS_FLAG)

    fun panel(c: Canvas, p: Paint, r: RectF, d: Float, accent: Int, now: Long) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = 0xC4090E15.toInt()
        CyUi.drawCut(c, p, r, 9 * d)
        grad.style = Paint.Style.FILL
        grad.shader = LinearGradient(0f, r.top, 0f, r.bottom, Cy.a(accent, 0.16f), 0x00000000, Shader.TileMode.CLAMP)
        CyUi.drawCut(c, grad, r, 9 * d)
        grad.shader = null
        // scan lines + a slow sheen
        c.save()
        c.clipRect(r)
        p.color = 0x0AFFFFFF
        var y = r.top + 2 * d
        while (y < r.bottom) { c.drawRect(r.left, y, r.right, y + 0.8f * d, p); y += 3.2f * d }
        val sx = r.left - 30 * d + ((now % 4200L) / 4200f) * (r.width() + 60 * d)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 12 * d
        p.color = 0x0AFFFFFF
        c.drawLine(sx, r.bottom, sx + 18 * d, r.top, p)
        c.restore()
        // edge
        val pulse = 0.5f + 0.5f * sin(now / 380f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3.4f * d
        p.color = Cy.a(accent, 0.10f + 0.08f * pulse)
        CyUi.drawCut(c, p, r, 9 * d)
        p.strokeWidth = 1f * d
        p.color = Cy.a(accent, 0.65f)
        CyUi.drawCut(c, p, r, 9 * d)
        // corner brackets
        p.strokeWidth = 1.8f * d
        p.strokeCap = Paint.Cap.ROUND
        p.color = Cy.PINK
        c.drawLine(r.left + 1.5f * d, r.top + 15 * d, r.left + 1.5f * d, r.top + 3 * d, p)
        c.drawLine(r.left + 1.5f * d, r.top + 3 * d, r.left + 13 * d, r.top + 3 * d, p)
        p.color = Cy.a(accent, 0.9f)
        c.drawLine(r.right - 2 * d, r.bottom - 12 * d, r.right - 2 * d, r.bottom - 2 * d, p)
        c.drawLine(r.right - 2 * d, r.bottom - 2 * d, r.right - 12 * d, r.bottom - 2 * d, p)
    }

    /** The small arrow on the edge of a panel that tells where the status overlay is. */
    fun pointer(c: Canvas, p: Paint, path: Path, side: Int, w: Float, h: Float, card: RectF, q: Float, d: Float, accent: Int, now: Long) {
        val pulse = 0.5f + 0.5f * sin(now / 260f)
        p.style = Paint.Style.FILL
        p.color = Cy.a(accent, 0.6f + 0.4f * pulse)
        path.reset()
        val a = 5 * d
        when (side) {
            0 -> { path.moveTo(q - a, card.top + d); path.lineTo(q, 0f); path.lineTo(q + a, card.top + d) }
            1 -> { path.moveTo(q - a, card.bottom - d); path.lineTo(q, h); path.lineTo(q + a, card.bottom - d) }
            2 -> { path.moveTo(card.left + d, q - a); path.lineTo(0f, q); path.lineTo(card.left + d, q + a) }
            3 -> { path.moveTo(card.right - d, q - a); path.lineTo(w, q); path.lineTo(card.right - d, q + a) }
            else -> return
        }
        path.close()
        c.drawPath(path, p)
    }
}

/** Nova's speech bubble: a small floating screen that types its line in Frameline's own letters. */
class NovaView(ctx: Context) : View(ctx) {
    var onTyped: (() -> Unit)? = null
    var onExpire: (() -> Unit)? = null
    var onActionDone: (() -> Unit)? = null

    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val path = Path()
    private var talk: NovaTalk? = null
    private var lines: List<String> = emptyList()
    private var typedAt = 0L
    private var doneAt = 0L
    private var firedTyped = false
    private var expired = false
    private var running = false

    var compact = false
        set(v) { field = v; relayout() }
    var side = 0           // where the status overlay is: 0 above this bubble, 1 below, 2 left, 3 right
        set(v) { field = v; relayout() }
    var ptr = 0f           // where along that edge the pointer sits (px)

    private val m get() = 4 * d
    private val pt get() = 6 * d
    private val cardW get() = (if (compact) 170 else 200) * d
    private val gh get() = (if (compact) 8f else 9f) * d      // letter height
    private val charMs = 26L

    private var actKind = ""
    private var actSteps: List<String> = emptyList()
    private var actAt = 0L
    private var actDone = false
    private val stepMs = 620L

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    fun say(t: NovaTalk) {
        talk = t
        actKind = ""
        typedAt = System.currentTimeMillis()
        doneAt = 0L
        firedTyped = false
        expired = false
        relayout()
    }

    fun startAction(kind: String, steps: List<String>) {
        actKind = kind
        actSteps = steps
        actAt = System.currentTimeMillis()
        actDone = false
    }

    private fun relayout() {
        val t = talk
        lines = if (t == null) emptyList() else VFont.wrap(t.text, gh, cardW - 20 * d)
        invalidate()
    }

    /** Window size in px for a given side. */
    fun measure(s: Int): IntArray {
        val w = (cardW + 2 * m + (if (s >= 2) pt else 0f)).toInt()
        val extra = 2 * m + (if (s < 2) pt else 0f)
        if (actKind.isNotEmpty()) return intArrayOf(w, (58 * d + extra).toInt())
        val n = max(1, lines.size)
        val h = 9 * d + 6 * d + 7 * d + n * (gh + 5 * d) - 5 * d + 10 * d + extra
        return intArrayOf(w, h.toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = System.currentTimeMillis()
        val bob = sin(now / 600f) * 1.1f * d
        val l = m + (if (side == 2) pt else 0f)
        val r = w - m - (if (side == 3) pt else 0f)
        val t = m + (if (side == 0) pt else 0f)
        val b = h - m - (if (side == 1) pt else 0f)

        c.save()
        c.translate(0f, bob)
        rr.set(l, t, r, b)
        Glass.panel(c, p, rr, d, Neon.CYAN, now)
        if (actKind.isNotEmpty()) drawAction(c, l, r, t, b, now) else drawTalk(c, l, t, now)
        c.restore()
        val q = ptr.coerceIn(16 * d, (if (side < 2) w else h) - 16 * d)
        rr.set(l, t, r, b)
        Glass.pointer(c, p, path, side, w, h, rr, q, d, Neon.CYAN, now)
    }

    private fun drawTalk(c: Canvas, l: Float, t: Float, now: Long) {
        val tk = talk ?: return
        // name tag
        p.style = Paint.Style.FILL
        p.color = Neon.CYAN
        path.reset()
        val dx = l + 12 * d
        val dy = t + 10.5f * d
        path.moveTo(dx, dy - 3 * d); path.lineTo(dx + 3 * d, dy); path.lineTo(dx, dy + 3 * d); path.lineTo(dx - 3 * d, dy); path.close()
        c.drawPath(path, p)
        VFont.draw(c, p, "NOVA", l + 20 * d, t + 7.5f * d, 5.5f * d, Cy.a(Neon.CYAN, 0.95f), true)

        var left = ((now - typedAt) / charMs).toInt()
        val total = tk.text.length
        var y = t + 22 * d
        var endX = l + 10 * d
        var endY = y
        for (ln in lines) {
            if (left <= 0) break
            val n = min(left, ln.length)
            endX = VFont.draw(c, p, ln, l + 10 * d, y, gh, 0xFFEAF6FF.toInt(), true, n)
            endY = y
            left -= ln.length + 1
            y += gh + 5 * d
        }
        val typedAll = ((now - typedAt) / charMs).toInt() >= total
        if (!typedAll) {
            if ((now / 260) % 2 == 0L) {
                p.style = Paint.Style.FILL
                p.color = Neon.CYAN
                c.drawRect(endX + 1 * d, endY, endX + 4 * d, endY + gh, p)
            }
        } else {
            if (doneAt == 0L) doneAt = now
            if (!firedTyped) { firedTyped = true; post { onTyped?.invoke() } }
            if (!expired) {
                val hold = if (tk.chips.isEmpty()) tk.holdMs else (if (tk.holdMs < 20_000L) 20_000L else tk.holdMs)
                if (now - doneAt > hold) { expired = true; post { onExpire?.invoke() } }
            }
        }
    }

    private fun drawAction(c: Canvas, l: Float, r: Float, t: Float, b: Float, now: Long) {
        val el = now - actAt
        val n = max(1, actSteps.size)
        val total = n * stepMs + 450L
        val prog = (el.toFloat() / total).coerceIn(0f, 1f)
        val step = min(n - 1, (el / stepMs).toInt())
        val midY = (t + b) / 2f
        // record
        val cx = l + 28 * d
        val R = 17 * d
        p.style = Paint.Style.FILL
        p.color = 0xFF05080C.toInt()
        c.drawCircle(cx, midY, R, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = Cy.a(Neon.CYAN, 0.25f)
        c.drawCircle(cx, midY, R * 0.82f, p)
        c.drawCircle(cx, midY, R * 0.64f, p)
        val ang = now / 5f
        rr.set(cx - R, midY - R, cx + R, midY + R)
        p.strokeWidth = 2.2f * d
        p.strokeCap = Paint.Cap.ROUND
        p.color = Cy.a(Neon.CYAN, 0.9f)
        c.drawArc(rr, ang, 50f, false, p)
        p.color = Cy.a(Cy.PINK, 0.9f)
        c.drawArc(rr, ang + 180f, 50f, false, p)
        p.style = Paint.Style.FILL
        p.color = Cy.PINK
        c.drawCircle(cx, midY, 4.5f * d, p)
        p.color = 0xFF05080C.toInt()
        c.drawCircle(cx, midY, 1.4f * d, p)
        // text + equalizer
        val tx = l + 54 * d
        val maxW = r - tx - 10 * d
        VFont.draw(c, p, "NOVA", tx, t + 8 * d, 5.5f * d, Cy.a(Neon.CYAN, 0.95f), true)
        val label = VFont.fit(actSteps[step], 7.5f * d, maxW - 24 * d)
        VFont.draw(c, p, label, tx, t + 17 * d, 7.5f * d, 0xFFFFFFFF.toInt(), true)
        VFont.draw(c, p, (step + 1).toString() + "/" + n, r - 10 * d - VFont.width("1/1", 5.5f * d), t + 8 * d, 5.5f * d, 0xFF9AA7B4.toInt(), false)
        val bars = 11
        val bw = (maxW - (bars - 1) * 2 * d) / bars
        p.style = Paint.Style.FILL
        for (i in 0 until bars) {
            val k = 0.5f + 0.5f * sin(now / 130f + i * 0.9f)
            val bh = (3 + 13 * k) * d * (0.3f + 0.7f * prog)
            p.color = Cy.a(if (i % 3 == 0) Cy.PINK else Neon.CYAN, 0.9f)
            val bx = tx + i * (bw + 2 * d)
            c.drawRect(bx, b - 9 * d - bh, bx + bw, b - 9 * d, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * d
        p.color = Cy.a(Neon.CYAN, 0.2f)
        c.drawLine(tx, b - 6 * d, tx + maxW, b - 6 * d, p)
        p.color = Neon.GREEN
        c.drawLine(tx, b - 6 * d, tx + maxW * prog, b - 6 * d, p)
        if (prog >= 1f && !actDone) { actDone = true; post { onActionDone?.invoke() } }
    }
}

/** The tappable replies, as small separate floating pills under (or above) the bubble. */
class NovaChipsView(ctx: Context) : View(ctx) {
    var onChip: ((String) -> Unit)? = null
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private var items: List<NovaChip> = emptyList()
    private var rects: List<RectF> = emptyList()
    private var maxW = 0f
    private var t0 = System.currentTimeMillis()
    private var pressed = -1
    private var running = false
    private val ch = 22 * d
    private val th = 7f * d

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    fun setItems(list: List<NovaChip>, maxWidthPx: Float) {
        items = list
        maxW = maxWidthPx
        t0 = System.currentTimeMillis()
        pressed = -1
        layoutRects()
        invalidate()
    }

    private fun pillW(i: Int) = VFont.width(items[i].label, th) + 18 * d

    private fun layoutRects() {
        val out = ArrayList<RectF>()
        var x = 4 * d
        var y = 4 * d
        for (i in items.indices) {
            val w = pillW(i)
            if (x > 4 * d && x + w > maxW - 4 * d) { x = 4 * d; y += ch + 5 * d }
            out.add(RectF(x, y, x + w, y + ch))
            x += w + 6 * d
        }
        rects = out
    }

    fun measure(): IntArray {
        val rows = if (rects.isEmpty()) 1 else ((rects.last().top - 4 * d) / (ch + 5 * d)).toInt() + 1
        return intArrayOf(maxW.toInt(), (rows * ch + (rows - 1) * 5 * d + 10 * d).toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { pressed = hit(e.x, e.y); invalidate() }
            MotionEvent.ACTION_UP -> {
                val h = hit(e.x, e.y)
                pressed = -1
                invalidate()
                if (h >= 0) onChip?.invoke(items[h].id)
            }
            MotionEvent.ACTION_CANCEL -> { pressed = -1; invalidate() }
        }
        return true
    }

    private fun hit(x: Float, y: Float): Int {
        for (i in rects.indices) if (rects[i].contains(x, y)) return i
        return -1
    }

    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis()
        for (i in items.indices) {
            val k = ((now - t0 - i * 90L) / 260f).coerceIn(0f, 1f)
            if (k <= 0f) continue
            val r0 = rects.getOrNull(i) ?: continue
            val bob = sin(now / 500f + i * 1.4f) * 1f * d
            val off = (1f - k) * 8 * d
            rr.set(r0.left, r0.top + bob + off, r0.right, r0.bottom + bob + off)
            val quiet = items[i].id == "bye"
            val col = if (quiet) 0xFF9AA7B4.toInt() else Neon.CYAN
            p.style = Paint.Style.FILL
            p.color = Cy.a(0xFF090E15.toInt(), 0.8f * k)
            CyUi.drawCut(c, p, rr, 6 * d)
            p.color = Cy.a(col, (if (pressed == i) 0.35f else 0.10f) * k)
            CyUi.drawCut(c, p, rr, 6 * d)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f * d
            p.color = Cy.a(col, 0.10f * k)
            CyUi.drawCut(c, p, rr, 6 * d)
            p.strokeWidth = 1f * d
            p.color = Cy.a(col, 0.8f * k)
            CyUi.drawCut(c, p, rr, 6 * d)
            val lw = VFont.width(items[i].label, th)
            VFont.draw(c, p, items[i].label, rr.centerX() - lw / 2f, rr.centerY() - th / 2f, th,
                Cy.a(if (quiet) 0xFFCFD8E0.toInt() else 0xFFFFFFFF.toInt(), k), true)
        }
    }
}

/** A small floating window that shows Boost working: a ring around the game icon pulling data in, then what was freed. */
class BoostMini(ctx: Context, private val icon: Drawable?, @Suppress("unused") private val gameName: String) : View(ctx) {
    var onDismiss: (() -> Unit)? = null
    var side = -1
    var ptr = 0f

    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val path = Path()
    private var target = 0.04f
    private var disp = 0f
    private var stepText = "STARTING"
    private var freed = -1L
    private var doneAt = 0L
    private var dismissed = false
    private val t0 = System.currentTimeMillis()
    private var running = false

    fun setProgress(pr: Float, text: String) { target = pr; stepText = text }
    fun finish(freedMb: Long) { target = 1f; freed = freedMb }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onTouchEvent(e: MotionEvent): Boolean = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = System.currentTimeMillis()
        val t = (now - t0) / 1000f
        disp = min(target, disp + 0.012f)
        if (freed >= 0L && disp >= 0.995f && doneAt == 0L) doneAt = now
        val done = doneAt != 0L
        val td = if (done) (now - doneAt) / 1000f else 0f
        if (done && td > 1.9f && !dismissed) { dismissed = true; post { onDismiss?.invoke() } }
        val accent = if (done) Neon.GREEN else Neon.CYAN
        val m = 4 * d
        val pt = 6 * d
        val l = m + (if (side == 2) pt else 0f)
        val r = w - m - (if (side == 3) pt else 0f)
        val top = m + (if (side == 0) pt else 0f)
        val bot = h - m - (if (side == 1) pt else 0f)
        val bob = sin(now / 600f) * 1.1f * d

        c.save()
        c.translate(0f, bob)
        rr.set(l, top, r, bot)
        Glass.panel(c, p, rr, d, accent, now)
        val cy = (top + bot) / 2f
        val cx = l + 30 * d
        val R = 17 * d
        // icon
        if (icon != null) {
            val s = 22 * d
            c.save()
            path.reset()
            path.addRoundRect(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, 6 * d, 6 * d, Path.Direction.CW)
            c.clipPath(path)
            icon.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
            icon.draw(c)
            c.restore()
        }
        // ring
        rr.set(cx - R, cy - R, cx + R, cy + R)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 2.4f * d
        p.color = Cy.a(accent, 0.2f)
        c.drawArc(rr, 0f, 360f, false, p)
        p.color = accent
        c.drawArc(rr, -90f, 360f * disp, false, p)
        if (!done) {
            p.strokeWidth = 1.4f * d
            p.color = Cy.a(Neon.CYAN, 0.7f)
            c.drawArc(rr, t * 300f, 40f, false, p)
            // data pulled into the ring
            p.style = Paint.Style.FILL
            for (i in 0 until 9) {
                val k = (t * 0.9f + i * 0.111f) % 1f
                val a = (i * 40f + t * 40f) * PI.toFloat() / 180f
                val rad = R + 15 * d * (1f - k)
                p.color = Cy.a(Neon.CYAN, 0.85f * k)
                c.drawCircle(cx + cos(a) * rad, cy + sin(a) * rad, (1.9f - 0.6f * k) * d, p)
            }
        } else {
            val s = td / 0.7f
            if (s in 0f..1f) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2.2f * d * (1f - s)
                p.color = Cy.a(Neon.GREEN, 0.8f * (1f - s))
                c.drawCircle(cx, cy, R * (1f + 0.8f * s), p)
            }
        }
        // texts
        val tx = cx + R + 12 * d
        val maxW = r - tx - 10 * d
        VFont.draw(c, p, if (done) "READY" else "BOOST", tx, top + 7 * d, 5.5f * d, Cy.a(accent, 0.95f), true)
        if (!done) {
            VFont.draw(c, p, VFont.fit(stepText, 8f * d, maxW), tx, cy - 5 * d, 8f * d, 0xFFFFFFFF.toInt(), true)
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = 2.2f * d
            p.color = Cy.a(Neon.CYAN, 0.18f)
            c.drawLine(tx, bot - 9 * d, tx + maxW, bot - 9 * d, p)
            p.shader = LinearGradient(tx, 0f, tx + maxW, 0f, Neon.CYAN, Neon.GREEN, Shader.TileMode.CLAMP)
            if (disp > 0.01f) c.drawLine(tx, bot - 9 * d, tx + maxW * disp, bot - 9 * d, p)
            p.shader = null
        } else if (freed > 0L) {
            val k = (td / 0.8f).coerceIn(0f, 1f)
            val v = (freed * (1f - (1f - k) * (1f - k) * (1f - k))).toLong()
            VFont.draw(c, p, "+$v", tx, cy - 6 * d, 13f * d, Neon.GREEN, true)
            VFont.draw(c, p, "MB FREED", tx, cy + 11 * d, 5.5f * d, 0xFF9AA7B4.toInt(), false)
        } else {
            VFont.draw(c, p, VFont.fit("RAM CLEAN", 10f * d, maxW), tx, cy - 5 * d, 10f * d, Neon.GREEN, true)
            VFont.draw(c, p, "NOTHING TO FREE", tx, cy + 11 * d, 5.5f * d, 0xFF9AA7B4.toInt(), false)
        }
        c.restore()
        val q = ptr.coerceIn(16 * d, (if (side < 2) w else h) - 16 * d)
        rr.set(l, top, r, bot)
        Glass.pointer(c, p, path, side, w, h, rr, q, d, accent, now)
    }
}

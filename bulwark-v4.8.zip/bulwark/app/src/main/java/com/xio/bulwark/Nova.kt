package com.xio.bulwark

import android.content.Context
import java.util.Calendar

/** One thing Nova says: the text, the quick replies under it, and how long it stays when nobody answers. */
class NovaChip(val id: String, val label: String)

class NovaTalk(val text: String, val chips: List<NovaChip>, val holdMs: Long = 2600L)

/** What Nova knows about the moment when she talks. */
class NovaCtx(
    val game: String,
    val freedMb: Long,
    val boosted: Boolean,
    val minutes: Int,
    val fps: Int,
    val bat: Int,
    val temp: Int
)

/**
 * Nova's voice. Every line is built from small parts (opener, body, question, mood, joke), so the same game opened
 * ten times still sounds different, and she remembers what was said lately so she does not repeat herself. It all
 * runs on the phone, no internet.
 */
object NovaBrain {
    private val rnd = java.util.Random()

    private fun recent(c: Context): MutableList<String> =
        Prefs.str(c, "nova_recent", "").split("|").filter { it.isNotEmpty() }.toMutableList()

    /** Picks one option that was not used in the last few lines. */
    private fun pick(c: Context, tag: String, opts: List<String>): String {
        val r = recent(c)
        val fresh = opts.filter { (tag + opts.indexOf(it)) !in r }
        val i = opts.indexOf((if (fresh.isEmpty()) opts else fresh)[rnd.nextInt(if (fresh.isEmpty()) opts.size else fresh.size)])
        r.add(tag + i)
        while (r.size > 14) r.removeAt(0)
        Prefs.putStr(c, "nova_recent", r.joinToString("|"))
        return opts[i]
    }

    private fun fill(s: String, x: NovaCtx): String =
        s.replace("{g}", x.game).replace("{mb}", x.freedMb.toString()).replace("{min}", x.minutes.toString())
            .replace("{fps}", x.fps.toString()).replace("{bat}", x.bat.toString()).replace("{t}", x.temp.toString())

    private fun bucket(): Int {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (h) { in 5..11 -> 0; in 12..17 -> 1; in 18..22 -> 2; else -> 3 }
    }

    private val openers = listOf(
        listOf("Good morning, handsome.", "Morning, handsome. Gaming before breakfast?", "Rise and shine, handsome.", "Handsome, early start today.", "Morning, handsome. Coffee first, then glory.", "Hey handsome, fresh day, fresh match."),
        listOf("Hey handsome.", "Good afternoon, handsome.", "Handsome, you're back.", "Afternoon, handsome. Ready to play?", "There you are, handsome.", "Hi handsome, perfect time for a match."),
        listOf("Good evening, handsome.", "Evening, handsome. Prime time.", "Handsome, the night is yours.", "Hey handsome, the evening squad is here.", "Welcome back, handsome.", "Evening, handsome. Let's make it count."),
        listOf("It's late, handsome.", "Midnight session, handsome?", "Handsome, you should be asleep. But fine.", "Late night, handsome. I'll keep you company.", "Night owl mode, handsome.", "Handsome, the world is asleep. We're not.")
    )

    private val bodyFreed = listOf(
        "I cleared {mb} MB for {g}.", "{g} just got {mb} MB of breathing room.", "Boost done, {mb} MB freed.",
        "I swept out {mb} MB so {g} runs smooth.", "{mb} MB cleaned. {g} is all yours.", "Everything's tuned and {mb} MB lighter."
    )
    private val bodyClean = listOf(
        "Your RAM was already spotless.", "Nothing to clear, you keep things tidy.", "{g} is boosted and ready.",
        "Everything's tuned, nothing was in the way.", "Boost done, the phone was already in top shape."
    )
    private val bodyPlain = listOf(
        "{g} is open and I'm watching the numbers.", "I'm tracking {g} for you.", "Status is up, {g} is running.",
        "All set on my side.", "I've got your back in {g}."
    )
    private val asks = listOf(
        "Ready to play?", "Want some music while we play?", "What's the plan?", "Shall we drop in?", "Need anything before we start?",
        "Any requests?", "How are we feeling today?", "Say the word and I'll help."
    )

    fun greeting(c: Context, x: NovaCtx): NovaTalk {
        val op = pick(c, "o" + bucket(), openers[bucket()])
        val body = fill(
            if (x.boosted && x.freedMb > 0) pick(c, "bf", bodyFreed)
            else if (x.boosted) pick(c, "bc", bodyClean)
            else pick(c, "bp", bodyPlain), x
        )
        val ask = pick(c, "a", asks)
        var text = fill("$op $body", x)
        if (text.length + ask.length < 76) text += " " + ask
        val list = ArrayList<NovaChip>()
        val musicNo = Prefs.int(c, "nova_music_no", 0)
        val musicYes = Prefs.int(c, "nova_music_yes", 0)
        if (musicNo < musicYes + 3) list.add(NovaChip("music", "Play music"))
        list.add(listOf(NovaChip("go", "Let's go"), NovaChip("how", "How am I doing?"), NovaChip("joke", "Tell me something")).random())
        list.add(NovaChip("bye", "Not now"))
        return NovaTalk(text, list)
    }

    fun reply(c: Context, id: String, x: NovaCtx): NovaTalk {
        when (id) {
            "go" -> return NovaTalk(fill(pick(c, "go", listOf(
                "That's the spirit, handsome. Go get them.", "Locked in. I'll keep watch.", "Show them what you've got, handsome.",
                "Good luck out there, I'm right here.", "Go be legendary, handsome.", "On your signal, champ. I'll stay quiet."
            )), x), emptyList())
            "bye" -> {
                Prefs.putInt(c, "nova_music_no", Prefs.int(c, "nova_music_no", 0) + 1)
                return NovaTalk(fill(pick(c, "by", listOf(
                    "No problem, handsome. I'll be here.", "Okay, I'll stay out of your way.", "Understood. Shout if you need me.",
                    "Quiet mode on. Have fun.", "Sure thing. I'm still watching your stats."
                )), x), emptyList(), 1800L)
            }
            "thanks" -> return NovaTalk(fill(pick(c, "th", listOf(
                "Anytime, handsome.", "That's what I'm here for.", "Always, handsome.", "My pleasure. Now go win.", "Happy to help."
            )), x), emptyList(), 1800L)
            "how" -> {
                val fpsLine = if (x.fps <= 0) "" else pick(c, "hf", listOf(
                    " You're holding {fps} FPS.", " {fps} FPS right now, steady.", " The frame counter says {fps}.", " Running at {fps} FPS."
                ))
                val time = pick(c, "hm", listOf(
                    "You've been in {g} for {min} min.", "{min} minutes in so far.", "That's {min} minutes of {g} already.", "{min} min on the clock."
                ))
                val bt = pick(c, "hb", listOf(
                    " Battery is at {bat}%, {t}°C.", " Battery {bat}%, temperature {t}°C.", " Phone is at {t}°C with {bat}% left.", " {bat}% battery and {t}°C."
                ))
                return NovaTalk(fill(time + fpsLine + bt, x), listOf(NovaChip("music", "Play music"), NovaChip("thanks", "Thanks")))
            }
            "joke" -> {
                val a = pick(c, "j1", listOf(
                    "Fun fact: you've opened {g} more than your fridge today.", "I don't blink, so I never miss a frame.", "My favourite number is 90, you know why.",
                    "If lag was a person, I'd politely escort it out.", "I've counted your frames. You're doing great.", "Somewhere a battery is quietly rooting for you.",
                    "Tip: hydrate. Even legends need water.", "I was going to tell a joke about RAM but I forgot it.", "They say gamers never sleep. I say we don't need to.",
                    "Thermal check: you're the coolest thing here."
                ))
                val b = pick(c, "j2", listOf(" Anyway.", " Just saying.", " Don't tell the others.", " Okay, back to work.", " Carry on, handsome.", ""))
                return NovaTalk(fill(a + b, x), listOf(NovaChip("joke", "Another"), NovaChip("music", "Play music"), NovaChip("thanks", "Thanks")))
            }
        }
        return NovaTalk("Anything else, handsome?", listOf(NovaChip("bye", "That's all")))
    }

    fun noPlaylist(c: Context, x: NovaCtx) = NovaTalk(fill(pick(c, "np", listOf(
        "You don't have a playlist yet, handsome. Make one in Frameline > Music.", "No playlists found. Create one in the Music tab and I'll play it.",
        "I'd love to, but there's no playlist. Add one in Frameline > Music."
    )), x), emptyList(), 3200L)

    fun askPlaylist(c: Context, names: List<Pair<String, String>>, x: NovaCtx): NovaTalk {
        val chips = names.take(4).map { NovaChip("pl:" + it.first, it.second) } + NovaChip("bye", "Not now")
        return NovaTalk(fill(pick(c, "ap", listOf(
            "Which playlist, handsome?", "Pick a playlist and I'll start it.", "What are we in the mood for?", "Choose your soundtrack.", "Which one should I play?"
        )), x), chips, 30_000L)
    }

    fun musicStart(c: Context, name: String): String = pick(c, "ms", listOf(
        "On it, handsome.", "Tuning in to $name.", "Coming right up.", "Sound check for $name.", "Let me set the mood."
    ))

    fun musicDone(c: Context, name: String, x: NovaCtx): NovaTalk = NovaTalk(pick(c, "md", listOf(
        "Now playing $name. Enjoy, handsome.", "$name is on. Turn it up.", "Your soundtrack is live: $name.", "Done. $name is playing.", "$name, as ordered."
    )), listOf(NovaChip("skip", "Next song"), NovaChip("thanks", "Thanks")), 8000L)
}


package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View

/** A landscape "game screen" (about 19.5 : 9) with nothing on it, where an animation plays. Tap it to replay. */
class FxStage(ctx: Context) : View(ctx) {
    private val render = FxRender(ctx)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val r = RectF()
    private var bg: Shader? = null

    var anim: FxAnim? = null
    var loop = false
    var onTap: (() -> Unit)? = null
    var playing = false
        private set
    private var t0 = 0L

    fun play() {
        playing = true
        t0 = SystemClock.uptimeMillis()
        invalidate()
    }

    fun stop() {
        playing = false
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val width = MeasureSpec.getSize(w)
        setMeasuredDimension(width, (width * 9f / 19.5f).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val rad = Ui.dp(context, 14f)
        clip.reset()
        r.set(0f, 0f, w.toFloat(), h.toFloat())
        clip.addRoundRect(r, rad, rad, Path.Direction.CW)
        bg = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFF0E161F.toInt(), 0xFF05090D.toInt(), Shader.TileMode.CLAMP)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            performClick()
            onTap?.invoke()
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat()
        val h = height.toFloat()
        c.save()
        c.clipPath(clip)
        p.style = Paint.Style.FILL
        p.shader = bg
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        // faint grid and centre cross, so you can judge where things land
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = 0x0AFFFFFF
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, h, p); x += w / 20f }
        var y = 0f
        while (y < h) { c.drawLine(0f, y, w, y, p); y += h / 9f }
        p.color = 0x1419E6F2
        c.drawLine(w / 2f, 0f, w / 2f, h, p)
        c.drawLine(0f, h / 2f, w, h / 2f, p)

        // a hint of the phone: camera notch on the left edge
        p.style = Paint.Style.FILL
        p.color = 0xFF020406.toInt()
        r.set(-6f * d, h / 2f - 9f * d, 7f * d, h / 2f + 9f * d)
        c.drawRoundRect(r, 6f * d, 6f * d, p)

        p.style = Paint.Style.FILL
        p.textSize = 8f * d
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.2f
        p.textAlign = Paint.Align.LEFT
        p.color = Neon.a(Neon.CYAN, 150)
        c.drawText("LANDSCAPE STAGE", 20f * d, 17f * d, p)
        p.textAlign = Paint.Align.RIGHT
        c.drawText(if (playing) "PLAYING" else "TAP TO PLAY", w - 14f * d, 17f * d, p)
        p.letterSpacing = 0f

        val a = anim
        if (a != null && playing) {
            val total = a.totalMs()
            val now = SystemClock.uptimeMillis()
            var el = (now - t0).toInt()
            if (el > total + 600) {
                if (loop) { t0 = now; el = 0 } else { playing = false }
            }
            if (playing) {
                render.draw(c, w, h, a, el)
                postInvalidateOnAnimation()
            }
        }
        c.restore()

        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Ui.EDGE
        r.set(0.6f * d, 0.6f * d, w - 0.6f * d, h - 0.6f * d)
        c.drawRoundRect(r, 14f * d, 14f * d, p)
    }
}

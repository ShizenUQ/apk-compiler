package com.xio.bulwark

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

class VItem(val id: String, val uri: String, val title: String, val dur: Long)
class VList(val id: String, var name: String, val ids: MutableList<String>)

/**
 * The video player's library. Videos are not copied: only a link to the file is kept, so adding is instant
 * whatever the size. Playlists and the place where you stopped in every video are saved here too.
 */
object VideoLib {
    const val ALL = "all"

    private var items: MutableList<VItem>? = null
    private var lists: MutableList<VList>? = null

    var onChange: (() -> Unit)? = null

    @Synchronized
    private fun load(c: Context) {
        if (items != null) return
        val it = ArrayList<VItem>()
        try {
            val a = JSONArray(Prefs.str(c, "vl_items", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                it.add(VItem(o.getString("id"), o.getString("u"), o.optString("t", "video"), o.optLong("d", 0L)))
            }
        } catch (t: Throwable) { }
        items = it
        val ls = ArrayList<VList>()
        try {
            val a = JSONArray(Prefs.str(c, "vl_lists", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val ids = ArrayList<String>()
                val ja = o.getJSONArray("v")
                for (k in 0 until ja.length()) ids.add(ja.getString(k))
                ls.add(VList(o.getString("id"), o.optString("n", "Playlist"), ids))
            }
        } catch (t: Throwable) { }
        lists = ls
    }

    @Synchronized
    private fun save(c: Context) {
        val a = JSONArray()
        for (v in items ?: emptyList<VItem>()) a.put(JSONObject().put("id", v.id).put("u", v.uri).put("t", v.title).put("d", v.dur))
        Prefs.putStr(c, "vl_items", a.toString())
        val b = JSONArray()
        for (l in lists ?: emptyList<VList>()) {
            val ja = JSONArray()
            for (x in l.ids) ja.put(x)
            b.put(JSONObject().put("id", l.id).put("n", l.name).put("v", ja))
        }
        Prefs.putStr(c, "vl_lists", b.toString())
    }

    @Synchronized fun videos(c: Context): List<VItem> { load(c); return items!!.toList() }
    @Synchronized fun playlists(c: Context): List<VList> { load(c); return lists!!.toList() }
    @Synchronized fun video(c: Context, id: String): VItem? { load(c); return items!!.firstOrNull { it.id == id } }
    @Synchronized fun playlist(c: Context, id: String): VList? { load(c); return lists!!.firstOrNull { it.id == id } }

    /** Videos of a playlist, or all of them for the built-in "all videos" list. */
    @Synchronized
    fun videosOf(c: Context, plId: String): List<VItem> {
        load(c)
        if (plId == ALL) return items!!.toList()
        val l = lists!!.firstOrNull { it.id == plId } ?: return items!!.toList()
        return l.ids.mapNotNull { id -> items!!.firstOrNull { it.id == id } }
    }

    @Synchronized
    fun has(c: Context, uri: String): Boolean { load(c); return items!!.any { it.uri == uri } }

    @Synchronized
    fun add(c: Context, uri: Uri, title: String, dur: Long): VItem? {
        load(c)
        val s = uri.toString()
        if (items!!.any { it.uri == s }) return null
        val v = VItem(java.lang.Long.toString(System.currentTimeMillis(), 36) + (Math.random() * 999).toInt(), s, title, dur)
        items!!.add(v)
        save(c)
        return v
    }

    @Synchronized
    fun remove(c: Context, id: String) {
        load(c)
        items!!.removeAll { it.id == id }
        for (l in lists!!) l.ids.remove(id)
        Prefs.putInt(c, "vp_$id", 0)
        save(c)
        onChange?.invoke()
    }

    @Synchronized
    fun createList(c: Context, name: String): VList {
        load(c)
        val l = VList(java.lang.Long.toString(System.currentTimeMillis(), 36), name, ArrayList())
        lists!!.add(l)
        save(c)
        return l
    }

    @Synchronized
    fun renameList(c: Context, id: String, name: String) {
        load(c); lists!!.firstOrNull { it.id == id }?.name = name; save(c)
    }

    @Synchronized
    fun deleteList(c: Context, id: String) {
        load(c)
        val gone = lists!!.firstOrNull { it.id == id }?.ids?.toList() ?: emptyList()
        lists!!.removeAll { it.id == id }
        for (v in gone) if (lists!!.none { it.ids.contains(v) }) { items!!.removeAll { it.id == v }; Prefs.putInt(c, "vp_$v", 0) }
        if (activeId(c) == id) setActive(c, lists!!.firstOrNull()?.id ?: ALL)
        save(c)
    }

    /** Removes a video from one playlist; if no playlist has it any more it leaves the library too. */
    @Synchronized
    fun dropFromList(c: Context, listId: String, vid: String) {
        load(c)
        lists!!.firstOrNull { it.id == listId }?.ids?.remove(vid)
        if (lists!!.none { it.ids.contains(vid) }) { items!!.removeAll { it.id == vid }; Prefs.putInt(c, "vp_$vid", 0) }
        save(c)
        onChange?.invoke()
    }

    /** Moves the video at [i] up (-1) or down (+1). */
    @Synchronized
    fun move(c: Context, listId: String, i: Int, dir: Int) {
        load(c)
        val l = lists!!.firstOrNull { it.id == listId } ?: return
        val j = i + dir
        if (i !in l.ids.indices || j !in l.ids.indices) return
        val t = l.ids[i]; l.ids[i] = l.ids[j]; l.ids[j] = t
        save(c)
    }

    /** Puts these videos in the playlist in this order (added at the end). */
    @Synchronized
    fun appendOrdered(c: Context, listId: String, ids: List<String>) {
        load(c)
        val l = lists!!.firstOrNull { it.id == listId } ?: return
        for (id in ids) if (!l.ids.contains(id)) l.ids.add(id)
        save(c)
        onChange?.invoke()
    }

    /** Sorts the whole playlist by the given order of ids. */
    @Synchronized
    fun setOrder(c: Context, listId: String, ids: List<String>) {
        load(c)
        val l = lists!!.firstOrNull { it.id == listId } ?: return
        l.ids.clear(); l.ids.addAll(ids)
        save(c)
    }

    @Synchronized
    fun setInList(c: Context, listId: String, vid: String, inside: Boolean) {
        load(c)
        val l = lists!!.firstOrNull { it.id == listId } ?: return
        if (inside) { if (!l.ids.contains(vid)) l.ids.add(vid) } else l.ids.remove(vid)
        save(c)
    }

    fun activeId(c: Context): String {
        val a = Prefs.str(c, "vl_active", "")
        if (a.isNotEmpty() && a != ALL && playlist(c, a) != null) return a
        return playlists(c).firstOrNull()?.id ?: ALL
    }

    fun setActive(c: Context, id: String) { Prefs.putStr(c, "vl_active", id); onChange?.invoke() }

    // ---- where you stopped ----
    fun pos(c: Context, id: String): Int = Prefs.int(c, "vp_$id", 0)
    fun setPos(c: Context, id: String, ms: Int) { Prefs.putInt(c, "vp_$id", ms) }

    // ---- settings ----
    fun size(c: Context): Int = Prefs.int(c, "vp_size", 1).coerceIn(0, 2)
    fun setSize(c: Context, v: Int) = Prefs.putInt(c, "vp_size", v)
    fun sound(c: Context): Boolean = Prefs.bool(c, "vp_sound", true)
    fun autoShrink(c: Context): Boolean = Prefs.bool(c, "vp_shrink", true)

    fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val ss = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, ss) else String.format("%d:%02d", m, ss)
    }
}

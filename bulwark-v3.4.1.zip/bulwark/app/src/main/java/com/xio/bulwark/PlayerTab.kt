package com.xio.bulwark

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Thumbnail card for one library video: picture, name, length and how far you got. */
private class VidCard(ctx: Context, val v: VItem) : LinearLayout(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val img = ImageView(ctx)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val frac = if (v.dur > 0) (VideoLib.pos(ctx, v.id).toFloat() / v.dur).coerceIn(0f, 1f) else 0f
    var onTap: (() -> Unit)? = null

    init {
        orientation = VERTICAL
        setWillNotDraw(false)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.setBackgroundColor(0xFF0B1118.toInt())
        addView(img, LayoutParams(-1, 0))
        val t = TextView(ctx)
        t.text = v.title; t.textSize = 12f; t.maxLines = 2; t.setTextColor(0xFFE8ECF2.toInt())
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (7 * d).toInt())
        addView(t, LayoutParams(-1, -2))
        val b = VThumbs.peek(v)
        if (b != null) img.setImageBitmap(b) else VThumbs.load(ctx, v) { bm -> if (bm != null) img.setImageBitmap(bm) }
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val lpI = img.layoutParams
        lpI.height = (w * 9f / 16f).toInt()
        super.onMeasure(wSpec, hSpec)
    }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val w = width.toFloat(); val ih = img.height.toFloat()
        // length badge
        val s = VideoLib.fmt(v.dur)
        val k = 0.5f * d
        val tw = CyUi.width(s, k)
        p.style = Paint.Style.FILL; p.color = 0xCC000000.toInt()
        c.drawRect(w - tw - 12 * d, ih - 15 * d, w - 3 * d, ih - 3 * d, p)
        CyUi.text(c, p, s, w - tw - 7.5f * d, ih - 12.5f * d, k, 0xFFEAFBFF.toInt(), 1f, false)
        if (frac > 0.02f) {
            p.color = 0xAA000000.toInt(); c.drawRect(0f, ih - 3 * d, w, ih, p)
            p.color = CyUi.YELLOW; c.drawRect(0f, ih - 3 * d, w * frac, ih, p)
        }
        CyUi.chamfer(path, d * 0.6f, d * 0.6f, w - d * 0.6f, height - d * 0.6f, 9 * d)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d; p.color = Cy.a(Cy.CYAN, 0.45f)
        c.drawPath(path, p)
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = true
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}

/** Playlist as a wide strip: a 2x2 mosaic of its videos on the left, name and count on the right. */
private class ListStrip(ctx: Context, val l: VList, val active: Boolean) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val vids = VideoLib.videosOf(ctx, l.id)
    var onTap: (() -> Unit)? = null
    var onMore: (() -> Unit)? = null
    private val more = RectF()

    init {
        for (v in vids.take(4)) if (VThumbs.peek(v) == null) VThumbs.load(ctx, v) { invalidate() }
    }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), (74 * d).toInt()) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val col = if (active) CyUi.YELLOW else Cy.CYAN
        CyUi.chamfer(path, d, d, w - d, h - d, 10 * d)
        p.style = Paint.Style.FILL; p.color = Cy.a(col, if (active) 0.1f else 0.05f); c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = (if (active) 1.6f else 1.1f) * d; p.color = Cy.a(col, if (active) 0.9f else 0.4f); c.drawPath(path, p)
        // mosaic
        val m = 8 * d; val s = h - 2 * m; val half = s / 2f
        c.save()
        c.clipRect(m, m, m + s * 1.6f, m + s)
        for (i in 0 until 4) {
            val x = m + (i % 2) * half * 1.6f; val y = m + (i / 2) * half
            val v = vids.getOrNull(i)
            val b = if (v != null) VThumbs.peek(v) else null
            val r = RectF(x, y, x + half * 1.6f - d, y + half - d)
            if (b != null) c.drawBitmap(b, android.graphics.Rect(0, 0, b.width, b.height), r, p)
            else { p.style = Paint.Style.FILL; p.color = 0xFF0B1118.toInt(); c.drawRect(r, p) }
        }
        c.restore()
        val tx = m + s * 1.6f + 12 * d
        val nm = l.name.uppercase()
        val k = 0.8f * d
        var show = nm
        if (CyUi.supported(show)) {
            while (show.length > 1 && CyUi.width(show, k) > w - tx - 46 * d) show = show.dropLast(1)
            CyUi.text(c, p, show, tx, 16 * d, k, 0xFFEAFBFF.toInt(), 1f, false)
        } else {
            p.style = Paint.Style.FILL; p.color = 0xFFEAFBFF.toInt(); p.textSize = 14 * d; p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            c.drawText(l.name, tx, 27 * d, p)
        }
        val sub = vids.size.toString() + (if (vids.size == 1) " VIDEO" else " VIDEOS")
        CyUi.text(c, p, sub, tx, 40 * d, 0.6f * d, 0xFF9FB0C2.toInt(), 1f, false)
        if (active) CyUi.text(c, p, "ON STATUS", tx, 52 * d, 0.6f * d, CyUi.YELLOW, 1f, false)
        else CyUi.text(c, p, "TAP TO OPEN", tx, 52 * d, 0.55f * d, Cy.a(Cy.CYAN, 0.7f), 1f, false)
        more.set(w - 40 * d, 0f, w, h)
        p.style = Paint.Style.FILL; p.color = Cy.a(Cy.CYAN, 0.9f)
        for (i in 0..2) c.drawRect(w - 20 * d, h / 2f - 8 * d + i * 7 * d, w - 14 * d, h / 2f - 5 * d + i * 7 * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) { if (more.contains(e.x, e.y)) onMore?.invoke() else onTap?.invoke() }
        return true
    }
}

/** One episode in a playlist: small thumbnail, title, move up / down and remove. */
private class EpRow(ctx: Context, val v: VItem, val n: Int, val first: Boolean, val last: Boolean) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    var onUp: (() -> Unit)? = null
    var onDown: (() -> Unit)? = null
    var onDel: (() -> Unit)? = null
    private val rUp = RectF(); private val rDn = RectF(); private val rDel = RectF()
    private val frac = if (v.dur > 0) (VideoLib.pos(ctx, v.id).toFloat() / v.dur).coerceIn(0f, 1f) else 0f

    init { if (VThumbs.peek(v) == null) VThumbs.load(ctx, v) { invalidate() } }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), (50 * d).toInt()) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL; p.color = 0xFF161C26.toInt(); c.drawRect(0f, h - 1f, w, h, p)
        CyUi.text(c, p, n.toString(), 4 * d, h / 2f - 3.5f * d, 0.55f * d, Cy.a(Cy.CYAN, 0.8f), 1f, false)
        val tx = 26 * d; val tw = 64 * d; val th = 36 * d; val ty = (h - th) / 2f
        val b = VThumbs.peek(v)
        if (b != null) c.drawBitmap(b, Rect(0, 0, b.width, b.height), RectF(tx, ty, tx + tw, ty + th), p)
        else { p.color = 0xFF0B1118.toInt(); c.drawRect(tx, ty, tx + tw, ty + th, p) }
        if (frac > 0.02f) { p.color = 0xAA000000.toInt(); c.drawRect(tx, ty + th - 2.5f * d, tx + tw, ty + th, p); p.color = CyUi.YELLOW; c.drawRect(tx, ty + th - 2.5f * d, tx + tw * frac, ty + th, p) }
        p.color = 0xFFE8ECF2.toInt(); p.textSize = 12.5f * d; p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val bw = 28 * d
        val room = w - tx - tw - 10 * d - bw * 3
        var t = v.title
        while (t.length > 1 && p.measureText(t) > room) t = t.dropLast(1)
        c.drawText(t, tx + tw + 8 * d, h / 2f - 2 * d, p)
        p.color = 0xFF8B96A3.toInt(); p.textSize = 10.5f * d
        c.drawText(VideoLib.fmt(v.dur), tx + tw + 8 * d, h / 2f + 13 * d, p)
        rDel.set(w - bw, 0f, w, h); rDn.set(w - bw * 2, 0f, w - bw, h); rUp.set(w - bw * 3, 0f, w - bw * 2, h)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.8f * d; p.strokeJoin = Paint.Join.MITER
        val cy = h / 2f
        p.color = if (first) Cy.a(Cy.CYAN, 0.2f) else Cy.CYAN
        path.reset(); path.moveTo(rUp.centerX() - 5 * d, cy + 2.5f * d); path.lineTo(rUp.centerX(), cy - 3 * d); path.lineTo(rUp.centerX() + 5 * d, cy + 2.5f * d); c.drawPath(path, p)
        p.color = if (last) Cy.a(Cy.CYAN, 0.2f) else Cy.CYAN
        path.reset(); path.moveTo(rDn.centerX() - 5 * d, cy - 2.5f * d); path.lineTo(rDn.centerX(), cy + 3 * d); path.lineTo(rDn.centerX() + 5 * d, cy - 2.5f * d); c.drawPath(path, p)
        p.color = Cy.PINK
        c.drawLine(rDel.centerX() - 4.5f * d, cy - 4.5f * d, rDel.centerX() + 4.5f * d, cy + 4.5f * d, p)
        c.drawLine(rDel.centerX() + 4.5f * d, cy - 4.5f * d, rDel.centerX() - 4.5f * d, cy + 4.5f * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            if (rDel.contains(e.x, e.y)) onDel?.invoke()
            else if (rDn.contains(e.x, e.y)) { if (!last) onDown?.invoke() }
            else if (rUp.contains(e.x, e.y)) { if (!first) onUp?.invoke() }
        }
        return true
    }
}

/** The Player page: playlists of videos for the floating player on the status. Open a playlist to add episodes and put them in order. */
class PlayerTab(private val act: Activity, private val page: android.widget.ScrollView, private val cards: ArrayList<View>) {
    private val d = act.resources.displayMetrics.density
    private fun dp(v: Float) = (v * d).toInt()
    private val col = LinearLayout(act)
    private lateinit var title: CyTitle
    private lateinit var body: LinearLayout
    private var openId = ""
    private var target = ""

    private fun tv(s: String, size: Float, color: Int): TextView {
        val t = TextView(act); t.text = s; t.textSize = size; t.setTextColor(color)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); return t
    }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).also { it.topMargin = top }

    fun build() {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        page.addView(col, FrameLayout.LayoutParams(-1, -2))
        page.overScrollMode = View.OVER_SCROLL_NEVER
        title = CyTitle(act, "PLAYER", "", Cy.CYAN)
        col.addView(title, lp(dp(4f))); cards.add(title)
        body = LinearLayout(act); body.orientation = LinearLayout.VERTICAL
        col.addView(body, lp(0))
        refresh()
    }

    fun refresh() {
        body.removeAllViews()
        if (openId.isNotEmpty() && VideoLib.playlist(act, openId) != null) detail(openId) else { openId = ""; home() }
    }

    // ---------- all playlists ----------

    private fun home() {
        title.setTagText(VideoLib.playlists(act).size.toString() + " LISTS")
        val pb = CyPanel(act)
        pb.setPadding(dp(14f), dp(12f), dp(14f), dp(14f))
        pb.addView(CyTitle(act, "PLAYLISTS", "STATUS PLAYER", Cy.PINK))
        pb.addView(tv("Make a playlist and fill it from your files. The playlist marked ON STATUS opens from the player tab under the status.", 12f, 0xFF8B96A3.toInt()), lp(dp(6f)))
        val np = CyBtn(act, "+ NEW PLAYLIST", Cy.PINK)
        np.onClick = { nameDialog("New playlist", "") { n -> val l = VideoLib.createList(act, n); openId = l.id; pickFiles(l.id); refresh() } }
        pb.addView(np, lp(dp(12f)))
        val lists = LinearLayout(act); lists.orientation = LinearLayout.VERTICAL
        val act0 = VideoLib.activeId(act)
        for (l in VideoLib.playlists(act)) {
            val s = ListStrip(act, l, act0 == l.id)
            s.onTap = { openId = l.id; refresh() }
            s.onMore = { openId = l.id; refresh() }
            lists.addView(s, lp(dp(8f)))
        }
        if (VideoLib.playlists(act).isEmpty()) lists.addView(tv("No playlists yet.", 12.5f, 0xFF8B96A3.toInt()), lp(dp(10f)))
        pb.addView(lists, lp(dp(4f)))
        body.addView(pb, lp(dp(12f))); cards.add(pb)

        val sp = CyPanel(act)
        sp.setPadding(dp(14f), dp(12f), dp(14f), dp(14f))
        sp.addView(CyTitle(act, "FLOATING PLAYER", "16:9", Cy.CYAN))
        sp.addView(tv("Window size", 13f, 0xFFE8ECF2.toInt()), lp(dp(8f)))
        val seg = CySeg(act, listOf("SMALL", "MEDIUM", "LARGE"), Cy.CYAN)
        seg.select(VideoLib.size(act))
        seg.onSelect = { i -> VideoLib.setSize(act, i) }
        sp.addView(seg, lp(dp(6f)))
        fun row(t: String, s: String, key: String, def: Boolean) {
            val r = LinearLayout(act); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(0, dp(9f), 0, dp(3f))
            val c2 = LinearLayout(act); c2.orientation = LinearLayout.VERTICAL
            c2.addView(tv(t, 14f, 0xFFE8ECF2.toInt())); c2.addView(tv(s, 11.5f, 0xFF8B96A3.toInt()))
            r.addView(c2, LinearLayout.LayoutParams(0, -2, 1f))
            val sw = PSwitch(act); sw.setChecked(Prefs.bool(act, key, def)); sw.onChange = { v -> Prefs.putBool(act, key, v) }
            r.addView(sw, LinearLayout.LayoutParams(-2, -2))
            sp.addView(r, lp(dp(4f)))
        }
        row("Shrink when paused", "Hides after a few seconds. Tap the tab under the status to bring it back.", "vp_shrink", true)
        row("Sound", "Start with sound on", "vp_sound", true)
        body.addView(sp, lp(dp(12f))); cards.add(sp)
    }

    // ---------- one playlist ----------

    private fun detail(id: String) {
        val pl = VideoLib.playlist(act, id) ?: return
        val vids = VideoLib.videosOf(act, id)
        title.setTagText(vids.size.toString() + " VIDEOS")
        val pb = CyPanel(act)
        pb.setPadding(dp(14f), dp(12f), dp(14f), dp(14f))
        pb.addView(CyTitle(act, pl.name.uppercase().take(16), if (VideoLib.activeId(act) == id) "ON STATUS" else "PLAYLIST", if (VideoLib.activeId(act) == id) CyUi.YELLOW else Cy.PINK))
        val top = LinearLayout(act)
        val back = CyBtn(act, "BACK", Cy.CYAN); back.onClick = { openId = ""; refresh() }
        top.addView(back, LinearLayout.LayoutParams(0, -2, 1f))
        val use = CyBtn(act, if (VideoLib.activeId(act) == id) "IN USE" else "USE ON STATUS", CyUi.YELLOW)
        use.onClick = { VideoLib.setActive(act, id); refresh() }
        val ul = LinearLayout.LayoutParams(0, -2, 1.6f); ul.leftMargin = dp(8f)
        top.addView(use, ul)
        pb.addView(top, lp(dp(8f)))
        val add = CyBtn(act, "+ ADD VIDEOS FROM FILES", Cy.CYAN)
        add.onClick = { pickFiles(id) }
        pb.addView(add, lp(dp(8f)))
        pb.addView(tv("Episodes are put in order by their file names (S01E05, Episode 5, - 05 ...). Use the arrows to fix any.", 11.5f, 0xFF8B96A3.toInt()), lp(dp(8f)))
        val list = LinearLayout(act); list.orientation = LinearLayout.VERTICAL
        if (vids.isEmpty()) list.addView(tv("Empty. Tap Add videos and pick them from your files.", 12.5f, 0xFF8B96A3.toInt()), lp(dp(8f)))
        for ((i, v) in vids.withIndex()) {
            val r = EpRow(act, v, i + 1, i == 0, i == vids.size - 1)
            r.onUp = { VideoLib.move(act, id, i, -1); refresh() }
            r.onDown = { VideoLib.move(act, id, i, 1); refresh() }
            r.onDel = { VideoLib.dropFromList(act, id, v.id); refresh() }
            list.addView(r, lp(0))
        }
        pb.addView(list, lp(dp(10f)))
        val bar = LinearLayout(act)
        val sort = CyBtn(act, "SORT BY NAME", Cy.CYAN); sort.onClick = { autoSort(id); refresh() }
        bar.addView(sort, LinearLayout.LayoutParams(0, -2, 1f))
        val ren = CyBtn(act, "RENAME", Cy.CYAN); ren.onClick = { nameDialog("Rename", pl.name) { n -> VideoLib.renameList(act, id, n); refresh() } }
        val rl = LinearLayout.LayoutParams(0, -2, 1f); rl.leftMargin = dp(8f); bar.addView(ren, rl)
        pb.addView(bar, lp(dp(12f)))
        val del = CyBtn(act, "DELETE PLAYLIST", Cy.PINK)
        del.onClick = {
            AlertDialog.Builder(act).setTitle("Delete this playlist?").setMessage("Your video files stay on your phone.")
                .setPositiveButton("Delete") { _, _ -> VideoLib.deleteList(act, id); openId = ""; refresh() }
                .setNegativeButton("Cancel", null).show()
        }
        pb.addView(del, lp(dp(8f)))
        body.addView(pb, lp(dp(12f))); cards.add(pb)
    }

    private fun autoSort(id: String) {
        val vids = VideoLib.videosOf(act, id)
        val order = Episodes.sortKey(vids.map { it.title })
        VideoLib.setOrder(act, id, order.map { vids[it].id })
    }

    // ---------- adding from files ----------

    private fun pickFiles(id: String) {
        target = id
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "video/*"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        act.startActivityForResult(i, 36)
    }

    /** Called from the activity: true when it was ours. */
    fun onResult(code: Int, res: Int, data: Intent?): Boolean {
        if (code != 36) return false
        if (res != Activity.RESULT_OK || data == null || target.isEmpty()) { refresh(); return true }
        val uris = ArrayList<Uri>()
        val cd = data.clipData
        if (cd != null) for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) else data.data?.let { uris.add(it) }
        val id = target
        Toast.makeText(act, "Adding " + uris.size + "...", Toast.LENGTH_SHORT).show()
        Thread {
            val names = ArrayList<String>()
            for (u in uris) {
                try { act.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (t: Throwable) { }
                var n = "video"
                try { act.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) n = it.getString(0) ?: n } } catch (t: Throwable) { }
                names.add(n)
            }
            val ids = ArrayList<String>()
            for (i in Episodes.sortKey(names)) {
                val u = uris[i]
                var dur = 0L
                try {
                    val m = MediaMetadataRetriever(); m.setDataSource(act, u)
                    dur = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    m.release()
                } catch (t: Throwable) { }
                val info = Episodes.parse(names[i])
                val v = VideoLib.add(act, u, info.title, dur) ?: VideoLib.videos(act).firstOrNull { it.uri == u.toString() }
                if (v != null) ids.add(v.id)
            }
            VideoLib.appendOrdered(act, id, ids)
            act.runOnUiThread { Toast.makeText(act, "Added " + ids.size, Toast.LENGTH_SHORT).show(); refresh() }
        }.start()
        return true
    }

    private fun nameDialog(t: String, cur: String, ok: (String) -> Unit) {
        val e = EditText(act); e.setText(cur); e.setSingleLine(true); e.setSelection(cur.length)
        AlertDialog.Builder(act).setTitle(t).setView(e)
            .setPositiveButton("OK") { _, _ -> val n = e.text.toString().trim(); if (n.isNotEmpty()) ok(n.take(24)) }
            .setNegativeButton("Cancel", null).show()
    }
}

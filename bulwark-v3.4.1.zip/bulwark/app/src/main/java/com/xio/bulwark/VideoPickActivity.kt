package com.xio.bulwark

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/**
 * Picks videos from the phone's own library (Photos style, with thumbnails). Nothing is copied: only a
 * link to each video is saved, so even a long movie is added in no time.
 */
class VideoPickActivity : Activity() {
    private class Row(val id: Long, val uri: Uri, val name: String, val dur: Long)

    private val rows = ArrayList<Row>()
    private val chosen = LinkedHashSet<Long>()
    private lateinit var grid: GridView
    private lateinit var msg: TextView
    private lateinit var addBtn: CyBtn
    private val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private val cache = object : LruCache<Long, Bitmap>(90) {}
    private fun dp(v: Float) = Ui.dpi(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF05080C.toInt()
        window.navigationBarColor = 0xFF05080C.toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF05080C.toInt())
        root.setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
        root.addView(CyTitle(this, "SELECT VIDEOS", "", Cy.CYAN))

        msg = TextView(this)
        msg.textSize = 12.5f
        msg.setTextColor(0xFF8B96A3.toInt())
        msg.setPadding(dp(2f), dp(4f), dp(2f), dp(6f))
        root.addView(msg)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val more = CyBtn(this, "SELECT MORE ACCESS", Cy.CYAN)
        more.onClick = { askPermission() }
        val files = CyBtn(this, "FILES", Cy.CYAN)
        files.onClick = { openFiles() }
        bar.addView(more, LinearLayout.LayoutParams(0, -2, 1.7f))
        bar.addView(View(this), LinearLayout.LayoutParams(dp(8f), 1))
        bar.addView(files, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        grid = GridView(this)
        grid.numColumns = 3
        grid.horizontalSpacing = dp(5f)
        grid.verticalSpacing = dp(5f)
        grid.setPadding(0, dp(10f), 0, dp(10f))
        grid.clipToPadding = false
        grid.adapter = Adapter()
        grid.setSelector(android.R.color.transparent)
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))

        val bot = LinearLayout(this)
        bot.orientation = LinearLayout.HORIZONTAL
        val cancel = CyBtn(this, "CANCEL", Cy.PINK)
        cancel.onClick = { finish() }
        addBtn = CyBtn(this, "ADD", CyUi.YELLOW)
        addBtn.onClick = { addChosen() }
        bot.addView(cancel, LinearLayout.LayoutParams(0, -2, 1f))
        bot.addView(View(this), LinearLayout.LayoutParams(dp(8f), 1))
        bot.addView(addBtn, LinearLayout.LayoutParams(0, -2, 1.6f))
        root.addView(bot, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        if (hasAccess()) load() else askPermission()
    }

    // ---------- permission ----------

    private fun perms(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_VIDEO, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED")
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun hasAccess(): Boolean {
        if (Build.VERSION.SDK_INT >= 34 && checkSelfPermission("android.permission.READ_MEDIA_VISUAL_USER_SELECTED") == PackageManager.PERMISSION_GRANTED) return true
        return checkSelfPermission(perms()[0]) == PackageManager.PERMISSION_GRANTED
    }

    private fun askPermission() { requestPermissions(perms(), 77) }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77) {
            if (hasAccess()) load()
            else msg.text = "No access to your videos. Allow it, or use FILES."
        }
    }

    // ---------- list ----------

    private fun load() {
        msg.text = "Loading..."
        Thread {
            val out = ArrayList<Row>()
            try {
                val proj = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION)
                contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")?.use { cu ->
                    while (cu.moveToNext()) {
                        val id = cu.getLong(0)
                        out.add(Row(id, ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id), cu.getString(1) ?: "video", cu.getLong(2)))
                    }
                }
            } catch (t: Throwable) { }
            main.post {
                rows.clear(); rows.addAll(out)
                (grid.adapter as BaseAdapter).notifyDataSetChanged()
                msg.text = if (out.isEmpty()) "No videos visible. Use SELECT MORE ACCESS, or FILES." else "Tap the videos you want, then ADD."
                updateBtn()
            }
        }.start()
    }

    private fun updateBtn() { addBtn.label = if (chosen.isEmpty()) "ADD" else "ADD " + chosen.size; addBtn.invalidate() }

    private fun addChosen() {
        if (chosen.isEmpty()) { Toast.makeText(this, "Pick at least one video", Toast.LENGTH_SHORT).show(); return }
        var n = 0
        for (r in rows) if (chosen.contains(r.id)) {
            if (VideoLib.add(this, r.uri, r.name.substringBeforeLast('.'), r.dur) != null) n++
        }
        VideoLib.onChange?.invoke()
        Toast.makeText(this, "Added $n", Toast.LENGTH_SHORT).show()
        finish()
    }

    // ---------- files fallback ----------

    private fun openFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "video/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, 78)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 78 || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val cd = data.clipData
        if (cd != null) for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) else data.data?.let { uris.add(it) }
        var n = 0
        for (u in uris) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (t: Throwable) { }
            var name = "video"
            try { contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name } } catch (t: Throwable) { }
            val dur = durationOf(u)
            if (VideoLib.add(this, u, name.substringBeforeLast('.'), dur) != null) n++
        }
        VideoLib.onChange?.invoke()
        Toast.makeText(this, "Added $n", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun durationOf(u: Uri): Long {
        return try {
            val m = android.media.MediaMetadataRetriever()
            m.setDataSource(this, u)
            val d = m.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            m.release()
            d
        } catch (t: Throwable) { 0L }
    }

    override fun onDestroy() { super.onDestroy(); pool.shutdownNow() }

    // ---------- grid ----------

    private inner class Tile(val v: Activity) : View(v) {
        var row: Row? = null
        var bmp: Bitmap? = null
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()

        override fun onMeasure(w: Int, h: Int) {
            val ww = MeasureSpec.getSize(w)
            setMeasuredDimension(ww, (ww * 0.62f).toInt())
        }

        override fun onDraw(c: Canvas) {
            val d = Ui.dp(context, 1f)
            val w = width.toFloat(); val h = height.toFloat()
            val r = row ?: return
            val on = chosen.contains(r.id)
            CyUi.chamfer(path, d, d, w - d, h - d, 9 * d)
            c.save()
            c.clipPath(path)
            p.style = Paint.Style.FILL
            p.color = 0xFF0B1118.toInt()
            c.drawRect(0f, 0f, w, h, p)
            val b = bmp
            if (b != null) {
                val sc = maxOf(w / b.width, h / b.height)
                val bw = b.width * sc; val bh = b.height * sc
                c.drawBitmap(b, null, android.graphics.RectF((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f), p)
            }
            if (on) { p.color = Cy.a(Cy.CYAN, 0.28f); c.drawRect(0f, 0f, w, h, p) }
            p.color = 0xB0000000.toInt()
            c.drawRect(0f, h - 16 * d, w, h, p)
            c.restore()
            p.style = Paint.Style.STROKE
            p.strokeWidth = (if (on) 2f else 1f) * d
            p.color = if (on) Cy.CYAN else Cy.a(Cy.CYAN, 0.3f)
            c.drawPath(path, p)
            CyUi.text(c, p, VideoLib.fmt(r.dur), w - 5 * d, h - 12.5f * d, 0.62f * d, 0xFFEAFBFF.toInt(), 1f, false, 2)
            if (on) {
                p.style = Paint.Style.FILL
                p.color = Cy.CYAN
                c.drawRect(5 * d, 5 * d, 17 * d, 17 * d, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f * d
                p.color = 0xFF05080C.toInt()
                c.drawLine(7.5f * d, 11 * d, 10.5f * d, 14 * d, p); c.drawLine(10.5f * d, 14 * d, 14.5f * d, 8 * d, p)
            }
        }
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(i: Int): Any = rows[i]
        override fun getItemId(i: Int): Long = rows[i].id
        override fun getView(i: Int, cv: View?, parent: ViewGroup): View {
            val t = (cv as? Tile) ?: Tile(this@VideoPickActivity)
            val r = rows[i]
            t.row = r
            t.bmp = cache.get(r.id)
            if (t.bmp == null) {
                t.tag = r.id
                pool.execute {
                    var b: Bitmap? = null
                    try {
                        b = if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(r.uri, Size(320, 200), null)
                        else @Suppress("DEPRECATION") MediaStore.Video.Thumbnails.getThumbnail(contentResolver, r.id, MediaStore.Video.Thumbnails.MINI_KIND, null)
                    } catch (e: Throwable) { }
                    if (b != null) {
                        cache.put(r.id, b)
                        main.post { if (t.tag == r.id) { t.bmp = b; t.invalidate() } }
                    }
                }
            }
            t.setOnClickListener {
                if (!chosen.remove(r.id)) chosen.add(r.id)
                t.invalidate(); updateBtn()
            }
            return t
        }
    }
}

package com.xio.bulwark

/** Reads a video file name and works out the show, the episode number and a clean title. Offline, name-based only. */
object Episodes {
    class Info(val show: String, val ep: Int, val season: Int, val title: String)

    private val junk = Regex("""[\[(][^\])]*[\])]""")
    private val tags = Regex("""(?i)\b(2160p|1080p|720p|480p|4k|x264|x265|h\.?264|h\.?265|hevc|10bit|8bit|bluray|bdrip|brrip|web-?dl|webrip|hdtv|aac|ac3|flac|dual|multi|sub|subbed|dubbed|uncensored|repack|proper)\b""")
    private val ext = Regex("""\.[A-Za-z0-9]{2,4}$""")

    private val pats = listOf(
        Regex("""(?i)\bS(\d{1,2})\s*[ ._-]?E(\d{1,3})\b"""),
        Regex("""(?i)\b(\d{1,2})x(\d{2,3})\b"""),
        Regex("""(?i)\b(?:episode|ep|e)[ ._-]*(\d{1,3})\b"""),
        Regex("""(?i)(?:^|[\s._\-])#?(\d{1,3})(?:v\d)?(?=[\s._\-]|$)""")
    )

    private fun clean(s: String): String =
        s.replace('_', ' ').replace('.', ' ').replace(Regex("""\s+"""), " ").trim(' ', '-', ' ')

    fun parse(fileName: String): Info {
        var n = fileName.replace(ext, "")
        n = junk.replace(n, " ")
        n = tags.replace(n, " ")
        n = n.replace('_', ' ')
        var season = 1; var ep = -1; var cut = n.length
        val m0 = pats[0].find(n)
        val m1 = pats[1].find(n)
        if (m0 != null) { season = m0.groupValues[1].toInt(); ep = m0.groupValues[2].toInt(); cut = m0.range.first }
        else if (m1 != null) { season = m1.groupValues[1].toInt(); ep = m1.groupValues[2].toInt(); cut = m1.range.first }
        else {
            val m2 = pats[2].find(n)
            if (m2 != null) { ep = m2.groupValues[1].toInt(); cut = m2.range.first }
            else {
                // a bare number: "Show - 05", the last number that is not a year
                val all = pats[3].findAll(n).toList().filter { it.groupValues[1].toInt() in 0..999 && !(it.groupValues[1].length == 4) }
                val m3 = all.lastOrNull()
                if (m3 != null) { ep = m3.groupValues[1].toInt(); cut = m3.range.first }
            }
        }
        var show = clean(n.substring(0, cut.coerceIn(0, n.length)))
        if (ep < 0) show = clean(n)
        val title = if (ep >= 0) {
            val e = if (ep < 10) "0$ep" else "$ep"
            (if (show.isNotEmpty()) "$show - " else "") + (if (season > 1) "S$season " else "") + "Ep $e"
        } else clean(n).ifEmpty { fileName }
        return Info(show.lowercase(), ep, season, title)
    }

    /** Natural order for names without an episode number: 2 before 10. */
    fun natural(a: String, b: String): Int {
        val ra = Regex("""\d+|\D+""").findAll(a.lowercase()).map { it.value }.toList()
        val rb = Regex("""\d+|\D+""").findAll(b.lowercase()).map { it.value }.toList()
        for (i in 0 until minOf(ra.size, rb.size)) {
            val x = ra[i]; val y = rb[i]
            val c = if (x[0].isDigit() && y[0].isDigit()) (x.toLongOrNull() ?: 0L).compareTo(y.toLongOrNull() ?: 0L) else x.compareTo(y)
            if (c != 0) return c
        }
        return ra.size.compareTo(rb.size)
    }

    /** Orders file names: by show, season, episode; names without a number by natural order. */
    fun sortKey(names: List<String>): List<Int> {
        val infos = names.map { parse(it) }
        return names.indices.sortedWith(Comparator { i, j ->
            val a = infos[i]; val b = infos[j]
            val c1 = a.show.compareTo(b.show)
            if (c1 != 0) return@Comparator c1
            if (a.ep >= 0 && b.ep >= 0) {
                val c2 = a.season.compareTo(b.season)
                if (c2 != 0) c2 else a.ep.compareTo(b.ep)
            } else natural(names[i], names[j])
        })
    }
}

package com.xio.bulwark

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.util.LruCache

/** Playlist covers: a generated angular pattern (5 styles) or your own photo. Static, no animation. */
object Cover {
    val names = listOf("Slash", "Grid", "Chevron", "Bars", "Frame")
    private val cache = object : LruCache<String, Bitmap>(24) {}
    private val clip = Path()
    private val tmp = Path()
    private val src = Rect()
    private val dst = RectF()

    fun photoKey(id: String) = "plc_$id"
    fun photo(c: Context, id: String): String = Prefs.str(c, photoKey(id), "")
    fun setPhoto(c: Context, id: String, uri: String) { Prefs.putStr(c, photoKey(id), uri); cache.remove(id) }

    private fun bitmap(c: Context, id: String): Bitmap? {
        val u = photo(c, id)
        if (u.isEmpty()) return null
        cache.get(id + u)?.let { return it }
        return try {
            val uri = Uri.parse(u)
            val o = BitmapFactory.Options(); o.inJustDecodeBounds = true
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var ss = 1
            while (o.outWidth / ss > 600 && o.outHeight / ss > 600) ss *= 2
            val o2 = BitmapFactory.Options(); o2.inSampleSize = ss
            val b = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (b != null) cache.put(id + u, b)
            b
        } catch (t: Throwable) { null }
    }

    /** Draws the cover of playlist [id] (style [style]) into the square l,t,r,b. */
    fun draw(c: Canvas, p: Paint, ctx: Context, id: String?, style: Int, name: String, l: Float, t: Float, r: Float, b: Float, d: Float, hot: Boolean) {
        val col = Faces.color(style)
        val cut = (r - l) * 0.2f
        CyUi.chamfer(clip, l, t, r, b, cut)
        p.shader = null
        p.style = Paint.Style.FILL; p.color = 0xFF0B1118.toInt(); c.drawPath(clip, p)
        val bm = if (id != null) bitmap(ctx, id) else null
        c.save()
        c.clipPath(clip)
        if (bm != null) {
            val bw = bm.width.toFloat(); val bh = bm.height.toFloat()
            val s = maxOf((r - l) / bw, (b - t) / bh)
            val cw = (r - l) / s; val ch = (b - t) / s
            src.set(((bw - cw) / 2f).toInt(), ((bh - ch) / 2f).toInt(), ((bw + cw) / 2f).toInt(), ((bh + ch) / 2f).toInt())
            dst.set(l, t, r, b)
            c.drawBitmap(bm, src, dst, p)
        } else {
            val w = r - l; val h = b - t
            p.style = Paint.Style.FILL; p.color = Cy.a(col, 0.12f); c.drawRect(l, t, r, b, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = maxOf(1f, w * 0.035f); p.color = Cy.a(col, 0.55f)
            when (style % 5) {
                0 -> { var x = l - h; while (x < r) { c.drawLine(x, b, x + h, t, p); x += w * 0.2f } }
                1 -> { var x = l; while (x <= r) { c.drawLine(x, t, x, b, p); x += w / 5f }; var y = t; while (y <= b) { c.drawLine(l, y, r, y, p); y += h / 5f } }
                2 -> { var y = t - h * 0.2f; while (y < b + h * 0.2f) { tmp.reset(); tmp.moveTo(l, y + h * 0.2f); tmp.lineTo((l + r) / 2f, y); tmp.lineTo(r, y + h * 0.2f); c.drawPath(tmp, p); y += h * 0.2f } }
                3 -> { p.style = Paint.Style.FILL; val bw = w / 9f; for (i in 0 until 5) { val bh = h * (0.3f + 0.12f * ((i * 3) % 5)); c.drawRect(l + bw * (1 + i * 1.6f), b - bh, l + bw * (1 + i * 1.6f) + bw, b, p) } }
                else -> { for (i in 1..3) { val m = w * 0.12f * i; c.drawRect(l + m, t + m, r - m, b - m, p) } }
            }
            val s1 = name.trim().take(1).uppercase()
            if (s1.isNotEmpty() && CyUi.supported(s1)) {
                val k = (b - t) / 11f * 0.5f
                CyUi.text(c, p, s1, (l + r) / 2f, (t + b) / 2f - 5f * k, k, col, 1f, false, 1)
            }
        }
        c.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = maxOf(1f, d * (if (hot) 1.8f else 1.2f))
        p.color = if (hot) CyUi.YELLOW else Cy.a(col, 0.8f)
        c.drawPath(clip, p)
        p.strokeWidth = maxOf(1.5f, d * 2f); p.color = Cy.PINK
        c.drawLine(l, t + (b - t) * 0.3f, l, t, p); c.drawLine(l, t, l + (r - l) * 0.3f, t, p)
    }
}

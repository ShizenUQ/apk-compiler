package com.xio.bulwark

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.os.SystemClock
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Beat source for the music faces. With the audio permission it reads the loudness of our own music
 * player (nothing is recorded). Without it, a steady fake rhythm is used while music plays.
 */
object Beat {
    @Volatile var level = 0f      // smoothed loudness 0..1
    @Volatile var kick = 0f       // jumps to 1 on every beat, then fades
    @Volatile var real = false

    private var vis: Visualizer? = null
    private var avg = 0.05f
    private var lastKick = 0L
    private var lastStep = 0L
    private var target = 0f
    private var fakeAt = 0L

    fun allowed(c: Context): Boolean =
        Prefs.bool(c, "beat_sync", true) &&
            c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun attach(c: Context, session: Int) {
        detach()
        if (!allowed(c) || session <= 0) return
        try {
            val v = Visualizer(session)
            val r = Visualizer.getCaptureSizeRange()
            v.setCaptureSize(min(1024, r[1]))
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vz: Visualizer?, w: ByteArray?, rate: Int) { }
                override fun onFftDataCapture(vz: Visualizer?, fft: ByteArray?, rate: Int) {
                    if (fft == null) return
                    val bins = fft.size / 2
                    var bass = 0f
                    var all = 0f
                    for (k in 1 until min(bins, 64)) {
                        val re = fft[2 * k].toInt().toFloat()
                        val im = fft[2 * k + 1].toInt().toFloat()
                        val m = hypot(re, im) / 128f
                        if (k <= 6) bass += m
                        all += m
                    }
                    bass /= 6f
                    all /= 63f
                    target = min(1f, all * 3.2f)
                    val now = SystemClock.uptimeMillis()
                    if (bass > avg * 1.3f + 0.06f && now - lastKick > 170) { kick = 1f; lastKick = now }
                    avg = avg * 0.92f + bass * 0.08f
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            v.setEnabled(true)
            vis = v
            real = true
        } catch (t: Throwable) {
            vis = null
            real = false
        }
    }

    fun detach() {
        try { vis?.setEnabled(false) } catch (t: Throwable) { }
        try { vis?.release() } catch (t: Throwable) { }
        vis = null
        real = false
        target = 0f
    }

    /** Call once per drawn frame. */
    fun step(playing: Boolean) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastStep == 0L) 0.033f else min(0.1f, (now - lastStep) / 1000f)
        if (now - lastStep < 6) return
        lastStep = now
        if (!playing) target = 0f
        else if (!real) {
            if (now - fakeAt > 480) { fakeAt = now; kick = 1f }
            target = 0.45f + 0.3f * ((now / 240) % 3) / 2f
        }
        level += (target - level) * min(1f, dt * 9f)
        kick = max(0f, kick - dt * 3.4f)
    }
}

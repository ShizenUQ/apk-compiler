package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.roundToInt

/**
 * The overlay drawing. Three designs (0 glass, 1 gauge, 2 pill) x three sizes (0 full, 1 compact, 2 dot).
 * Everything is drawn by hand in "design units" (1 unit = 1dp at 100% size). Touch lives in HudRoot.
 * Animation only runs while something is moving.
 */
class HudView(private val ctx: Context) : View(ctx) {

    var onTick: (() -> Unit)? = null
    var hasVideo = false
        set(v) {
            if (field != v) { field = v; if (prefsLoaded) retarget() }
        }
    var hasImage = false
        set(v) {
            if (field != v) { field = v; if (prefsLoaded) retarget() }
        }
    private val hasMedia get() = hasVideo || hasImage
    var locked = false
        private set

    private val dens = resources.displayMetrics.density
    private var sc = 1f
    private var laidSc = -1f
    private var style = 0
    private var modePref = 0
    private var collapsed = false
    private var showGraph = true
    private var showBars = true
    private var showFooter = true
    private var targetFps = 60

    private var data = FpsData.na("NOLINK")
    private var sys: SysData? = null

    private var dispFps = 0f
    private var reveal = 0f
    private var flash = 0f
    private var sheenStart = -100000L
    private var lastState = 0
    private var lastFrameT = 0L
    private var running = false

    // size transition
    private var initialized = false
    private var prefsLoaded = false
    private var curW = 0f
    private var curH = 0f
    private var fromW = 0f
    private var fromH = 0f
    private var toW = 0f
    private var toH = 0f
    private var tAnim = 1f
    private var tgtStyle = 0
    private var tgtMode = 0
    private var shownStyle = 0
    private var shownMode = 0
    private var mediaWanted = false

    // paints
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val num = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    private val lab = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val mono = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    private val plate = Path()
    private val sheen = Path()
    private val tmp = RectF()
    private val fpsNum = CyNumber()
    private var fx = true
    private val wave = Path()
    private val waveFill = Path()
    private val cell = Path()
    private val cyP = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cachedH = -1f

    companion object {
        const val GLASS_W = 188f
        const val GAUGE_W = 176f
        const val MEDIA_W = 60f
        const val MEDIA_H = 34f
    }

    // ---------------- loop ----------------

    private val ticker = object : Runnable {
        override fun run() {
            advance()
            invalidate()
            onTick?.invoke()
            if (needAnim()) {
                if (reveal < 1f || tAnim < 1f) postOnAnimation(this) else postDelayed(this, 30)
            } else running = false
        }
    }

    private val sheenLoop = object : Runnable {
        override fun run() {
            sheenStart = SystemClock.uptimeMillis()
            kick()
            postDelayed(this, 9000)
        }
    }

    private fun kick() {
        if (!running) {
            running = true
            lastFrameT = SystemClock.uptimeMillis()
            postOnAnimation(ticker)
        }
    }

    private fun needAnim(): Boolean {
        val now = SystemClock.uptimeMillis()
        return reveal < 1f || tAnim < 1f || flash > 0f ||
            (data.fps >= 0f && abs(dispFps - data.fps) > 0.01f) || now - sheenStart < 950 ||
            (musicOn() && Music.playing) || (fx && data.fps >= 0f) || glitchLevel() > 0.08f ||
            (nyxOn() && brain.busy(now))
    }

    // ---------------- music (glass, full size only) ----------------

    private var musicCount = 0
    private var vidCount = 0

    private fun nyxOn() = nyxPref && shownStyle == 0 && shownMode == 0

    private fun sessionSecs(s: String): Long {
        val p = s.split(":")
        return try { if (p.size == 3) p[0].toLong() * 3600 + p[1].toLong() * 60 + p[2].toLong() else 0L } catch (t: Throwable) { 0L }
    }

    /** Tap on the Nyx bar: she reacts. */
    fun nyxPoke() {
        brain.poke(SystemClock.uptimeMillis()) { nyxFit(it) }
        kick()
        invalidate()
    }

    fun nyxHit(): RectF? {
        if (!nyxOn() || tAnim < 1f || reveal < 1f) return null
        return RectF(8f, 54f, GLASS_W - 8f, 91f)
    }

    private fun playerOn() = vidCount > 0

    private val TAB_H = 7f
    private fun tabH() = if (playerOn()) TAB_H else 0f
    private fun tabX0() = 10f
    private fun tabX1() = min(tabX0() + 74f, curW - 12f)

    /** Player tab hanging under the status, in design units. */
    fun playerHit(): RectF? {
        if (!playerOn() || reveal < 1f || curW < 40f) return null
        return RectF(tabX0() - 2f, curH - 2.5f, tabX1() + 3f, curH + TAB_H)
    }

    /** `|______/` : a thin shelf under the status edge: straight left side, flat bottom, slanted right end. */
    private fun drawPlayerTab(c: Canvas) {
        val x0 = tabX0(); val x1 = tabX1(); val top = curH - 0.6f; val bot = curH + TAB_H - 0.8f
        val on = PlayerState.open || PlayerState.listOpen
        mp.reset()
        mp.moveTo(x0, top); mp.lineTo(x0, bot); mp.lineTo(x1 - 6f, bot); mp.lineTo(x1, top)
        fill.color = Cy.a(0xFF090C12.toInt(), 0.92f)
        mp.close()
        c.drawPath(mp, fill)
        line.strokeWidth = 0.8f
        line.color = Cy.a(Cy.CYAN, if (on) 0.95f else 0.55f)
        c.drawPath(mp, line)
        line.strokeWidth = 1.5f
        line.color = Cy.PINK
        c.drawLine(x0, top + 0.5f, x0, bot, line)
        // little play mark
        mp.reset()
        mp.moveTo(x0 + 5f, curH + 1.3f); mp.lineTo(x0 + 9.6f, curH + TAB_H * 0.5f + 0.2f); mp.lineTo(x0 + 5f, bot - 1.3f); mp.close()
        fill.color = if (PlayerState.playing) CyUi.YELLOW else Cy.CYAN
        c.drawPath(mp, fill)
        // thin progress line along the bottom
        val lx0 = x0 + 14f; val lx1 = x1 - 11f
        if (lx1 > lx0 + 4f) {
            line.strokeWidth = 0.9f
            line.color = Cy.a(Cy.CYAN, 0.3f)
            c.drawLine(lx0, bot - 2f, lx1, bot - 2f, line)
            val fr = PlayerState.frac
            if (fr > 0.005f) {
                line.color = CyUi.YELLOW
                c.drawLine(lx0, bot - 2f, lx0 + (lx1 - lx0) * fr, bot - 2f, line)
            }
        }
    }

    private fun musicOn() = musicCount > 0 && shownStyle == 0 && shownMode == 0

    private fun hasTrack() = Music.index >= 0

    /** Touch areas in design units: [0] list icon, then (when a song is chosen) [1] previous, [2] play / pause, [3] next. */
    fun musicHits(): List<RectF>? {
        if (!musicOn() || tAnim < 1f || reveal < 1f) return null
        val l = arrayListOf(RectF(72f, 5f, 92f, 24f))
        if (hasTrack()) {
            l.add(RectF(94f, 5f, 110f, 24f))
            l.add(RectF(111f, 5f, 129f, 24f))
            l.add(RectF(130f, 5f, 146f, 24f))
        }
        return l
    }

    fun poke() { kick(); invalidate() }

    private val mp = Path()
    private val brain = NyxBrain()
    private var nyxPref = true
    private val nyxP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val artP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val nyxFace = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun drawMusic(c: Canvas, acc: Int) {
        val now = SystemClock.uptimeMillis()
        val t = now / 1000f
        val playing = Music.playing
        val open = Music.panelOpen
        // one control plate with two cut corners
        mp.reset()
        mp.moveTo(75f, 5.5f); mp.lineTo(160f, 5.5f); mp.lineTo(160f, 21f); mp.lineTo(157f, 24f)
        mp.lineTo(72f, 24f); mp.lineTo(72f, 8.5f); mp.close()
        fill.color = if (open) 0x2619E6F2 else 0x1219E6F2
        c.drawPath(mp, fill)
        line.strokeWidth = 0.8f
        line.color = if (open || playing) Cy.a(Cy.CYAN, 0.85f) else Cy.a(Cy.CYAN, 0.38f)
        c.drawPath(mp, line)
        line.strokeWidth = 0.6f
        line.color = Cy.a(Cy.CYAN, 0.22f)
        c.drawLine(93f, 8f, 93f, 21.5f, line)
        // note
        line.strokeWidth = 1.3f
        line.strokeCap = Paint.Cap.ROUND
        line.color = if (open || playing) Cy.CYAN else 0xFFB4C2CF.toInt()
        c.drawLine(84.4f, 17f, 84.4f, 9.6f, line)
        c.drawLine(84.4f, 9.6f, 87.6f, 11.8f, line)
        fill.color = line.color
        c.drawCircle(82.4f, 17.4f, 2.1f, fill)
        line.strokeCap = Paint.Cap.BUTT
        if (!hasTrack()) return
        val col = 0xFFE6EDF3.toInt()
        fill.color = col
        mp.reset()
        mp.moveTo(106f, 10f); mp.lineTo(99f, 14.5f); mp.lineTo(106f, 19f); mp.close()
        c.drawPath(mp, fill)
        tmp.set(97f, 10f, 98.6f, 19f)
        c.drawRect(tmp, fill)
        mp.reset()
        mp.moveTo(134f, 10f); mp.lineTo(141f, 14.5f); mp.lineTo(134f, 19f); mp.close()
        c.drawPath(mp, fill)
        tmp.set(141.4f, 10f, 143f, 19f)
        c.drawRect(tmp, fill)
        // play: hexagon, with an electric arc running around it while playing
        mp.reset()
        for (i in 0..5) {
            val a = i * 1.0472f
            val px = 120f + 7.8f * kotlin.math.cos(a)
            val py = 14.5f + 7.8f * kotlin.math.sin(a)
            if (i == 0) mp.moveTo(px, py) else mp.lineTo(px, py)
        }
        mp.close()
        if (playing) {
            fill.color = Cy.a(0xFF3DDC97.toInt(), 0.22f)
            c.drawPath(mp, fill)
            line.strokeWidth = 1.2f
            line.color = 0xFF3DDC97.toInt()
            c.drawPath(mp, line)
            tmp.set(120f - 9.6f, 14.5f - 9.6f, 120f + 9.6f, 14.5f + 9.6f)
            line.strokeWidth = 1.3f
            line.strokeCap = Paint.Cap.ROUND
            line.color = Cy.CYAN
            c.drawArc(tmp, (t * 220f) % 360f, 62f, false, line)
            line.color = Cy.a(Cy.CYAN, 0.4f)
            c.drawArc(tmp, (t * 220f + 180f) % 360f, 30f, false, line)
            line.strokeCap = Paint.Cap.BUTT
            fill.color = 0xFF3DDC97.toInt()
            tmp.set(117.4f, 10.4f, 119.3f, 18.6f); c.drawRect(tmp, fill)
            tmp.set(120.9f, 10.4f, 122.8f, 18.6f); c.drawRect(tmp, fill)
        } else {
            line.strokeWidth = 1f
            line.color = 0x80FFFFFF.toInt()
            c.drawPath(mp, line)
            fill.color = col
            mp.reset()
            mp.moveTo(118.2f, 10.7f); mp.lineTo(123.6f, 14.5f); mp.lineTo(118.2f, 18.3f); mp.close()
            c.drawPath(mp, fill)
        }
        // small angular equalizer: five cut bars that follow the beat, flat when paused
        Beat.step(playing)
        fill.style = Paint.Style.FILL
        for (i in 0 until 5) {
            val ph = t * (5.2f + i * 1.3f) + i * 1.9f
            val lvl = if (playing) (0.25f + 0.55f * Beat.level * (0.6f + 0.4f * sin(ph)) + 0.25f * Beat.kick * (if (i % 2 == 0) 1f else 0.6f)).coerceIn(0.12f, 1f) else 0.12f
            val bh = 14f * lvl
            val x0 = 145.5f + i * 3.1f
            mp.reset()
            mp.moveTo(x0, 21.5f); mp.lineTo(x0, 21.5f - bh + 1.2f); mp.lineTo(x0 + 1.2f, 21.5f - bh); mp.lineTo(x0 + 2.2f, 21.5f - bh); mp.lineTo(x0 + 2.2f, 21.5f); mp.close()
            fill.color = if (i == 4 || (playing && lvl > 0.85f)) Cy.PINK else Cy.a(Cy.CYAN, if (playing) 0.95f else 0.5f)
            c.drawPath(mp, fill)
        }
        line.style = Paint.Style.STROKE
    }

    private fun Neon_a(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun advance() {
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastFrameT).coerceIn(1L, 64L).toFloat()
        lastFrameT = now
        if (reveal < 1f) reveal = min(1f, reveal + dt / 420f)
        if (tAnim < 1f) {
            tAnim = min(1f, tAnim + dt / 280f)
            val e = tAnim * tAnim * (3f - 2f * tAnim)
            curW = fromW + (toW - fromW) * e
            curH = fromH + (toH - fromH) * e
            if (tAnim >= 0.5f) { shownStyle = tgtStyle; shownMode = tgtMode }
            requestLayout()
        }
        if (data.fps >= 0f) {
            val diff = data.fps - dispFps
            dispFps = if (abs(diff) < 0.4f) data.fps else dispFps + diff * min(1f, dt / 110f)
        } else dispFps = 0f
        if (flash > 0f) flash = max(0f, flash - dt / 750f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        reveal = 0f
        postDelayed(sheenLoop, 1500)
        kick()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(sheenLoop)
        removeCallbacks(ticker)
        running = false
        super.onDetachedFromWindow()
    }

    // ---------------- public api ----------------

    fun scalePx(): Float = dens * sc

    fun applyPrefs() {
        sc = Prefs.int(ctx, Prefs.SCALE, 100) / 100f
        style = Prefs.int(ctx, Prefs.STYLE, 0).coerceIn(0, 2)
        modePref = Prefs.int(ctx, Prefs.MODE, 0).coerceIn(0, 2)
        collapsed = Prefs.bool(ctx, Prefs.COLLAPSED, false)
        showGraph = Prefs.bool(ctx, Prefs.GRAPH, true)
        showBars = Prefs.bool(ctx, Prefs.BARS, true)
        showFooter = Prefs.bool(ctx, Prefs.FOOTER, true)
        targetFps = Prefs.int(ctx, Prefs.TARGET, 60)
        locked = Prefs.bool(ctx, Prefs.LOCKED, false)
        fx = Prefs.bool(ctx, Prefs.EFFECTS, true)
        musicCount = Music.count(ctx)
        vidCount = VideoLib.videos(ctx).size
        nyxPref = Prefs.bool(ctx, Prefs.NYX, true)
        brain.freq = Prefs.int(ctx, Prefs.NYX_FREQ, 1)
        prefsLoaded = true
        retarget()
    }

    fun update(d: FpsData, s: SysData) {
        data = d
        sys = s
        if (nyxPref && shownStyle == 0) {
            brain.feed(SystemClock.uptimeMillis(), d.fps, targetFps, s.temp, s.bat, s.charging, Music.playing, sessionSecs(s.session)) { nyxFit(it) }
        }
        val st = stateOf(d)
        if (st > lastState && lastState != 0) flash = 1f
        lastState = st
        kick()
        invalidate()
    }

    fun toggleFold() {
        collapsed = !collapsed
        Prefs.putBool(ctx, Prefs.COLLAPSED, collapsed)
        retarget()
    }

    /** The only spot that folds / unfolds the status: the FPS number itself (or the whole thing when it is already just the FPS). */
    fun foldHit(): RectF? = when {
        shownMode != 0 || shownStyle == 2 -> RectF(0f, 0f, curW, curH)
        shownStyle == 1 -> RectF(0f, 0f, GAUGE_W - 32f, curH)
        else -> RectF(0f, 0f, 72f, 52f)
    }

    /** Lock icon touch area in design units, or null when there is no lock icon on screen. */
    fun lockHit(): RectF? {
        if (tAnim < 1f || reveal < 1f) return null
        return when (shownStyle) {
            2 -> if (locked) RectF(0f, 0f, 26f, curH) else null
            else -> if (shownMode == 0) (if (shownStyle == 0) RectF(GLASS_W - 32f, 0f, GLASS_W, 24f) else RectF(GAUGE_W - 32f, 0f, GAUGE_W, 22f))
            else if (locked) RectF(curW - 22f, 0f, curW, 20f) else null
        }
    }

    private fun colReady() = mediaWanted && tAnim >= 1f && reveal >= 1f && shownMode == 0

    private fun toPx(r: RectF): Rect {
        val s = scalePx()
        return Rect((r.left * s).roundToInt(), (r.top * s).roundToInt(), (r.right * s).roundToInt(), (r.bottom * s).roundToInt())
    }

    /** The video screen (top of the right-hand column), in pixels, or null. */
    fun videoRect(): Rect? {
        if (!hasVideo || !colReady()) return null
        return toPx(when (shownStyle) {
            0 -> { val bt = glassH() - 6f; if (hasImage) RectF(GLASS_W, 12f, GLASS_W + MEDIA_W, 12f + (bt - 12f) * 0.4f) else RectF(GLASS_W, 12f, GLASS_W + MEDIA_W, bt) }
            1 -> RectF(GAUGE_W, 21f, GAUGE_W + MEDIA_W, 21f + MEDIA_H)
            else -> RectF(baseSize(2, 0)[0] - 2f, 4f, baseSize(2, 0)[0] + 46f, 30f)
        })
    }

    /** The image screen (below the video screen), in pixels, or null. Gauge / Pill only show it when there is no video. */
    fun imageRect(): Rect? {
        if (!hasImage || !colReady()) return null
        return toPx(when (shownStyle) {
            0 -> { val bt = glassH() - 6f; if (hasVideo) RectF(GLASS_W, 12f + (bt - 12f) * 0.4f + 6f, GLASS_W + MEDIA_W, bt) else RectF(GLASS_W, 12f, GLASS_W + MEDIA_W, bt) }
            1 -> if (hasVideo) return null else RectF(GAUGE_W, 21f, GAUGE_W + MEDIA_W, 21f + MEDIA_H)
            else -> if (hasVideo) return null else RectF(baseSize(2, 0)[0] - 2f, 4f, baseSize(2, 0)[0] + 46f, 30f)
        })
    }

    // ---------------- sizes ----------------

    private fun glassH() = if (nyxPref) 109f else if (showFooter) 88f else 70f
    private fun gaugeBe() = if (showBars) 76f else 68f
    private fun gaugeH() = gaugeBe() + (if (showFooter) 16f else 0f)

    private fun baseSize(st: Int, md: Int): FloatArray = when (st) {
        0 -> when (md) {
            0 -> floatArrayOf(GLASS_W, glassH())
            1 -> floatArrayOf(132f, 38f)
            else -> floatArrayOf(54f, 30f)
        }
        1 -> when (md) {
            0 -> floatArrayOf(GAUGE_W, gaugeH())
            1 -> floatArrayOf(120f, 62f)
            else -> floatArrayOf(46f, 46f)
        }
        else -> when (md) {
            0 -> floatArrayOf(if (showBars) 172f else 122f, 34f)
            1 -> floatArrayOf(108f, 34f)
            else -> floatArrayOf(46f, 30f)
        }
    }

    private fun mediaExtra(st: Int) = if (st == 2) 54f else 70f

    private fun retarget() {
        val eff = if (collapsed) 2 else modePref
        val med = hasMedia && eff == 0
        val bs = baseSize(style, eff)
        val w = bs[0] + (if (med) mediaExtra(style) else 0f)
        val h = bs[1]
        if (laidSc != sc) { laidSc = sc; requestLayout(); invalidate() }
        if (initialized && style == tgtStyle && eff == tgtMode && w == toW && h == toH && med == mediaWanted) return
        tgtStyle = style
        tgtMode = eff
        mediaWanted = med
        if (!initialized) {
            initialized = true
            curW = w; curH = h; fromW = w; fromH = h; toW = w; toH = h
            shownStyle = style; shownMode = eff
            tAnim = 1f
        } else {
            fromW = curW; fromH = curH; toW = w; toH = h
            tAnim = 0f
        }
        requestLayout()
        kick()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = scalePx()
        setMeasuredDimension((curW * s).roundToInt(), ((curH + tabH()) * s).roundToInt())
    }

    // ---------------- helpers ----------------

    /** 0 = no data, 1 = good, 2 = mid, 3 = bad */
    private fun stateOf(d: FpsData): Int {
        if (d.fps < 0f) return 0
        val r = d.fps / targetFps
        return if (r >= 0.9f) 1 else if (r >= 0.7f) 2 else 3
    }

    private fun accent(st: Int) = when (st) {
        1 -> P.GOOD; 2 -> P.MID; 3 -> P.BAD; else -> P.DIM
    }

    /** 0 = smooth, up to 1 = signal dying. Only while a game is really being read. */
    private fun glitchLevel(): Float {
        if (data.status != "OK" || data.fps < 0f || data.fps >= 30f) return 0f
        return Math.pow(((30f - data.fps) / 30f).coerceIn(0f, 1f).toDouble(), 0.75).toFloat()
    }

    private fun drawFps(c: Canvas, x: Float, base: Float, h: Float, color: Int, center: Boolean) {
        val now = SystemClock.uptimeMillis()
        fpsNum.set(fpsStr(), now)
        fpsNum.draw(c, x, base, h, color, center, glitchLevel(), fx, now)
        if (fx && flash > 0.3f) fpsNum.burst(c, x, base, h, center, now)
    }

    private fun numW(h: Float) = Cy.width(fpsStr().length, h / 10f)

    private fun cyVal(c: Canvas, v: String, x: Float, base: Float, h: Float, color: Int) {
        val pct = v.endsWith("%")
        val sv = v.removeSuffix("%")
        val w = Cy.text(c, cyP, sv, x, base, h, color)
        if (pct) t(c, "%", x + w + 1.2f, base, 5.5f, P.DIM, lab, Paint.Align.LEFT)
    }

    private fun f1(v: Float) = String.format(Locale.US, "%.1f", v)
    private fun fpsStr() = if (data.fps < 0f) "--" else dispFps.roundToInt().toString()
    private fun ftStr() = if (data.ft > 0f) f1(data.ft) else "--"
    private fun lowStr() = if (data.low > 0f) data.low.roundToInt().toString() else "--"
    private fun cpuStr() = if (data.cpu >= 0f) data.cpu.roundToInt().toString() + "%" else "--"
    private fun ramFrac() = sys?.ram ?: -1f
    private fun ramStr() = if (ramFrac() >= 0f) (ramFrac() * 100f).roundToInt().toString() + "%" else "--"

    private fun statusText(): String = when (data.status) {
        "OK" -> "LIVE"
        "SELF" -> "OPEN A GAME"
        "NOLINK" -> "CONNECTING..."
        "STALE" -> "NO NEW FRAMES"
        "NOLAYER" -> "NO GAME LAYER"
        "NOPKG" -> "NO APP FOUND"
        "NOFRAMES" -> "NO FRAMES"
        "ERR" -> "READER ERROR"
        else -> data.status
    }

    private fun t(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, face: Typeface, al: Paint.Align, ls: Float = 0f) {
        txt.typeface = face
        txt.textSize = size
        txt.color = color
        txt.textAlign = al
        txt.letterSpacing = ls
        c.drawText(s, x, y, txt)
    }

    // ---------------- drawing ----------------

    override fun onDraw(canvas: Canvas) {
        val w = curW
        val h = curH
        if (w <= 0f) return
        val s = scalePx()
        canvas.save()
        canvas.scale(s, s)
        var layer = -1
        if (reveal < 1f) {
            val e = reveal * reveal * (3f - 2f * reveal)
            val k = 0.88f + 0.12f * e
            canvas.scale(k, k, w / 2f, h / 2f)
            layer = canvas.saveLayerAlpha(0f, 0f, w, h, (255 * e).toInt())
        }
        val rad = when (shownStyle) { 0 -> 11f; 1 -> 16f; else -> min(h / 2f, 17f) }
        tmp.set(0.6f, 0.6f, w - 0.6f, h - 0.6f)
        plate.reset()
        plate.addRoundRect(tmp, rad, rad, Path.Direction.CW)
        if (abs(h - cachedH) > 0.4f) {
            body.shader = LinearGradient(0f, 0f, 0f, h, P.BG_TOP, P.BG_BOT, Shader.TileMode.CLAMP)
            cachedH = h
        }
        canvas.drawPath(plate, body)
        line.strokeWidth = 0.9f
        if (flash > 0f) { line.color = P.BAD; line.alpha = (50 + flash * 200).toInt() } else line.color = P.EDGE
        canvas.drawPath(plate, line)

        val st = stateOf(data)
        when (shownStyle) {
            0 -> drawGlass(canvas, w, h, st)
            1 -> drawGauge(canvas, w, h, st)
            else -> drawPill(canvas, w, h, st)
        }
        if (locked && shownMode != 0 && shownStyle != 2) lockIcon(canvas, w - 10f, 9f, 0.7f)

        val sp = (SystemClock.uptimeMillis() - sheenStart) / 900f
        if (sp in 0f..1f) {
            val cx = -30f + sp * (w + 60f)
            canvas.save()
            canvas.clipPath(plate)
            sheen.reset()
            sheen.moveTo(cx, 0f); sheen.lineTo(cx + 9f, 0f); sheen.lineTo(cx - 5f, h); sheen.lineTo(cx - 14f, h); sheen.close()
            fill.color = 0x16FFFFFF
            canvas.drawPath(sheen, fill)
            canvas.restore()
        }
        if (layer >= 0) canvas.restoreToCount(layer)
        if (playerOn() && reveal >= 0.99f) drawPlayerTab(canvas)
        canvas.restore()
    }

    private fun lockIcon(c: Canvas, cx: Float, cy: Float, k: Float = 1f) {
        val col = if (locked) P.MID else P.DIM
        c.save()
        c.translate(cx, cy)
        c.scale(k, k)
        fill.color = col
        tmp.set(-4f, -0.5f, 4f, 5f)
        c.drawRoundRect(tmp, 1.2f, 1.2f, fill)
        line.color = col
        line.strokeWidth = 1.3f
        if (locked) {
            tmp.set(-2.7f, -5f, 2.7f, 1f)
            c.drawArc(tmp, 180f, 180f, false, line)
            c.drawLine(-2.7f, -2f, -2.7f, 0f, line)
            c.drawLine(2.7f, -2f, 2.7f, 0f, line)
        } else {
            tmp.set(0.3f, -6f, 5.7f, 0f)
            c.drawArc(tmp, 180f, 180f, false, line)
            c.drawLine(0.3f, -3f, 0.3f, -0.5f, line)
        }
        c.restore()
    }

    private fun miniBar(c: Canvas, x: Float, y: Float, w: Float, frac: Float) {
        fill.color = P.TRACK
        tmp.set(x, y, x + w, y + 2.4f)
        c.drawRoundRect(tmp, 1.2f, 1.2f, fill)
        val f = frac.coerceIn(0f, 1f)
        if (f > 0.01f) {
            fill.color = if (f < 0.6f) P.GOOD else if (f < 0.85f) P.MID else P.BAD
            tmp.set(x, y, x + w * f, y + 2.4f)
            c.drawRoundRect(tmp, 1.2f, 1.2f, fill)
        }
    }

    private fun footer(c: Canvas, w: Float, yLine: Float, yText: Float) {
        line.strokeWidth = 0.7f
        line.color = 0x22FFFFFF
        c.drawLine(10f, yLine, w - 10f, yLine, line)
        val sy = sys
        t(c, sy?.clock ?: "--:--", 12f, yText, 7.5f, P.TEXT, mono, Paint.Align.LEFT)
        val bat = if (sy == null || sy.bat < 0) "--" else sy.bat.toString() + "%" + (if (sy.charging) "+" else "")
        val tp = if (sy == null || sy.temp <= 0f) "" else "  " + sy.temp.roundToInt() + "°C"
        t(c, "BAT $bat$tp", w / 2f, yText, 7.5f, P.DIM, mono, Paint.Align.CENTER)
        t(c, sy?.session ?: "00:00:00", w - 12f, yText, 7.5f, P.LABEL, mono, Paint.Align.RIGHT)
    }

    private fun graph(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        val gh = y1 - y0
        val now = SystemClock.uptimeMillis()
        tmp.set(x0, y0, x1, y1)
        fill.color = 0x59000000
        c.drawRoundRect(tmp, 3f, 3f, fill)
        line.strokeWidth = 0.6f
        line.color = 0x3319E6F2
        c.drawRoundRect(tmp, 3f, 3f, line)
        val targetFt = 1000f / targetFps
        val maxMs = targetFt * 2.2f
        val ty = y1 - 2f - (targetFt / maxMs).coerceAtMost(1f) * (gh - 4f)
        line.strokeWidth = 0.6f
        line.color = 0x40FFFFFF
        var dx = x0 + 3f
        while (dx < x1 - 4f) { c.drawLine(dx, ty, dx + 2f, ty, line); dx += 4.5f }
        val fr = data.frames
        if (fr.isEmpty()) {
            line.strokeWidth = 0.8f
            line.color = P.TRACK
            c.drawLine(x0 + 3f, y1 - 4f, x1 - 3f, y1 - 4f, line)
            t(c, statusText(), (x0 + x1) / 2f, (y0 + y1) / 2f + 2f, 7f, P.DIM, lab, Paint.Align.CENTER, 0.1f)
            return
        }
        val acc = accent(stateOf(data))
        val n = min(48, fr.size)
        val stepX = (x1 - x0 - 6f) / 47f
        c.save()
        c.clipRect(tmp)
        wave.reset()
        waveFill.reset()
        var lx = 0f
        var ly = 0f
        for (i in 0 until n) {
            val ms = fr[fr.size - n + i]
            val px = x1 - 3f - (n - 1 - i) * stepX
            val py = y1 - 2f - (ms / maxMs).coerceIn(0.05f, 1f) * (gh - 4f)
            if (i == 0) {
                wave.moveTo(px, py)
                waveFill.moveTo(px, y1 - 1f)
                waveFill.lineTo(px, py)
            } else {
                wave.lineTo(px, py)
                waveFill.lineTo(px, py)
            }
            lx = px; ly = py
        }
        waveFill.lineTo(lx, y1 - 1f)
        waveFill.close()
        fill.shader = LinearGradient(0f, y0, 0f, y1, Cy.a(acc, 0.4f), Cy.a(acc, 0f), Shader.TileMode.CLAMP)
        c.drawPath(waveFill, fill)
        fill.shader = null
        line.strokeJoin = Paint.Join.MITER
        line.strokeWidth = 3.2f
        line.color = Cy.a(acc, 0.22f)
        c.drawPath(wave, line)
        line.strokeWidth = 1.1f
        line.color = acc
        c.drawPath(wave, line)
        // slow frames: red segments, with a spark on the worst ones
        var ppx = 0f
        var ppy = 0f
        for (i in 0 until n) {
            val ms = fr[fr.size - n + i]
            val px = x1 - 3f - (n - 1 - i) * stepX
            val py = y1 - 2f - (ms / maxMs).coerceIn(0.05f, 1f) * (gh - 4f)
            if (i > 0 && ms > targetFt * 1.7f) {
                line.strokeWidth = 1.3f
                line.color = P.BAD
                c.drawLine(ppx, ppy, px, py, line)
                if (fx && ms > targetFt * 2.1f && Cy.rnd((now / 120L).toInt() + i) < 0.5f) {
                    line.strokeWidth = 0.7f
                    line.color = Cy.a(0xFFFFC0B8.toInt(), 0.9f)
                    Cy.arc(c, line, px, py, px + (Cy.rnd(i * 3 + (now / 120L).toInt()) - 0.5f) * 5f, py - 4.5f, i, 0.9f)
                }
            }
            ppx = px; ppy = py
        }
        if (fx) {
            // scan sweep
            val sx = x0 + ((now % 2400L) / 2400f) * (x1 - x0 + 30f) - 15f
            fill.shader = LinearGradient(sx - 14f, 0f, sx + 14f, 0f,
                intArrayOf(0, Cy.a(Cy.CYAN, 0.28f), 0), null, Shader.TileMode.CLAMP)
            c.drawRect(sx - 14f, y0, sx + 14f, y1, fill)
            fill.shader = null
            // leading dot
            val pl = 0.5f + 0.5f * kotlin.math.sin(now / 180f)
            fill.color = Cy.a(acc, 0.35f)
            c.drawCircle(lx, ly, 3.4f + 1.3f * pl, fill)
            fill.color = 0xFFFFFFFF.toInt()
            c.drawCircle(lx, ly, 1.5f, fill)
        }
        c.restore()
    }

    /** Segmented energy cells with a spark at the edge of the charge. */
    private fun cellBar(c: Canvas, x: Float, y: Float, w: Float, frac: Float) {
        val n = 10
        val gap = 1f
        val cw = (w - gap * (n - 1)) / n
        val hh = 3f
        val sk = 1f
        val f = frac.coerceIn(0f, 1f)
        val lit = f * n
        val col = if (f < 0.6f) P.GOOD else if (f < 0.85f) P.MID else P.BAD
        val now = SystemClock.uptimeMillis()
        for (i in 0 until n) {
            val x0 = x + i * (cw + gap)
            val amt = (lit - i).coerceIn(0f, 1f)
            cell.reset()
            cell.moveTo(x0 + sk, y)
            cell.lineTo(x0 + cw + sk, y)
            cell.lineTo(x0 + cw, y + hh)
            cell.lineTo(x0, y + hh)
            cell.close()
            if (amt <= 0.01f) {
                fill.color = P.TRACK
            } else {
                var al = 0.32f + 0.68f * amt
                if (fx && f > 0.85f && Cy.rnd((now / 80L).toInt() * 13 + i) < 0.12f) al = 0.3f
                fill.color = Cy.a(col, al)
            }
            c.drawPath(cell, fill)
        }
        if (fx && f > 0.03f && now % 700L < 120L) {
            val li = min(n - 1, kotlin.math.ceil(lit.toDouble()).toInt() - 1).coerceAtLeast(0)
            val ex = x + li * (cw + gap) + cw * 0.7f
            line.strokeWidth = 0.7f
            line.color = Cy.a(0xFFFFFFFF.toInt(), 0.9f)
            Cy.arc(c, line, ex, y + 1f, ex + 2f, y - 3.6f, (now / 700L).toInt() + li, 0.9f)
        }
    }

    private fun ring(c: Canvas, cx: Float, cy: Float, r: Float, sw: Float, acc: Int) {
        tmp.set(cx - r, cy - r, cx + r, cy + r)
        line.strokeWidth = sw
        line.strokeCap = Paint.Cap.ROUND
        line.color = P.TRACK
        c.drawArc(tmp, 135f, 270f, false, line)
        val frac = if (data.fps < 0f) 0f else (dispFps / targetFps).coerceIn(0f, 1f)
        if (flash > 0f) {
            line.color = P.BAD
            line.alpha = (flash * 90).toInt()
            line.strokeWidth = sw + 4f
            c.drawArc(tmp, 135f, 270f, false, line)
            line.strokeWidth = sw
        }
        if (frac > 0.01f) {
            line.color = acc
            c.drawArc(tmp, 135f, 270f * frac, false, line)
        }
        line.strokeCap = Paint.Cap.BUTT
    }

    // ---------------- design 0: glass ----------------

    private fun drawGlass(c: Canvas, w: Float, h: Float, st: Int) {
        val acc = accent(st)
        line.strokeWidth = 2f
        line.strokeCap = Paint.Cap.ROUND
        line.color = acc
        c.drawLine(14f, 1.4f, 40f, 1.4f, line)
        line.strokeCap = Paint.Cap.BUTT
        val str = fpsStr()
        when (shownMode) {
            2 -> {
                fill.color = acc
                tmp.set(8f, 8f, 10.5f, h - 8f)
                c.drawRoundRect(tmp, 1.2f, 1.2f, fill)
                drawFps(c, w / 2f + 3f, h / 2f + 5.5f, 11f, acc, true)
            }
            1 -> {
                drawFps(c, 10f, 28f, 16f, acc, false)
                t(c, ftStr() + " ms", w - 10f, 17f, 8f, P.TEXT, mono, Paint.Align.RIGHT)
                t(c, "LOW " + lowStr(), w - 10f, 30f, 7f, P.DIM, mono, Paint.Align.RIGHT)
            }
            else -> {
                t(c, "FPS", 12f, 18f, 7f, P.LABEL, lab, Paint.Align.LEFT, 0.14f)
                drawFps(c, 11f, 47f, 24f, acc, false)
                val ft = ftStr()
                if (musicOn()) {
                    t(c, ft, 34f, 18f, 7.5f, P.TEXT, mono, Paint.Align.LEFT)
                    t(c, "ms", 34f + txt.measureText(ft) + 1.5f, 18f, 6f, P.DIM, lab, Paint.Align.LEFT)
                    drawMusic(c, acc)
                } else {
                    t(c, ft, 72f, 19f, 9f, P.TEXT, mono, Paint.Align.LEFT)
                    t(c, "ms", 72f + txt.measureText(ft) + 2f, 19f, 6.5f, P.DIM, lab, Paint.Align.LEFT)
                }
                lockIcon(c, GLASS_W - 14f, 11f, 1.15f)
                if (showGraph) graph(c, 72f, 25f, GLASS_W - 10f, 50f)
                else t(c, statusText(), 72f, 42f, 8f, P.DIM, lab, Paint.Align.LEFT, 0.1f)

                val labels = ArrayList<String>()
                val values = ArrayList<String>()
                val fracs = ArrayList<Float>()
                if (nyxPref) t(c, "LOW " + lowStr(), 12f, 52.6f, 5.6f, P.DIM, mono, Paint.Align.LEFT)
                else { labels.add("LOW"); values.add(lowStr()); fracs.add(-1f) }
                if (showBars) {
                    labels.add("CPU"); values.add(cpuStr()); fracs.add(if (data.cpu >= 0f) data.cpu / 100f else 0f)
                    labels.add("RAM"); values.add(ramStr()); fracs.add(max(0f, ramFrac()))
                }
                val colW = (GLASS_W - 24f) / max(1, labels.size)
                for (i in labels.indices) {
                    val x = 12f + i * colW
                    val ry = if (nyxPref) 99.5f else 62f
                    t(c, labels[i], x, ry, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                    cyVal(c, values[i], x + 21f, ry, 6.8f, P.TEXT)
                    if (fracs[i] >= 0f) cellBar(c, x, ry + 2.5f, colW - 12f, fracs[i])
                }
                if (nyxPref) drawNyx(c) else if (showFooter) footer(c, w, 72f, 82f)
            }
        }
    }

    // ---------------- Nyx screen (glass, full) ----------------

    private val WIDE_X = floatArrayOf(47f, 47f)
    private val WIDE_T = floatArrayOf(62.6f, 75.6f)
    private val WIDE_W = floatArrayOf(131f, 131f)
    private val SIDE_X = floatArrayOf(41f, 41f, 12f, 12f)
    private val SIDE_T = floatArrayOf(63f, 71.4f, 88.5f, 96.9f)
    private val SIDE_W = floatArrayOf(67f, 67f, 96f, 96f)

    private fun lnX() = WIDE_X
    private fun lnT() = WIDE_T
    private fun lnW() = WIDE_W
    private fun lnK() = 0.7f

    private class NW(val lines: List<String>, val pink: List<BooleanArray>)

    private val wrapCache = HashMap<String, NW>()

    private fun nyxWrap(s: String): NW {
        val key = s
        wrapCache[key]?.let { return it }
        val up = s.uppercase()
        val k = lnK()
        val ws = lnW()
        val lines = ArrayList<String>()
        var cur = ""
        for (w in up.split(' ')) {
            if (w.isEmpty()) continue
            val trial = if (cur.isEmpty()) w else "$cur $w"
            val maxW = ws[min(lines.size, ws.size - 1)]
            if (cur.isNotEmpty() && Cy.twidth(trial, k) - 2.2f * k > maxW) { lines.add(cur); cur = w } else cur = trial
        }
        if (cur.isNotEmpty()) lines.add(cur)
        val masks = ArrayList<BooleanArray>()
        for (ln in lines) {
            val m = BooleanArray(ln.length)
            var i = 0
            while (i < ln.length) {
                var j = i
                while (j < ln.length && ln[j] != ' ') j++
                val word = ln.substring(i, j).trim('!', '?', '.', ',', '~', '\'', ':', '♥')
                if (word == "MASTER") for (q in i until j) m[q] = true
                i = j + 1
            }
            masks.add(m)
        }
        if (wrapCache.size > 400) wrapCache.clear()
        val nw = NW(lines, masks)
        wrapCache[key] = nw
        return nw
    }

    private fun nyxFit(s: String): Boolean = nyxWrap(s).lines.size <= lnX().size

    private fun cyStr(c: Canvas, s: String, x: Float, top: Float, k: Float, col: Int, al: Float, glow: Boolean, right: Boolean) {
        var px = if (right) x - Cy.twidth(s, k) + 2.2f * k else x
        for (ch in s) { Cy.glyph(c, nyxP, ch, px, top, k, col, al, glow); px += Cy.adv(ch, k) }
    }

    private fun drawNyx(c: Canvas) {
        val side = false
        val now = SystemClock.uptimeMillis()
        val tt = now / 1000f
        val bx0 = 8f
        val bx1 = if (side) 112f else GLASS_W - 8f
        val by0 = 54f
        val by1 = if (side) 113f else 91f
        val cyc = (by0 + by1) / 2f
        val xs = lnX(); val ts = lnT(); val ws = lnW(); val k = lnK()
        val tx1 = bx1 - 4f
        brain.step(now)
        val ln = brain.line
        val typed = brain.typedChars(now)
        val al = brain.alpha(now)
        val talking = brain.typing(now)
        val has = ln != null && al > 0.02f
        val mood = if (has) ln!!.mood else 12
        val busy = ln != null && brain.busy(now)
        val col = NyxArt.moodColor(mood)
        mp.reset()
        mp.moveTo(bx0 + 4f, by0); mp.lineTo(bx1, by0); mp.lineTo(bx1, by1 - 4f)
        mp.lineTo(bx1 - 4f, by1); mp.lineTo(bx0, by1); mp.lineTo(bx0, by0 + 4f); mp.close()
        fill.color = 0x55060C14
        c.drawPath(mp, fill)
        line.strokeWidth = 0.8f
        line.color = Cy.a(if (busy) col else Cy.CYAN, if (busy) 0.7f else 0.38f)
        c.drawPath(mp, line)
        c.save()
        c.clipPath(mp)
        line.strokeWidth = 0.35f
        line.color = 0x0EFFFFFF
        var yy = by0 + 1f
        while (yy < by1) { c.drawLine(bx0, yy, bx1, yy, line); yy += 2f }
        if (busy) {
            val sy2 = by0 + ((now % 2200L) / 2200f) * (by1 - by0)
            fill.color = Cy.a(col, 0.07f)
            tmp.set(bx0, sy2 - 5f, bx1, sy2)
            c.drawRect(tmp, fill)
            line.strokeWidth = 0.7f
            line.color = Cy.a(col, 0.35f)
            c.drawLine(bx0, sy2, bx1, sy2, line)
        }
        c.restore()
        if (!side) {
            line.strokeWidth = 0.6f
            line.color = Cy.a(Cy.CYAN, 0.25f)
            c.drawLine(xs[0] - 3f, by0 + 4f, xs[0] - 3f, by1 - 4f, line)
        }
        // portrait
        val pop = if (ln != null) ((now - brain.popAt) / 380f).coerceIn(0f, 1f) else 1f
        val ps = if (pop < 1f) 0.6f + 0.4f * (1f + 2.2f * (pop - 1f) * (pop - 1f) * (pop - 1f) + 1.2f * (pop - 1f) * (pop - 1f)) else 1f
        val ax = if (side) 24.5f else 26f
        val ay = if (side) by0 + 17.5f else cyc
        val fs = if (side) 0.17f else 0.2f
        val bob = if (Music.playing) Beat.kick else 0f
        c.save()
        c.scale(ps, ps, ax, ay)
        NyxChibi.draw(c, artP, mood, ax, ay, fs, tt, if (talking) 1f else 0f, bob, if (has || ln == null) 1f else 0.85f)
        c.restore()
        // corner info
        val sy = sys
        val tagX = xs[0]
        cyStr(c, "NYX", tagX, 55.6f, 0.45f, Cy.a(Cy.PINK, 0.9f), 1f, false, false)
        line.strokeWidth = 0.5f
        line.color = Cy.a(Cy.PINK, 0.5f)
        c.drawLine(tagX + 15f, 58f, tagX + 21f, 58f, line)
        cyStr(c, sy?.clock ?: "--:--", tx1, 55.6f, 0.45f, 0xFFB4C2CF.toInt(), 0.9f, false, true)
        cyStr(c, sy?.session ?: "00:00:00", tx1, if (side) 106.4f else 85.8f, 0.42f, Cy.a(0xFF8B96A3.toInt(), 1f), 0.85f, false, true)
        // text
        val h = 10f * k
        val txtCol = 0xFFD6FBFF.toInt()
        if (ln == null || al < 0.02f) {
            cyStr(c, "NYX ONLINE", xs[0], ts[0], k, Cy.a(Cy.CYAN, 0.7f), 0.8f, true, false)
            cyStr(c, if (side) "TAP ME ♥" else "TAP ME, MASTER ♥", xs[1], ts[1], k, Cy.a(Cy.PINK, 0.8f), 0.55f, false, false)
        } else {
            val nw = nyxWrap(ln.text)
            var left = typed
            val last = min(xs.size, nw.lines.size)
            var curX = xs[0]
            var curTop = ts[0]
            for (li in 0 until last) {
                val s = nw.lines[li]
                val n = min(left, s.length)
                left -= s.length
                var px = xs[li]
                val top = ts[li]
                for (i in 0 until n) {
                    val ch = s[i]
                    val pk = nw.pink[li][i]
                    val isLast = (typed < ln.text.length && talking) && (i == n - 1) && left <= 0
                    val cc = if (ch == '♥' || pk) Cy.PINK else txtCol
                    if (isLast) {
                        Cy.glyph(c, nyxP, ch, px, top, k, 0xFFFFFFFF.toInt(), al, true)
                        Cy.glyph(c, nyxP, ch, px, top, k, col, 0.6f * al, true)
                    } else Cy.glyph(c, nyxP, ch, px, top, k, cc, al, true)
                    px += Cy.adv(ch, k)
                    if (pk && (i + 1 >= s.length || !nw.pink[li][i + 1]) && n == s.length && brain.done(now)) {
                        val bounce = 1f + 0.2f * max(0f, sin(tt * 8f))
                        NyxArt.heartAt(c, artP, px - 1.2f * k, top - 1.2f, 1.7f * bounce, Cy.PINK, al)
                    }
                }
                curX = px
                curTop = top
                if (left <= 0) break
            }
            val blink = if (brain.typing(now)) true else ((now / 380L) % 2L == 0L)
            if (blink && al > 0.3f) {
                fill.color = Cy.a(col, 0.9f * al)
                tmp.set(curX + 0.6f, curTop, curX + 0.6f + 3.2f, curTop + h)
                c.drawRect(tmp, fill)
            }
            if (brain.done(now)) {
                val age = brain.doneMs(now) / 380f
                val kk = age.coerceIn(0f, 1f)
                val sc = if (kk < 1f) 1.35f * kk * (2f - kk) else 1f
                val li = last - 1
                val sx = xs[li] + Cy.twidth(nw.lines[li], k) + 8f
                val ty = ts[li] + h / 2f
                if (sx < xs[li] + ws[li] - 4f) NyxArt.sym(c, artP, ln.sym, sx, ty, 3.2f, tt, sc, al)
                else NyxArt.sym(c, artP, ln.sym, if (side) 35f else 41f, if (side) 59f else 59f, 3.0f, tt, sc, al)
            }
        }
    }

    // ---------------- design 1: gauge ----------------

    private fun drawGauge(c: Canvas, w: Float, h: Float, st: Int) {
        val acc = accent(st)
        val str = fpsStr()
        when (shownMode) {
            2 -> {
                ring(c, 23f, 23f, 17f, 3.5f, acc)
                drawFps(c, 23f, 27.5f, 9f, P.TEXT, true)
            }
            1 -> {
                ring(c, 32f, 31f, 20f, 4.5f, acc)
                drawFps(c, 32f, 37f, 12f, P.TEXT, true)
                val xr = w - 10f
                t(c, "FRAME", 62f, 26f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                t(c, ftStr() + "ms", xr, 26f, 8.5f, P.TEXT, mono, Paint.Align.RIGHT)
                t(c, "1% LOW", 62f, 42f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                t(c, lowStr(), xr, 42f, 8.5f, P.TEXT, mono, Paint.Align.RIGHT)
            }
            else -> {
                ring(c, 36f, 38f, 24f, 5f, acc)
                drawFps(c, 36f, 45.5f, 15f, P.TEXT, true)
                t(c, "FPS", 36f, 55f, 6f, P.LABEL, lab, Paint.Align.CENTER, 0.14f)
                lockIcon(c, GAUGE_W - 14f, 11f, 1.15f)
                val x0 = 74f
                val xr = GAUGE_W - 10f
                t(c, "FRAME", x0, 25f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                t(c, ftStr() + "ms", xr, 25f, 9f, P.TEXT, mono, Paint.Align.RIGHT)
                t(c, "1% LOW", x0, 39f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                t(c, lowStr(), xr, 39f, 9f, P.TEXT, mono, Paint.Align.RIGHT)
                if (showBars) {
                    t(c, "CPU", x0, 53f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                    t(c, cpuStr(), xr, 53f, 8f, P.TEXT, mono, Paint.Align.RIGHT)
                    miniBar(c, x0, 56f, xr - x0, if (data.cpu >= 0f) data.cpu / 100f else 0f)
                    t(c, "RAM", x0, 67f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                    t(c, ramStr(), xr, 67f, 8f, P.TEXT, mono, Paint.Align.RIGHT)
                    miniBar(c, x0, 70f, xr - x0, max(0f, ramFrac()))
                }
                if (showFooter) {
                    val be = gaugeBe()
                    footer(c, w, be - 1f, be + 10f)
                }
            }
        }
    }

    // ---------------- design 2: pill ----------------

    private fun sep(c: Canvas, x: Float) {
        line.strokeWidth = 0.8f
        line.color = 0x30FFFFFF
        c.drawLine(x, 10f, x, 24f, line)
    }

    private fun drawPill(c: Canvas, w: Float, h: Float, st: Int) {
        val acc = accent(st)
        val str = fpsStr()
        when (shownMode) {
            2 -> {
                mark(c, 11f, h / 2f, acc)
                drawFps(c, 19f, h / 2f + 4.8f, 9.5f, P.TEXT, false)
            }
            1 -> {
                mark(c, 12f, h / 2f, acc)
                drawFps(c, 22f, 23f, 12f, P.TEXT, false)
                t(c, ftStr() + "ms", w - 10f, 21f, 8.5f, P.DIM, mono, Paint.Align.RIGHT)
            }
            else -> {
                mark(c, 12f, h / 2f, acc)
                var x = 22f
                drawFps(c, x, 23f, 12f, P.TEXT, false)
                x += numW(12f) + 3f
                t(c, "FPS", x, 21.5f, 6f, P.LABEL, lab, Paint.Align.LEFT, 0.12f)
                x += txt.measureText("FPS") + 8f
                sep(c, x)
                x += 7f
                val ft = ftStr() + "ms"
                t(c, ft, x, 21f, 8.5f, P.TEXT, mono, Paint.Align.LEFT)
                x += txt.measureText(ft) + 8f
                if (showBars) {
                    sep(c, x)
                    x += 7f
                    t(c, "CPU " + cpuStr(), x, 21f, 8.5f, P.DIM, mono, Paint.Align.LEFT)
                }
            }
        }
    }

    private fun mark(c: Canvas, x: Float, y: Float, col: Int) {
        if (locked) lockIcon(c, x, y - 1f, 0.85f) else dot(c, x, y, col)
    }

    private fun dot(c: Canvas, x: Float, y: Float, col: Int) {
        if (flash > 0f) {
            fill.color = P.BAD
            fill.alpha = (flash * 90).toInt()
            c.drawCircle(x, y, 7f, fill)
        }
        fill.color = col
        c.drawCircle(x, y, 3.4f, fill)
    }
}

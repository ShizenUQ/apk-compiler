package com.xio.bulwark

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.hypot

/** Angular "cyber" digits drawn by hand (no font file), plus small helpers for electric arcs and noise. */
object Cy {
    const val CYAN = 0xFF19E6F2.toInt()
    const val PINK = 0xFFFF2E93.toInt()

    private val defs: Map<Char, Array<FloatArray>> = mapOf(
        '0' to arrayOf(floatArrayOf(1.5f, 0f, 4.5f, 0f, 6f, 1.5f, 6f, 8.5f, 4.5f, 10f, 1.5f, 10f, 0f, 8.5f, 0f, 1.5f, 1.5f, 0f)),
        '1' to arrayOf(floatArrayOf(1f, 2.8f, 3.6f, 0f, 3.6f, 10f)),
        '2' to arrayOf(floatArrayOf(0f, 1.5f, 1.5f, 0f, 4.5f, 0f, 6f, 1.5f, 6f, 3.5f, 4.5f, 5f, 1.5f, 5f, 0f, 6.5f, 0f, 10f, 6f, 10f)),
        '3' to arrayOf(
            floatArrayOf(0f, 0f, 4.5f, 0f, 6f, 1.5f, 6f, 3.5f, 4.5f, 5f, 2f, 5f),
            floatArrayOf(4.5f, 5f, 6f, 6.5f, 6f, 8.5f, 4.5f, 10f, 0f, 10f)
        ),
        '4' to arrayOf(floatArrayOf(0f, 0f, 0f, 5.5f, 6f, 5.5f), floatArrayOf(4.5f, 0f, 4.5f, 10f)),
        '5' to arrayOf(floatArrayOf(6f, 0f, 0f, 0f, 0f, 4.5f, 4.5f, 4.5f, 6f, 6f, 6f, 8.5f, 4.5f, 10f, 0f, 10f)),
        '6' to arrayOf(floatArrayOf(5f, 0f, 1.5f, 0f, 0f, 1.5f, 0f, 8.5f, 1.5f, 10f, 4.5f, 10f, 6f, 8.5f, 6f, 6.2f, 4.5f, 4.7f, 0f, 4.7f)),
        '7' to arrayOf(floatArrayOf(0f, 0f, 6f, 0f, 2.4f, 10f)),
        '8' to arrayOf(
            floatArrayOf(1.5f, 0f, 4.5f, 0f, 6f, 1.5f, 6f, 8.5f, 4.5f, 10f, 1.5f, 10f, 0f, 8.5f, 0f, 1.5f, 1.5f, 0f),
            floatArrayOf(0f, 5f, 6f, 5f)
        ),
        '9' to arrayOf(floatArrayOf(6f, 5.3f, 1.5f, 5.3f, 0f, 3.8f, 0f, 1.5f, 1.5f, 0f, 4.5f, 0f, 6f, 1.5f, 6f, 8.5f, 4.5f, 10f, 1f, 10f)),
        '-' to arrayOf(floatArrayOf(0.5f, 5f, 5.5f, 5f))
    ) + parseAll()

    /** Letters and marks, written as "x,y x,y ..." strokes separated by '|'. Narrow glyphs are 4 or 2 wide. */
    private fun parseAll(): Map<Char, Array<FloatArray>> {
        val src = mapOf(
            'A' to "0,10 0,2.5 2.5,0 3.5,0 6,2.5 6,10|0,6 6,6",
            'B' to "0,10 0,0 4.5,0 6,1.5 6,3.5 4.5,5 0,5|4.5,5 6,6.5 6,8.5 4.5,10 0,10",
            'C' to "6,1.5 4.5,0 1.5,0 0,1.5 0,8.5 1.5,10 4.5,10 6,8.5",
            'D' to "0,0 0,10 3.5,10 6,7.5 6,2.5 3.5,0 0,0",
            'E' to "6,0 0,0 0,10 6,10|0,5 4.5,5",
            'F' to "6,0 0,0 0,10|0,5 4.5,5",
            'G' to "6,1.5 4.5,0 1.5,0 0,1.5 0,8.5 1.5,10 4.5,10 6,8.5 6,5.5 3.5,5.5",
            'H' to "0,0 0,10|6,0 6,10|0,5 6,5",
            'I' to "0,0 4,0|2,0 2,10|0,10 4,10",
            'J' to "6,0 6,8.5 4.5,10 1.5,10 0,8.5",
            'K' to "0,0 0,10|6,0 0,6|2,4.5 6,10",
            'L' to "0,0 0,10 6,10",
            'M' to "0,10 0,0 3,4 6,0 6,10",
            'N' to "0,10 0,0 6,10 6,0",
            'O' to "1.5,0 4.5,0 6,1.5 6,8.5 4.5,10 1.5,10 0,8.5 0,1.5 1.5,0",
            'P' to "0,10 0,0 4.5,0 6,1.5 6,4 4.5,5.5 0,5.5",
            'Q' to "1.5,0 4.5,0 6,1.5 6,8.5 4.5,10 1.5,10 0,8.5 0,1.5 1.5,0|3.5,7 6,10",
            'R' to "0,10 0,0 4.5,0 6,1.5 6,4 4.5,5.5 0,5.5|3,5.5 6,10",
            'S' to "6,1.5 4.5,0 1.5,0 0,1.5 0,3.5 1.5,5 4.5,5 6,6.5 6,8.5 4.5,10 1.5,10 0,8.5",
            'T' to "0,0 6,0|3,0 3,10",
            'U' to "0,0 0,8.5 1.5,10 4.5,10 6,8.5 6,0",
            'V' to "0,0 3,10 6,0",
            'W' to "0,0 1.5,10 3,5 4.5,10 6,0",
            'X' to "0,0 6,10|6,0 0,10",
            'Y' to "0,0 3,5 6,0|3,5 3,10",
            'Z' to "0,0 6,0 0,10 6,10",
            '!' to "1,0 1,6.5|1,8.8 1,10",
            '?' to "0,1.5 1.5,0 4.5,0 6,1.5 6,3.5 3,5.5 3,7|3,9 3,10",
            '.' to "1,8.8 1,10",
            ',' to "1,8.8 1,10 0,11.8",
            '\'' to "1,0 1,3",
            ':' to "1,2.5 1,3.8|1,7 1,8.3",
            '~' to "0,5 1.5,3.5 3,5 4.5,6.5 6,5",
            '/' to "0,10 6,0",
            '\u2665' to "3,10 0,5.5 0,2.5 1.5,1 3,2.5 4.5,1 6,2.5 6,5.5 3,10"
        )
        val out = HashMap<Char, Array<FloatArray>>()
        for ((ch, s) in src) {
            out[ch] = s.split('|').map { st ->
                val f = ArrayList<Float>()
                for (pt in st.trim().split(' ')) { val xy = pt.split(','); f.add(xy[0].toFloat()); f.add(xy[1].toFloat()) }
                f.toFloatArray()
            }.toTypedArray()
        }
        return out
    }

    /** How far to move right after drawing ch, when one grid unit is k. */
    fun has(ch: Char): Boolean = ch == ' ' || defs.containsKey(ch)

    fun adv(ch: Char, k: Float): Float = when (ch) {
        ' ' -> 4.2f * k
        'I' -> 6.2f * k
        '!', '.', ',', '\'', ':' -> 4.2f * k
        else -> 8.2f * k
    }

    fun twidth(s: String, k: Float): Float {
        var w = 0f
        for (ch in s) w += adv(ch, k)
        return w
    }
    private val paths = HashMap<Char, Path>()

    private fun path(ch: Char): Path? {
        paths[ch]?.let { return it }
        val d = defs[ch] ?: return null
        val p = Path()
        for (pl in d) {
            p.moveTo(pl[0], pl[1])
            var i = 2
            while (i < pl.size) { p.lineTo(pl[i], pl[i + 1]); i += 2 }
        }
        paths[ch] = p
        return p
    }

    fun a(c: Int, alpha: Float): Int = (c and 0x00FFFFFF) or ((alpha.coerceIn(0f, 1f) * 255f).toInt() shl 24)

    fun rnd(n: Int): Float {
        var x = n * 374761393 + 668265263
        x = (x xor (x ushr 13)) * 1274126177.toInt()
        x = x xor (x ushr 16)
        return (x and 0xFFFF) / 65535f
    }

    /** Width of n digits when one grid unit is k. */
    fun width(n: Int, k: Float): Float = if (n <= 0) 0f else n * 6f * k + (n - 1) * 2.2f * k

    fun glyph(c: Canvas, p: Paint, ch: Char, x: Float, top: Float, k: Float, color: Int, alpha: Float, glow: Boolean) {
        val path = path(ch) ?: return
        c.save()
        c.translate(x, top)
        c.scale(k, k)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.SQUARE
        p.strokeJoin = Paint.Join.MITER
        p.strokeMiter = 4f
        p.shader = null
        if (glow) {
            p.strokeWidth = 3.7f
            p.color = a(color, 0.2f * alpha)
            c.drawPath(path, p)
        }
        p.strokeWidth = 1.4f
        p.color = a(color, alpha)
        c.drawPath(path, p)
        if (glow) {
            p.strokeWidth = 0.45f
            p.color = a(0xFFFFFFFF.toInt(), 0.55f * alpha)
            c.drawPath(path, p)
        }
        c.restore()
    }

    /** Plain (not animated) cyber text for small values. Returns the width drawn. */
    fun text(c: Canvas, p: Paint, s: String, x: Float, base: Float, h: Float, color: Int): Float {
        val k = h / 10f
        for ((i, ch) in s.withIndex()) glyph(c, p, ch, x + i * 8.2f * k, base - h, k, color, 1f, false)
        return width(s.length, k)
    }

    /** A short jagged lightning line. */
    fun arc(c: Canvas, p: Paint, x0: Float, y0: Float, x1: Float, y1: Float, seed: Int, amp: Float) {
        val dx = x1 - x0
        val dy = y1 - y0
        val len = hypot(dx, dy)
        if (len < 0.1f) return
        val nx = -dy / len
        val ny = dx / len
        val n = 5
        var px = x0
        var py = y0
        for (i in 1..n) {
            val f = i / n.toFloat()
            val off = if (i == n) 0f else (rnd(seed * 31 + i) - 0.5f) * 2f * amp
            val x = x0 + dx * f + nx * off
            val y = y0 + dy * f + ny * off
            c.drawLine(px, py, x, y, p)
            px = x; py = y
        }
    }
}

/** The big FPS number: rolling digits, neon glow, electric sparks when healthy, glitch when FPS is low. */
class CyNumber {
    private var cur = ""
    private var prev = ""
    private var changeAt = 0L
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(s: String, now: Long) {
        if (s != cur) { prev = cur; cur = s; changeAt = now }
    }

    fun length() = cur.length

    private fun digits(c: Canvas, left: Float, base: Float, h: Float, color: Int, alpha: Float, ox: Float, oy: Float, glow: Boolean, now: Long) {
        val k = h / 10f
        val roll = (now - changeAt).toFloat() / 170f
        val n = cur.length
        for (i in 0 until n) {
            val ch = cur[i]
            val x = left + ox + i * 8.2f * k
            val pi = prev.length - (n - i)
            val pch = if (roll < 1f && pi >= 0 && pi < prev.length) prev[pi] else null
            if (pch != null && pch != ch) {
                val e = 1f - (1f - roll) * (1f - roll)
                c.save()
                c.clipRect(x - 1.5f * k, base - h * 1.15f + oy, x + 7.5f * k, base + h * 0.15f + oy)
                Cy.glyph(c, p, pch, x, base - h + oy - e * h, k, color, alpha * (1f - e), glow)
                Cy.glyph(c, p, ch, x, base - h + oy + (1f - e) * h, k, color, alpha * e, glow)
                c.restore()
            } else {
                Cy.glyph(c, p, ch, x, base - h + oy, k, color, alpha, glow)
            }
        }
    }

    fun draw(c: Canvas, x: Float, base: Float, h: Float, color: Int, center: Boolean, glitch: Float, fx: Boolean, now: Long) {
        if (cur.isEmpty()) return
        val k = h / 10f
        val total = Cy.width(cur.length, k)
        val left = if (center) x - total / 2f else x
        val slot = (now / 90L).toInt()
        val burst = glitch > 0.08f && (glitch > 0.9f || Cy.rnd(slot) < 0.10f + glitch * 0.8f)
        val u = h / 25f
        var jx = 0f
        var jy = 0f
        var al = 1f
        if (burst) {
            jx = (Cy.rnd(slot * 3 + 1) - 0.5f) * glitch * 3.4f * u
            jy = (Cy.rnd(slot * 3 + 2) - 0.5f) * glitch * 1.6f * u
            if (glitch > 0.6f && Cy.rnd(slot * 7) < 0.2f) al = 0.35f
        }
        if (burst && glitch > 0.12f) {
            val dx = (1f + glitch * 3f) * u
            digits(c, left, base, h, Cy.CYAN, 0.62f * al, jx - dx, jy, false, now)
            digits(c, left, base, h, Cy.PINK, 0.62f * al, jx + dx, jy, false, now)
        }
        digits(c, left, base, h, color, al, jx, jy, true, now)
        if (burst && fx && glitch > 0.4f) {
            val bands = if (glitch > 0.75f) 3 else 2
            for (b in 0 until bands) {
                val by = base - h + Cy.rnd(slot * 11 + b) * h * 0.8f
                val bh = h * (0.07f + Cy.rnd(slot * 13 + b) * 0.14f)
                val sh = (Cy.rnd(slot * 17 + b) - 0.5f) * glitch * h * 0.8f
                c.save()
                c.clipRect(left - h, by, left + total + h, by + bh)
                digits(c, left, base, h, 0xFFFFFFFF.toInt(), 0.9f, jx + sh, jy, false, now)
                c.restore()
            }
        }
        if (burst && fx && glitch > 0.85f) {
            p.style = Paint.Style.FILL
            for (i in 0 until 8) {
                val rx = left + Cy.rnd(slot * 19 + i) * total
                val ry = base - h + Cy.rnd(slot * 23 + i) * h
                p.color = Cy.a(0xFFFFFFFF.toInt(), 0.6f)
                c.drawRect(rx, ry, rx + h * 0.22f, ry + 0.7f * u + 0.4f, p)
            }
        }
        if (fx && glitch < 0.3f) {
            val ph = now % 900L
            if (ph < 150L) {
                val seed = (now / 900L).toInt()
                p.style = Paint.Style.STROKE
                p.strokeWidth = 0.8f
                p.strokeCap = Paint.Cap.ROUND
                p.color = Cy.a(0xFFBFFBFF.toInt(), 0.85f)
                val top = base - h - 1.5f * u
                val sx = left + Cy.rnd(seed * 5) * total
                Cy.arc(c, p, sx, top, sx + (Cy.rnd(seed * 7) - 0.5f) * h * 0.9f, top - h * 0.32f, seed, 1.6f * u)
                val ry = base - h * (0.2f + Cy.rnd(seed * 9) * 0.6f)
                Cy.arc(c, p, left + total + 1f, ry, left + total + h * 0.4f, ry + (Cy.rnd(seed * 11) - 0.5f) * h * 0.5f, seed + 3, 1.4f * u)
                p.strokeCap = Paint.Cap.BUTT
            }
        }
    }

    /** A burst of arcs, used when a frame drop is detected. */
    fun burst(c: Canvas, x: Float, base: Float, h: Float, center: Boolean, now: Long) {
        val k = h / 10f
        val total = Cy.width(cur.length, k)
        val left = if (center) x - total / 2f else x
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.9f
        p.strokeCap = Paint.Cap.ROUND
        p.color = Cy.a(0xFFFFB0A8.toInt(), 0.9f)
        val seed = (now / 70L).toInt()
        for (i in 0..2) {
            val sx = left + Cy.rnd(seed * 3 + i) * total
            val sy = base - h * Cy.rnd(seed * 5 + i)
            Cy.arc(c, p, sx, sy, sx + (Cy.rnd(seed * 7 + i) - 0.5f) * h * 1.3f, sy + (Cy.rnd(seed * 9 + i) - 0.5f) * h * 0.9f, seed + i, h * 0.07f)
        }
        p.strokeCap = Paint.Cap.BUTT
    }
}

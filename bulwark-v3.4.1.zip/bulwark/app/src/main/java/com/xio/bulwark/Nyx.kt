package com.xio.bulwark

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import java.util.Calendar
import java.util.Random
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class NyxLine(val text: String, val mood: Int, val sym: Int)

/**
 * Nyx's "mind": watches the phone and decides what to say and when. Scripted, offline.
 * Call feed() about once a second, read the typed text while drawing.
 */
class NyxBrain {
    var freq = 1                     // 0 quiet, 1 normal, 2 chatty
    var line: NyxLine? = null
        private set
    private val rnd = Random()
    private var phase = 0            // 0 idle, 1 typing, 2 hold, 3 fade
    private var t0 = 0L
    private var doneAt = 0L
    private var fadeAt = 0L
    private var nextIdle = 0L
    private var pending: NyxLine? = null
    private var pendingPrio = 0
    private val last = HashMap<String, Long>()
    private val recent = ArrayList<String>()
    private var greeted = false
    private var started = 0L
    private var activeSince = 0L
    private var inactiveSince = 0L
    private var lowSince = 0L
    private var goodSince = 0L
    private var lowFired = 0L
    private var wasPlaying = false
    private var gameLive = false
    private var lastSlot = -1L
    var popAt = 0L
        private set
    var lineAt = 0L
        private set

    companion object {
        const val CHAR_MS = 34L
        const val PRE_MS = 220L
    }

    fun busy(now: Long): Boolean = phase != 0 || pending != null

    fun typedChars(now: Long): Int {
        val l = line ?: return 0
        if (phase == 0) return 0
        if (phase >= 2) return l.text.length
        return ((now - t0 - PRE_MS) / CHAR_MS).toInt().coerceIn(0, l.text.length)
    }

    fun typing(now: Long) = phase == 1
    fun done(now: Long) = phase >= 2
    fun doneMs(now: Long): Long = if (phase >= 2) now - doneAt else -1L

    fun alpha(now: Long): Float = if (phase == 3) (1f - (now - fadeAt) / 420f).coerceIn(0f, 1f) else 1f

    private fun cd(key: String, now: Long, gap: Long): Boolean {
        val l = last[key] ?: 0L
        if (l != 0L && now - l < gap) return false
        last[key] = now
        return true
    }

    private fun pick(pool: List<String>, fit: (String) -> Boolean): String {
        var best = pool[rnd.nextInt(pool.size)]
        for (i in 0 until 14) {
            val s = pool[rnd.nextInt(pool.size)]
            if (s !in recent && fit(s)) { best = s; break }
        }
        recent.add(best)
        if (recent.size > 60) recent.removeAt(0)
        return best
    }

    private fun idleLine(fit: (String) -> Boolean): String {
        if (rnd.nextInt(100) < 38) {
            for (i in 0 until 16) {
                val s = NyxLines.OPEN[rnd.nextInt(NyxLines.OPEN.size)] + " " + NyxLines.END[rnd.nextInt(NyxLines.END.size)]
                if (s !in recent && fit(s)) { recent.add(s); if (recent.size > 60) recent.removeAt(0); return s }
            }
        }
        return pick(NyxLines.IDLE, fit)
    }

    private fun moods(pool: Int): IntArray = when (pool) {
        0 -> intArrayOf(0, 3, 9, 1)
        1 -> intArrayOf(9, 0, 3, 2)
        2 -> intArrayOf(6, 10, 7, 5)
        3 -> intArrayOf(9, 2, 0, 3)
        4 -> intArrayOf(10, 6, 5, 4)
        5 -> intArrayOf(7, 10, 6, 4)
        6 -> intArrayOf(0, 1, 9)
        7 -> intArrayOf(4, 10, 2, 8)
        8 -> intArrayOf(0, 9, 1, 3, 11)
        9 -> intArrayOf(4, 8, 2)
        10 -> intArrayOf(8, 3, 2, 11, 5, 1, 0)
        else -> intArrayOf(0, 1, 2, 3, 8, 9, 11, 10)
    }

    private fun syms(pool: Int): IntArray = when (pool) {
        0 -> intArrayOf(1, 0)
        1 -> intArrayOf(5, 1)
        2 -> intArrayOf(4, 6)
        3 -> intArrayOf(1, 5)
        4 -> intArrayOf(4, 6)
        5 -> intArrayOf(4, 5)
        6 -> intArrayOf(5, 0)
        7 -> intArrayOf(3, 4)
        8 -> intArrayOf(2)
        9 -> intArrayOf(3, 0)
        10 -> intArrayOf(0, 6, 1)
        else -> intArrayOf(0, 1, 2)
    }

    private fun make(poolId: Int, pool: List<String>, fit: (String) -> Boolean): NyxLine {
        val s = if (poolId == 11) idleLine(fit) else pick(pool, fit)
        val m = moods(poolId)
        val y = syms(poolId)
        return NyxLine(s, m[rnd.nextInt(m.size)], y[rnd.nextInt(y.size)])
    }

    private fun say(l: NyxLine, prio: Int, now: Long) {
        if (phase == 0) { begin(l, now); return }
        if (pending == null || prio >= pendingPrio) { pending = l; pendingPrio = prio }
    }

    private fun begin(l: NyxLine, now: Long) {
        line = l
        phase = 1
        t0 = now
        popAt = now
        lineAt = now
        pending = null
        pendingPrio = 0
        scheduleIdle(now)
    }

    private fun scheduleIdle(now: Long) {
        val (a, b) = when (freq) { 0 -> 35 to 75; 2 -> 5 to 12; else -> 9 to 22 }
        nextIdle = now + (a + rnd.nextInt(b - a + 1)) * 1000L
    }

    /** Someone tapped the bar. */
    fun poke(now: Long, fit: (String) -> Boolean) {
        if (!cd("poke", now, 700)) return
        val l = make(10, NyxLines.POKE, fit)
        if (phase == 1 || phase == 2) { phase = 0 }
        begin(l, now)
    }

    /** Moves typing -> hold -> fade -> idle. Cheap; also called while drawing. */
    fun step(now: Long) {
        if (phase == 1 && now - t0 - PRE_MS >= (line?.text?.length ?: 0) * CHAR_MS) { phase = 2; doneAt = now }
        if (phase == 2) {
            val len = line?.text?.length ?: 0
            if (now - doneAt > 2400L + len * 60L) { phase = 3; fadeAt = now }
        }
        if (phase == 3 && now - fadeAt > 420) { phase = 0 }
        if (phase == 0) { val p = pending; if (p != null) begin(p, now) }

    }

    fun feed(now: Long, fps: Float, target: Int, temp: Float, bat: Int, charging: Boolean,
             musicPlaying: Boolean, sessionSec: Long, fit: (String) -> Boolean) {
        step(now)
        if (started == 0L) { started = now; scheduleIdle(now) }
        val active = fps > 0f
        if (active) { if (activeSince == 0L) activeSince = now; inactiveSince = 0L }
        else { activeSince = 0L; if (inactiveSince == 0L) inactiveSince = now }

        if (!greeted && now - started > 1400) {
            greeted = true
            say(make(0, NyxLines.GREET, fit), 3, now)
            return
        }
        // game just started
        if (active) {
            if (!gameLive) {
                gameLive = true
                if (cd("game", now, 240_000L)) { say(make(1, NyxLines.GAME, fit), 4, now); return }
            }
        } else if (inactiveSince != 0L && now - inactiveSince > 15_000L) gameLive = false
        // lag
        if (active && fps < 30f) { if (lowSince == 0L) lowSince = now } else lowSince = 0L
        if (lowSince != 0L && now - lowSince > 4000 && cd("low", now, 90_000L)) {
            lowFired = now
            say(make(2, NyxLines.LOWFPS, fit), 6, now); return
        }
        if (active && fps >= max(20, target) * 0.9f) { if (goodSince == 0L) goodSince = now } else goodSince = 0L
        if (lowFired != 0L && goodSince != 0L && now - goodSince > 3000 && now - lowFired < 120_000L && cd("rec", now, 150_000L)) {
            lowFired = 0L
            say(make(3, NyxLines.RECOVER, fit), 4, now); return
        }
        if (temp >= 43f && cd("hot", now, 180_000L)) { say(make(4, NyxLines.HOT, fit), 7, now); return }
        if (bat in 1..20 && !charging && cd("bat", now, 420_000L)) { say(make(5, NyxLines.BATLOW, fit), 7, now); return }
        if (charging && bat >= 99 && cd("full", now, 900_000L)) { say(make(6, NyxLines.FULL, fit), 3, now); return }
        val slot = sessionSec / 1800L
        if (lastSlot == -1L) lastSlot = slot
        else if (slot > lastSlot) { lastSlot = slot; say(make(7, NyxLines.LONG, fit), 5, now); return }
        if (musicPlaying && !wasPlaying && cd("music", now, 150_000L)) {
            wasPlaying = true
            say(make(8, NyxLines.MUSIC, fit), 2, now); return
        }
        wasPlaying = musicPlaying
        // idle chatter
        if (phase == 0 && pending == null && now >= nextIdle) {
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val night = h >= 23 || h < 5
            if (night && rnd.nextInt(100) < 40) say(make(9, NyxLines.NIGHT, fit), 1, now)
            else say(make(11, NyxLines.IDLE, fit), 1, now)
        }
    }
}

/** Neon faces and small symbols for Nyx. All drawn in code, in the status's design units. */
object NyxArt {
    private val path = Path()
    private val rf = RectF()
    private const val PINK = 0xFFFF2E93.toInt()
    private const val CYAN = 0xFF19E6F2.toInt()
    private const val GREEN = 0xFF3DDC97.toInt()
    private const val AMBER = 0xFFFFC24B.toInt()
    private const val VIOLET = 0xFF8F6BFF.toInt()
    private const val BLUE = 0xFF6BA8FF.toInt()
    private const val RED = 0xFFFF5252.toInt()

    private fun a(c: Int, al: Float): Int = (c and 0x00FFFFFF) or ((al.coerceIn(0f, 1f) * 255f).toInt() shl 24)

    fun moodColor(m: Int): Int = when (m) {
        1, 8, 11 -> PINK
        5 -> RED
        9 -> AMBER
        7 -> BLUE
        4 -> VIOLET
        else -> CYAN
    }

    private fun stroke(p: Paint, col: Int, w: Float, al: Float = 1f) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = w
        p.color = a(col, al)
    }

    private fun arcAt(c: Canvas, p: Paint, cx: Float, cy: Float, rx: Float, ry: Float, st: Float, sw: Float) {
        rf.set(cx - rx, cy - ry, cx + rx, cy + ry)
        c.drawArc(rf, st, sw, false, p)
    }

    /** mood 0..11, talk 0..1 opens the mouth while she is typing. */
    fun face(c: Canvas, p: Paint, mood: Int, cx: Float, cy: Float, r: Float, t: Float, talk: Float, al: Float) {
        val u = r / 6f
        val col = moodColor(mood)
        val sh = if (mood == 5) sin(t * 40f) * 0.35f * u else 0f
        c.save()
        c.translate(cx + sh, cy)
        // head
        p.style = Paint.Style.FILL
        p.color = a(col, 0.14f * al)
        c.drawCircle(0f, 0f, r, p)
        stroke(p, col, 2.6f * u * 0.6f, 0.2f * al)
        c.drawCircle(0f, 0f, r, p)
        stroke(p, col, 0.95f * u * 0.9f, 0.95f * al)
        c.drawCircle(0f, 0f, r, p)
        val w = 0.9f * u
        stroke(p, col, w, al)
        val ex = 2.3f * u
        val ey = -1.1f * u
        val blink = (t % 3.6f) > 3.45f
        val mo = (0.4f + 0.6f * abs(sin(t * 13f))) * talk
        when (mood) {
            0 -> { // happy ^ ^
                arcAt(c, p, -ex, ey + 0.6f * u, 1.3f * u, 1.3f * u, 200f, 140f)
                arcAt(c, p, ex, ey + 0.6f * u, 1.3f * u, 1.3f * u, 200f, 140f)
                arcAt(c, p, 0f, 0.8f * u, 2.4f * u, 1.7f * u + mo * u, 15f, 150f)
            }
            1 -> { // heart eyes
                val s = (0.9f + 0.15f * sin(t * 8f)) * u
                heartPath(-ex, ey, s); p.style = Paint.Style.FILL; p.color = a(col, al); c.drawPath(path, p)
                heartPath(ex, ey, s); c.drawPath(path, p)
                stroke(p, col, w, al)
                arcAt(c, p, 0f, 0.8f * u, 2.2f * u, 1.6f * u + mo * u, 15f, 150f)
            }
            2 -> { // smug
                c.drawLine(-ex - 1.3f * u, ey, -ex + 1.3f * u, ey, p)
                c.drawLine(ex - 1.3f * u, ey, ex + 1.3f * u, ey, p)
                p.style = Paint.Style.FILL; p.color = a(col, al)
                c.drawCircle(-ex + 0.3f * u, ey + 0.8f * u, 0.55f * u, p)
                c.drawCircle(ex + 0.3f * u, ey + 0.8f * u, 0.55f * u, p)
                stroke(p, col, w, al)
                arcAt(c, p, 0.8f * u, 1.1f * u, 2.0f * u, 1.2f * u + mo * 0.6f * u, 10f, 120f)
            }
            3 -> { // wink
                p.style = Paint.Style.FILL; p.color = a(col, al)
                c.drawCircle(-ex, ey, 0.75f * u, p)
                stroke(p, col, w, al)
                c.drawLine(ex - 1.1f * u, ey - 0.9f * u, ex + 0.9f * u, ey, p)
                c.drawLine(ex + 0.9f * u, ey, ex - 1.1f * u, ey + 0.9f * u, p)
                arcAt(c, p, 0f, 0.8f * u, 2.3f * u, 1.6f * u + mo * u, 15f, 150f)
            }
            4 -> { // sleepy
                arcAt(c, p, -ex, ey, 1.3f * u, 0.9f * u, 20f, 140f)
                arcAt(c, p, ex, ey, 1.3f * u, 0.9f * u, 20f, 140f)
                val br = (0.7f + 0.35f * sin(t * 2f)) * u
                rf.set(-br, 1.8f * u, br, 1.8f * u + br * 1.4f)
                c.drawOval(rf, p)
            }
            5 -> { // angry
                c.drawLine(-ex - 1.3f * u, ey - 1.5f * u, -ex + 1.2f * u, ey - 0.3f * u, p)
                c.drawLine(ex + 1.3f * u, ey - 1.5f * u, ex - 1.2f * u, ey - 0.3f * u, p)
                p.style = Paint.Style.FILL; p.color = a(col, al)
                c.drawCircle(-ex, ey + 0.6f * u, 0.6f * u, p)
                c.drawCircle(ex, ey + 0.6f * u, 0.6f * u, p)
                stroke(p, col, w, al)
                path.reset()
                path.moveTo(-2f * u, 2.6f * u)
                path.lineTo(-1f * u, 1.8f * u + mo * 0.5f * u); path.lineTo(0f, 2.6f * u)
                path.lineTo(1f * u, 1.8f * u + mo * 0.5f * u); path.lineTo(2f * u, 2.6f * u)
                c.drawPath(path, p)
            }
            6 -> { // shocked
                val er = (1.1f + 0.1f * sin(t * 10f)) * u
                c.drawCircle(-ex, ey, er, p)
                c.drawCircle(ex, ey, er, p)
                val mr = (0.9f + 0.7f * mo + 0.3f * abs(sin(t * 6f))) * u
                rf.set(-mr, 1.5f * u, mr, 1.5f * u + mr * 1.7f)
                c.drawOval(rf, p)
            }
            7 -> { // cry
                c.drawLine(-ex - 1.2f * u, ey - 0.6f * u, -ex + 1.2f * u, ey - 0.6f * u, p)
                c.drawLine(-ex, ey - 0.6f * u, -ex, ey + 0.9f * u, p)
                c.drawLine(ex - 1.2f * u, ey - 0.6f * u, ex + 1.2f * u, ey - 0.6f * u, p)
                c.drawLine(ex, ey - 0.6f * u, ex, ey + 0.9f * u, p)
                arcAt(c, p, 0f, 3.2f * u, 1.9f * u, 1.1f * u + mo * 0.4f * u, 200f, 140f)
                p.style = Paint.Style.FILL; p.color = a(BLUE, 0.9f * al)
                for (k in 0..1) {
                    val f = ((t * 1.2f + k * 0.5f) % 1f)
                    c.drawCircle((if (k == 0) -ex else ex) + (if (k == 0) -0.6f else 0.6f) * u, ey + 1.2f * u + f * 3.4f * u, 0.5f * u * (1f - f * 0.4f), p)
                }
            }
            8 -> { // blush > <
                c.drawLine(-ex - 1.1f * u, ey - 1f * u, -ex + 0.9f * u, ey, p)
                c.drawLine(-ex + 0.9f * u, ey, -ex - 1.1f * u, ey + 1f * u, p)
                c.drawLine(ex + 1.1f * u, ey - 1f * u, ex - 0.9f * u, ey, p)
                c.drawLine(ex - 0.9f * u, ey, ex + 1.1f * u, ey + 1f * u, p)
                arcAt(c, p, 0f, 2.1f * u, 1.0f * u, 0.7f * u + mo * 0.4f * u, 15f, 150f)
                stroke(p, PINK, 0.7f * u, 0.9f * al)
                for (k in 0..1) {
                    val bx = if (k == 0) -3.6f * u else 3.6f * u
                    c.drawLine(bx - 0.7f * u, 1.0f * u, bx - 0.2f * u, 0.2f * u, p)
                    c.drawLine(bx + 0.1f * u, 1.0f * u, bx + 0.6f * u, 0.2f * u, p)
                }
            }
            9 -> { // star eyes
                val tw = 0.75f + 0.25f * sin(t * 9f)
                p.style = Paint.Style.FILL; p.color = a(col, al)
                starPath(-ex, ey, 1.6f * u * tw); c.drawPath(path, p)
                starPath(ex, ey, 1.6f * u * tw); c.drawPath(path, p)
                stroke(p, col, w, al)
                arcAt(c, p, 0f, 0.8f * u, 2.4f * u, 1.8f * u + mo * u, 15f, 150f)
            }
            10 -> { // nervous
                p.style = Paint.Style.FILL; p.color = a(col, al)
                c.drawCircle(-ex, ey, 0.7f * u, p)
                c.drawCircle(ex, ey, 0.7f * u, p)
                stroke(p, col, w, al)
                path.reset()
                path.moveTo(-2f * u, 2.4f * u)
                path.cubicTo(-1f * u, 1.6f * u, -0.5f * u, 3.2f * u, 0f, 2.4f * u)
                path.cubicTo(0.5f * u, 1.6f * u, 1f * u, 3.2f * u, 2f * u, 2.4f * u)
                c.drawPath(path, p)
                val f = (t * 0.9f) % 1f
                p.style = Paint.Style.FILL; p.color = a(BLUE, (1f - f) * al)
                c.drawCircle(4.1f * u, -3f * u + f * 3.4f * u, 0.6f * u, p)
            }
            else -> { // kiss: ^ ^ and a tiny heart mouth
                arcAt(c, p, -ex, ey + 0.6f * u, 1.3f * u, 1.3f * u, 200f, 140f)
                arcAt(c, p, ex, ey + 0.6f * u, 1.3f * u, 1.3f * u, 200f, 140f)
                val s = (0.55f + 0.1f * sin(t * 9f) + 0.1f * mo) * u
                heartPath(0f, 2.2f * u, s)
                p.style = Paint.Style.FILL; p.color = a(PINK, al)
                c.drawPath(path, p)
            }
        }
        if (blink && mood in intArrayOf(2, 3, 5, 6, 10)) {
            p.style = Paint.Style.FILL
            p.color = a(0xFF0A1118.toInt(), 0.85f)
            c.drawRect(-ex - 1.6f * u, ey - 1.5f * u, ex + 1.6f * u, ey + 1.5f * u, p)
            stroke(p, col, w, al)
            c.drawLine(-ex - 1f * u, ey, -ex + 1f * u, ey, p)
            c.drawLine(ex - 1f * u, ey, ex + 1f * u, ey, p)
        }
        c.restore()
    }

    fun heartAt(c: Canvas, p: Paint, cx: Float, cy: Float, s: Float, col: Int, al: Float) {
        heartPath(cx, cy, s)
        p.style = Paint.Style.FILL; p.shader = null; p.color = a(col, al)
        c.drawPath(path, p)
    }

    private fun heartPath(cx: Float, cy: Float, s: Float) {
        path.reset()
        path.moveTo(cx, cy + s)
        path.cubicTo(cx - s * 1.7f, cy - s * 0.1f, cx - s * 0.8f, cy - s * 1.35f, cx, cy - s * 0.45f)
        path.cubicTo(cx + s * 0.8f, cy - s * 1.35f, cx + s * 1.7f, cy - s * 0.1f, cx, cy + s)
        path.close()
    }

    private fun starPath(cx: Float, cy: Float, s: Float) {
        path.reset()
        path.moveTo(cx, cy - s)
        path.lineTo(cx + s * 0.28f, cy - s * 0.28f)
        path.lineTo(cx + s, cy)
        path.lineTo(cx + s * 0.28f, cy + s * 0.28f)
        path.lineTo(cx, cy + s)
        path.lineTo(cx - s * 0.28f, cy + s * 0.28f)
        path.lineTo(cx - s, cy)
        path.lineTo(cx - s * 0.28f, cy - s * 0.28f)
        path.close()
    }

    /** Small animated symbol that pops in after a line. 0 heart, 1 spark, 2 note, 3 zzz, 4 drop, 5 bolt, 6 bang. */
    fun sym(c: Canvas, p: Paint, id: Int, cx: Float, cy: Float, s: Float, t: Float, scale: Float, al: Float) {
        if (scale <= 0.01f) return
        c.save()
        c.translate(cx, cy)
        c.scale(scale, scale)
        when (id) {
            0 -> {
                val k = 1f + 0.18f * max(0f, sin(t * 9f))
                heartPath(0f, 0f, s * 0.85f * k)
                p.style = Paint.Style.FILL; p.color = a(PINK, 0.25f * al)
                c.save(); c.scale(1.35f, 1.35f); c.drawPath(path, p); c.restore()
                heartPath(0f, 0f, s * 0.85f * k)
                p.color = a(PINK, al)
                c.drawPath(path, p)
            }
            1 -> {
                c.rotate(sin(t * 3f) * 18f)
                val k = 0.75f + 0.25f * sin(t * 8f)
                starPath(0f, 0f, s * k)
                p.style = Paint.Style.FILL; p.color = a(AMBER, al)
                c.drawPath(path, p)
            }
            2 -> {
                val b = sin(t * 7f) * 0.5f
                c.translate(0f, b)
                p.style = Paint.Style.FILL; p.color = a(GREEN, al)
                c.drawCircle(-s * 0.3f, s * 0.6f, s * 0.42f, p)
                stroke(p, GREEN, s * 0.2f, al)
                c.drawLine(s * 0.05f, s * 0.55f, s * 0.05f, -s * 0.8f, p)
                c.drawLine(s * 0.05f, -s * 0.8f, s * 0.7f, -s * 0.4f, p)
            }
            3 -> {
                val f = (t * 0.8f) % 1f
                c.translate(f * s * 0.5f, -f * s * 0.7f)
                stroke(p, VIOLET, s * 0.2f, al * (1f - f * 0.6f))
                path.reset()
                path.moveTo(-s * 0.6f, -s * 0.5f); path.lineTo(s * 0.5f, -s * 0.5f); path.lineTo(-s * 0.6f, s * 0.6f); path.lineTo(s * 0.5f, s * 0.6f)
                c.drawPath(path, p)
            }
            4 -> {
                val f = (t * 1.1f) % 1f
                c.translate(0f, f * s * 0.5f)
                path.reset()
                path.moveTo(0f, -s)
                path.quadTo(s * 0.9f, s * 0.15f, 0f, s * 0.9f)
                path.quadTo(-s * 0.9f, s * 0.15f, 0f, -s)
                p.style = Paint.Style.FILL; p.color = a(BLUE, al * (1f - f * 0.5f))
                c.drawPath(path, p)
            }
            5 -> {
                val fl = if (sin(t * 22f) > -0.3f) 1f else 0.55f
                path.reset()
                path.moveTo(s * 0.2f, -s); path.lineTo(-s * 0.6f, s * 0.15f); path.lineTo(-s * 0.05f, s * 0.15f)
                path.lineTo(-s * 0.3f, s); path.lineTo(s * 0.65f, -s * 0.2f); path.lineTo(s * 0.05f, -s * 0.2f)
                path.close()
                p.style = Paint.Style.FILL; p.color = a(AMBER, al * fl)
                c.drawPath(path, p)
            }
            else -> {
                c.translate(sin(t * 38f) * s * 0.12f, 0f)
                stroke(p, RED, s * 0.28f, al)
                c.drawLine(0f, -s * 0.9f, 0f, s * 0.25f, p)
                p.style = Paint.Style.FILL; p.color = a(RED, al)
                c.drawCircle(0f, s * 0.78f, s * 0.2f, p)
            }
        }
        c.restore()
    }
}

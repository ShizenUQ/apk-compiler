package com.xio.bulwark

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * Reads the frame timing of the game in front. `run` executes a shell command as the shell user
 * (through Shizuku) and returns its output, or a string starting with "ERR:" if it could not run.
 * Several fallbacks at every step, and a short timeline so we can always see what it did.
 */
class FpsEngine(private val run: (String) -> String) {

    @Volatile var failed = false
    @Volatile var error = ""
    @Volatile var dbg = "no sample yet"

    private var own = ""
    private var pkg = ""
    private var layer = ""
    private var lastPkgCheck = 0L
    private var lastFind = 0L
    private var lastTs = 0L
    private var lastChange = 0L
    private var zeroTicks = 0
    private var prevTotal = 0L
    private var prevIdle = 0L
    private var idInfo = ""
    private var fgHow = ""
    private var fgRaw = ""
    private var lastOkPack: String? = null
    private var lastOkMs = 0L
    private var layerInfo = ""
    private val timeline = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val pkgRe = Regex("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+)/")

    private fun sh(cmd: String): String {
        val o = run(cmd)
        if (o.startsWith("ERR:")) { failed = true; error = o }
        return o
    }

    // ---------- which app is in front ----------

    private fun parseFg(out: String, key: String?): String {
        for (line in out.lines()) {
            if (key != null && !line.contains(key)) continue
            if (line.contains("=null")) continue
            val m = pkgRe.find(line)
            if (m != null) return m.groupValues[1]
        }
        return ""
    }

    private fun ignored(p: String) =
        p == "com.android.systemui" || p.contains(".inputmethod") || p.contains("gamebooster") ||
            p.contains("gameturbo") || p.contains("keyboard")

    private fun foreground(): String {
        val a = sh("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
        var r = parseFg(a, "mCurrentFocus")
        if (r.isNotEmpty() && !ignored(r)) { fgHow = "focus"; return r }
        val r2 = parseFg(a, "mFocusedApp")
        if (r2.isNotEmpty() && !ignored(r2)) { fgHow = "focusedApp"; return r2 }
        val b = sh("dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity'")
        r = parseFg(b, null)
        if (r.isNotEmpty() && !ignored(r)) { fgHow = "resumed"; return r }
        val c = sh("dumpsys activity top | grep -m1 ACTIVITY")
        r = parseFg(c, null)
        if (r.isNotEmpty() && !ignored(r)) { fgHow = "top"; return r }
        fgHow = "none"
        fgRaw = a.trim().take(160)
        return ""
    }

    // ---------- frame data ----------

    private fun latency(name: String): List<Long> {
        val out = sh("dumpsys SurfaceFlinger --latency '$name'")
        val res = ArrayList<Long>()
        val lines = out.lines()
        for (i in 1 until lines.size) {
            val parts = lines[i].trim().split(Regex("\\s+"))
            if (parts.size < 3) continue
            val t = parts[1].toLongOrNull() ?: continue
            if (t <= 0L || t >= Long.MAX_VALUE / 2) continue
            res.add(t)
        }
        return res.distinct()
    }

    private fun findLayer(p: String): String {
        val all = sh("dumpsys SurfaceFlinger --list").lines().map { it.trim() }.filter { it.isNotEmpty() }
        var cands = all.filter {
            it.contains(p) && !it.startsWith("Background for") && !it.startsWith("Bounds for") &&
                !it.contains("Letterbox")
        }
        var how = "by package"
        if (cands.isEmpty()) {
            how = "any surface"
            cands = all.filter {
                (it.contains("SurfaceView") || it.contains("BLAST")) && !it.contains(own) &&
                    !it.contains("systemui") && !it.startsWith("Background for") && !it.startsWith("Bounds for")
            }
        }
        cands = cands.sortedBy { if (it.contains("SurfaceView")) 0 else 1 }.take(6)
        var best = ""
        var bestLast = 0L
        var bestSize = 0
        for (c in cands) {
            val ts = latency(c)
            if (ts.isEmpty()) continue
            val last = ts.last()
            if (last > bestLast || (last == bestLast && ts.size > bestSize)) {
                best = c; bestLast = last; bestSize = ts.size
            }
        }
        layerInfo = "layers total ${all.size}, tried ${cands.size} ($how)"
        return best
    }

    private fun cpuUsage(): Float {
        return try {
            val line = sh("head -n 1 /proc/stat")
            val n = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (n.size < 5) return -1f
            val idle = n[3] + n[4]
            val total = n.sum()
            val first = prevTotal == 0L
            val dt = total - prevTotal
            val di = idle - prevIdle
            prevTotal = total; prevIdle = idle
            if (first || dt <= 0) -1f else (1f - di.toFloat() / dt.toFloat()).coerceIn(0f, 1f) * 100f
        } catch (t: Throwable) {
            -1f
        }
    }

    private fun pack(fps: Float, low: Float, ft: Float, cpu: Float, status: String, frames: List<Float>): String {
        return String.format(
            Locale.US, "%.1f|%.1f|%.2f|%.0f|%s|%s|%s|%s",
            fps, low, ft, cpu, pkg, status,
            frames.joinToString(",") { String.format(Locale.US, "%.1f", it) }, layer
        )
    }

    private var lastKey = ""
    private var lastCount = 0
    private var lastStart = ""
    private var maxFps = 0f

    private fun entry() = lastStart + "  " + lastKey + "  x" + lastCount + "  maxfps=" + String.format(Locale.US, "%.0f", maxFps)

    private fun log(status: String, fps: Float) {
        val key = status.padEnd(9) + " " + pkg
        synchronized(timeline) {
            if (key == lastKey && timeline.isNotEmpty()) {
                lastCount++
                if (fps > maxFps) maxFps = fps
                timeline.removeLast()
                timeline.addLast(entry())
            } else {
                lastKey = key; lastCount = 1; lastStart = clock.format(Date()); maxFps = fps
                timeline.addLast(entry())
                while (timeline.size > 30) timeline.removeFirst()
            }
            dbg = "$idInfo\nforeground: $pkg (via $fgHow)\nlayer: $layer\n$layerInfo\n" +
                (if (fgRaw.isNotEmpty()) "last focus text: $fgRaw\n" else "") +
                "\nchanges only, newest last (x = readings in a row):\n" + timeline.joinToString("\n")
        }
    }

    // ---------- public ----------

    fun sample(ownPkg: String): String {
        failed = false
        own = ownPkg
        val raw = try {
            doSample()
        } catch (t: Throwable) {
            dbg = "sample crashed: $t"
            "-1|-1|-1|-1||ERR||"
        }
        val p = raw.split("|")
        val st = if (p.size > 5) p[5] else ""
        val now = System.currentTimeMillis()
        if (st == "OK") {
            lastOkPack = raw; lastOkMs = now
        } else if (lastOkPack != null && now - lastOkMs < 1500 &&
            (st == "NOLAYER" || st == "NOFRAMES" || st == "STALE" || st == "NOPKG")
        ) {
            return lastOkPack!!                       // short hiccup: keep showing the last good reading
        }
        return raw
    }

    private fun doSample(): String {
        if (idInfo.isEmpty()) idInfo = sh("id").trim()
        val nowMs = System.currentTimeMillis()
        val cpu = cpuUsage()

        if (pkg.isEmpty() || nowMs - lastPkgCheck > 2000) {
            lastPkgCheck = nowMs
            val np = foreground()
            if (np.isNotEmpty() && np != pkg) {
                pkg = np; layer = ""; lastTs = 0L; zeroTicks = 0; lastFind = 0L
            }
        }
        if (pkg.isEmpty()) { log("NOPKG", -1f); return pack(-1f, -1f, -1f, cpu, "NOPKG", emptyList()) }
        if (pkg == own) { log("SELF", -1f); return pack(-1f, -1f, -1f, cpu, "SELF", emptyList()) }

        if (layer.isEmpty() || (zeroTicks >= 3 && nowMs - lastFind > 4000)) {
            lastFind = nowMs
            val f = findLayer(pkg)
            if (f.isNotEmpty()) { layer = f; zeroTicks = 0 }
        }
        if (layer.isEmpty()) { log("NOLAYER", -1f); return pack(-1f, -1f, -1f, cpu, "NOLAYER", emptyList()) }

        val ts = latency(layer)
        if (ts.size < 2) {
            zeroTicks++
            log("NOFRAMES", 0f)
            return pack(0f, 0f, 0f, cpu, "NOFRAMES", emptyList())
        }
        val lastT = ts.last()
        if (lastT != lastTs) { lastTs = lastT; lastChange = nowMs }
        if (nowMs - lastChange > 1800) {
            zeroTicks++
            log("STALE", 0f)
            return pack(0f, 0f, 0f, cpu, "STALE", emptyList())
        }

        val cut = lastT - 1_000_000_000L
        val win = ts.filter { it >= cut }
        val fps = if (win.size >= 2) (win.size - 1) * 1e9f / (win.last() - win.first()) else 0f
        val deltas = ts.zipWithNext { a, b -> (b - a) / 1e6f }
        val winDeltas = win.zipWithNext { a, b -> (b - a) / 1e6f }
        val ft = if (winDeltas.isNotEmpty()) winDeltas.average().toFloat() else 0f
        val sorted = deltas.sortedDescending()
        val worst = if (sorted.isEmpty()) 0f else sorted[(sorted.size * 0.01f).toInt().coerceAtMost(sorted.size - 1)]
        val low = if (worst > 0f) 1000f / worst else 0f
        val frames = deltas.takeLast(48)
        if (fps <= 0f) zeroTicks++ else zeroTicks = 0
        log("OK", fps)
        return pack(fps, low, ft, cpu, "OK", frames)
    }
}

package com.xio.bulwark

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Five animated neon faces. Each reacts to the beat when playing and sleeps when not. */
object Faces {
    val names = listOf("Squint", "Blob", "Cat", "Robot", "Ghost")
    val colors = intArrayOf(0xFF19E6F2.toInt(), 0xFF3DDC97.toInt(), 0xFF8F6BFF.toInt(), 0xFFFFC24B.toInt(), 0xFFFF2E93.toInt())
    fun color(id: Int) = colors[((id % 5) + 5) % 5]

    private val rf = RectF()
    private val path = Path()
    private var cp: Paint? = null
    private var u = 1f
    private var col = 0
    private var sw = 1f

    private fun a(c: Int, al: Float): Int = (c and 0x00FFFFFF) or ((al.coerceIn(0f, 1f) * 255f).toInt() shl 24)

    private fun ln(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        val p = cp!!
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = sw * 2.6f
        p.color = a(col, 0.18f)
        c.drawLine(x0, y0, x1, y1, p)
        p.strokeWidth = sw
        p.color = col
        c.drawLine(x0, y0, x1, y1, p)
    }

    private fun arc(c: Canvas, l: Float, t: Float, r: Float, b: Float, st: Float, sweep: Float) {
        val p = cp!!
        rf.set(l, t, r, b)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = sw * 2.6f
        p.color = a(col, 0.18f)
        c.drawArc(rf, st, sweep, false, p)
        p.strokeWidth = sw
        p.color = col
        c.drawArc(rf, st, sweep, false, p)
    }

    private fun oval(c: Canvas, l: Float, t: Float, r: Float, b: Float, fillA: Float) {
        val p = cp!!
        rf.set(l, t, r, b)
        p.style = Paint.Style.FILL
        p.color = a(col, fillA)
        c.drawOval(rf, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw * 2.6f
        p.color = a(col, 0.18f)
        c.drawOval(rf, p)
        p.strokeWidth = sw
        p.color = col
        c.drawOval(rf, p)
    }

    private fun dot(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        val p = cp!!
        p.style = Paint.Style.FILL
        p.color = color
        c.drawCircle(x, y, r, p)
    }

    private fun note(c: Canvas, x: Float, y: Float, al: Float) {
        val p = cp!!
        p.style = Paint.Style.FILL
        p.color = a(col, al)
        c.drawCircle(x, y, 2.6f * u, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = sw * 0.8f
        c.drawLine(x + 2.4f * u, y, x + 2.4f * u, y - 9 * u, p)
        c.drawLine(x + 2.4f * u, y - 9 * u, x + 6 * u, y - 6.5f * u, p)
    }

    /**
     * id 0..4. (cx, cy) centre, r = radius of the face area. t seconds. level 0..1 loudness, kick 0..1 beat pulse,
     * on = music playing. Needs a Paint (its state is changed).
     */
    fun draw(c: Canvas, p: Paint, id: Int, cx: Float, cy: Float, r: Float, t: Float, level: Float, kick: Float, on: Boolean) {
        cp = p
        u = r / 50f
        col = color(id)
        sw = max(0.5f, 2.4f * u)
        val lv = if (on) level else 0f
        val kk = if (on) kick else 0f
        val bob = if (on) sin(t * 2.4f) * 2f * u - kk * 3f * u else sin(t * 1.1f) * 1.2f * u
        c.save()
        c.translate(cx, cy + bob)
        val sc = 1f + kk * 0.07f
        c.scale(sc, sc)
        when (((id % 5) + 5) % 5) {
            0 -> squint(c, t, lv, kk, on)
            1 -> blob(c, t, lv, kk, on)
            2 -> cat(c, t, lv, kk, on)
            3 -> robot(c, t, lv, kk, on)
            else -> ghost(c, t, lv, kk, on)
        }
        c.restore()
    }

    private fun blink(t: Float, period: Float): Float {
        val k = (t % period)
        return if (k > period - 0.16f) abs((k - (period - 0.08f)) / 0.08f) else 1f
    }

    // ---- 0: >_< ----
    private fun squint(c: Canvas, t: Float, lv: Float, kk: Float, on: Boolean) {
        oval(c, -40 * u, -40 * u, 40 * u, 40 * u, 0.08f)
        if (on) {
            val sq = kk * 3f * u
            val sh = 7f * u + lv * 3f * u
            ln(c, -24 * u + sq, -sh - 4 * u, -9 * u + sq, -4 * u)
            ln(c, -9 * u + sq, -4 * u, -24 * u + sq, sh - 4 * u)
            ln(c, 24 * u - sq, -sh - 4 * u, 9 * u - sq, -4 * u)
            ln(c, 9 * u - sq, -4 * u, 24 * u - sq, sh - 4 * u)
            val mh = (5f + 13f * (0.35f + lv * 0.65f + kk * 0.3f)) * u
            path.reset()
            path.moveTo(-13 * u, 10 * u)
            path.lineTo(13 * u, 10 * u)
            path.quadTo(0f, 10 * u + mh * 1.6f, -13 * u, 10 * u)
            cp!!.style = Paint.Style.FILL
            cp!!.color = a(col, 0.22f)
            c.drawPath(path, cp!!)
            ln(c, -13 * u, 10 * u, 13 * u, 10 * u)
            arc(c, -13 * u, 10 * u - mh * 0.6f, 13 * u, 10 * u + mh * 1.0f, 0f, 180f)
            ln(c, -33 * u, 6 * u, -27 * u, 9 * u)
            ln(c, 33 * u, 6 * u, 27 * u, 9 * u)
            if (kk > 0.5f) { ln(c, 30 * u, -34 * u, 36 * u, -40 * u); ln(c, 36 * u, -34 * u, 30 * u, -40 * u) }
        } else {
            val b = blink(t, 4f)
            ln(c, -24 * u, -4 * u, -10 * u, -4 * u * b - 1f * u)
            ln(c, 10 * u, -4 * u * b - 1f * u, 24 * u, -4 * u)
            ln(c, -8 * u, 14 * u, 8 * u, 14 * u)
            note(c, 30 * u, -26 * u + sin(t * 1.5f) * 3 * u, 0.0f)
        }
    }

    // ---- 1: blob ----
    private fun blob(c: Canvas, t: Float, lv: Float, kk: Float, on: Boolean) {
        val w = (40f + kk * 5f) * u
        val h = (34f - kk * 4f + lv * 3f) * u
        oval(c, -w, -h + 4 * u, w, h + 4 * u, 0.12f)
        val b = blink(t, 3.4f)
        val er = 4.2f * u
        dot(c, -15 * u, -6 * u, er, col)
        dot(c, 15 * u, -6 * u, er, col)
        if (b < 0.9f) {
            dot(c, -15 * u, -6 * u, er + 0.8f * u, 0xFF0A0D11.toInt())
            dot(c, 15 * u, -6 * u, er + 0.8f * u, 0xFF0A0D11.toInt())
            ln(c, -19 * u, -6 * u, -11 * u, -6 * u)
            ln(c, 11 * u, -6 * u, 19 * u, -6 * u)
        }
        if (on) {
            val mh = (3f + 15f * (lv * 0.7f + kk * 0.5f)) * u
            oval(c, -9 * u, 8 * u, 9 * u, 8 * u + mh, 0.3f)
            for (i in 0..1) {
                val f = ((t * 0.5f + i * 0.5f) % 1f)
                note(c, (28f + i * 6f) * u, (-10f - 34f * f) * u, 1f - f)
            }
        } else {
            arc(c, -9 * u, 6 * u, 9 * u, 18 * u, 20f, 140f)
        }
    }

    // ---- 2: cat with headphones ----
    private fun cat(c: Canvas, t: Float, lv: Float, kk: Float, on: Boolean) {
        val tw = if (on) sin(t * 9f) * kk * 2f * u else 0f
        // ears
        ln(c, -30 * u, -22 * u, -34 * u + tw, -44 * u)
        ln(c, -34 * u + tw, -44 * u, -12 * u, -33 * u)
        ln(c, 30 * u, -22 * u, 34 * u - tw, -44 * u)
        ln(c, 34 * u - tw, -44 * u, 12 * u, -33 * u)
        oval(c, -34 * u, -34 * u, 34 * u, 32 * u, 0.1f)
        // headphones
        arc(c, -42 * u, -48 * u, 42 * u, 30 * u, 195f, 150f)
        val cup = (1f + kk * 0.18f)
        val cw = 7f * u * cup
        oval(c, -42 * u - cw * 0.3f, -8 * u, -42 * u + cw, 14 * u, if (on) 0.5f else 0.2f)
        oval(c, 42 * u - cw, -8 * u, 42 * u + cw * 0.3f, 14 * u, if (on) 0.5f else 0.2f)
        if (on) {
            arc(c, -22 * u, -8 * u, -8 * u, 4 * u, 200f, 140f)
            arc(c, 8 * u, -8 * u, 22 * u, 4 * u, 200f, 140f)
        } else {
            val b = blink(t, 4.6f)
            ln(c, -22 * u, -2 * u, -9 * u, -2 * u + b * 0.1f)
            ln(c, 9 * u, -2 * u, 22 * u, -2 * u)
        }
        dot(c, 0f, 7 * u, 2.2f * u, col)
        arc(c, -8 * u, 8 * u, 0f, 17 * u, 0f, 150f)
        arc(c, 0f, 8 * u, 8 * u, 17 * u, 30f, 150f)
        val wg = if (on) sin(t * 8f) * (1f + lv) * 1.5f * u else 0f
        for (i in -1..1) {
            ln(c, -20 * u, (11f + i * 4f) * u, -38 * u, (11f + i * 6f) * u + wg)
            ln(c, 20 * u, (11f + i * 4f) * u, 38 * u, (11f + i * 6f) * u - wg)
        }
    }

    // ---- 3: robot with equalizer eyes ----
    private fun robot(c: Canvas, t: Float, lv: Float, kk: Float, on: Boolean) {
        rf.set(-36 * u, -28 * u, 36 * u, 32 * u)
        val p = cp!!
        p.style = Paint.Style.FILL
        p.color = a(col, 0.1f)
        c.drawRoundRect(rf, 9 * u, 9 * u, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = sw * 2.6f
        p.color = a(col, 0.18f)
        c.drawRoundRect(rf, 9 * u, 9 * u, p)
        p.strokeWidth = sw
        p.color = col
        c.drawRoundRect(rf, 9 * u, 9 * u, p)
        ln(c, 0f, -28 * u, 0f, -40 * u)
        val ant = if (on) 0.4f + kk * 0.6f else (if (((t * 1.2f).toInt() % 2) == 0) 0.9f else 0.2f)
        dot(c, 0f, -43 * u, 3.4f * u, a(col, ant))
        dot(c, -41 * u, 2 * u, 2.6f * u, a(col, 0.8f))
        dot(c, 41 * u, 2 * u, 2.6f * u, a(col, 0.8f))
        for (side in intArrayOf(-1, 1)) {
            val ex = side * 16 * u
            if (on) {
                for (k in -1..1) {
                    val ph = sin(t * (7f + k * 2.3f) + side * 1.3f + k) * 0.5f + 0.5f
                    val hgt = (3f + 12f * (0.25f + lv * 0.55f + kk * 0.25f) * (0.4f + 0.6f * ph)) * u
                    ln(c, ex + k * 5.5f * u, -6 * u - hgt / 2f, ex + k * 5.5f * u, -6 * u + hgt / 2f)
                }
            } else {
                val b = blink(t, 3.8f)
                ln(c, ex - 7 * u, -6 * u, ex + 7 * u, -6 * u)
                if (b > 0.5f) dot(c, ex, -6 * u, 1.8f * u, a(col, 0.8f))
            }
        }
        ln(c, -18 * u, 16 * u, 18 * u, 16 * u)
        for (k in -3..3) {
            val hh = if (on) (2f + 5f * abs(sin(t * 9f + k * 1.7f)) * (0.4f + lv)) * u else 2f * u
            ln(c, k * 5.5f * u, 16 * u - hh, k * 5.5f * u, 16 * u + hh)
        }
    }

    // ---- 4: sleepy ghost ----
    private fun ghost(c: Canvas, t: Float, lv: Float, kk: Float, on: Boolean) {
        val fl = if (on) sin(t * 3f) * 3f * u else sin(t * 1.3f) * 2f * u
        c.translate(0f, fl)
        path.reset()
        path.moveTo(-30 * u, -4 * u)
        rf.set(-30 * u, -36 * u, 30 * u, 24 * u)
        path.arcTo(rf, 180f, 180f)
        path.lineTo(30 * u, 34 * u)
        var x = 30f
        while (x >= -30f) {
            path.lineTo(x * u, (34f + sin(x * 0.4f + t * 4f) * 3f) * u)
            x -= 5f
        }
        path.close()
        val p = cp!!
        p.style = Paint.Style.FILL
        p.color = a(col, 0.12f)
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = sw * 2.6f
        p.color = a(col, 0.18f)
        c.drawPath(path, p)
        p.strokeWidth = sw
        p.color = col
        c.drawPath(path, p)
        if (on) {
            val ex = 6f * u + kk * 1.5f * u
            oval(c, -15 * u - ex / 2f, -12 * u, -15 * u + ex, -2 * u, 0.5f)
            oval(c, 9 * u, -12 * u, 15 * u + ex, -2 * u, 0.5f)
            dot(c, -12 * u + sin(t * 2f) * 1.2f * u, -7 * u, 1.6f * u, 0xFFFFFFFF.toInt())
            dot(c, 12 * u + sin(t * 2f) * 1.2f * u, -7 * u, 1.6f * u, 0xFFFFFFFF.toInt())
            val mr = (2.5f + 6f * (lv * 0.7f + kk * 0.5f)) * u
            oval(c, -mr, 8 * u, mr, 8 * u + mr * 1.6f, 0.3f)
            ln(c, -26 * u, 4 * u, -21 * u, 4 * u)
            ln(c, 21 * u, 4 * u, 26 * u, 4 * u)
        } else {
            arc(c, -20 * u, -10 * u, -8 * u, 0f, 20f, 140f)
            arc(c, 8 * u, -10 * u, 20 * u, 0f, 20f, 140f)
            arc(c, -5 * u, 8 * u, 5 * u, 14 * u, 20f, 140f)
            val f = (t * 0.35f) % 1f
            val zx = (24f + f * 8f) * u
            val zy = (-30f - f * 20f) * u
            p.style = Paint.Style.STROKE
            p.strokeWidth = sw * 0.8f
            p.color = a(col, 1f - f)
            c.drawLine(zx - 3 * u, zy - 3 * u, zx + 3 * u, zy - 3 * u, p)
            c.drawLine(zx + 3 * u, zy - 3 * u, zx - 3 * u, zy + 3 * u, p)
            c.drawLine(zx - 3 * u, zy + 3 * u, zx + 3 * u, zy + 3 * u, p)
        }
    }
}

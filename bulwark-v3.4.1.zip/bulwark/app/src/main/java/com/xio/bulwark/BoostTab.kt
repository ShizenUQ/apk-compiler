package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** The big reactor on the Boost tab: RAM ring, charge-up, result count-up. */
class BoostCore(ctx: Context) : View(ctx) {
    private val IDLE = 0
    private val CHARGE = 1
    private val DONE = 2
    private val OFF = 3

    var onTap: (() -> Unit)? = null
    private var state = IDLE
    private var off = false
    private var availMb = 0L
    private var totalMb = 1L
    private var target = 0f
    private var disp = 0f
    private var stepText = ""
    private var pendingFreed = -1L
    private var freed = 0L
    private var doneAt = 0L
    private var press = 0f
    private var pressed = false
    private var lastT = 0L
    private var heat = 0f
    private var ang = 0f
    private var running = false

    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!isShown || windowVisibility != View.VISIBLE) { tickIdle = true; return }
            invalidate()
            postDelayed(this, 33)
        }
    }

    private var tickIdle = false

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (262 * d).toInt())

    fun setMem(avail: Long, total: Long) { availMb = avail; totalMb = max(1L, total) }
    fun setOff(v: Boolean) { off = v }
    fun isBusy() = state == CHARGE

    fun start() {
        state = CHARGE; target = 0.04f; disp = 0f; pendingFreed = -1L; stepText = "Starting"
    }

    fun setProgress(pr: Float, text: String) { target = pr; stepText = text }

    fun finish(freedMb: Long) { target = 1f; pendingFreed = freedMb }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val dx = e.x - width / 2f
        val dy = e.y - 122 * d
        val inside = hypot(dx, dy) < 92 * d
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { if (inside) { pressed = true; return true }; return false }
            MotionEvent.ACTION_UP -> {
                val was = pressed
                pressed = false
                if (was && inside) { performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK); onTap?.invoke() }
                return true
            }
            MotionEvent.ACTION_CANCEL -> { pressed = false; return true }
        }
        return true
    }

    private fun segColor(f: Float): Int = when {
        f < 0.55f -> Neon.GREEN
        f < 0.78f -> Neon.CYAN
        f < 0.90f -> 0xFFFFC24B.toInt()
        else -> 0xFFFF2E93.toInt()
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, sizeDp: Float, color: Int, bold: Boolean, sp: Float) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", if (bold) Typeface.BOLD else Typeface.NORMAL)
        p.textSize = sizeDp * d
        p.letterSpacing = sp
        p.color = color
        c.drawText(s, x, y, p)
        p.letterSpacing = 0f
    }

    private fun digits(c: Canvas, s: String, cx: Float, base: Float, h: Float, color: Int) {
        val k = h / 10f
        val w = Cy.width(s.length, k)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        Cy.text(c, p, s, cx - w / 2f, base, h, color)
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = now / 1000f
        val dt = if (lastT == 0L) 0.033f else min(0.1f, (now - lastT) / 1000f)
        lastT = now
        val w = width.toFloat()
        val cx = w / 2f
        val cy = 122 * d
        press += ((if (pressed) 1f else 0f) - press) * 0.35f
        val R = 62 * d * (1f - 0.05f * press)

        if (state == CHARGE) {
            disp = min(target, disp + 0.42f * dt)
            if (pendingFreed >= 0 && disp >= 0.995f) {
                state = DONE; freed = pendingFreed; doneAt = now
            }
        }
        if (state == DONE && now - doneAt > 9000L) state = IDLE
        if (state != CHARGE && off) state = OFF
        if (state == OFF && !off) state = IDLE
        val charging = state == CHARGE
        heat += ((if (charging) 1f else if (state == DONE) 0.45f else 0f) - heat) * 0.08f
        ang = (ang + (30f + 700f * heat * heat) * dt) % 3600f
        val shock = if (state == DONE) min(1f, (now - doneAt) / 900f) else 1f

        // glow
        p.style = Paint.Style.FILL
        val gc = if (state == OFF) 0xFFFF2E93.toInt() else Neon.CYAN
        p.shader = RadialGradient(cx, cy, R * 1.9f, Cy.a(gc, 0.08f + 0.3f * heat), 0, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R * 1.9f, p)
        p.shader = null

        // RAM segments
        val used = (1f - availMb / totalMb.toFloat()).coerceIn(0f, 1f)
        val n = 60
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 2.6f * d
        val r0 = R + 9 * d
        for (i in 0 until n) {
            val f = i / n.toFloat()
            val a = (-90f + i * 360f / n) * 0.0174533f
            val lit = if (charging || (state == DONE && disp < 1f)) f < disp else f < used
            var col = segColor(f)
            var al = if (lit) 0.95f else 0.14f
            var len = if (lit) 9f else 5f
            if (charging) {
                val head = 1f - ((disp - f) * 6f).coerceIn(0f, 1f)
                if (lit) { col = Neon.CYAN; al = 0.5f + 0.5f * head; len = 8f + 6f * head }
            }
            if (state == OFF) { col = 0xFFFF2E93.toInt(); al = if (i % 5 == 0) 0.4f else 0.12f; len = 5f }
            p.color = Cy.a(col, al)
            c.drawLine(cx + cos(a) * r0, cy + sin(a) * r0, cx + cos(a) * (r0 + len * d), cy + sin(a) * (r0 + len * d), p)
        }

        // rotating arcs
        rr.set(cx - R, cy - R, cx + R, cy + R)
        p.strokeWidth = 3f * d
        p.color = Cy.a(gc, 0.18f)
        c.drawArc(rr, 0f, 360f, false, p)
        p.color = if (state == OFF) 0xFFFF2E93.toInt() else Neon.GREEN
        c.drawArc(rr, ang * 0.6f, 60f + 50f * heat, false, p)
        p.color = gc
        c.drawArc(rr, -ang * 0.9f + 180f, 36f + 44f * heat, false, p)
        rr.inset(10 * d, 10 * d)
        p.strokeWidth = 1.2f * d
        p.color = Cy.a(gc, 0.35f)
        c.drawArc(rr, ang * 1.3f, 90f, false, p)
        c.drawArc(rr, ang * 1.3f + 180f, 90f, false, p)

        // core disc
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, R * 0.9f, intArrayOf(Cy.a(gc, 0.10f + 0.22f * heat), 0xF0081018.toInt()), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R - 12 * d, p)
        p.shader = null

        // lightning + particles while charging
        if (charging || heat > 0.1f) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.5f * d
            val seed = (t * 14f).toInt()
            for (i in 0 until 5) {
                val a = (seed * 0.9f + i * 72f) * 0.0174533f
                p.color = Cy.a(if (i % 2 == 0) Neon.CYAN else Neon.GREEN, 0.8f * heat)
                Cy.arc(c, p, cx + cos(a) * R * 0.3f, cy + sin(a) * R * 0.3f, cx + cos(a) * (R - 10 * d), cy + sin(a) * (R - 10 * d), seed * 7 + i, 6 * d)
            }
            p.style = Paint.Style.FILL
            for (i in 0 until 16) {
                val f = ((t * (0.7f + Cy.rnd(i) * 0.6f) + Cy.rnd(i * 3 + 1)) % 1f)
                val a = (Cy.rnd(i * 5 + 2) * 360f) * 0.0174533f
                val rad = (R * 2.0f) * (1f - f) + R * 0.35f
                p.color = Cy.a(Neon.CYAN, 0.7f * heat * (1f - f))
                c.drawCircle(cx + cos(a) * rad, cy + sin(a) * rad, (1.2f + 1.4f * Cy.rnd(i)) * d, p)
            }
        }

        // shockwave
        if (state == DONE && shock < 1f) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f * d * (1f - shock)
            p.color = Cy.a(Neon.GREEN, 0.8f * (1f - shock))
            c.drawCircle(cx, cy, R * (0.9f + 1.1f * shock), p)
        }

        // centre text
        when (state) {
            CHARGE -> {
                digits(c, "${(disp * 100).toInt()}", cx, cy + 12 * d, 28 * d, Neon.CYAN)
                txt(c, "PERCENT", cx, cy + 32 * d, 9f, P.DIM, false, 0.2f)
                txt(c, stepText.uppercase(), cx, cy + R + 44 * d, 11f, Neon.CYAN, false, 0.15f)
            }
            DONE -> {
                val k = ((now - doneAt) / 1100f).coerceIn(0f, 1f)
                val v = (freed * (1f - (1f - k) * (1f - k))).toLong()
                txt(c, "FREED", cx, cy - 22 * d, 9f, P.DIM, false, 0.25f)
                digits(c, "$v", cx, cy + 14 * d, 28 * d, Neon.GREEN)
                txt(c, "MB", cx, cy + 32 * d, 10f, Neon.GREEN, true, 0.2f)
                txt(c, "${availMb} MB FREE NOW", cx, cy + R + 44 * d, 11f, Neon.GREEN, false, 0.12f)
            }
            OFF -> {
                txt(c, "SHIZUKU", cx, cy - 2 * d, 15f, 0xFFFF2E93.toInt(), true, 0.15f)
                txt(c, "IS OFF", cx, cy + 18 * d, 11f, P.DIM, false, 0.2f)
                txt(c, "START SHIZUKU, THEN TAP", cx, cy + R + 44 * d, 11f, P.DIM, false, 0.1f)
            }
            else -> {
                txt(c, "FREE RAM", cx, cy - 20 * d, 9f, P.DIM, false, 0.25f)
                digits(c, "$availMb", cx, cy + 12 * d, 26 * d, Neon.CYAN)
                txt(c, "MB", cx, cy + 32 * d, 10f, Neon.CYAN, true, 0.2f)
                val pulse = 0.55f + 0.45f * sin(t * 3f)
                txt(c, "TAP TO BOOST", cx, cy + R + 44 * d, 12f, Cy.a(Neon.GREEN, pulse), true, 0.25f)
            }
        }
    }
}

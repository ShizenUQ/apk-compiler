package com.xio.bulwark

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.SystemClock
import java.util.Date

/** Frame data coming back from the Shizuku shell process. fps < 0 means "not available". */
class FpsData(
    val fps: Float,
    val low: Float,
    val ft: Float,
    val cpu: Float,
    val pkg: String,
    val status: String,
    val frames: FloatArray
) {
    companion object {
        fun na(status: String) = FpsData(-1f, -1f, -1f, -1f, "", status, FloatArray(0))

        fun parse(raw: String?): FpsData {
            if (raw == null) return na("NOLINK")
            val p = raw.trim().split("|")
            if (p.size < 7) return na("BAD")
            return try {
                val fr = if (p[6].isEmpty()) FloatArray(0)
                else p[6].split(",").mapNotNull { it.toFloatOrNull() }.toFloatArray()
                FpsData(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat(), p[4], p[5], fr)
            } catch (e: Exception) {
                na("BAD")
            }
        }
    }
}

class SysData(
    val ram: Float,
    val bat: Int,
    val temp: Float,
    val charging: Boolean,
    val clock: String,
    val session: String
)

object StatsReader {
    fun read(c: Context, sessionStart: Long): SysData {
        val bi: Intent? = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        var level = -1
        var temp = -1f
        var charging = false
        if (bi != null) {
            val l = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val s = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (l >= 0 && s > 0) level = (l * 100) / s
            temp = bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) / 10f
            val st = bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        }
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val ram = if (mi.totalMem > 0) 1f - mi.availMem.toFloat() / mi.totalMem.toFloat() else -1f

        val clock = android.text.format.DateFormat.getTimeFormat(c).format(Date())
        val sec = ((SystemClock.elapsedRealtime() - sessionStart) / 1000).toInt()
        val sess = String.format("%02d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60)
        return SysData(ram, level, temp, charging, clock, sess)
    }
}

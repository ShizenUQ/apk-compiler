package com.xio.bulwark

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private fun lerpTo(v: View, from: Float, to: Float, ms: Long, f: (Float) -> Unit) {
    val a = ValueAnimator.ofFloat(from, to)
    a.duration = ms
    a.interpolator = DecelerateInterpolator(1.8f)
    a.addUpdateListener { f(it.animatedValue as Float); v.invalidate() }
    a.start()
}

/** Draws time as "12h 40m" with the cyber digits. Returns its width. */
private fun drawTime(c: Canvas, p: Paint, ms: Long, cx: Float, base: Float, h: Float, d: Float, color: Int, center: Boolean): Float {
    val mins = ms / 60_000L
    val hh = mins / 60
    val mm = mins % 60
    val k = h / 10f
    val hs = hh.toString()
    val ms2 = if (hh > 0) String.format("%02d", mm) else mm.toString()
    val unit = h * 0.55f
    p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    p.textSize = unit
    p.style = Paint.Style.FILL
    val uw = p.measureText("h") + 3 * d
    val gap = 5 * d
    val total = (if (hh > 0) Cy.width(hs.length, k) + uw + gap else 0f) + Cy.width(ms2.length, k) + p.measureText("m")
    var x = if (center) cx - total / 2f else cx
    if (hh > 0) {
        x += Cy.text(c, p, hs, x, base, h, color)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = unit
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.color = Cy.a(color, 0.7f)
        c.drawText("h", x + 2 * d, base, p)
        x += uw + gap
    }
    x += Cy.text(c, p, ms2, x, base, h, color)
    p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    p.textSize = unit
    p.style = Paint.Style.FILL
    p.textAlign = Paint.Align.LEFT
    p.color = Cy.a(color, 0.7f)
    c.drawText("m", x + 1 * d, base, p)
    return total
}

/** The panel at the top of the Games tab: all-time hours, today (or the live session) and game count. Static, redraws once a second only while a game runs. */
class TurboCore(ctx: Context) : View(ctx) {
    var todayMs = 0L
    var totalMs = 0L
    var gameCount = 0
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var running = false
    private var liveName = ""
    private var livePk = ""

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (Tracker.livePkg.isNotEmpty() && isShown && windowVisibility == View.VISIBLE) invalidate()
            postDelayed(this, 1000)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (138 * d).toInt())

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val now = SystemClock.uptimeMillis()
        val live = Tracker.livePkg
        val on = live.isNotEmpty()
        if (live != livePk) {
            livePk = live; liveName = ""
            if (on) liveName = try {
                context.packageManager.getApplicationLabel(context.packageManager.getApplicationInfo(live, 0)).toString()
            } catch (e: Throwable) { live }
        }
        CyUi.chamfer(path, d, d, w - d, h - d, 16 * d)
        p.style = Paint.Style.FILL; p.shader = null; p.color = Cy.a(Cy.CYAN, 0.06f); c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d; p.color = Cy.a(Cy.CYAN, 0.4f); c.drawPath(path, p)
        p.strokeWidth = 2.2f * d; p.color = Cy.PINK
        c.drawLine(d, 26 * d, d, 2 * d, p); c.drawLine(d, 2 * d, 46 * d, 2 * d, p)
        p.color = Cy.CYAN
        c.drawLine(w - 46 * d, h - 2 * d, w - 22 * d, h - 2 * d, p)
        p.strokeWidth = d; p.color = Cy.a(Cy.CYAN, 0.45f)
        for (i in 0 until 4) c.drawLine(w - 22 * d - i * 5 * d, 6 * d, w - 22 * d - i * 5 * d, 10 * d, p)

        val colW = (w - 36 * d) / 3f
        val x0 = 18 * d
        val k = 0.58f * d
        val labels = arrayOf("ALL TIME", if (on) "LIVE" else "TODAY", "GAMES")
        val cols = intArrayOf(Cy.CYAN, if (on) CyUi.YELLOW else Cy.CYAN, Cy.CYAN)
        for (i in 0..2) {
            val cx = x0 + colW * i + colW / 2f
            CyUi.text(c, p, labels[i], cx, 24 * d, k, Cy.a(cols[i], 0.85f), 1f, false, 1)
            if (i > 0) { p.style = Paint.Style.FILL; p.color = Cy.a(Cy.CYAN, 0.2f); c.drawRect(x0 + colW * i, 24 * d, x0 + colW * i + d, 76 * d, p) }
        }
        drawTime(c, p, totalMs, x0 + colW / 2f, 66 * d, 15 * d, d, 0xFFFFFFFF.toInt(), true)
        if (on) {
            val sec = ((now - Tracker.liveStart) / 1000L).toInt()
            val str = String.format("%d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60)
            val tw = Cy.width(str.length, 1.5f * d)
            Cy.text(c, p, str, x0 + colW * 1.5f - tw / 2f, 66 * d, 15 * d, 0xFFFFFFFF.toInt())
        } else drawTime(c, p, todayMs, x0 + colW * 1.5f, 66 * d, 15 * d, d, 0xFFFFFFFF.toInt(), true)
        val gs = gameCount.toString()
        val gw = Cy.width(gs.length, 1.5f * d)
        Cy.text(c, p, gs, x0 + colW * 2.5f - gw / 2f, 66 * d, 15 * d, 0xFFFFFFFF.toInt())

        // status line: a small square mark and the message
        p.style = Paint.Style.FILL
        p.color = if (on) CyUi.YELLOW else Cy.a(Cy.CYAN, 0.5f)
        c.drawRect(18 * d, h - 28 * d, 24 * d, h - 22 * d, p)
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 12 * d
        p.color = if (on) 0xFFFFFFFF.toInt() else 0xFF8B96A3.toInt()
        val msg = if (on) liveName else if (gameCount == 0) "Add or install a game to begin" else "Idle. Start a game and it is tracked here."
        c.drawText(TextUtils.ellipsize(msg, TextPaint(p), w - 70 * d, TextUtils.TruncateAt.END).toString(), 32 * d, h - 18.5f * d, p)
    }
}

/**
 * A game in the Hangar. Tinted with the colour of its icon. Press and hold to flip it over and peek at the app's
 * details (package, size, version, dates); let go and it flips back. A normal tap still opens the game page.
 */
class GameCard(ctx: Context, val app: Games.GameApp, private val icon: Drawable?, private val total: Long, private val maxMs: Long, private val last: Long) : View(ctx) {
    var onOpen: (() -> Unit)? = null
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val path = Path()
    private val col: Int = IconColor.of(app.pkg, icon)
    private val lite: Int = mix(col, 0xFFFFFFFF.toInt(), 0.45f)
    private var fill = 0f
    private var down = false
    private var info: GameInfo? = null
    private var flip = 0f
    private var flipAnim: ValueAnimator? = null
    private var peeking = false

    init {
        isClickable = true
        isLongClickable = true
        cameraDistance = 9000f * d
        setOnClickListener { onOpen?.invoke() }
        setOnLongClickListener { startPeek(); true }
    }

    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) * (1f - t) + Color.red(b) * t).toInt(),
        (Color.green(a) * (1f - t) + Color.green(b) * t).toInt(),
        (Color.blue(a) * (1f - t) + Color.blue(b) * t).toInt()
    )

    private fun startPeek() {
        peeking = true
        parent?.requestDisallowInterceptTouchEvent(true)
        if (info == null) {
            val c = context.applicationContext
            val pk = app.pkg
            Thread {
                val i = GameInfo.load(c, pk)
                post { info = i; invalidate() }
            }.start()
        }
        flipTo(1f)
    }

    private fun endPeek() {
        if (!peeking) return
        peeking = false
        flipTo(0f)
    }

    private fun flipTo(t: Float) {
        flipAnim?.cancel()
        val a = ValueAnimator.ofFloat(flip, t)
        a.duration = (340f * abs(t - flip)).toLong().coerceAtLeast(80L)
        a.interpolator = DecelerateInterpolator(1.4f)
        a.addUpdateListener {
            flip = it.animatedValue as Float
            rotationY = if (flip < 0.5f) flip * 180f else (flip - 1f) * 180f
            invalidate()
        }
        flipAnim = a
        a.start()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lerpTo(this, 0f, 1f, 800) { fill = it }
    }

    override fun onDetachedFromWindow() { flipAnim?.cancel(); super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((150 * d).toInt(), (218 * d).toInt())

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start(); invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false
                animate().scaleX(1f).scaleY(1f).setDuration(200).start()
                endPeek()
                invalidate()
            }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        if (flip >= 0.5f) drawBack(c) else drawFront(c)
    }

    private fun body(c: Canvas, w: Float, h: Float, glow: Float) {
        rr.set(d, d, w - d, h - d)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(Cy.a(col, 0.46f), 0xF2101823.toInt(), 0xF2070B10.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        CyUi.drawCut(c, p, rr, 16 * d)
        p.shader = RadialGradient(w / 2f, 70 * d, 96 * d, Cy.a(col, glow), 0, Shader.TileMode.CLAMP)
        c.drawCircle(w / 2f, 70 * d, 96 * d, p)
        p.shader = null
        rr.set(d, d, w - d, h - d)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.3f * d
        p.color = Cy.a(col, if (down || peeking) 0.95f else 0.55f)
        CyUi.drawCut(c, p, rr, 16 * d)
    }

    private fun drawFront(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        body(c, w, h, 0.42f)
        // corner brackets
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * d
        p.color = Cy.a(lite, 0.85f)
        val m = 6 * d
        val k = 11 * d
        c.drawLine(m, m + k, m, m, p); c.drawLine(m, m, m + k, m, p)
        c.drawLine(w - m - k, h - m, w - m, h - m, p); c.drawLine(w - m, h - m, w - m, h - m - k, p)

        val cx = w / 2f
        val cy = 66 * d
        if (icon != null) {
            val s = 70 * d
            // soft ring behind the icon
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * d
            p.color = Cy.a(0xFFFFFFFF.toInt(), 0.16f)
            c.drawRoundRect(cx - s / 2 - 3 * d, cy - s / 2 - 3 * d, cx + s / 2 + 3 * d, cy + s / 2 + 3 * d, 19 * d, 19 * d, p)
            c.save()
            path.reset()
            path.addRoundRect(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, 16 * d, 16 * d, Path.Direction.CW)
            c.clipPath(path)
            icon.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
            icon.draw(c)
            c.restore()
        }
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 13 * d
        p.color = 0xFFFFFFFF.toInt()
        c.drawText(TextUtils.ellipsize(app.name, TextPaint(p), w - 24 * d, TextUtils.TruncateAt.END).toString(), cx, 142 * d, p)
        if (total > 0L) {
            drawTime(c, p, total, cx, 168 * d, 18 * d, d, lite, true)
        } else {
            p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.textSize = 13 * d
            p.color = 0xFF8794A2.toInt()
            c.drawText("No time yet", cx, 166 * d, p)
        }
        // share of the most played game
        val bl = 18 * d
        val br = w - 18 * d
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3.4f * d
        p.color = Cy.a(col, 0.22f)
        c.drawLine(bl, 183 * d, br, 183 * d, p)
        val frac = if (maxMs > 0) (total.toFloat() / maxMs).coerceIn(0f, 1f) * fill else 0f
        if (frac > 0.01f) {
            p.shader = LinearGradient(bl, 0f, br, 0f, col, lite, Shader.TileMode.CLAMP)
            c.drawLine(bl, 183 * d, bl + (br - bl) * frac, 183 * d, p)
            p.shader = null
        }
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 10.5f * d
        p.color = 0xFF9AA7B4.toInt()
        c.drawText(Games.ago(last), cx, 204 * d, p)
    }

    private fun drawBack(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        body(c, w, h, 0.22f)
        val x = 16 * d
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 10.5f * d
        p.letterSpacing = 0.22f
        p.color = lite
        c.drawText("APP INFO", x, 28 * d, p)
        p.letterSpacing = 0f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.4f * d
        p.color = Cy.a(col, 0.6f)
        c.drawLine(x, 36 * d, x + 34 * d, 36 * d, p)
        val i = info
        val labels = arrayOf("PACKAGE", i?.sizeLabel ?: "APP SIZE", "VERSION", "INSTALLED", "UPDATED")
        val vals = arrayOf(app.pkg, i?.size ?: "...", i?.version ?: "...", i?.installed ?: "...", i?.updated ?: "...")
        for (r in 0 until 5) {
            val y = 56 * d + r * 32 * d
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.textSize = 8.5f * d
            p.letterSpacing = 0.18f
            p.color = 0xFF8794A2.toInt()
            c.drawText(labels[r], x, y, p)
            p.letterSpacing = 0f
            p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            p.textSize = 12f * d
            p.color = 0xFFFFFFFF.toInt()
            val maxW = w - 2 * x
            c.drawText(TextUtils.ellipsize(vals[r], TextPaint(p), maxW, TextUtils.TruncateAt.MIDDLE).toString(), x, y + 15 * d, p)
        }
    }
}

/**
 * The last 7 days as slanted, glowing blocks. Each block is stacked by game, in the game's own colour. Tap a day to
 * see which games made it up.
 */
class WeekChart(ctx: Context) : View(ctx) {
    private var segs: List<WeekSeg> = emptyList()
    private var grow = 0f
    private var sel = -1
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val days = arrayOf("S", "M", "T", "W", "T", "F", "S")

    /** One series in a single colour (the chart on a game's own page). */
    fun set(v: LongArray, color: Int = Neon.CYAN) {
        setStack(listOf(WeekSeg("", color, v)))
    }

    /** Several games stacked on top of each other. */
    fun setStack(list: List<WeekSeg>) {
        segs = list
        sel = -1
        requestLayout()
        lerpTo(this, 0f, 1f, 800) { grow = it }
    }

    private fun dayTotal(i: Int): Long {
        var t = 0L
        for (s in segs) t += s.vals[i]
        return t
    }

    private val stacked: Boolean get() = segs.size > 1

    override fun onMeasure(w: Int, h: Int) =
        setMeasuredDimension(MeasureSpec.getSize(w), ((if (stacked) 250 else 186) * d).toInt())

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) return true
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val slot = width / 7f
            val i = (e.x / slot).toInt().coerceIn(0, 6)
            sel = if (sel == i) -1 else i
            performClick()
            invalidate()
            return true
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    private fun slant(y: Float, top: Float, bot: Float): Float = 7 * d * (bot - y) / (bot - top)

    private fun block(xl: Float, xr: Float, y0: Float, y1: Float, top: Float, bot: Float) {
        path.reset()
        path.moveTo(xl + slant(y1, top, bot), y1)
        path.lineTo(xr + slant(y1, top, bot), y1)
        path.lineTo(xr + slant(y0, top, bot), y0)
        path.lineTo(xl + slant(y0, top, bot), y0)
        path.close()
    }

    override fun onDraw(c: Canvas) {
        if (segs.isEmpty()) return
        val w = width.toFloat()
        val h = height.toFloat()
        val tot = LongArray(7) { dayTotal(it) }
        val mx = max(1L, tot.maxOrNull() ?: 1L)
        var best = 0
        for (i in 0 until 7) if (tot[i] > tot[best]) best = i
        val cur = if (sel >= 0) sel else best
        val slot = w / 7f
        val bw = slot * 0.46f
        val top = 36 * d
        val bot = top + 112 * d
        val cal = Calendar.getInstance()
        for (i in 0 until 7) {
            val x = slot * i + slot / 2f - 3 * d
            val xl = x - bw / 2f
            val xr = x + bw / 2f
            val isSel = i == cur && tot[i] > 0L
            // empty track
            block(xl, xr, top, bot, top, bot)
            p.style = Paint.Style.FILL
            p.color = Cy.a(0xFFFFFFFF.toInt(), 0.05f)
            c.drawPath(path, p)
            // stacked game segments, bottom to top
            val gap = 1.6f * d
            var y = bot
            val full = (bot - top) * (tot[i].toFloat() / mx) * grow
            var firstCol = Neon.CYAN
            for (s in segs) {
                val v = s.vals[i]
                if (v <= 0L || tot[i] <= 0L) continue
                firstCol = s.color
                val hh = full * v.toFloat() / tot[i]
                val y0 = max(top, y - hh)
                if (y - y0 < 1.2f * d) continue
                block(xl, xr, y0, y - gap, top, bot)
                p.shader = LinearGradient(0f, y0, 0f, y, s.color, Cy.a(s.color, 0.55f), Shader.TileMode.CLAMP)
                c.drawPath(path, p)
                p.shader = null
                y = y0
            }
            if (isSel && full > 0f) {
                block(xl - 1.5f * d, xr + 1.5f * d, y, bot, top, bot)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.6f * d
                p.color = Cy.a(0xFFFFFFFF.toInt(), 0.85f)
                c.drawPath(path, p)
                p.style = Paint.Style.FILL
                p.shader = RadialGradient(x + slant(y, top, bot), y, 34 * d, Cy.a(firstCol, 0.35f), 0, Shader.TileMode.CLAMP)
                c.drawCircle(x + slant(y, top, bot), y, 34 * d, p)
                p.shader = null
                p.textAlign = Paint.Align.CENTER
                p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                p.textSize = 11.5f * d
                p.color = 0xFFFFFFFF.toInt()
                c.drawText(Games.fmt(tot[i]), x + slant(y, top, bot) + bw / 2f - 4 * d, y - 9 * d, p)
            }
            // day letter
            cal.timeInMillis = Games.dayStart(i - 6) + 3_600_000L
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            p.textSize = 11.5f * d
            p.color = if (i == 6) Neon.CYAN else if (i == cur) 0xFFFFFFFF.toInt() else 0xFF7C8996.toInt()
            c.drawText(days[cal.get(Calendar.DAY_OF_WEEK) - 1], x, bot + 22 * d, p)
            if (i == 6) {
                p.color = Cy.a(Neon.CYAN, 0.8f)
                c.drawRect(x - 5 * d, bot + 27 * d, x + 5 * d, bot + 28.6f * d, p)
            }
        }
        // legend for the chosen day: which games made it up
        if (stacked) {
            val rows = ArrayList<Pair<WeekSeg, Long>>()
            for (s in segs) if (s.vals[cur] > 0L) rows.add(Pair(s, s.vals[cur]))
            rows.sortByDescending { it.second }
            var y = bot + 54 * d
            if (rows.isEmpty()) {
                p.textAlign = Paint.Align.LEFT
                p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                p.textSize = 12f * d
                p.color = 0xFF7C8996.toInt()
                c.drawText("No play on this day", 6 * d, y, p)
            }
            for ((k, r) in rows.withIndex()) {
                if (k >= 3) break
                p.style = Paint.Style.FILL
                p.color = r.first.color
                c.drawRoundRect(6 * d, y - 9 * d, 14 * d, y - 1 * d, 2 * d, 2 * d, p)
                p.textAlign = Paint.Align.LEFT
                p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                p.textSize = 12.5f * d
                p.color = 0xFFE6EDF3.toInt()
                c.drawText(TextUtils.ellipsize(r.first.name, TextPaint(p), w - 100 * d, TextUtils.TruncateAt.END).toString(), 22 * d, y, p)
                p.textAlign = Paint.Align.RIGHT
                p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                p.color = 0xFFFFFFFF.toInt()
                c.drawText(Games.fmt(r.second), w - 6 * d, y, p)
                y += 20 * d
            }
        }
    }
}

/** One row in "Most played". */
class RankRow(ctx: Context, private val rank: Int, private val app: Games.GameApp, private val icon: Drawable?, private val total: Long, private val maxMs: Long, private val last: Long) : View(ctx) {
    var onOpen: (() -> Unit)? = null
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private var fill = 0f
    private var down = false

    init {
        isClickable = true
        setOnClickListener { onOpen?.invoke() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); lerpTo(this, 0f, 1f, 700) { fill = it } }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (62 * d).toInt())

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) { down = true; invalidate() }
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) { down = false; invalidate() }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (down) {
            p.style = Paint.Style.FILL
            p.color = Cy.a(Neon.CYAN, 0.1f)
            rr.set(0f, 2 * d, w, h - 2 * d)
            c.drawRoundRect(rr, 10 * d, 10 * d, p)
        }
        Cy.text(c, p, rank.toString(), 4 * d, h / 2f + 6 * d, 12 * d, if (rank == 1) Neon.GREEN else 0xFF5F6B78.toInt())
        if (icon != null) {
            c.save()
            val clip = Path()
            clip.addRoundRect(26 * d, h / 2f - 19 * d, 64 * d, h / 2f + 19 * d, 10 * d, 10 * d, Path.Direction.CW)
            c.clipPath(clip)
            icon.setBounds((26 * d).toInt(), (h / 2f - 19 * d).toInt(), (64 * d).toInt(), (h / 2f + 19 * d).toInt())
            icon.draw(c)
            c.restore()
        }
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 14 * d
        p.color = 0xFFFFFFFF.toInt()
        c.drawText(TextUtils.ellipsize(app.name, TextPaint(p), w - 70 * d - 92 * d, TextUtils.TruncateAt.END).toString(), 74 * d, h / 2f - 4 * d, p)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 10.5f * d
        p.color = 0xFF6F7C8A.toInt()
        c.drawText(Games.ago(last), 74 * d, h / 2f + 11 * d, p)
        // bar under the name
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 2.4f * d
        val bl = 74 * d
        val br = w - 92 * d
        p.color = Cy.a(Neon.CYAN, 0.15f)
        c.drawLine(bl, h - 7 * d, br, h - 7 * d, p)
        val f = if (maxMs > 0) (total.toFloat() / maxMs).coerceIn(0f, 1f) * fill else 0f
        if (f > 0.01f) {
            p.color = Neon.CYAN
            c.drawLine(bl, h - 7 * d, bl + (br - bl) * f, h - 7 * d, p)
        }
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL
        val tw = drawTime(c, p, total, 0f, -1000f, 14 * d, d, Neon.CYAN, false)   // measure only (drawn off screen)
        drawTime(c, p, total, w - 4 * d - tw, h / 2f + 6 * d, 14 * d, d, Neon.CYAN, false)
    }
}

/** One finished play session with its FPS wave. */
class SessionRow(ctx: Context, private val s: Games.Session, private val name: String, private val icon: Drawable?) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var grow = 0f

    override fun onAttachedToWindow() { super.onAttachedToWindow(); lerpTo(this, 0f, 1f, 800) { grow = it } }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (62 * d).toInt())

    private fun whenText(): String {
        val cal = Calendar.getInstance()
        cal.timeInMillis = s.start
        val day = when {
            s.start >= Games.dayStart() -> "Today"
            s.start >= Games.dayStart(-1) -> "Yesterday"
            else -> "" + cal.get(Calendar.DAY_OF_MONTH) + "/" + (cal.get(Calendar.MONTH) + 1)
        }
        return day + " " + String.format("%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)) + " - " + Games.fmt(s.ms)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (icon != null) {
            c.save()
            val clip = Path()
            clip.addRoundRect(2 * d, h / 2f - 17 * d, 36 * d, h / 2f + 17 * d, 9 * d, 9 * d, Path.Direction.CW)
            c.clipPath(clip)
            icon.setBounds((2 * d).toInt(), (h / 2f - 17 * d).toInt(), (36 * d).toInt(), (h / 2f + 17 * d).toInt())
            icon.draw(c)
            c.restore()
        }
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 13.5f * d
        p.color = 0xFFFFFFFF.toInt()
        c.drawText(TextUtils.ellipsize(name, TextPaint(p), w - 46 * d - 120 * d, TextUtils.TruncateAt.END).toString(), 46 * d, h / 2f - 3 * d, p)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 10.5f * d
        p.color = 0xFF6F7C8A.toInt()
        c.drawText(whenText(), 46 * d, h / 2f + 12 * d, p)
        // right side: average FPS number + wave
        val fx = w - 112 * d
        val fs = if (s.avgFps > 0f) s.avgFps.toInt().toString() else "--"
        val col = if (s.avgFps <= 0f) 0xFF6F7C8A.toInt() else if (s.avgFps >= 50f) Neon.GREEN else if (s.avgFps >= 30f) 0xFFF2C14E.toInt() else 0xFFFF5A4D.toInt()
        Cy.text(c, p, fs, w - Cy.width(fs.length, 1.3f * d) - 22 * d, h / 2f - 3 * d, 13 * d, col)
        p.style = Paint.Style.FILL
        p.textSize = 9 * d
        p.color = 0xFF6F7C8A.toInt()
        p.textAlign = Paint.Align.RIGHT
        c.drawText("fps", w - 2 * d, h / 2f - 3 * d, p)
        if (s.wave.size >= 2) {
            val mn = s.wave.minOrNull() ?: 0f
            val mx = max(s.wave.maxOrNull() ?: 1f, mn + 1f)
            val x0 = fx
            val x1 = w - 4 * d
            val y0 = h / 2f + 4 * d
            val y1 = h - 6 * d
            path.reset()
            for ((i, v) in s.wave.withIndex()) {
                val x = x0 + (x1 - x0) * i / (s.wave.size - 1).toFloat()
                val y = y1 - (v - mn) / (mx - mn) * (y1 - y0) * grow
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.3f * d
            p.strokeJoin = Paint.Join.MITER
            p.color = Cy.a(col, 0.35f)
            p.strokeWidth = 3f * d
            c.drawPath(path, p)
            p.strokeWidth = 1.2f * d
            p.color = col
            c.drawPath(path, p)
        }
    }
}

/** Big icon inside the ring-and-bolt style frame. */
class HeroIcon(ctx: Context, private val icon: Drawable?) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private var running = false
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!isShown || windowVisibility != View.VISIBLE) { tickIdle = true; return }
            invalidate()
            postDelayed(this, 33)
        }
    }

    private var tickIdle = false

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow() }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (170 * d).toInt())

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        rr.set(cx - 56 * d, cy - 56 * d, cx + 56 * d, cy + 56 * d)
        p.style = Paint.Style.FILL; p.color = 0xFF0B1118.toInt()
        CyUi.drawCut(c, p, rr, 18 * d)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.4f * d; p.color = Cy.a(Neon.CYAN, 0.5f)
        CyUi.drawCut(c, p, rr, 18 * d)
        p.strokeWidth = 2.4f * d; p.color = Cy.PINK
        c.drawLine(cx - 56 * d, cy - 30 * d, cx - 56 * d, cy - 56 * d, p); c.drawLine(cx - 56 * d, cy - 56 * d, cx - 30 * d, cy - 56 * d, p)
        p.color = Cy.CYAN
        c.drawLine(cx + 30 * d, cy + 56 * d, cx + 8 * d, cy + 56 * d, p)
        if (icon != null) {
            val s = 84 * d
            c.save()
            val clip = Path()
            clip.addRoundRect(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, 12 * d, 12 * d, Path.Direction.CW)
            c.clipPath(clip)
            icon.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
            icon.draw(c)
            c.restore()
        }
    }
}

/** A number tile that counts up when it appears. */
class StatTile(ctx: Context, private val label: String, private val value: Float, private val unit: String, private val decimals: Int) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private var f = 0f

    override fun onAttachedToWindow() { super.onAttachedToWindow(); lerpTo(this, 0f, 1f, 900) { f = it } }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (78 * d).toInt())

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        rr.set(2 * d, 2 * d, w - 2 * d, h - 2 * d)
        p.style = Paint.Style.FILL
        p.color = Cy.a(Neon.CYAN, 0.07f)
        CyUi.drawCut(c, p, rr, 12 * d)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = Cy.a(Neon.CYAN, 0.3f)
        CyUi.drawCut(c, p, rr, 12 * d)
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 9 * d
        p.letterSpacing = 0.15f
        p.color = 0xFF6F7C8A.toInt()
        c.drawText(label, 12 * d, 20 * d, p)
        p.letterSpacing = 0f
        val v = value * f
        val str = if (decimals == 0) Math.round(v).toString() else String.format(java.util.Locale.US, "%." + decimals + "f", v)
        val parts = str.split(".")
        var x = 12 * d
        val base = 56 * d
        val hh = 20 * d
        if (value <= 0f) {
            Cy.text(c, p, "--", x, base, hh, 0xFF4A5560.toInt())
        } else {
            x += Cy.text(c, p, parts[0], x, base, hh, 0xFFFFFFFF.toInt())
            p.style = Paint.Style.FILL
            if (parts.size > 1) {
                p.color = 0xFFFFFFFF.toInt()
                c.drawRect(x + 1 * d, base - 2.4f * d, x + 3.6f * d, base, p)
                x += 6 * d
                x += Cy.text(c, p, parts[1], x, base, hh, 0xFFFFFFFF.toInt())
            }
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            p.textSize = 11 * d
            p.color = Cy.a(Neon.CYAN, 0.9f)
            c.drawText(unit, x + 4 * d, base, p)
        }
    }
}

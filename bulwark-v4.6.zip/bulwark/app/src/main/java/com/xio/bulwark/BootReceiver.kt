package com.xio.bulwark

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val boot = Prefs.bool(context, Prefs.BOOT, false)
        val auto = Prefs.bool(context, Prefs.AUTO, false)
        if (!boot && !auto) return
        if (!Settings.canDrawOverlays(context)) return
        try {
            // after a reboot Frameline only watches for games; the status shows up when one opens
            context.startForegroundService(Intent(context, OverlayService::class.java).putExtra(OverlayService.EXTRA_WATCH, true))
        } catch (t: Throwable) { }
    }
}

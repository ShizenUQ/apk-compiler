package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The big reactor on the Boost tab. Idle: a breathing RAM ring. Charging: energy streams into the core while a
 * checklist ticks off every step. Done: shockwaves, a spark burst and a count-up of the freed memory.
 * The same drawing is reused by the small auto-boost banner later, so it only needs the numbers pushed into it.
 */
class BoostCore(ctx: Context) : View(ctx) {
    private val IDLE = 0
    private val CHARGE = 1
    private val DONE = 2
    private val OFF = 3

    var onTap: (() -> Unit)? = null
    private var state = IDLE
    private var off = false
    private var availMb = 0L
    private var totalMb = 1L
    private var beforeMb = 0L
    private var target = 0f
    private var disp = 0f
    private var stepText = ""
    private val steps = ArrayList<String>()
    private var pendingFreed = -1L
    private var freed = 0L
    private var doneAt = 0L
    private var press = 0f
    private var pressed = false
    private var lastT = 0L
    private var heat = 0f
    private var ang = 0f
    private var running = false

    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val path = Path()
    private val dash = DashPathEffect(floatArrayOf(3f * d, 9f * d), 0f)

    private val cyDp = 112f

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!isShown || windowVisibility != View.VISIBLE) { tickIdle = true; return }
            invalidate()
            postDelayed(this, 33)
        }
    }

    private var tickIdle = false

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE && tickIdle && running) { tickIdle = false; post(tick) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (292 * d).toInt())

    fun setMem(avail: Long, total: Long) { availMb = avail; totalMb = max(1L, total) }
    fun setOff(v: Boolean) { off = v }
    fun isBusy() = state == CHARGE

    fun start() {
        state = CHARGE; target = 0.04f; disp = 0f; pendingFreed = -1L; stepText = ""
        steps.clear()
        beforeMb = availMb
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
    }

    fun setProgress(pr: Float, text: String) {
        target = pr
        if (text != stepText) {
            stepText = text
            if (text != "Starting" && text != "Done") {
                steps.add(if (text == "Measuring") "Measuring the result" else text)
                performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
            }
        }
    }

    fun finish(freedMb: Long) { target = 1f; pendingFreed = freedMb }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val dx = e.x - width / 2f
        val dy = e.y - cyDp * d
        val inside = hypot(dx, dy) < 92 * d
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { if (inside) { pressed = true; return true }; return false }
            MotionEvent.ACTION_UP -> {
                val was = pressed
                pressed = false
                if (was && inside) { performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK); onTap?.invoke() }
                return true
            }
            MotionEvent.ACTION_CANCEL -> { pressed = false; return true }
        }
        return true
    }

    private fun segColor(f: Float): Int = when {
        f < 0.55f -> Neon.GREEN
        f < 0.78f -> Neon.CYAN
        f < 0.90f -> 0xFFFFC24B.toInt()
        else -> 0xFFFF2E93.toInt()
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, sizeDp: Float, color: Int, bold: Boolean, sp: Float, align: Paint.Align = Paint.Align.CENTER) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.textAlign = align
        p.typeface = Typeface.create("sans-serif-medium", if (bold) Typeface.BOLD else Typeface.NORMAL)
        p.textSize = sizeDp * d
        p.letterSpacing = sp
        p.color = color
        c.drawText(s, x, y, p)
        p.letterSpacing = 0f
    }

    private fun digits(c: Canvas, s: String, cx: Float, base: Float, h: Float, color: Int) {
        val k = h / 10f
        val w = Cy.width(s.length, k)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        Cy.text(c, p, s, cx - w / 2f, base, h, color)
    }

    private fun check(c: Canvas, x: Float, y: Float, color: Int) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = 2f * d
        p.color = color
        path.reset()
        path.moveTo(x - 4 * d, y)
        path.lineTo(x - 1.2f * d, y + 3 * d)
        path.lineTo(x + 4.5f * d, y - 4 * d)
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = now / 1000f
        val dt = if (lastT == 0L) 0.033f else min(0.1f, (now - lastT) / 1000f)
        lastT = now
        val w = width.toFloat()
        val cx = w / 2f
        val cy = cyDp * d
        press += ((if (pressed) 1f else 0f) - press) * 0.35f
        val breathe = 1f + 0.018f * sin(t * 2.2f)
        val R = 58 * d * (1f - 0.06f * press) * (if (state == IDLE) breathe else 1f)

        if (state == CHARGE) {
            disp = min(target, disp + 0.42f * dt)
            if (pendingFreed >= 0 && disp >= 0.995f) {
                state = DONE; freed = pendingFreed; doneAt = now
                performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK)
            }
        }
        if (state == DONE && now - doneAt > 12000L) state = IDLE
        if (state != CHARGE && off) state = OFF
        if (state == OFF && !off) state = IDLE
        val charging = state == CHARGE
        heat += ((if (charging) 1f else if (state == DONE) 0.45f else 0.18f * press) - heat) * 0.08f
        ang = (ang + (30f + 700f * heat * heat) * dt) % 3600f
        val tDone = if (state == DONE) (now - doneAt) / 1000f else 9f

        // glow behind everything
        p.style = Paint.Style.FILL
        val gc = if (state == OFF) 0xFFFF2E93.toInt() else if (state == DONE) Neon.GREEN else Neon.CYAN
        p.shader = RadialGradient(cx, cy, R * 2.1f, Cy.a(gc, 0.08f + 0.32f * heat + 0.12f * press), 0, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R * 2.1f, p)
        p.shader = null

        // energy streaming into the core
        if (charging) {
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = 1.6f * d
            for (i in 0 until 26) {
                val f = (t * (0.8f + Cy.rnd(i) * 0.9f) + Cy.rnd(i * 3 + 1)) % 1f
                val a = Cy.rnd(i * 5 + 2) * 6.2832f
                val rad = R * 2.3f * (1f - f) + R * 0.45f
                val tail = 8f * d * (0.4f + f)
                p.color = Cy.a(if (i % 3 == 0) Neon.GREEN else Neon.CYAN, 0.85f * f)
                c.drawLine(cx + cos(a) * rad, cy + sin(a) * rad, cx + cos(a) * (rad + tail), cy + sin(a) * (rad + tail), p)
            }
        }

        // outer dashed ring that turns the other way
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * d
        p.strokeCap = Paint.Cap.ROUND
        p.pathEffect = dash
        p.color = Cy.a(gc, 0.22f + 0.4f * heat)
        c.save()
        c.rotate(-ang * 0.35f, cx, cy)
        c.drawCircle(cx, cy, R + 30 * d, p)
        c.restore()
        p.pathEffect = null

        // RAM segments
        val used = (1f - availMb / totalMb.toFloat()).coerceIn(0f, 1f)
        val n = 60
        p.strokeWidth = 2.6f * d
        val r0 = R + 9 * d
        for (i in 0 until n) {
            val f = i / n.toFloat()
            val a = (-90f + i * 360f / n) * 0.0174533f
            val lit = if (charging || (state == DONE && disp < 1f)) f < disp else f < used
            var col = segColor(f)
            var al = if (lit) 0.95f else 0.14f
            var len = if (lit) 9f else 5f
            if (charging) {
                val head = 1f - ((disp - f) * 6f).coerceIn(0f, 1f)
                if (lit) { col = Neon.CYAN; al = 0.5f + 0.5f * head; len = 8f + 7f * head }
            }
            if (state == DONE) { col = Neon.GREEN; al = if (f < used) 0.9f else 0.14f; len = if (f < used) 9f else 5f }
            if (state == OFF) { col = 0xFFFF2E93.toInt(); al = if (i % 5 == 0) 0.4f else 0.12f; len = 5f }
            p.color = Cy.a(col, al)
            c.drawLine(cx + cos(a) * r0, cy + sin(a) * r0, cx + cos(a) * (r0 + len * d), cy + sin(a) * (r0 + len * d), p)
        }

        // rotating arcs
        rr.set(cx - R, cy - R, cx + R, cy + R)
        p.strokeWidth = 3f * d
        p.color = Cy.a(gc, 0.18f)
        c.drawArc(rr, 0f, 360f, false, p)
        p.color = if (state == OFF) 0xFFFF2E93.toInt() else Neon.GREEN
        c.drawArc(rr, ang * 0.6f, 60f + 50f * heat, false, p)
        p.color = gc
        c.drawArc(rr, -ang * 0.9f + 180f, 36f + 44f * heat, false, p)
        rr.inset(10 * d, 10 * d)
        p.strokeWidth = 1.2f * d
        p.color = Cy.a(gc, 0.35f)
        c.drawArc(rr, ang * 1.3f, 90f, false, p)
        c.drawArc(rr, ang * 1.3f + 180f, 90f, false, p)

        // core disc
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, R * 0.9f, intArrayOf(Cy.a(gc, 0.10f + 0.22f * heat + 0.1f * press), 0xF0081018.toInt()), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R - 12 * d, p)
        p.shader = null

        // lightning inside the core
        if (charging || heat > 0.2f) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.5f * d
            val seed = (t * 14f).toInt()
            for (i in 0 until 5) {
                val a = (seed * 0.9f + i * 72f) * 0.0174533f
                p.color = Cy.a(if (i % 2 == 0) Neon.CYAN else Neon.GREEN, 0.8f * min(1f, heat))
                Cy.arc(c, p, cx + cos(a) * R * 0.3f, cy + sin(a) * R * 0.3f, cx + cos(a) * (R - 10 * d), cy + sin(a) * (R - 10 * d), seed * 7 + i, 6 * d)
            }
        }

        // finish: three shockwaves, a burst of sparks and a quick flash
        if (state == DONE) {
            p.style = Paint.Style.STROKE
            for (k in 0 until 3) {
                val s = (tDone - k * 0.2f) / 1.2f
                if (s in 0f..1f) {
                    p.strokeWidth = (3.4f - k) * d * (1f - s)
                    p.color = Cy.a(if (k == 1) Neon.CYAN else Neon.GREEN, 0.85f * (1f - s))
                    c.drawCircle(cx, cy, R * (0.9f + 1.9f * s), p)
                }
            }
            val tb = (tDone / 1.3f).coerceIn(0f, 1f)
            if (tb < 1f) {
                val e = 1f - (1f - tb) * (1f - tb)
                p.style = Paint.Style.FILL
                for (i in 0 until 30) {
                    val a = Cy.rnd(i * 7 + 3) * 6.2832f
                    val dist = R * (0.9f + (1.2f + 1.8f * Cy.rnd(i)) * e)
                    p.color = Cy.a(if (i % 2 == 0) Neon.GREEN else 0xFFFFFFFF.toInt(), 0.9f * (1f - tb))
                    c.drawCircle(cx + cos(a) * dist, cy + sin(a) * dist, (1.2f + 1.8f * Cy.rnd(i + 11)) * d * (1f - 0.5f * tb), p)
                }
            }
            val fl = (1f - tDone / 0.45f).coerceIn(0f, 1f)
            if (fl > 0f) {
                p.style = Paint.Style.FILL
                p.shader = RadialGradient(cx, cy, R * 3.2f, Cy.a(0xFFFFFFFF.toInt(), 0.35f * fl), 0, Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, R * 3.2f, p)
                p.shader = null
            }
        }

        // centre text
        when (state) {
            CHARGE -> {
                digits(c, "${(disp * 100).toInt()}", cx, cy + 12 * d, 28 * d, Neon.CYAN)
                txt(c, "PERCENT", cx, cy + 32 * d, 9f, P.DIM, false, 0.2f)
            }
            DONE -> {
                val k = (tDone / 1.1f).coerceIn(0f, 1f)
                val v = (freed * (1f - (1f - k) * (1f - k) * (1f - k))).toLong()
                txt(c, "FREED", cx, cy - 22 * d, 9f, P.DIM, false, 0.25f)
                digits(c, "$v", cx, cy + 14 * d, 28 * d, Neon.GREEN)
                txt(c, "MB", cx, cy + 32 * d, 10f, Neon.GREEN, true, 0.2f)
            }
            OFF -> {
                txt(c, "SHIZUKU", cx, cy - 2 * d, 15f, 0xFFFF2E93.toInt(), true, 0.15f)
                txt(c, "IS OFF", cx, cy + 18 * d, 11f, P.DIM, false, 0.2f)
            }
            else -> {
                txt(c, "FREE RAM", cx, cy - 20 * d, 9f, P.DIM, false, 0.25f)
                digits(c, "$availMb", cx, cy + 12 * d, 26 * d, Neon.CYAN)
                txt(c, "MB", cx, cy + 32 * d, 10f, Neon.CYAN, true, 0.2f)
            }
        }

        // bottom area: status, or the checklist of steps
        val by = cy + R + 44 * d
        when (state) {
            IDLE -> {
                val pulse = 0.55f + 0.45f * sin(t * 3f)
                txt(c, "TAP TO BOOST", cx, by, 12f, Cy.a(Neon.GREEN, pulse), true, 0.25f)
                txt(c, "${(used * 100).toInt()}% OF RAM IN USE", cx, by + 22 * d, 10f, P.DIM, false, 0.15f)
            }
            OFF -> txt(c, "START SHIZUKU, THEN TAP", cx, by, 11f, P.DIM, false, 0.1f)
            else -> {
                val shown = min(4, steps.size)
                for (j in 0 until shown) {
                    val idx = steps.size - shown + j
                    val y = by - 6 * d + j * 21 * d
                    val doneStep = state == DONE || idx < steps.size - 1
                    val s = steps[idx]
                    val col = if (doneStep) 0xFFE6EDF3.toInt() else Neon.CYAN
                    p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    p.textSize = 12f * d
                    val tw = p.measureText(s)
                    val x0 = cx - tw / 2f
                    if (doneStep) check(c, x0 - 14 * d, y - 4 * d, Neon.GREEN)
                    else {
                        p.style = Paint.Style.FILL
                        p.color = Cy.a(Neon.CYAN, 0.5f + 0.5f * sin(t * 9f))
                        c.drawCircle(x0 - 14 * d, y - 4 * d, 3.2f * d, p)
                    }
                    txt(c, s, x0, y, 12f, Cy.a(col, if (doneStep) 0.8f else 1f), false, 0f, Paint.Align.LEFT)
                }
                if (state == DONE) {
                    val ya = by - 6 * d + shown * 21 * d + 8 * d
                    txt(c, "BOOST COMPLETE  -  ${availMb} MB FREE NOW", cx, ya, 11f, Neon.GREEN, true, 0.1f)
                }
            }
        }
    }
}

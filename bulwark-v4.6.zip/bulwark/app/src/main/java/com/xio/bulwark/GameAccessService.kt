package com.xio.bulwark

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

/**
 * Android tells this service the moment a window of any app changes, so Frameline knows instantly which app is in
 * front, with no checking and no timers. It only receives "window changed" events: it cannot read the screen.
 */
class GameAccessService : AccessibilityService() {

    companion object {
        @Volatile var connected = false

        /** Is the service switched on in Settings > Accessibility? */
        fun enabled(c: Context): Boolean {
            if (connected) return true
            return try {
                val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
                val me = ComponentName(c, GameAccessService::class.java)
                s.split(':').any { ComponentName.unflattenFromString(it) == me }
            } catch (t: Throwable) { false }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
        AutoLog.note("accessibility connected")
        if (Prefs.bool(this, Prefs.AUTO, false) && !OverlayService.running && Settings.canDrawOverlays(this)) {
            try { startForegroundService(Intent(this, OverlayService::class.java).putExtra(OverlayService.EXTRA_WATCH, true)) } catch (t: Throwable) { }
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        OverlayService.front(pkg, e.className?.toString())
    }

    override fun onInterrupt() { }

    override fun onUnbind(intent: Intent?): Boolean {
        connected = false
        AutoLog.note("accessibility disconnected")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        connected = false
        super.onDestroy()
    }
}

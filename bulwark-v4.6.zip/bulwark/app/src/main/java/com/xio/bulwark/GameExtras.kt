package com.xio.bulwark

import android.app.usage.StorageStatsManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One game's play time per day (oldest first), for the stacked week chart. */
class WeekSeg(val name: String, val color: Int, val vals: LongArray)

/** The main colour of a game's icon, used to tint its card, chart bars and backdrop. */
object IconColor {
    private val cache = HashMap<String, Int>()

    @Synchronized
    fun of(pkg: String, icon: Drawable?): Int {
        val hit = cache[pkg]
        if (hit != null) return hit
        val v = compute(icon)
        cache[pkg] = v
        return v
    }

    private fun compute(icon: Drawable?): Int {
        if (icon == null) return Neon.CYAN
        try {
            val s = 24
            val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
            val cv = Canvas(b)
            val dr = icon.constantState?.newDrawable()?.mutate() ?: icon
            dr.setBounds(0, 0, s, s)
            dr.draw(cv)
            val px = IntArray(s * s)
            b.getPixels(px, 0, s, 0, 0, s, s)
            b.recycle()
            var sr = 0f; var sg = 0f; var sb = 0f; var sw = 0f
            val hsv = FloatArray(3)
            for (c in px) {
                if (Color.alpha(c) < 200) continue
                Color.colorToHSV(c, hsv)
                if (hsv[2] < 0.3f) continue
                val w = hsv[1] * hsv[1] * hsv[2]
                sr += Color.red(c) * w; sg += Color.green(c) * w; sb += Color.blue(c) * w; sw += w
            }
            if (sw < 0.4f) return Neon.CYAN
            Color.colorToHSV(Color.rgb((sr / sw).toInt().coerceIn(0, 255), (sg / sw).toInt().coerceIn(0, 255), (sb / sw).toInt().coerceIn(0, 255)), hsv)
            hsv[1] = hsv[1].coerceIn(0.55f, 1f)
            hsv[2] = hsv[2].coerceIn(0.8f, 1f)
            return Color.HSVToColor(hsv)
        } catch (t: Throwable) {
            return Neon.CYAN
        }
    }
}

/** The facts shown on the back of a game card. Nothing here is on the game page already. */
class GameInfo(val pkg: String, val version: String, val sizeLabel: String, val size: String, val installed: String, val updated: String) {
    companion object {
        private fun bytes(n: Long): String = when {
            n >= 1_000_000_000L -> String.format(Locale.US, "%.2f GB", n / 1_000_000_000.0)
            n >= 1_000_000L -> String.format(Locale.US, "%d MB", n / 1_000_000L)
            n > 0L -> String.format(Locale.US, "%d KB", n / 1000L)
            else -> "-"
        }

        @Suppress("DEPRECATION")
        private fun vcode(pi: android.content.pm.PackageInfo): Long =
            if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()

        fun load(c: Context, pkg: String): GameInfo {
            val pm = c.packageManager
            var version = "-"
            var installed = "-"
            var updated = "-"
            var sizeLabel = "APP SIZE"
            var size = "-"
            try {
                val pi = pm.getPackageInfo(pkg, 0)
                version = (pi.versionName ?: "?") + " (" + vcode(pi) + ")"
                val f = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
                installed = f.format(Date(pi.firstInstallTime))
                updated = f.format(Date(pi.lastUpdateTime))
                val ai = pm.getApplicationInfo(pkg, 0)
                var got = false
                try {
                    val ssm = c.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
                    val st = ssm.queryStatsForPackage(ai.storageUuid, pkg, android.os.Process.myUserHandle())
                    size = bytes(st.appBytes + st.dataBytes + st.cacheBytes)
                    sizeLabel = "APP + DATA SIZE"
                    got = true
                } catch (t: Throwable) { }
                if (!got) {
                    // without Usage access the phone hides data size, so show the installed files only
                    var n = File(ai.sourceDir).length()
                    val sp = ai.splitSourceDirs
                    if (sp != null) for (s in sp) n += File(s).length()
                    size = bytes(n)
                    sizeLabel = "APP SIZE"
                }
            } catch (t: Throwable) { }
            return GameInfo(pkg, version, sizeLabel, size, installed, updated)
        }
    }
}

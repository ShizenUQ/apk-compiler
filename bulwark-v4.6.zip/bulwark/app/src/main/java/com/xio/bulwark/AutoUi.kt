package com.xio.bulwark

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Which app is in front, read from Android's usage events. Works without Shizuku, needs Usage access. */
object ForegroundApp {
    private var lastQuery = 0L
    private var fg: String? = null

    @Synchronized
    @Suppress("DEPRECATION")
    fun top(c: Context): String? {
        if (!Games.hasUsage(c)) return null
        try {
            val now = System.currentTimeMillis()
            val from = if (lastQuery == 0L) now - 20_000L else lastQuery - 1_500L
            lastQuery = now
            val u = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val ev = u.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) fg = e.packageName
            }
        } catch (t: Throwable) { }
        return fg
    }

    @Synchronized
    fun reset() { lastQuery = 0L; fg = null }
}

/** Small progress card that plays over a game while Boost runs, then shows what it freed. */
class BoostBanner(ctx: Context, private val icon: Drawable?, private val gameName: String) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val path = Path()
    private var target = 0.04f
    private var disp = 0f
    private var stepText = "Starting"
    private var freed = -1L
    private var doneAt = 0L
    private var t0 = System.currentTimeMillis()
    private var running = false
    private var steps = 0
    var onDismiss: (() -> Unit)? = null
    private var dismissed = false

    fun setProgress(pr: Float, text: String) {
        target = pr
        if (text != stepText) { stepText = text; steps++ }
    }

    fun finish(freedMb: Long) { target = 1f; freed = freedMb }
    val isDone: Boolean get() = freed >= 0L && disp >= 0.995f

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = System.currentTimeMillis()
        val t = (now - t0) / 1000f
        disp = min(target, disp + 0.012f)
        if (freed >= 0L && disp >= 0.995f && doneAt == 0L) doneAt = now
        val done = doneAt != 0L
        val td = if (done) (now - doneAt) / 1000f else 0f
        val accent = if (done) Neon.GREEN else Neon.CYAN
        if (done && td > 2.4f && !dismissed) { dismissed = true; post { onDismiss?.invoke() } }

        rr.set(d, d, w - d, h - d)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, h, 0xF2121C27.toInt(), 0xF2070B10.toInt(), Shader.TileMode.CLAMP)
        CyUi.drawCut(c, p, rr, 14 * d)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Cy.a(accent, 0.6f)
        CyUi.drawCut(c, p, rr, 14 * d)
        p.strokeWidth = 2.4f * d
        p.color = Cy.PINK
        c.drawLine(d * 2, 20 * d, d * 2, 3 * d, p); c.drawLine(d * 2, 3 * d, 30 * d, 3 * d, p)

        // icon with a ring around it
        val cx = 14 * d + 30 * d
        val cy = h / 2f
        if (icon != null) {
            val s = 46 * d
            c.save()
            path.reset()
            path.addRoundRect(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, 11 * d, 11 * d, Path.Direction.CW)
            c.clipPath(path)
            icon.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
            icon.draw(c)
            c.restore()
        }
        val R = 29 * d
        rr.set(cx - R, cy - R, cx + R, cy + R)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 2.6f * d
        p.color = Cy.a(accent, 0.2f)
        c.drawArc(rr, 0f, 360f, false, p)
        p.color = accent
        if (done) c.drawArc(rr, 0f, 360f, false, p)
        else c.drawArc(rr, -90f + t * 360f, 80f, false, p)
        p.strokeWidth = 1.4f * d
        p.color = Cy.a(accent, 0.6f)
        c.drawArc(rr, -90f, 360f * disp, false, p)

        // texts
        val tx = cx + R + 14 * d
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 10f * d
        p.letterSpacing = 0.22f
        p.color = accent
        c.drawText(if (done) "READY TO PLAY" else "BOOSTING", tx, cy - 14 * d, p)
        p.letterSpacing = 0f
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 13.5f * d
        p.color = 0xFFFFFFFF.toInt()
        val line = if (done) gameName else stepText
        c.drawText(TextUtils.ellipsize(line, TextPaint(p), w - tx - 84 * d, TextUtils.TruncateAt.END).toString(), tx, cy + 4 * d, p)

        // progress bar
        val bl = tx
        val br = w - 16 * d
        val by = cy + 20 * d
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3f * d
        p.color = Cy.a(accent, 0.18f)
        c.drawLine(bl, by, br, by, p)
        if (disp > 0.01f) {
            p.shader = LinearGradient(bl, 0f, br, 0f, Neon.CYAN, Neon.GREEN, Shader.TileMode.CLAMP)
            c.drawLine(bl, by, bl + (br - bl) * disp, by, p)
            p.shader = null
        }

        // right side: percent while running, freed memory when done
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.RIGHT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        if (done) {
            val k = (td / 0.9f).coerceIn(0f, 1f)
            val v = (freed * (1f - (1f - k) * (1f - k) * (1f - k))).toLong()
            p.textSize = 19f * d
            p.color = Neon.GREEN
            c.drawText("+$v", w - 16 * d, cy - 6 * d, p)
            p.textSize = 9.5f * d
            p.letterSpacing = 0.2f
            p.color = 0xFF9AA7B4.toInt()
            c.drawText("MB FREED", w - 16 * d, cy + 6 * d, p)
            p.letterSpacing = 0f
            // shockwave ring from the icon
            val s = td / 0.8f
            if (s in 0f..1f) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2.4f * d * (1f - s)
                p.color = Cy.a(Neon.GREEN, 0.8f * (1f - s))
                c.drawCircle(cx, cy, R * (1f + 0.9f * s), p)
            }
        } else {
            p.textSize = 17f * d
            p.color = Neon.CYAN
            c.drawText("${(disp * 100).toInt()}%", w - 16 * d, cy - 6 * d, p)
        }
    }
}

/**
 * A tappable notice on top of the game: "Shizuku is off", or "go back to your game". Kind 0 = warning (pink),
 * 1 = good news (green).
 */
class HudChip(ctx: Context, private val title: String, private val sub: String, private val kind: Int) : View(ctx) {
    var onTap: (() -> Unit)? = null
    var onClose: (() -> Unit)? = null
    private var downX = 0f
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private var pressed = false
    private var running = false
    private val t0 = System.currentTimeMillis()

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 40)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; post(tick) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { pressed = true; downX = e.x; invalidate() }
            MotionEvent.ACTION_UP -> {
                pressed = false; invalidate()
                if (downX > width - 46 * d && e.x > width - 46 * d) onClose?.invoke() else onTap?.invoke()
            }
            MotionEvent.ACTION_CANCEL -> { pressed = false; invalidate() }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = (System.currentTimeMillis() - t0) / 1000f
        val accent = if (kind == 1) Neon.GREEN else 0xFFFF2E93.toInt()
        val pulse = 0.55f + 0.45f * sin(t * 4f)
        rr.set(d, d, w - d, h - d)
        p.style = Paint.Style.FILL
        p.color = if (pressed) 0xF2182430.toInt() else 0xF20B1118.toInt()
        CyUi.drawCut(c, p, rr, 12 * d)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.4f * d
        p.color = Cy.a(accent, 0.45f + 0.5f * pulse)
        CyUi.drawCut(c, p, rr, 12 * d)
        // status dot
        p.style = Paint.Style.FILL
        p.color = Cy.a(accent, 0.25f * pulse)
        c.drawCircle(24 * d, h / 2f, 11 * d, p)
        p.color = accent
        c.drawCircle(24 * d, h / 2f, 5 * d, p)
        // texts
        val tx = 46 * d
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 13.5f * d
        p.color = 0xFFFFFFFF.toInt()
        c.drawText(TextUtils.ellipsize(title, TextPaint(p), w - tx - 74 * d, TextUtils.TruncateAt.END).toString(), tx, h / 2f - 3 * d, p)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 11f * d
        p.color = 0xFF9AA7B4.toInt()
        c.drawText(TextUtils.ellipsize(sub, TextPaint(p), w - tx - 74 * d, TextUtils.TruncateAt.END).toString(), tx, h / 2f + 14 * d, p)
        // arrow
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 2.2f * d
        p.color = Cy.a(accent, 0.6f + 0.4f * pulse)
        val ax = w - 56 * d + 2 * d * pulse
        c.drawLine(ax - 5 * d, h / 2f - 6 * d, ax, h / 2f, p)
        c.drawLine(ax, h / 2f, ax - 5 * d, h / 2f + 6 * d, p)
        // close
        p.strokeWidth = 1.8f * d
        p.color = 0xFF9AA7B4.toInt()
        val xx = w - 23 * d
        c.drawLine(xx - 5 * d, h / 2f - 5 * d, xx + 5 * d, h / 2f + 5 * d, p)
        c.drawLine(xx - 5 * d, h / 2f + 5 * d, xx + 5 * d, h / 2f - 5 * d, p)
    }
}

/** The icon of the game you are playing, pinned to the corner of the status overlay. */
class GameBadge(ctx: Context, private val icon: Drawable?) : View(ctx) {
    private val d = Ui.dp(ctx, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 7 * d
        p.style = Paint.Style.FILL
        p.color = 0xF00B1118.toInt()
        c.drawRoundRect(0f, 0f, w, h, r + 2 * d, r + 2 * d, p)
        if (icon != null) {
            val m = 2.5f * d
            c.save()
            path.reset()
            path.addRoundRect(m, m, w - m, h - m, r, r, Path.Direction.CW)
            c.clipPath(path)
            icon.setBounds(m.toInt(), m.toInt(), (w - m).toInt(), (h - m).toInt())
            icon.draw(c)
            c.restore()
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.4f * d
        p.color = Cy.a(Neon.CYAN, 0.8f)
        c.drawRoundRect(d, d, w - d, h - d, r + 1 * d, r + 1 * d, p)
    }
}

/** A short diary of what Auto mode did (game seen, boost, errors), shown in Diagnostics so a missed game can be explained. */
object AutoLog {
    private val lines = ArrayList<String>()
    private val fmt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)

    @Synchronized
    fun note(msg: String) {
        lines.add(fmt.format(java.util.Date()) + " " + msg)
        while (lines.size > 40) lines.removeAt(0)
    }

    @Synchronized
    fun text(c: Context): String {
        val head = "AUTO MODE LOG (auto=" + Prefs.bool(c, Prefs.AUTO, false) + ", watcher=" + OverlayService.running +
            ", overlay=" + OverlayService.shown + ", pinned=" + OverlayService.pinned + ", accessibility=" + GameAccessService.enabled(c) + ", usage=" + Games.hasUsage(c) + ")"
        if (lines.isEmpty()) return head + "\n(nothing yet)"
        return head + "\n" + lines.joinToString("\n")
    }
}

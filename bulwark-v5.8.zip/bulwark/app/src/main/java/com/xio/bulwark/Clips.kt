package com.xio.bulwark

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sqrt

/** Plain 16-bit mono WAV files at 44100 Hz. */
object Wav {
    const val RATE = 44100

    fun write(f: File, pcm: ShortArray, n: Int) {
        f.parentFile?.mkdirs()
        val bytes = n * 2
        val bb = ByteBuffer.allocate(44 + bytes).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + bytes); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(RATE); bb.putInt(RATE * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(bytes)
        for (i in 0 until n) bb.putShort(pcm[i])
        f.writeBytes(bb.array())
    }

    fun read(f: File): ShortArray? {
        return try {
            val b = f.readBytes()
            if (b.size < 46) return null
            val n = (b.size - 44) / 2
            val bb = ByteBuffer.wrap(b, 44, n * 2).order(ByteOrder.LITTLE_ENDIAN)
            val out = ShortArray(n)
            for (i in 0 until n) out[i] = bb.short
            out
        } catch (t: Throwable) { null }
    }
}

/** Raw recordings: the last seconds of audio saved from the listener, waiting to be trimmed. */
object Recordings {
    fun dir(c: Context) = File(c.filesDir, "rec").also { it.mkdirs() }

    fun list(c: Context): List<File> =
        (dir(c).listFiles() ?: emptyArray()).filter { it.name.endsWith(".wav") }.sortedByDescending { it.lastModified() }

    fun newFile(c: Context): File {
        val f = File(dir(c), "rec_" + System.currentTimeMillis() + ".wav")
        val all = list(c)
        for (i in 5 until all.size) all[i].delete()
        return f
    }

    fun seconds(f: File): Float = max(0L, f.length() - 44) / 2f / Wav.RATE
}

class Trigger(
    val id: String,
    var title: String,
    var clip: String,
    var animId: String,
    var sens: Int = 50,
    var cooldown: Int = 8,
    var enabled: Boolean = true
) {
    /** The score a match must reach, from 0.90 (strict) down to 0.60 (loose). */
    fun threshold(): Float = 0.90f - 0.30f * sens / 100f

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("t", title).put("c", clip).put("a", animId)
        .put("s", sens).put("cd", cooldown).put("on", enabled)

    companion object {
        fun from(o: JSONObject) = Trigger(
            o.getString("id"), o.optString("t", "Sound"), o.optString("c", ""), o.optString("a", ""),
            o.optInt("s", 50), o.optInt("cd", 8), o.optBoolean("on", true)
        )
    }
}

object TriggerStore {
    private val list = ArrayList<Trigger>()
    private var loaded = false
    @Volatile var version = 0

    private fun file(c: Context) = File(c.filesDir, "fx_triggers.json")

    @Synchronized
    private fun load(c: Context) {
        if (loaded) return
        loaded = true
        try {
            val f = file(c)
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) list.add(Trigger.from(a.getJSONObject(i)))
            }
        } catch (t: Throwable) { }
    }

    @Synchronized
    fun all(c: Context): List<Trigger> { load(c); return ArrayList(list) }

    fun get(c: Context, id: String): Trigger? { load(c); return list.firstOrNull { it.id == id } }

    /** Writes the file. Pass bump = true when sounds were added, removed or switched, so the listener reloads them. */
    @Synchronized
    fun save(c: Context, bump: Boolean = false) {
        try {
            val a = JSONArray()
            for (t in list) a.put(t.toJson())
            file(c).writeText(a.toString())
        } catch (t: Throwable) { }
        if (bump) version++
    }

    @Synchronized
    fun add(c: Context, t: Trigger) { load(c); list.add(t); save(c, true) }

    @Synchronized
    fun remove(c: Context, id: String) {
        load(c)
        val t = list.firstOrNull { it.id == id }
        if (t != null) { try { File(t.clip).delete() } catch (e: Throwable) { } }
        list.removeAll { it.id == id }
        save(c, true)
    }
}

/** A saved sound turned into numbers the matcher can compare. */
class Template(val frames: Array<FloatArray>, val w: FloatArray, val wSum: Float)

/**
 * Sound fingerprint. Audio is cut into short frames, each frame becomes 32 band energies on a log scale,
 * and the pattern over time is compared. Volume does not matter, only the shape of the sound.
 */
object Fp {
    const val RATE = 11025
    const val N = 512
    const val HOP = 256
    const val B = 32

    private val win = FloatArray(N) { (0.5 - 0.5 * cos(2.0 * Math.PI * it / (N - 1))).toFloat() }
    private val edges = IntArray(B + 1)
    private val cosT = FloatArray(N / 2) { cos(2.0 * Math.PI * it / N).toFloat() }
    private val sinT = FloatArray(N / 2) { (-kotlin.math.sin(2.0 * Math.PI * it / N)).toFloat() }
    private val rev = IntArray(N)

    init {
        val bin = RATE.toDouble() / N
        val lo = (150.0 / bin).toInt()
        val hi = (5000.0 / bin).toInt()
        for (i in 0..B) edges[i] = round(lo * (hi.toDouble() / lo).pow(i.toDouble() / B)).toInt()
        for (i in 1..B) if (edges[i] <= edges[i - 1]) edges[i] = edges[i - 1] + 1
        var bits = 0
        while ((1 shl bits) < N) bits++
        for (i in 0 until N) {
            var x = i
            var r = 0
            for (b in 0 until bits) { r = (r shl 1) or (x and 1); x = x shr 1 }
            rev[i] = r
        }
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        for (i in 0 until N) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= N) {
            val half = len / 2
            val step = N / len
            var i = 0
            while (i < N) {
                var k = 0
                for (j in i until i + half) {
                    val wr = cosT[k]
                    val wi = sinT[k]
                    val xr = re[j + half] * wr - im[j + half] * wi
                    val xi = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - xr
                    im[j + half] = im[j] - xi
                    re[j] += xr
                    im[j] += xi
                    k += step
                }
                i += len
            }
            len *= 2
        }
    }

    private val re = FloatArray(N)
    private val im = FloatArray(N)

    /** One frame starting at `off` in x. Fills `out` with the normalised band pattern and returns the frame energy in dB. */
    @Synchronized
    fun frame(x: FloatArray, off: Int, out: FloatArray): Float {
        for (i in 0 until N) { re[i] = x[off + i] * win[i]; im[i] = 0f }
        fft(re, im)
        var total = 0.0
        var mean = 0f
        for (b in 0 until B) {
            var e = 0.0
            val e1 = max(edges[b + 1], edges[b] + 1)
            for (k in edges[b] until e1) e += (re[k] * re[k] + im[k] * im[k]).toDouble()
            total += e
            val v = ln(e + 1e-6).toFloat()
            out[b] = v
            mean += v
        }
        mean /= B
        var nrm = 0f
        for (b in 0 until B) { out[b] -= mean; nrm += out[b] * out[b] }
        nrm = sqrt(nrm) + 1e-6f
        for (b in 0 until B) out[b] /= nrm
        return (10.0 * log10(total + 1e-9)).toFloat()
    }

    /** 44100 Hz shorts to 11025 Hz floats by averaging groups of four. */
    fun down(pcm: ShortArray, n: Int): FloatArray {
        val m = n / 4
        val o = FloatArray(m)
        for (i in 0 until m) {
            val j = i * 4
            o[i] = (pcm[j] + pcm[j + 1] + pcm[j + 2] + pcm[j + 3]) / (4f * 32768f)
        }
        return o
    }

    fun templateOf(pcm: ShortArray): Template? {
        val x = down(pcm, pcm.size)
        if (x.size < N + HOP * 6) return null
        val nf = (x.size - N) / HOP + 1
        val fr = Array(nf) { FloatArray(B) }
        val en = FloatArray(nf)
        var mx = -1000f
        for (f in 0 until nf) { en[f] = frame(x, f * HOP, fr[f]); if (en[f] > mx) mx = en[f] }
        val w = FloatArray(nf)
        var s = 0f
        for (f in 0 until nf) { w[f] = ((en[f] - (mx - 30f)) / 30f).coerceIn(0f, 1f); s += w[f] }
        if (s < 1f) return null
        return Template(fr, w, s)
    }
}

/** What the listener heard and matched, for the Triggers tab to show. */
object MatchBus {
    val scores = ConcurrentHashMap<String, Float>()
    @Volatile var lastId = ""
    @Volatile var lastScore = 0f
    @Volatile var lastMs = 0L
    @Volatile var count = 0
    @Volatile var onFire: ((Trigger, Float) -> Unit)? = null
}

/** Compares live audio with every saved sound, about 43 times a second. */
class Matcher(private val ctx: Context) {
    private class Slot(val t: Trigger, val tpl: Template) { var last = 0L }

    private var slots: List<Slot> = emptyList()
    private var seen = -1
    private val acc = FloatArray(Fp.N * 3)
    private var accN = 0
    private val carry = ShortArray(4)
    private var carryN = 0
    private val cap = 640
    private val live = Array(cap) { FloatArray(Fp.B) }
    private var head = -1
    private var filled = 0
    private val tmp = FloatArray(Fp.B)

    private fun reload() {
        seen = TriggerStore.version
        val out = ArrayList<Slot>()
        for (t in TriggerStore.all(ctx)) {
            if (!t.enabled) continue
            val pcm = Wav.read(File(t.clip)) ?: continue
            val tpl = Fp.templateOf(pcm) ?: continue
            if (tpl.frames.size < cap - 4) out.add(Slot(t, tpl))
        }
        slots = out
        MatchBus.scores.clear()
    }

    fun feed(buf: ShortArray, n: Int) {
        if (seen != TriggerStore.version) reload()
        if (slots.isEmpty()) return
        var i = 0
        while (i < n) {
            carry[carryN++] = buf[i++]
            if (carryN == 4) {
                carryN = 0
                if (accN < acc.size) acc[accN++] = (carry[0] + carry[1] + carry[2] + carry[3]) / (4f * 32768f)
                while (accN >= Fp.N) {
                    frame()
                    System.arraycopy(acc, Fp.HOP, acc, 0, accN - Fp.HOP)
                    accN -= Fp.HOP
                }
            }
        }
    }

    private fun frame() {
        Fp.frame(acc, 0, tmp)
        head = (head + 1) % cap
        System.arraycopy(tmp, 0, live[head], 0, Fp.B)
        if (filled < cap) filled++
        val now = System.currentTimeMillis()
        for (s in slots) {
            val tp = s.tpl
            val f = tp.frames.size
            if (filled < f) continue
            var sum = 0f
            for (t in 0 until f) {
                val a = tp.frames[t]
                val b = live[((head - f + 1 + t) % cap + cap) % cap]
                var d = 0f
                for (k in 0 until Fp.B) d += a[k] * b[k]
                sum += d * tp.w[t]
            }
            val score = sum / tp.wSum
            MatchBus.scores[s.t.id] = score
            if (score >= s.t.threshold() && now - s.last > s.t.cooldown * 1000L) {
                s.last = now
                MatchBus.lastId = s.t.id
                MatchBus.lastScore = score
                MatchBus.lastMs = now
                MatchBus.count++
                MatchBus.onFire?.invoke(s.t, score)
            }
        }
    }
}

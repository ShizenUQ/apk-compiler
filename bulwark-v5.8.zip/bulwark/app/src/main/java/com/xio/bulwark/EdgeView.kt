package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/**
 * Helmet HUD around the screen, like a visor: a slim glass strip at the top (FPS tape), CPU and heat ladders on the
 * sides, battery and session rings in the bottom corners. Never takes touches. All drawing is in "units"
 * (1 unit = 1dp at full size, scaled down on small screens).
 */
class EdgeView(private val ctx: Context) : View(ctx) {

    var demo = false

    private val d = resources.displayMetrics.density
    private var u = d
    private var bright = 0.85f
    private var showTop = true
    private var showSides = true
    private var showRings = true
    private var showVisor = true
    private var fxOn = true
    private var lowPower = false
    private var lw = 0.9f
    private var targetFps = 60

    private var data = FpsData.na("NOLINK")
    private var sys: SysData? = null
    private var dispFps = 0f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glassP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sweepP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val vigP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val plate = Path()
    private val inner = Path()
    private val tmp = Path()
    private val seg = Path()
    private val frame = Path()
    private val pm = PathMeasure()
    private val rf = RectF()
    private var perim = 0f
    private var W = 0f
    private var H = 0f

    private var sweepStart = -1L
    private var sweepCol = Cy.CYAN
    private var badUntil = 0L
    private var wasBad = false
    private var lastHour = -1
    private var running = false
    private var lastT = 0L

    private val tk = Runnable { step() }

    private val mono = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    fun applyPrefs() {
        bright = Prefs.int(ctx, Prefs.EDGE_BRIGHT, 85).coerceIn(20, 100) / 100f
        showTop = Prefs.bool(ctx, Prefs.EDGE_FPS, true)
        showSides = Prefs.bool(ctx, Prefs.EDGE_SIDES, true)
        showRings = Prefs.bool(ctx, Prefs.EDGE_TIME, true)
        showVisor = Prefs.bool(ctx, Prefs.EDGE_READ, true)
        fxOn = Prefs.bool(ctx, Prefs.EDGE_FX, true)
        lowPower = Prefs.bool(ctx, Prefs.EDGE_LOW, false)
        lw = 0.45f * Prefs.int(ctx, Prefs.EDGE_THICK, 2).coerceIn(1, 6)
        targetFps = Prefs.int(ctx, Prefs.TARGET, 60)
        kick()
        invalidate()
    }

    fun update(f: FpsData, s: SysData) {
        data = f
        sys = s
        val now = SystemClock.uptimeMillis()
        val bad = f.status == "OK" && f.fps >= 0f && f.fps < targetFps * 0.7f
        if (bad && !wasBad && fxOn) badUntil = now + 900
        wasBad = bad
        val hr = (sessionSecs(s.session) / 3600L).toInt()
        if (!demo && lastHour >= 0 && hr > lastHour && fxOn) sweep(Cy.PINK)
        lastHour = hr
        kick()
        invalidate()
    }

    /** One bright streak runs around the whole visor. */
    fun sweep(color: Int) {
        if (!fxOn) return
        sweepStart = SystemClock.uptimeMillis()
        sweepCol = color
        kick()
    }

    private fun sessionSecs(s: String): Long {
        val q = s.split(":")
        return try { if (q.size == 3) q[0].toLong() * 3600 + q[1].toLong() * 60 + q[2].toLong() else 0L } catch (t: Throwable) { 0L }
    }

    // ---------- loop ----------

    private fun ambient() = !lowPower && fxOn
    private fun hot() = (sys?.temp ?: 0f) >= 43f
    private fun batLow() = sys?.let { it.bat in 0..15 && !it.charging } ?: false

    private fun animating(now: Long): Boolean =
        sweepStart >= 0 || now < badUntil || ambient() || (fxOn && (hot() || batLow())) ||
            (data.fps >= 0f && abs(dispFps - data.fps) > 0.05f)

    private fun kick() {
        if (!running && isAttachedToWindow) {
            running = true
            lastT = SystemClock.uptimeMillis()
            postOnAnimation(tk)
        }
    }

    private fun step() {
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastT).coerceIn(1L, 80L).toFloat()
        lastT = now
        if (data.fps >= 0f) {
            val diff = data.fps - dispFps
            dispFps = if (abs(diff) < 0.3f) data.fps else dispFps + diff * min(1f, dt / 140f)
        } else dispFps = 0f
        if (sweepStart >= 0 && now - sweepStart > 1000) sweepStart = -1
        invalidate()
        if (animating(now)) postDelayed(tk, if (lowPower) 70L else 33L) else running = false
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastHour = -1
        kick()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tk)
        running = false
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val s = min(1f, min(w / (d * 640f), h / (d * 300f))).coerceAtLeast(0.3f)
        u = d * s
        W = w / u
        H = h / u
        val i = 5f
        val r = min(34f, min(W, H) / 5f)
        frame.reset()
        rf.set(i, i, W - i, H - i)
        frame.addRoundRect(rf, r, r, Path.Direction.CW)
        pm.setPath(frame, true)
        perim = pm.length
        vigP.shader = RadialGradient(W / 2f, H / 2f, maxOf(W, H) * 0.72f, intArrayOf(0x00000A10, 0x00000A10, 0x5000131C), floatArrayOf(0f, 0.62f, 1f), Shader.TileMode.CLAMP)
        sweepP.shader = LinearGradient(0f, 0f, 26f, 0f, intArrayOf(0x00FFFFFF, 0x66BFF8FF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        glassP.shader = LinearGradient(0f, 0f, 0f, 36f, intArrayOf(0x66167A86, 0xD2051820.toInt(), 0xE0041018.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        buildPlate()
    }

    private fun buildPlate() {
        val cx = W / 2f
        plate.reset()
        plate.moveTo(cx - 150f, 0f); plate.lineTo(cx + 150f, 0f); plate.lineTo(cx + 137f, 22f)
        plate.lineTo(cx + 124f, 34f); plate.lineTo(cx - 124f, 34f); plate.lineTo(cx - 137f, 22f); plate.close()
        inner.reset()
        inner.moveTo(cx - 143f, 3f); inner.lineTo(cx + 143f, 3f); inner.lineTo(cx + 131f, 21f)
        inner.lineTo(cx + 120f, 31f); inner.lineTo(cx - 120f, 31f); inner.lineTo(cx - 131f, 21f); inner.close()
    }

    // ---------- helpers ----------

    private fun accent(): Int {
        if (data.fps < 0f) return Cy.CYAN
        val r = data.fps / targetFps
        return if (r >= 0.9f) P.GOOD else if (r >= 0.7f) P.MID else P.BAD
    }

    private fun al(c: Int, a: Float) = Cy.a(c, (a * bright).coerceIn(0f, 1f))

    private fun ln(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, col: Int, a: Float, w: Float = lw) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = w
        p.color = al(col, a)
        c.drawLine(x0, y0, x1, y1, p)
    }

    private fun tx(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int, a: Float, align: Paint.Align = Paint.Align.LEFT, spacing: Float = 0f) {
        p.style = Paint.Style.FILL
        p.typeface = mono
        p.textSize = size
        p.textAlign = align
        p.letterSpacing = spacing
        p.color = al(col, a)
        c.drawText(s, x, y, p)
        p.letterSpacing = 0f
        p.style = Paint.Style.STROKE
    }

    private fun tri(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, x2: Float, y2: Float, col: Int, a: Float, fill: Boolean) {
        tmp.reset(); tmp.moveTo(x0, y0); tmp.lineTo(x1, y1); tmp.lineTo(x2, y2); tmp.close()
        p.style = if (fill) Paint.Style.FILL else Paint.Style.STROKE
        p.strokeWidth = lw * 1.5f
        p.color = al(col, a)
        c.drawPath(tmp, p)
        p.style = Paint.Style.STROKE
    }

    /** Scale ladder on a side. val01 = 0 bottom .. 1 top. */
    private fun ladder(c: Canvas, x: Float, dir: Float, yT: Float, yB: Float, val01: Float, lo: Int, hi: Int, step: Int, col: Int, text: String) {
        val n = ((yB - yT) / 4.5f).toInt().coerceAtLeast(5)
        for (i in 0..n) {
            val y = yT + i * (yB - yT) / n
            val major = i % 5 == 0
            ln(c, x, y, x + dir * (if (major) 9f else 5f), y, Cy.CYAN, if (major) 0.9f else 0.45f, if (major) lw * 1.3f else lw)
            if (major) {
                val v = hi - (hi - lo) * (i.toFloat() / n)
                val vs = (Math.round(v / step) * step).toString()
                tx(c, vs, x + dir * 13f, y + 2f, 5.5f, 0xFF8B96A3.toInt(), 0.9f, if (dir > 0) Paint.Align.LEFT else Paint.Align.RIGHT)
            }
        }
        val y = yT + (1f - val01.coerceIn(0f, 1f)) * (yB - yT)
        tri(c, x - dir * 2f, y, x - dir * 9f, y - 3.5f, x - dir * 9f, y + 3.5f, col, 1f, true)
        p.pathEffect = DashPathEffect(floatArrayOf(2.5f, 2.5f), 0f)
        ln(c, x - dir * 9f, y, x - dir * 9f + dir * 62f, y, col, 0.7f)
        p.pathEffect = null
        tx(c, text, x - dir * 9f + dir * 66f, y + 2.4f, 6.8f, col, 1f, if (dir > 0) Paint.Align.LEFT else Paint.Align.RIGHT)
    }

    private fun ring(c: Canvas, cx: Float, cy: Float, r: Float, frac: Float, col: Int, label: String, center: String, rot: Float) {
        val f = frac.coerceIn(0f, 1f)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.BUTT
        rf.set(cx - r - 10f, cy - r - 10f, cx + r + 10f, cy + r + 10f)
        p.strokeWidth = lw; p.color = al(Cy.CYAN, 0.35f); c.drawArc(rf, 160f, 220f, false, p)
        rf.set(cx - r, cy - r, cx + r, cy + r)
        p.pathEffect = DashPathEffect(floatArrayOf(3.2f, 2.6f), 0f)
        p.strokeWidth = 4f; p.color = al(Cy.CYAN, 0.17f); c.drawArc(rf, 160f, 220f, false, p)
        p.color = al(col, 0.95f); c.drawArc(rf, 160f, 220f * f, false, p)
        p.pathEffect = null
        rf.set(cx - r - 8f, cy - r - 8f, cx + r + 8f, cy + r + 8f)
        p.strokeWidth = lw * 2f; p.color = al(Cy.PINK, 0.9f)
        c.drawArc(rf, 160f + rot, 28f, false, p)
        c.drawArc(rf, 300f + rot, 22f, false, p)
        tx(c, center, cx, cy + 5f, 12f, 0xFFE6EDF3.toInt(), 1f, Paint.Align.CENTER)
        tx(c, label, cx, cy - 8f, 5.5f, 0xFF8B96A3.toInt(), 1f, Paint.Align.CENTER, 0.1f)
    }

    private fun comet(c: Canvas, head: Float, len: Float, color: Int, a: Float, sw: Float) {
        if (perim <= 0f) return
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.color = al(color, a)
        seg.reset()
        val hh = ((head % perim) + perim) % perim
        val ss = hh - len
        if (ss >= 0f) pm.getSegment(ss, hh, seg, true)
        else { pm.getSegment(0f, hh, seg, true); pm.getSegment(perim + ss, perim, seg, true) }
        c.drawPath(seg, p)
    }

    // ---------- draw ----------

    override fun onDraw(c: Canvas) {
        if (width <= 0 || height <= 0 || W <= 0f) return
        val now = SystemClock.uptimeMillis()
        val acc = accent()
        val bad = data.fps >= 0f && data.fps < targetFps * 0.7f
        val glitch = fxOn && now < badUntil
        val sy = sys

        c.save()
        c.scale(u, u)
        p.style = Paint.Style.STROKE
        p.pathEffect = null

        if (showVisor) {
            c.drawRect(0f, 0f, W, H, vigP)
            p.strokeWidth = lw; p.color = al(Cy.CYAN, 0.5f)
            c.drawPath(frame, p)
        }

        // status text and warning triangles in the top corners
        val statusTxt = when {
            bad -> "FRAME DROP"
            hot() -> "OVERHEAT"
            batLow() -> "LOW BATTERY"
            else -> "SYS NOMINAL"
        }
        val warn = bad || hot() || batLow()
        val sc = if (bad) P.BAD else if (warn) P.MID else P.GOOD
        if (showTop || showSides) {
            tx(c, statusTxt, 22f, 17f, 6.3f, sc, 1f, Paint.Align.LEFT, 0.08f)
            tx(c, "TGT $targetFps", W - 22f, 17f, 6.3f, 0xFF8B96A3.toInt(), 1f, Paint.Align.RIGHT, 0.08f)
            val blink = !warn || (now / 250L) % 2L == 0L
            for (k in 0..1) {
                val x = if (k == 0) 20f else W - 20f
                tri(c, x, 24f, x - 6f, 35f, x + 6f, 35f, if (warn) sc else P.MID, if (blink) 1f else 0.3f, false)
                tx(c, "!", x, 33f, 6f, if (warn) sc else P.MID, if (blink) 1f else 0.3f, Paint.Align.CENTER)
            }
        }

        // ---- sides: CPU left, heat right
        if (showSides) {
            val yT = maxOf(60f, H * 0.24f)
            val yB = minOf(H - 70f, H * 0.72f)
            if (yB - yT > 40f) {
                val cpu = if (data.cpu >= 0f) data.cpu else 0f
                ladder(c, 16f, 1f, yT, yB, cpu / 100f, 0, 100, 10, Cy.PINK, "CPU " + cpu.toInt() + "%")
                if (sy != null && sy.temp > 0f) {
                    val tc = if (sy.temp >= 43f) P.BAD else if (sy.temp >= 39f) P.MID else Cy.CYAN
                    ladder(c, W - 16f, -1f, yT, yB, (sy.temp - 30f) / 16f, 30, 46, 2, if (sy.temp >= 39f) tc else P.MID, "TEMP " + sy.temp.toInt() + "°")
                }
            }
        }

        // ---- bottom rings
        if (showRings && sy != null) {
            val rot = if (ambient()) ((now % 9000L) / 9000f) * 360f else 0f
            val ry = H - 44f
            val bf = if (sy.bat >= 0) sy.bat / 100f else 0f
            val bcol = if (sy.charging) P.GOOD else if (bf > 0.3f) P.GOOD else if (bf > 0.15f) P.MID else Cy.PINK
            val blinkB = !(fxOn && batLow()) || (now / 450L) % 2L == 0L
            ring(c, 52f, ry, 25f, bf, if (blinkB) bcol else P.BAD, "BAT", if (sy.bat >= 0) sy.bat.toString() + "%" else "--", rot)
            val secs = sessionSecs(sy.session)
            val hh = (secs / 3600L).toString().padStart(2, '0')
            val mm = ((secs / 60L) % 60L).toString().padStart(2, '0')
            ring(c, W - 52f, ry, 25f, (secs % 3600L) / 3600f, Cy.CYAN, "SESSION", "$hh:$mm", -rot)
        }

        // ---- top glass strip
        if (showTop) drawStrip(c, now, acc, bad, glitch)

        // ---- events
        if (fxOn) {
            if (glitch) {
                val k = (badUntil - now) / 900f
                p.style = Paint.Style.STROKE
                p.strokeWidth = lw * 2.4f
                p.color = al(P.BAD, 0.7f * k)
                c.drawPath(frame, p)
            } else if (hot()) {
                val k = 0.5f + 0.5f * sin(now / 450f)
                p.style = Paint.Style.STROKE
                p.strokeWidth = lw * 2f
                p.color = al(P.MID, 0.1f + 0.28f * k)
                c.drawPath(frame, p)
            }
            if (sweepStart >= 0 && perim > 0f) {
                val e = ((now - sweepStart) / 900f).coerceIn(0f, 1f)
                val head = e * perim * 1.15f
                comet(c, head, perim * 0.22f, sweepCol, 0.35f, lw * 2.4f)
                comet(c, head, perim * 0.07f, 0xFFFFFFFF.toInt(), 0.95f, lw * 3f)
            }
        }
        c.restore()
    }

    private fun drawStrip(c: Canvas, now: Long, acc: Int, bad: Boolean, glitch: Boolean) {
        val cx = W / 2f
        // glass body
        glassP.alpha = (255 * bright).toInt()
        c.drawPath(plate, glassP)
        // light sweep
        if (ambient()) {
            c.save()
            c.clipPath(plate)
            val sx = cx - 170f + ((now % 3200L) / 3200f) * 340f
            c.translate(sx, 0f)
            sweepP.alpha = (130 * bright).toInt()
            c.drawRect(0f, 0f, 26f, 36f, sweepP)
            c.restore()
        }
        // tape
        c.save()
        c.clipRect(cx - 84f, 0f, cx + 84f, 36f)
        val ppu = 4.2f
        val f0 = dispFps
        var v = Math.floor((f0 - 22f).toDouble()).toInt()
        val vEnd = Math.ceil((f0 + 22f).toDouble()).toInt()
        while (v <= vEnd) {
            if (v >= 0) {
                val x = cx + (v - f0) * ppu
                val big = v % 10 == 0
                val mid = v % 5 == 0
                val fade = 1f - min(1f, abs(x - cx) / 84f)
                ln(c, x, 4f, x, 4f + (if (big) 8f else if (mid) 5f else 3f), Cy.CYAN, (if (big) 0.95f else if (mid) 0.65f else 0.4f) * (0.3f + 0.7f * fade), if (big) lw * 1.4f else lw)
                if (big && abs(x - cx) > 26f) tx(c, v.toString(), x, 21f, 5f, 0xFF8B96A3.toInt(), 0.35f + 0.65f * fade, Paint.Align.CENTER)
            }
            v++
        }
        c.restore()
        // centre pointer + number window
        ln(c, cx, 0f, cx, 6f, acc, 1f, lw * 1.8f)
        tmp.reset()
        tmp.moveTo(cx - 16f, 15f); tmp.lineTo(cx + 16f, 15f); tmp.lineTo(cx + 23f, 24f); tmp.lineTo(cx + 16f, 33f)
        tmp.lineTo(cx - 16f, 33f); tmp.lineTo(cx - 23f, 24f); tmp.close()
        p.style = Paint.Style.FILL; p.color = al(0xFF05141B.toInt(), 0.92f); c.drawPath(tmp, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = lw * 1.5f; p.color = al(acc, 0.95f); c.drawPath(tmp, p)
        val num = if (data.fps >= 0f) Math.round(dispFps).toString() else "--"
        val jit = if (glitch) (Cy.rnd((now / 30L).toInt()) - 0.5f) * 3.5f else 0f
        if (glitch) {
            tx(c, num, cx + jit, 29.5f, 14f, Cy.PINK, 0.6f, Paint.Align.CENTER)
            tx(c, num, cx - jit, 29.5f, 14f, Cy.CYAN, 0.5f, Paint.Align.CENTER)
        }
        val flick = if (glitch && Cy.rnd((now / 50L).toInt() + 3) < 0.2f) 0.5f else 1f
        tx(c, num, cx, 29.5f, 14f, acc, flick, Paint.Align.CENTER)
        // chevrons
        val pulse = if (ambient()) 0.55f + 0.45f * sin(now / 300f) else 0.8f
        tx(c, "«", cx - 33f, 28f, 11f, Cy.CYAN, pulse, Paint.Align.CENTER)
        tx(c, "»", cx + 33f, 28f, 11f, Cy.CYAN, pulse, Paint.Align.CENTER)
        // side readouts
        val ftTxt = if (data.fps > 0f) String.format(java.util.Locale.US, "%.1f ms", 1000f / max1(data.fps)) else "-- ms"
        tx(c, "FPS", cx - 124f, 13f, 5.3f, 0xFF8B96A3.toInt(), 1f, Paint.Align.LEFT, 0.2f)
        tx(c, ftTxt, cx - 124f, 25f, 7.4f, 0xFFE6EDF3.toInt(), 1f)
        val lowTxt = if (data.low >= 0f) Math.round(data.low).toString() else "--"
        tx(c, "LOW", cx + 124f, 13f, 5.3f, 0xFF8B96A3.toInt(), 1f, Paint.Align.RIGHT, 0.2f)
        tx(c, lowTxt, cx + 124f, 25f, 7.4f, 0xFFE6EDF3.toInt(), 1f, Paint.Align.RIGHT)
        // outlines
        p.style = Paint.Style.STROKE
        p.strokeWidth = lw * 1.5f; p.color = al(if (bad) P.BAD else Cy.CYAN, 0.95f)
        c.drawPath(plate, p)
        p.strokeWidth = lw * 0.7f; p.color = al(Cy.CYAN, 0.28f)
        c.drawPath(inner, p)
        ln(c, cx - 150f, 0.8f, cx - 112f, 0.8f, Cy.PINK, 1f, lw * 3.2f)
        ln(c, cx + 112f, 0.8f, cx + 150f, 0.8f, Cy.PINK, 1f, lw * 3.2f)
    }

    private fun max1(v: Float) = if (v < 1f) 1f else v
}

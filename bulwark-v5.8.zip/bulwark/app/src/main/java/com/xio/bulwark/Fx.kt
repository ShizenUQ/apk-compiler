package com.xio.bulwark

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Shader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** The kinds of effect an animation can be built from. */
object FxType {
    const val COMET = 0
    const val GLOW = 1
    const val GLITCH = 2
    const val SCAN = 3
    const val FLASH = 4
    const val WAVE = 5
    const val TEXT = 6
    const val SHAKE = 7
    val names = listOf("Comet sweep", "Glow pulse", "Glitch", "Scan line", "Flash", "Shockwave", "Text", "Shake")
    val hints = listOf(
        "A light races around the screen edge",
        "The edge glows and pulses",
        "Torn lines and colour splits",
        "A bright line sweeps down the screen",
        "A quick flash of colour",
        "A ring expands from the centre",
        "A word pops up in the middle",
        "Shakes the text and your images"
    )
}

/** One step of an animation. Times are in milliseconds from the start. */
class FxEffect(
    var type: Int,
    var color: Int,
    var power: Int = 70,
    var speed: Int = 50,
    var startMs: Int = 0,
    var durMs: Int = 1500,
    var text: String = ""
) {
    fun copy() = FxEffect(type, color, power, speed, startMs, durMs, text)

    fun toJson(): JSONObject = JSONObject()
        .put("t", type).put("c", color).put("p", power).put("s", speed)
        .put("a", startMs).put("d", durMs).put("x", text)

    companion object {
        fun from(o: JSONObject) = FxEffect(
            o.optInt("t", 0), o.optInt("c", 0xFF19E6F2.toInt()), o.optInt("p", 70), o.optInt("s", 50),
            o.optInt("a", 0), o.optInt("d", 1500), o.optString("x", "")
        )
    }
}

/** A picture placed on the screen. x and y are 0..1 across the screen, scale 1 = a quarter of the screen height. */
class FxLayer(
    var path: String,
    var x: Float = 0.5f,
    var y: Float = 0.5f,
    var scale: Float = 1f,
    var rot: Float = 0f,
    var alpha: Float = 1f,
    var startMs: Int = 0,
    var durMs: Int = 1500,
    var intro: Int = 1,
    var outro: Int = 1
) {
    fun copy() = FxLayer(path, x, y, scale, rot, alpha, startMs, durMs, intro, outro)

    fun toJson(): JSONObject = JSONObject()
        .put("f", path).put("x", x.toDouble()).put("y", y.toDouble()).put("k", scale.toDouble())
        .put("r", rot.toDouble()).put("o", alpha.toDouble()).put("a", startMs).put("d", durMs)
        .put("i", intro).put("u", outro)

    companion object {
        fun from(o: JSONObject) = FxLayer(
            o.optString("f", ""), o.optDouble("x", 0.5).toFloat(), o.optDouble("y", 0.5).toFloat(),
            o.optDouble("k", 1.0).toFloat(), o.optDouble("r", 0.0).toFloat(), o.optDouble("o", 1.0).toFloat(),
            o.optInt("a", 0), o.optInt("d", 1500), o.optInt("i", 1), o.optInt("u", 1)
        )
    }
}

class FxAnim(val id: String, var name: String, val builtIn: Boolean) {
    val effects = ArrayList<FxEffect>()
    val layers = ArrayList<FxLayer>()
    var audio = ""
    var volume = 80

    fun totalMs(): Int {
        var m = 600
        for (e in effects) m = max(m, e.startMs + e.durMs)
        for (l in layers) m = max(m, l.startMs + l.durMs)
        return m
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id).put("name", name).put("b", builtIn).put("au", audio).put("vol", volume)
        val e = JSONArray()
        for (x in effects) e.put(x.toJson())
        o.put("e", e)
        val l = JSONArray()
        for (x in layers) l.put(x.toJson())
        o.put("l", l)
        return o
    }

    fun copyAs(newId: String, newName: String): FxAnim {
        val a = FxAnim(newId, newName, false)
        for (e in effects) a.effects.add(e.copy())
        for (l in layers) a.layers.add(l.copy())
        a.audio = audio
        a.volume = volume
        return a
    }

    companion object {
        fun from(o: JSONObject): FxAnim {
            val a = FxAnim(o.getString("id"), o.optString("name", "Animation"), o.optBoolean("b", false))
            a.audio = o.optString("au", "")
            a.volume = o.optInt("vol", 80)
            val e = o.optJSONArray("e")
            if (e != null) for (i in 0 until e.length()) a.effects.add(FxEffect.from(e.getJSONObject(i)))
            val l = o.optJSONArray("l")
            if (l != null) for (i in 0 until l.length()) a.layers.add(FxLayer.from(l.getJSONObject(i)))
            return a
        }
    }
}

/** All animations: the built-in ones plus the ones you make. Saved as one small json file. */
object FxStore {
    private val list = ArrayList<FxAnim>()
    private var loaded = false

    val GOLD = 0xFFFFC94A.toInt()
    val RED = 0xFFFF3B30.toInt()
    val CYAN = 0xFF19E6F2.toInt()
    val PINK = 0xFFFF2E93.toInt()
    val GREEN = 0xFF3DDC97.toInt()
    val VIOLET = 0xFF8F6BFF.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val ORANGE = 0xFFFF8A2B.toInt()
    val swatches = intArrayOf(CYAN, GOLD, RED, PINK, GREEN, VIOLET, ORANGE, WHITE)

    private fun file(c: Context) = File(c.filesDir, "fx_anims.json")

    fun newId(): String = "u" + System.currentTimeMillis().toString(36)

    private fun defaults(): List<FxAnim> {
        val out = ArrayList<FxAnim>()

        val v = FxAnim("b_victory", "Victory", true)
        v.effects.add(FxEffect(FxType.FLASH, GOLD, 55, 50, 0, 500))
        v.effects.add(FxEffect(FxType.WAVE, GOLD, 80, 55, 0, 1200))
        v.effects.add(FxEffect(FxType.COMET, CYAN, 80, 60, 100, 2200))
        v.effects.add(FxEffect(FxType.GLOW, GOLD, 70, 50, 250, 2300))
        v.effects.add(FxEffect(FxType.TEXT, GOLD, 80, 50, 150, 2500, "VICTORY"))
        out.add(v)

        val d = FxAnim("b_defeat", "Defeat", true)
        d.effects.add(FxEffect(FxType.GLITCH, RED, 85, 60, 0, 1500))
        d.effects.add(FxEffect(FxType.SHAKE, WHITE, 60, 60, 0, 900))
        d.effects.add(FxEffect(FxType.TEXT, RED, 80, 50, 100, 2300, "DEFEAT"))
        d.effects.add(FxEffect(FxType.SCAN, RED, 60, 50, 300, 1600))
        d.effects.add(FxEffect(FxType.GLOW, RED, 50, 40, 300, 1900))
        out.add(d)

        val f = FxAnim("b_firstblood", "First blood", true)
        f.effects.add(FxEffect(FxType.FLASH, RED, 60, 50, 0, 380))
        f.effects.add(FxEffect(FxType.COMET, RED, 90, 80, 0, 1500))
        f.effects.add(FxEffect(FxType.SHAKE, WHITE, 70, 70, 0, 550))
        f.effects.add(FxEffect(FxType.WAVE, RED, 60, 60, 0, 900))
        f.effects.add(FxEffect(FxType.TEXT, RED, 70, 50, 100, 1900, "FIRST BLOOD"))
        out.add(f)

        val s = FxAnim("b_savage", "Savage", true)
        s.effects.add(FxEffect(FxType.GLITCH, PINK, 75, 70, 0, 1300))
        s.effects.add(FxEffect(FxType.WAVE, PINK, 85, 65, 0, 1100))
        s.effects.add(FxEffect(FxType.COMET, CYAN, 85, 85, 150, 1900))
        s.effects.add(FxEffect(FxType.SHAKE, WHITE, 55, 70, 100, 700))
        s.effects.add(FxEffect(FxType.TEXT, PINK, 80, 50, 150, 2300, "SAVAGE"))
        out.add(s)
        return out
    }

    @Synchronized
    private fun load(c: Context) {
        if (loaded) return
        loaded = true
        list.clear()
        try {
            val f = file(c)
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) list.add(FxAnim.from(a.getJSONObject(i)))
            }
        } catch (t: Throwable) { }
        val have = HashSet<String>()
        for (x in list) have.add(x.id)
        var changed = false
        val ds = defaults()
        for ((i, d) in ds.withIndex()) {
            if (!have.contains(d.id)) { list.add(minOf(i, list.size), d); changed = true }
        }
        if (changed) save(c)
    }

    @Synchronized
    fun all(c: Context): List<FxAnim> { load(c); return ArrayList(list) }

    fun get(c: Context, id: String): FxAnim? { load(c); return list.firstOrNull { it.id == id } }

    @Synchronized
    fun save(c: Context) {
        try {
            val a = JSONArray()
            for (x in list) a.put(x.toJson())
            file(c).writeText(a.toString())
        } catch (t: Throwable) { }
    }

    @Synchronized
    fun add(c: Context, a: FxAnim) { load(c); list.add(a); save(c) }

    @Synchronized
    fun remove(c: Context, id: String) {
        load(c)
        list.removeAll { it.id == id && !it.builtIn }
        save(c)
    }

    /** Puts a built-in animation back to how it came. */
    @Synchronized
    fun reset(c: Context, id: String) {
        load(c)
        val d = defaults().firstOrNull { it.id == id } ?: return
        val i = list.indexOfFirst { it.id == id }
        if (i >= 0) list[i] = d else list.add(d)
        save(c)
    }
}

/** Draws one animation at one moment. The same code is used by the stage in the app and, later, by the game overlay. */
class FxRender(private val ctx: Context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val seg = Path()
    private val rect = RectF()
    private val pm = PathMeasure()
    private val bmps = HashMap<String, Bitmap?>()

    private fun env(k: Float): Float = min(1f, min(k / 0.12f, (1f - k) / 0.3f)).coerceIn(0f, 1f)

    private fun col(c: Int, a: Float): Int = (c and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24)

    fun draw(c: Canvas, w: Float, h: Float, a: FxAnim, t: Int) {
        val u = h / 360f
        var sx = 0f
        var sy = 0f
        for (e in a.effects) {
            if (e.type != FxType.SHAKE || t < e.startMs || t >= e.startMs + e.durMs) continue
            val k = (t - e.startMs).toFloat() / max(1, e.durMs)
            val amp = e.power / 100f * 16f * u * (1f - k)
            val fr = 0.05f + e.speed * 0.002f
            sx += (sin(t * fr * 1.3f) + sin(t * fr * 2.9f + 1.7f)) * 0.5f * amp
            sy += (sin(t * fr * 1.7f + 0.6f) + sin(t * fr * 3.3f + 2.4f)) * 0.5f * amp
        }

        // pictures first, so effects sit on top of them
        c.save()
        c.translate(sx, sy)
        for (l in a.layers) drawLayer(c, w, h, u, l, t)
        c.restore()

        for (e in a.effects) {
            if (t < e.startMs || t > e.startMs + e.durMs) continue
            val k = ((t - e.startMs).toFloat() / max(1, e.durMs)).coerceIn(0f, 1f)
            when (e.type) {
                FxType.COMET -> comet(c, w, h, u, e, k)
                FxType.GLOW -> glow(c, w, h, u, e, k)
                FxType.GLITCH -> glitch(c, w, h, u, e, k, t)
                FxType.SCAN -> scan(c, w, h, u, e, k)
                FxType.FLASH -> flash(c, w, h, e, k)
                FxType.WAVE -> wave(c, w, h, u, e, k)
                FxType.TEXT -> text(c, w, h, u, e, k, sx, sy)
            }
        }
    }

    private fun bitmapFor(path: String): Bitmap? {
        if (path.isEmpty()) return null
        if (bmps.containsKey(path)) return bmps[path]
        var b: Bitmap? = null
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, o)
            var s = 1
            while (o.outWidth / (s * 2) >= 1024 && o.outWidth > 0) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            b = BitmapFactory.decodeFile(path, o2)
        } catch (t: Throwable) { }
        bmps[path] = b
        return b
    }

    /** Width and height in pixels of a picture on a screen of the given height, or null if it cannot be loaded. */
    fun layerDims(h: Float, l: FxLayer, scale: Float = l.scale): FloatArray? {
        val bmp = bitmapFor(l.path) ?: return null
        val target = h * 0.25f * scale
        val ratio = bmp.width.toFloat() / max(1, bmp.height).toFloat()
        return floatArrayOf(target * ratio, target)
    }

    /** Draws a picture as it will look at its best, for placing it. selected gets an outline. */
    fun drawLayerStatic(c: Canvas, w: Float, h: Float, l: FxLayer, selected: Boolean) {
        val bmp = bitmapFor(l.path) ?: return
        val dm = layerDims(h, l) ?: return
        c.save()
        c.translate(w * l.x, h * l.y)
        c.rotate(l.rot)
        p.style = Paint.Style.FILL
        p.shader = null
        p.alpha = (l.alpha.coerceIn(0f, 1f) * 255f).toInt()
        rect.set(-dm[0] / 2f, -dm[1] / 2f, dm[0] / 2f, dm[1] / 2f)
        c.drawBitmap(bmp, null, rect, p)
        p.alpha = 255
        if (selected) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = max(1.5f, h / 180f)
            p.color = 0xFF19E6F2.toInt()
            c.drawRect(rect, p)
            p.style = Paint.Style.FILL
            val s = max(3f, h / 70f)
            for (sx in floatArrayOf(-1f, 1f)) for (sy in floatArrayOf(-1f, 1f)) c.drawCircle(sx * dm[0] / 2f, sy * dm[1] / 2f, s, p)
        }
        c.restore()
    }

    /** Just the selection frame of a picture (used by the editor, which draws the picture itself). */
    fun drawLayerOutline(c: Canvas, w: Float, h: Float, l: FxLayer) {
        val dm = layerDims(h, l) ?: return
        c.save()
        c.translate(w * l.x, h * l.y)
        c.rotate(l.rot)
        rect.set(-dm[0] / 2f, -dm[1] / 2f, dm[0] / 2f, dm[1] / 2f)
        p.style = Paint.Style.STROKE
        p.shader = null
        p.strokeWidth = max(1.5f, h / 180f)
        p.color = 0xFF19E6F2.toInt()
        c.drawRect(rect, p)
        p.style = Paint.Style.FILL
        val s = max(3f, h / 70f)
        for (sx in floatArrayOf(-1f, 1f)) for (sy in floatArrayOf(-1f, 1f)) c.drawCircle(sx * dm[0] / 2f, sy * dm[1] / 2f, s, p)
        c.restore()
    }

    /** True when the point (px, py) on a stage of w x h lands on this picture. */
    fun hitLayer(w: Float, h: Float, l: FxLayer, px: Float, py: Float): Boolean {
        val dm = layerDims(h, l) ?: return false
        val dx = px - w * l.x
        val dy = py - h * l.y
        val a = Math.toRadians(-l.rot.toDouble())
        val rx = (dx * kotlin.math.cos(a) - dy * kotlin.math.sin(a)).toFloat()
        val ry = (dx * kotlin.math.sin(a) + dy * kotlin.math.cos(a)).toFloat()
        return kotlin.math.abs(rx) <= dm[0] / 2f && kotlin.math.abs(ry) <= dm[1] / 2f
    }

    private fun drawLayer(c: Canvas, w: Float, h: Float, u: Float, l: FxLayer, t: Int) {
        if (t < l.startMs || t > l.startMs + l.durMs) return
        val bmp = bitmapFor(l.path) ?: return
        val k = ((t - l.startMs).toFloat() / max(1, l.durMs)).coerceIn(0f, 1f)
        val inK = (k / 0.15f).coerceIn(0f, 1f)
        val outK = ((1f - k) / 0.2f).coerceIn(0f, 1f)
        var al = l.alpha
        var sc = l.scale
        var dx = 0f
        when (l.intro) {
            1 -> al *= inK
            2 -> { al *= inK; sc *= 0.4f + 0.6f * (1f - (1f - inK).pow(3)) + 0.12f * sin(inK * PI.toFloat()) }
            3 -> { al *= inK; dx = -(1f - inK) * 60f * u }
        }
        when (l.outro) {
            1 -> al *= outK
            2 -> { al *= outK; sc *= 0.6f + 0.4f * outK }
        }
        val target = h * 0.25f * sc
        val ratio = bmp.width.toFloat() / max(1, bmp.height).toFloat()
        val bw = target * ratio
        val bh = target
        c.save()
        c.translate(w * l.x + dx, h * l.y)
        c.rotate(l.rot)
        p.style = Paint.Style.FILL
        p.shader = null
        p.alpha = (al.coerceIn(0f, 1f) * 255f).toInt()
        rect.set(-bw / 2f, -bh / 2f, bw / 2f, bh / 2f)
        c.drawBitmap(bmp, null, rect, p)
        p.alpha = 255
        c.restore()
    }

    private fun frame(w: Float, h: Float, u: Float): Float {
        val inset = 6f * u
        rect.set(inset, inset, w - inset, h - inset)
        return 18f * u
    }

    private fun comet(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val rad = frame(w, h, u)
        path.reset()
        path.addRoundRect(rect, rad, rad, Path.Direction.CW)
        pm.setPath(path, true)
        val len = pm.length
        val laps = 1f + e.speed / 100f * 1.5f
        val ease = k * k * (3f - 2f * k)
        val head = ease * laps * len
        val trail = len * (0.12f + e.power / 100f * 0.12f)
        val en = env(k)
        val width = (2.2f + e.power / 100f * 3.8f) * u
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.shader = null
        val n = 14
        for (i in 0 until n) {
            val from = head - trail * (i + 1) / n
            val to = head - trail * i / n
            val f = ((from % len) + len) % len
            val tt = ((to % len) + len) % len
            seg.rewind()
            if (tt >= f) pm.getSegment(f, tt, seg, true)
            else { pm.getSegment(f, len, seg, true); pm.getSegment(0f, tt, seg, true) }
            val fade = 1f - i.toFloat() / n
            p.strokeWidth = width * (0.35f + 0.65f * fade)
            p.color = col(e.color, 0.9f * fade * fade * en)
            c.drawPath(seg, p)
        }
        val pos = FloatArray(2)
        pm.getPosTan(((head % len) + len) % len, pos, null)
        p.style = Paint.Style.FILL
        p.color = col(e.color, 0.18f * en)
        c.drawCircle(pos[0], pos[1], width * 4.5f, p)
        p.color = col(e.color, 0.4f * en)
        c.drawCircle(pos[0], pos[1], width * 2.4f, p)
        p.color = col(0xFFFFFFFF.toInt(), 0.95f * en)
        c.drawCircle(pos[0], pos[1], width * 0.9f, p)
        p.strokeCap = Paint.Cap.BUTT
    }

    private fun glow(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val rad = frame(w, h, u)
        val pulses = 2f + e.speed / 100f * 4f
        val a = env(k) * (0.55f + 0.45f * sin(k * pulses * 2f * PI.toFloat() - 1.2f)) * (e.power / 100f)
        p.style = Paint.Style.STROKE
        p.shader = null
        for (j in 0..4) {
            p.strokeWidth = (2f + j * 6f) * u
            p.color = col(e.color, a * (if (j == 0) 0.95f else 0.5f / j))
            c.drawRoundRect(rect, rad, rad, p)
        }
    }

    private fun glitch(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float, t: Int) {
        val seed = t / max(30, 90 - e.speed / 2)
        val en = env(k)
        val pw = e.power / 100f
        p.style = Paint.Style.FILL
        p.shader = null
        val n = 4 + (pw * 10f).toInt()
        for (i in 0 until n) {
            val y = Cy.rnd(seed * 31 + i * 7) * h
            val bh = (2f + Cy.rnd(seed * 17 + i * 3) * 10f) * u
            val x0 = Cy.rnd(seed * 13 + i * 5) * w * 0.6f
            val bw = w * (0.15f + Cy.rnd(seed * 19 + i * 11) * 0.4f)
            val off = (Cy.rnd(seed * 23 + i * 2) - 0.5f) * 40f * u * pw
            p.color = col(e.color, (0.18f + 0.3f * Cy.rnd(seed * 5 + i)) * en)
            c.drawRect(x0 + off, y, x0 + off + bw, y + bh, p)
            if (i % 3 == 0) {
                p.color = col(FxStore.CYAN, 0.22f * en)
                c.drawRect(x0 + off - 6f * u, y, x0 + off + bw * 0.6f, y + bh * 0.5f, p)
            }
        }
        if (Cy.rnd(seed * 7) > 0.78f) {
            p.color = col(e.color, 0.08f * pw * en)
            c.drawRect(0f, 0f, w, h, p)
        }
        val sw = (10f + 22f * pw) * u
        p.color = col(FxStore.PINK, 0.3f * en * Cy.rnd(seed * 3 + 1))
        c.drawRect(0f, 0f, sw, h, p)
        p.color = col(FxStore.CYAN, 0.3f * en * Cy.rnd(seed * 3 + 2))
        c.drawRect(w - sw, 0f, w, h, p)
    }

    private fun scan(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val en = env(k)
        val y = (k * k * (3f - 2f * k)) * (h + 80f * u) - 40f * u
        val tr = (40f + e.power / 100f * 90f) * u
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, y - tr, 0f, y, col(e.color, 0f), col(e.color, 0.35f * en), Shader.TileMode.CLAMP)
        c.drawRect(0f, y - tr, w, y, p)
        p.shader = null
        p.color = col(e.color, 0.95f * en)
        c.drawRect(0f, y - 1.5f * u, w, y + 1.5f * u, p)
        p.color = col(0xFFFFFFFF.toInt(), 0.7f * en)
        c.drawRect(0f, y - 0.5f * u, w, y + 0.5f * u, p)
    }

    private fun flash(c: Canvas, w: Float, h: Float, e: FxEffect, k: Float) {
        val a = (1f - k).pow(2f) * (e.power / 100f) * 0.85f
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = col(e.color, a)
        c.drawRect(0f, 0f, w, h, p)
    }

    private fun wave(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float) {
        val maxR = hypot(w, h) / 2f * (0.55f + e.speed / 100f * 0.6f)
        p.style = Paint.Style.STROKE
        p.shader = null
        for (j in 0..1) {
            val kk = ((k - j * 0.14f) / (1f - j * 0.14f)).coerceIn(0f, 1f)
            if (kk <= 0f) continue
            val r = (1f - (1f - kk).pow(3)) * maxR
            p.strokeWidth = (3f + e.power / 100f * 11f) * u * (1f - kk) * (if (j == 0) 1f else 0.6f)
            p.color = col(e.color, (1f - kk) * 0.9f)
            c.drawCircle(w / 2f, h / 2f, r, p)
        }
    }

    private fun text(c: Canvas, w: Float, h: Float, u: Float, e: FxEffect, k: Float, sx: Float, sy: Float) {
        val s = e.text.uppercase()
        if (s.isEmpty()) return
        val en = env(k)
        val pop = if (k < 0.15f) 1.5f - 0.5f * (k / 0.15f).pow(0.6f) else 1f
        val height = (34f + e.power / 100f * 40f) * u * pop
        val kk = height / 10f
        val spread = 1f + (1f - en) * 0.25f
        p.style = Paint.Style.STROKE
        c.save()
        c.translate(sx, sy)
        c.scale(spread, 1f, w / 2f, h / 2f)
        CyUi.text(c, p, s, w / 2f, h / 2f - height / 2f, kk, e.color, en, true, 1)
        c.restore()
        p.style = Paint.Style.FILL
    }
}

package com.xio.bulwark

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Small custom controls for the Frameline app screens (everything is drawn by hand, no stock widgets). */
object Ui {
    val BG0 = 0xFF0A0D11.toInt()
    val BG1 = 0xFF121820.toInt()
    val CARD = 0xFF151B23.toInt()
    val EDGE = 0x24FFFFFF.toInt()

    fun dp(c: Context, v: Float): Float = v * c.resources.displayMetrics.density
    fun dpi(c: Context, v: Float): Int = (v * c.resources.displayMetrics.density).roundToInt()

    fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val ar = (a shr 24 and 255) * (1 - k) + (b shr 24 and 255) * k
        val rr = (a shr 16 and 255) * (1 - k) + (b shr 16 and 255) * k
        val gg = (a shr 8 and 255) * (1 - k) + (b shr 8 and 255) * k
        val bb = (a and 255) * (1 - k) + (b and 255) * k
        return (ar.toInt() shl 24) or (rr.toInt() shl 16) or (gg.toInt() shl 8) or bb.toInt()
    }

    fun cardBg(c: Context, radius: Float = 18f): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(CARD)
        g.cornerRadius = dp(c, radius)
        g.setStroke(dpi(c, 1f), EDGE)
        return g
    }

    /** Slide-up + fade-in, one after another. */
    fun enter(views: List<View>, startDelay: Long = 0L) {
        for ((i, v) in views.withIndex()) {
            v.alpha = 0f
            v.translationY = 28f
            v.animate().alpha(1f).translationY(0f).setStartDelay(startDelay + i * 55L).setDuration(420)
                .setInterpolator(DecelerateInterpolator(1.6f)).start()
        }
    }
}

/** On / off switch: hard-edged cells, square thumb. */
class PSwitch(ctx: Context) : View(ctx) {
    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null
    private var pos = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init {
        isClickable = true
        setOnClickListener {
            moveTo(!checked)
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onChange?.invoke(checked)
        }
    }

    private fun moveTo(v: Boolean) {
        checked = v
        anim?.cancel()
        val a = ValueAnimator.ofFloat(pos, if (v) 1f else 0f)
        a.duration = 130
        a.addUpdateListener { pos = it.animatedValue as Float; invalidate() }
        a.start()
        anim = a
    }

    /** Set from code without calling onChange. */
    fun setChecked(v: Boolean) {
        if (v == checked) return
        moveTo(v)
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(Ui.dpi(context, 52f), Ui.dpi(context, 28f))
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat()
        val h = height.toFloat()
        val t = pos.coerceIn(0f, 1f)
        CyUi.chamfer(path, d, d, w - d, h - d, 7 * d)
        p.style = Paint.Style.FILL
        p.color = Ui.mix(0xFF0B1118.toInt(), Cy.a(Cy.CYAN, 0.22f), t)
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Ui.mix(Cy.a(Cy.CYAN, 0.28f), Cy.a(Cy.CYAN, 0.95f), t)
        c.drawPath(path, p)
        val tw = 16 * d
        val x0 = 5 * d + (w - 10 * d - tw) * t
        p.style = Paint.Style.FILL
        p.color = Ui.mix(0xFF566274.toInt(), 0xFFFFFFFF.toInt(), t)
        c.drawRect(x0, 6 * d, x0 + tw, h - 6 * d, p)
    }
}

/** Slider with a filled track. */
class PSlider(ctx: Context, private val lo: Int, private val hi: Int) : View(ctx) {
    var value = lo
        private set
    var onValue: ((Int) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    fun setValue(v: Int) {
        value = v.coerceIn(lo, hi)
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 36f))
    }

    private fun pad() = Ui.dp(context, 12f)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val f = ((e.x - pad()) / max(1f, width - 2 * pad())).coerceIn(0f, 1f)
                val v = lo + (f * (hi - lo)).roundToInt()
                if (v != value) { value = v; onValue?.invoke(v); invalidate() }
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat()
        val cy = height / 2f
        val x0 = pad()
        val x1 = w - pad()
        val f = (value - lo).toFloat() / (hi - lo)
        val tx = x0 + (x1 - x0) * f
        p.style = Paint.Style.FILL
        p.color = 0xFF1A2330.toInt()
        c.drawRect(x0, cy - 2 * d, x1, cy + 2 * d, p)
        p.color = Cy.CYAN
        c.drawRect(x0, cy - 2 * d, tx, cy + 2 * d, p)
        p.color = Cy.a(Cy.CYAN, 0.35f)
        var tk = x0
        while (tk <= x1 + 0.5f) { c.drawRect(tk - 0.5f * d, cy + 5 * d, tk + 0.5f * d, cy + 8 * d, p); tk += (x1 - x0) / 10f }
        p.color = 0xFFFFFFFF.toInt()
        c.drawRect(tx - 5 * d, cy - 9 * d, tx + 5 * d, cy + 9 * d, p)
        p.color = Cy.CYAN
        c.drawRect(tx - 1 * d, cy - 6 * d, tx + 1 * d, cy + 6 * d, p)
    }
}

/** Pick-one control with hard-edged cells. */
class Segmented(ctx: Context, private val labels: List<String>) : View(ctx) {
    var selected = 0
        private set
    var onSelect: ((Int) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    fun select(i: Int, animate: Boolean = true) {
        selected = i.coerceIn(0, labels.size - 1)
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 40f))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val i = (e.x / (width.toFloat() / labels.size)).toInt().coerceIn(0, labels.size - 1)
            if (i != selected) {
                select(i)
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                onSelect?.invoke(i)
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat()
        val h = height.toFloat()
        val cw = w / labels.size
        for (i in labels.indices) {
            val l = i * cw + 1.5f * d
            val r = (i + 1) * cw - 1.5f * d
            CyUi.chamfer(path, l, d, r, h - d, 8 * d)
            val on = i == selected
            p.style = Paint.Style.FILL
            p.color = Cy.a(Cy.CYAN, if (on) 0.30f else 0.06f)
            c.drawPath(path, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = (if (on) 1.5f else 1f) * d
            p.color = Cy.a(Cy.CYAN, if (on) 0.95f else 0.25f)
            c.drawPath(path, p)
            CyUi.label(c, p, labels[i], (l + r) / 2f, h / 2f, 0.8f * d, if (on) 0xFFFFFFFF.toInt() else 0xFF8B96A3.toInt(), on, context)
        }
    }
}

/** A small picture of one overlay design, tap to choose it. */
class DesignCard(ctx: Context, private val style: Int, private val name: String) : View(ctx) {
    var onPick: (() -> Unit)? = null
    private var sel = 0f
    private var selected = false
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()

    fun setSelected2(v: Boolean) {
        if (v == selected) return
        selected = v
        anim?.cancel()
        val a = ValueAnimator.ofFloat(sel, if (v) 1f else 0f)
        a.duration = 260
        a.addUpdateListener { sel = it.animatedValue as Float; invalidate() }
        a.start()
        anim = a
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 92f))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onPick?.invoke()
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = Ui.dp(context, 1f)
        p.style = Paint.Style.FILL
        p.color = Ui.mix(0xFF0A1016.toInt(), Cy.a(Cy.CYAN, 0.14f), sel)
        CyUi.chamfer(path, d, d, w - d, h - d, 12 * d)
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.3f * d
        p.color = Ui.mix(Cy.a(Cy.CYAN, 0.25f), Cy.a(Cy.CYAN, 0.95f), sel)
        c.drawPath(path, p)

        val cx = w / 2f
        val cy = h * 0.42f
        p.style = Paint.Style.FILL
        when (style) {
            0 -> {
                r.set(cx - 26 * d, cy - 15 * d, cx + 26 * d, cy + 15 * d)
                p.color = 0xFF1B2229.toInt()
                c.drawRoundRect(r, 6 * d, 6 * d, p)
                p.color = 0xFF3DDC97.toInt()
                r.set(cx - 22 * d, cy - 14 * d, cx - 8 * d, cy - 12.5f * d)
                c.drawRect(r, p)
                p.textSize = 13 * d
                p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                p.textAlign = Paint.Align.LEFT
                c.drawText("60", cx - 21 * d, cy + 6 * d, p)
                p.color = 0xFF3DDC97.toInt()
                for (i in 0 until 6) {
                    val bh = (4 + (i * 7 % 5)) * d
                    r.set(cx + (-2 + i * 4) * d, cy + 9 * d - bh, cx + (0.4f + i * 4) * d, cy + 9 * d)
                    c.drawRect(r, p)
                }
            }
            1 -> {
                // blade: slanted strip, spine, big number, segment meter
                path.reset()
                path.moveTo(cx - 24 * d, cy - 14 * d); path.lineTo(cx + 30 * d, cy - 14 * d); path.lineTo(cx + 30 * d, cy + 6 * d)
                path.lineTo(cx + 24 * d, cy + 14 * d); path.lineTo(cx - 30 * d, cy + 14 * d); path.lineTo(cx - 30 * d, cy - 8 * d); path.close()
                p.color = 0xFF1B2229.toInt()
                c.drawPath(path, p)
                p.color = 0xFF3DDC97.toInt()
                r.set(cx - 30 * d, cy - 8 * d, cx - 28 * d, cy + 14 * d)
                c.drawRect(r, p)
                p.color = 0xFFE6EDF3.toInt()
                p.textSize = 14 * d
                p.textAlign = Paint.Align.LEFT
                p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                c.drawText("60", cx - 24 * d, cy + 4 * d, p)
                p.color = 0xFF3DDC97.toInt()
                for (i in 0 until 4) {
                    r.set(cx - 24 * d + i * 5 * d, cy + 8 * d, cx - 20.5f * d + i * 5 * d, cy + 10.5f * d)
                    c.drawRect(r, p)
                }
                p.color = 0xFF29313A.toInt()
                for (i in 0 until 6) {
                    r.set(cx - 2 * d + i * 5 * d, cy - 6 * d + (i % 3) * 2 * d, cx + 1.5f * d + i * 5 * d, cy + 8 * d)
                    c.drawRect(r, p)
                }
            }
            else -> {
                // stack: tall tower with cut corners
                path.reset()
                path.moveTo(cx - 14 * d, cy - 22 * d); path.lineTo(cx + 8 * d, cy - 22 * d); path.lineTo(cx + 16 * d, cy - 14 * d)
                path.lineTo(cx + 16 * d, cy + 20 * d); path.lineTo(cx - 8 * d, cy + 20 * d); path.lineTo(cx - 16 * d, cy + 12 * d)
                path.lineTo(cx - 16 * d, cy - 20 * d); path.close()
                p.color = 0xFF1B2229.toInt()
                c.drawPath(path, p)
                p.color = 0xFFE6EDF3.toInt()
                p.textSize = 14 * d
                p.textAlign = Paint.Align.CENTER
                p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                c.drawText("60", cx, cy - 6 * d, p)
                p.color = 0xFF3DDC97.toInt()
                r.set(cx - 11 * d, cy - 2 * d, cx + 6 * d, cy + 0.5f * d)
                c.drawRect(r, p)
                p.color = 0xFF29313A.toInt()
                for (i in 0 until 3) {
                    r.set(cx - 11 * d, cy + (5 + i * 5) * d, cx + 11 * d, cy + (7 + i * 5) * d)
                    c.drawRect(r, p)
                }
                p.color = 0xFF3DDC97.toInt()
                r.set(cx - 11 * d, cy + 5 * d, cx + 2 * d, cy + 7 * d)
                c.drawRect(r, p)
            }
        }
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 12 * d
        p.color = Ui.mix(0xFF8B96A3.toInt(), 0xFFFFFFFF.toInt(), sel)
        c.drawText(name, cx, h - 11 * d, p)
    }
}

/** Hard-edged button. kind: 0 = main (yellow), 1 = quiet (cyan), 2 = stop (red). */
class PButton(ctx: Context, var text: String, var kind: Int = 0) : View(ctx) {
    var onClick: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var heightDp = 48f
    private var down = false

    constructor(ctx: Context, text: String, kind: Int, heightDp: Float) : this(ctx, text, kind) {
        this.heightDp = heightDp
    }

    init {
        isClickable = true
        setOnClickListener {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onClick?.invoke()
        }
    }

    fun set(t: String, k: Int) {
        text = t
        kind = k
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, heightDp))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { down = false; invalidate() }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat()
        val h = height.toFloat()
        val col = when (kind) { 0 -> CyUi.YELLOW; 2 -> 0xFFFF5A4D.toInt(); else -> Cy.CYAN }
        CyUi.chamfer(path, d, d, w - d, h - d, min(12 * d, h / 3f))
        p.style = Paint.Style.FILL
        p.color = Cy.a(col, if (down) 0.38f else 0.16f)
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.4f * d
        p.color = Cy.a(col, 0.95f)
        c.drawPath(path, p)
        CyUi.label(c, p, text, w / 2f, h / 2f, 0.9f * d, 0xFFEAFBFF.toInt(), true, context)
    }
}

/** Bottom tab bar with a sliding highlight. Tabs that are not ready yet are dimmed and cannot be tapped. */
class NavBar(ctx: Context, private val labels: List<String>, private val enabled: List<Boolean>) : View(ctx) {
    var onSelect: ((Int) -> Unit)? = null
    var selected = 0
        private set
    private var pill = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()

    fun select(i: Int) {
        if (i == selected) return
        selected = i
        anim?.cancel()
        val a = ValueAnimator.ofFloat(pill, i.toFloat())
        a.duration = 300
        a.interpolator = OvershootInterpolator(1.1f)
        a.addUpdateListener { pill = it.animatedValue as Float; invalidate() }
        a.start()
        anim = a
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 68f))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val i = (e.x / (width.toFloat() / labels.size)).toInt().coerceIn(0, labels.size - 1)
            if (enabled[i] && i != selected) {
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                select(i)
                onSelect?.invoke(i)
            }
        }
        return true
    }

    private fun icon(c: Canvas, i: Int, cx: Float, cy: Float, d: Float, col: Int) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.8f * d
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = col
        path.reset()
        val kind = when (labels[i]) { "Live" -> 0; "Games" -> 1; "Boost" -> 2; "Music" -> 4; "Gallery" -> 5; "Player" -> 6; "Triggers" -> 7; else -> 3 }
        when (kind) {
            7 -> {
                val hs = floatArrayOf(4f, 9f, 14f, 7f, 11f)
                for (k in hs.indices) {
                    val x = cx - 8 * d + k * 4 * d
                    c.drawLine(x, cy - hs[k] / 2f * d, x, cy + hs[k] / 2f * d, p)
                }
            }
            6 -> {
                path.moveTo(cx - 9 * d, cy - 6 * d); path.lineTo(cx + 5 * d, cy - 6 * d); path.lineTo(cx + 9 * d, cy - 2 * d)
                path.lineTo(cx + 9 * d, cy + 6 * d); path.lineTo(cx - 5 * d, cy + 6 * d); path.lineTo(cx - 9 * d, cy + 2 * d); path.close()
                c.drawPath(path, p)
                path.reset()
                path.moveTo(cx - 2 * d, cy - 2.5f * d); path.lineTo(cx + 3.5f * d, cy); path.lineTo(cx - 2 * d, cy + 2.5f * d); path.close()
                p.style = Paint.Style.FILL
                c.drawPath(path, p)
                p.style = Paint.Style.STROKE
            }
            5 -> {
                r.set(cx - 9 * d, cy - 7 * d, cx + 9 * d, cy + 7 * d)
                c.drawRoundRect(r, 2.5f * d, 2.5f * d, p)
                path.moveTo(cx - 9 * d, cy + 4 * d)
                path.lineTo(cx - 3 * d, cy - 1.5f * d)
                path.lineTo(cx + 1 * d, cy + 2 * d)
                path.lineTo(cx + 4 * d, cy - 0.5f * d)
                path.lineTo(cx + 9 * d, cy + 4 * d)
                c.drawPath(path, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx + 4.5f * d, cy - 3.2f * d, 1.5f * d, p)
                p.style = Paint.Style.STROKE
            }
            4 -> {
                path.moveTo(cx + 3 * d, cy + 4 * d)
                path.lineTo(cx + 3 * d, cy - 8 * d)
                path.lineTo(cx + 8 * d, cy - 6 * d)
                c.drawPath(path, p)
                r.set(cx - 6 * d, cy + 1 * d, cx + 3 * d, cy + 8 * d)
                c.drawOval(r, p)
            }
            0 -> {
                path.moveTo(cx - 9 * d, cy + 1 * d)
                path.lineTo(cx - 4 * d, cy + 1 * d)
                path.lineTo(cx - 1.5f * d, cy - 6 * d)
                path.lineTo(cx + 2.5f * d, cy + 7 * d)
                path.lineTo(cx + 5 * d, cy - 1 * d)
                path.lineTo(cx + 9 * d, cy - 1 * d)
                c.drawPath(path, p)
            }
            1 -> {
                for (a in 0..1) for (b in 0..1) {
                    r.set(cx - 8 * d + a * 9 * d, cy - 8 * d + b * 9 * d, cx - 1 * d + a * 9 * d, cy - 1 * d + b * 9 * d)
                    c.drawRoundRect(r, 2 * d, 2 * d, p)
                }
            }
            2 -> {
                path.moveTo(cx + 2 * d, cy - 9 * d)
                path.lineTo(cx - 6 * d, cy + 2 * d)
                path.lineTo(cx - 0.5f * d, cy + 2 * d)
                path.lineTo(cx - 2 * d, cy + 9 * d)
                path.lineTo(cx + 6 * d, cy - 2 * d)
                path.lineTo(cx + 0.5f * d, cy - 2 * d)
                path.close()
                c.drawPath(path, p)
            }
            else -> {
                for (k in 0..2) {
                    val y = cy - 6 * d + k * 6 * d
                    c.drawLine(cx - 9 * d, y, cx + 9 * d, y, p)
                    p.style = Paint.Style.FILL
                    val x = cx - 4 * d + ((k * 5) % 9) * d
                    c.drawCircle(x, y, 2.4f * d, p)
                    p.style = Paint.Style.STROKE
                }
            }
        }
        p.strokeCap = Paint.Cap.BUTT
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = Ui.dp(context, 1f)
        p.style = Paint.Style.FILL
        p.color = 0xF0070B10.toInt()
        c.drawRect(0f, 0f, w, h, p)
        p.color = Neon.a(Neon.CYAN, 50)
        c.drawRect(0f, 0f, w, 1f * d, p)
        val seg = w / labels.size
        val pulseN = 0.5f + 0.5f * kotlin.math.sin(Neon.now() * 3f)
        // glowing bar above the selected tab
        val bx = seg * pill + seg / 2f
        p.color = Neon.a(Neon.CYAN, (40 + 40 * pulseN).toInt())
        r.set(bx - 26 * d, 0f, bx + 26 * d, 5 * d)
        c.drawRoundRect(r, 3 * d, 3 * d, p)
        p.color = Neon.CYAN
        r.set(bx - 20 * d, 0f, bx + 20 * d, 2f * d)
        c.drawRoundRect(r, 2 * d, 2 * d, p)
        val pillW = min(seg - 6 * d, 76 * d)
        val pcx = seg * pill + seg / 2f
        p.color = 0x243DDC97
        r.set(pcx - pillW / 2f, 8 * d, pcx + pillW / 2f, h - 8 * d)
        c.drawRoundRect(r, 16 * d, 16 * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = 0x663DDC97
        c.drawRoundRect(r, 16 * d, 16 * d, p)
        for (i in labels.indices) {
            val near = max(0f, 1f - kotlin.math.abs(pill - i))
            val base = if (enabled[i]) 0xFF8B96A3.toInt() else 0xFF4A535E.toInt()
            val col = Ui.mix(base, 0xFF3DDC97.toInt(), near)
            val cx = seg * i + seg / 2f
            icon(c, i, cx, h * 0.38f, d, col)
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.textSize = 10.5f * d
            p.color = col
            c.drawText(labels[i], cx, h * 0.80f, p)
            if (!enabled[i]) {
                p.textSize = 6.5f * d
                p.color = 0xFF6A7480.toInt()
                p.letterSpacing = 0.12f
                c.drawText("SOON", cx + 13 * d, h * 0.22f, p)
                p.letterSpacing = 0f
            }
        }
        postInvalidateDelayed(50)
    }
}

/** The "game screen" behind the live preview. */
class PreviewBox(ctx: Context) : FrameLayout(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val r = RectF()

    init {
        setWillNotDraw(false)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val rad = Ui.dp(context, 20f)
        clip.reset()
        r.set(0f, 0f, w.toFloat(), h.toFloat())
        clip.addRoundRect(r, rad, rad, Path.Direction.CW)
    }

    override fun dispatchDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = Ui.dp(context, 1f)
        c.save()
        c.clipPath(clip)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, h, 0xF0121C26.toInt(), 0xF0070C11.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = 0x0DFFFFFF
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, h, p); x += 28 * d }
        var y = 0f
        while (y < h) { c.drawLine(0f, y, w, y, p); y += 28 * d }
        p.style = Paint.Style.FILL
        p.textSize = 8.5f * d
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.2f
        p.color = Neon.a(Neon.CYAN, 150)
        p.textAlign = Paint.Align.LEFT
        c.drawText("LIVE PREVIEW", 14 * d, 20 * d, p)
        p.letterSpacing = 0f
        super.dispatchDraw(c)
        c.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Ui.EDGE
        r.set(0.6f * d, 0.6f * d, w - 0.6f * d, h - 0.6f * d)
        c.drawRoundRect(r, 20 * d, 20 * d, p)
    }
}

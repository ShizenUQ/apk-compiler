package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import java.io.File

/** Plays the sound that belongs to an animation. */
object FxAudio {
    private var mp: MediaPlayer? = null

    @Synchronized
    fun play(path: String, volume: Int) {
        if (path.isEmpty() || !File(path).exists()) return
        stop()
        try {
            val m = MediaPlayer()
            m.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            m.setDataSource(path)
            val v = (volume / 100f).coerceIn(0f, 1f)
            m.setVolume(v, v)
            m.setOnCompletionListener { x -> try { x.release() } catch (t: Throwable) { }; if (mp === x) mp = null }
            m.setOnErrorListener { x, _, _ -> try { x.release() } catch (t: Throwable) { }; if (mp === x) mp = null; true }
            m.prepare()
            m.start()
            mp = m
        } catch (t: Throwable) { mp = null }
    }

    @Synchronized
    fun stop() {
        try { mp?.stop() } catch (t: Throwable) { }
        try { mp?.release() } catch (t: Throwable) { }
        mp = null
    }
}

/** Full-screen view that plays one animation over everything, then removes itself. */
class FxPlayView(ctx: Context, private val anim: FxAnim) : View(ctx) {
    private val render = FxRender(ctx)
    private var t0 = 0L
    var onDone: (() -> Unit)? = null
    private var done = false

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        t0 = SystemClock.uptimeMillis()
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val el = (SystemClock.uptimeMillis() - t0).toInt()
        if (el > anim.totalMs() + 250) {
            if (!done) { done = true; post { onDone?.invoke() } }
            return
        }
        render.draw(c, width.toFloat(), height.toFloat(), anim, el)
        postInvalidateOnAnimation()
    }
}

/** Shows an animation on top of the game. Needs the "display over other apps" permission Frameline already uses. */
object FxOverlay {
    private val ui = Handler(Looper.getMainLooper())
    private var view: FxPlayView? = null

    fun play(ctx: Context, a: FxAnim) {
        val app = ctx.applicationContext
        ui.post {
            if (!Settings.canDrawOverlays(app)) return@post
            removeNow(app)
            val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = FxPlayView(app, a)
            val l = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            l.gravity = Gravity.TOP or Gravity.START
            l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            v.onDone = { removeNow(app) }
            try {
                wm.addView(v, l)
                view = v
                FxAudio.play(a.audio, a.volume)
            } catch (t: Throwable) { view = null }
        }
    }

    private fun removeNow(app: Context) {
        val v = view ?: return
        view = null
        try { (app.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (t: Throwable) { }
    }
}

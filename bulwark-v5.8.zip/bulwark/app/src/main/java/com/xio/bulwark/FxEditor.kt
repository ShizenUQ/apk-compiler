package com.xio.bulwark

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/** One row of the timeline. kind: 1 = effect, 2 = picture, 3 = sound. */
private class TlRow(val kind: Int, val idx: Int)

/**
 * The timeline: one bar per picture, effect and sound. Drag a bar to move it, drag its ends to trim it,
 * drag along the ruler to move the playhead.
 */
class TimelineView(ctx: Context, private val ed: FxEditorActivity) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val d = Ui.dp(ctx, 1f)
    private val rulerH = 20 * d
    private val rowH = 26 * d
    private val padL = 10 * d
    private val padR = 10 * d
    private var rows = ArrayList<TlRow>()
    private var audioMs = 0
    private var audioPath = ""

    private var mode = 0           // 0 none, 1 scrub, 2 move, 3 trim start, 4 trim end, 5 undecided (empty area)
    private var downX = 0f
    private var downY = 0f
    private var s0 = 0
    private var d0 = 0
    private var rowSel = -1

    fun totalSec(): Int {
        val a = ed.work
        return max(4, min(40, ceil((a.totalMs() + 800) / 1000.0).toInt()))
    }

    private fun pxPerMs(): Float = (width - padL - padR) / (totalSec() * 1000f)
    private fun xOf(ms: Int) = padL + ms * pxPerMs()

    fun rebuild() {
        val a = ed.work
        rows.clear()
        for (i in a.layers.indices) rows.add(TlRow(2, i))
        for (i in a.effects.indices) rows.add(TlRow(1, i))
        if (a.audio.isNotEmpty()) {
            rows.add(TlRow(3, 0))
            if (audioPath != a.audio) {
                audioPath = a.audio
                audioMs = try {
                    val m = MediaMetadataRetriever()
                    m.setDataSource(a.audio)
                    val v = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toInt() ?: 3000
                    m.release()
                    v
                } catch (t: Throwable) { 3000 }
            }
        }
        requestLayout()
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val n = max(1, rows.size)
        setMeasuredDimension(MeasureSpec.getSize(w), (rulerH + n * rowH + 8 * d).toInt())
    }

    private fun rowStart(k: TlRow): Int = when (k.kind) {
        1 -> ed.work.effects[k.idx].startMs
        2 -> ed.work.layers[k.idx].startMs
        else -> 0
    }

    private fun rowDur(k: TlRow): Int = when (k.kind) {
        1 -> ed.work.effects[k.idx].durMs
        2 -> ed.work.layers[k.idx].durMs
        else -> audioMs
    }

    private fun setTimes(k: TlRow, s: Int, du: Int) {
        when (k.kind) {
            1 -> { val e = ed.work.effects[k.idx]; e.startMs = s; e.durMs = du }
            2 -> { val l = ed.work.layers[k.idx]; l.startMs = s; l.durMs = du }
        }
    }

    private fun scrub(x: Float) {
        val ms = ((x - padL) / pxPerMs()).toInt().coerceIn(0, totalSec() * 1000)
        ed.seek(ms)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val total = totalSec() * 1000
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                mode = 0
                rowSel = -1
                if (e.y < rulerH) {
                    mode = 1
                    parent?.requestDisallowInterceptTouchEvent(true)
                    ed.pause()
                    scrub(e.x)
                    return true
                }
                val ri = ((e.y - rulerH) / rowH).toInt()
                if (ri in rows.indices) {
                    val k = rows[ri]
                    val s = rowStart(k)
                    val du = rowDur(k)
                    val x0 = xOf(s)
                    val x1 = xOf(s + du)
                    if (e.x >= x0 - 6 * d && e.x <= x1 + 6 * d) {
                        rowSel = ri
                        s0 = s
                        d0 = du
                        ed.select(k.kind, k.idx)
                        val edge = min(16 * d, (x1 - x0) / 3f)
                        mode = if (k.kind == 3) 0
                        else if (e.x <= x0 + edge) 3
                        else if (e.x >= x1 - edge) 4
                        else 2
                        parent?.requestDisallowInterceptTouchEvent(true)
                        return true
                    }
                }
                mode = 5
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 5) {
                    if (abs(e.x - downX) > 14 * d && abs(e.x - downX) > abs(e.y - downY) * 1.5f) {
                        mode = 1
                        parent?.requestDisallowInterceptTouchEvent(true)
                        ed.pause()
                    }
                }
                if (mode == 1) { scrub(e.x); return true }
                if (mode in 2..4 && rowSel in rows.indices) {
                    val k = rows[rowSel]
                    val dms = (((e.x - downX) / pxPerMs()) / 50f).toInt() * 50
                    when (mode) {
                        2 -> setTimes(k, (s0 + dms).coerceIn(0, 60000), d0)
                        3 -> {
                            val ns = (s0 + dms).coerceIn(0, s0 + d0 - 100)
                            setTimes(k, ns, d0 - (ns - s0))
                        }
                        4 -> setTimes(k, s0, (d0 + dms).coerceIn(100, 60000))
                    }
                    ed.timesChanged()
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode == 5 && abs(e.x - downX) < 8 * d && abs(e.y - downY) < 8 * d) ed.select(0, -1)
                mode = 0
                performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val a = ed.work
        val total = totalSec() * 1000
        p.style = Paint.Style.FILL
        p.color = 0xFF0B1118.toInt()
        c.drawRect(0f, 0f, w, h, p)
        p.color = 0xFF101A24.toInt()
        c.drawRect(0f, 0f, w, rulerH, p)

        // ruler
        p.textSize = 9 * d
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textAlign = Paint.Align.LEFT
        var sec = 0
        while (sec * 1000 <= total) {
            val x = xOf(sec * 1000)
            p.color = 0x4419E6F2
            c.drawRect(x - 0.5f * d, rulerH - 6 * d, x + 0.5f * d, rulerH, p)
            p.color = 0xFF8B96A3.toInt()
            c.drawText(sec.toString() + "s", x + 3 * d, rulerH - 8 * d, p)
            if (sec * 1000 + 500 <= total) {
                p.color = 0x2219E6F2
                val xm = xOf(sec * 1000 + 500)
                c.drawRect(xm - 0.5f * d, rulerH - 3 * d, xm + 0.5f * d, rulerH, p)
            }
            sec++
        }

        // rows
        for ((i, k) in rows.withIndex()) {
            val top = rulerH + i * rowH
            if (i % 2 == 0) {
                p.color = 0x0AFFFFFF
                c.drawRect(0f, top, w, top + rowH, p)
            }
            val s = rowStart(k)
            val du = rowDur(k)
            val x0 = xOf(s)
            val x1 = max(xOf(s + du), x0 + 8 * d)
            val sel = ed.selKind == k.kind && ed.selIdx == k.idx
            var col = 0xFF8F6BFF.toInt()
            var label = ""
            when (k.kind) {
                1 -> {
                    val ef = a.effects[k.idx]
                    col = if (ef.type == FxType.SHAKE) 0xFF8B96A3.toInt() else ef.color
                    label = if (ef.type == FxType.TEXT) "Text: " + ef.text else FxType.names[ef.type]
                }
                2 -> { col = 0xFF2B8CFF.toInt(); label = "Picture " + (k.idx + 1) }
                3 -> { col = 0xFF3DDC97.toInt(); label = "Sound" }
            }
            r.set(x0, top + 3 * d, x1, top + rowH - 3 * d)
            p.style = Paint.Style.FILL
            p.color = Cy.a(col, if (sel) 0.75f else 0.45f)
            c.drawRoundRect(r, 5 * d, 5 * d, p)
            if (k.kind != 3) {
                p.color = Cy.a(0xFFFFFFFF.toInt(), if (sel) 0.9f else 0.35f)
                c.drawRoundRect(x0 + 1.5f * d, top + 7 * d, x0 + 4 * d, top + rowH - 7 * d, 2 * d, 2 * d, p)
                c.drawRoundRect(x1 - 4 * d, top + 7 * d, x1 - 1.5f * d, top + rowH - 7 * d, 2 * d, 2 * d, p)
            }
            if (sel) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.6f * d
                p.color = 0xFFFFFFFF.toInt()
                c.drawRoundRect(r, 5 * d, 5 * d, p)
            }
            c.save()
            c.clipRect(x0 + 7 * d, top, x1 - 5 * d, top + rowH)
            p.style = Paint.Style.FILL
            p.color = 0xFFFFFFFF.toInt()
            p.textSize = 10 * d
            c.drawText(label, x0 + 8 * d, top + rowH / 2f + 3.5f * d, p)
            c.restore()
        }
        if (rows.isEmpty()) {
            p.color = 0xFF8B96A3.toInt()
            p.textSize = 11 * d
            c.drawText("Empty. Use the buttons below to add a picture, an effect, a text or a sound.", padL, rulerH + rowH * 0.7f, p)
        }

        // playhead
        val hx = xOf(ed.head.coerceIn(0, total))
        p.style = Paint.Style.FILL
        p.color = Cy.PINK
        c.drawRect(hx - 1 * d, 0f, hx + 1 * d, h, p)
        c.drawCircle(hx, 5 * d, 5 * d, p)
    }
}

/**
 * The animation editor. A full landscape screen: preview on the left, settings of the selected item on the
 * right, the timeline underneath and the add buttons at the bottom. Save writes it back and returns.
 */
class FxEditorActivity : Activity() {
    companion object {
        const val EX_ID = "id"
        const val EX_NEW = "new"
        const val REQ = 75

        fun open(a: Activity, id: String, isNew: Boolean) {
            a.startActivityForResult(Intent(a, FxEditorActivity::class.java).putExtra(EX_ID, id).putExtra(EX_NEW, isNew), REQ)
        }
    }

    lateinit var work: FxAnim
    private var animId = ""
    private var isNew = false
    private var dirty = false
    var selKind = -1
    var selIdx = -1
    var head = 0
        private set
    private var playing = false
    private var t0 = 0L

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var stage: FxStage
    private lateinit var tl: TimelineView
    private lateinit var inspector: LinearLayout
    private lateinit var nameView: TextView
    private lateinit var timeView: TextView
    private lateinit var playBtn: PButton
    private lateinit var ux: FxUi
    private val sync = ArrayList<() -> Unit>()
    private val dummy = ArrayList<View>()

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        animId = intent.getStringExtra(EX_ID) ?: FxStore.newId()
        isNew = intent.getBooleanExtra(EX_NEW, false)
        val orig = FxStore.get(this, animId)
        work = if (orig != null) FxAnim.from(JSONObject(orig.toJson().toString()))
        else {
            val all = FxStore.all(this)
            var n = 1
            while (all.any { it.name == "My animation $n" }) n++
            FxAnim(animId, "My animation $n", false)
        }
        ux = FxUi(this, dummy)
        build()
        select(0, -1)
        tl.rebuild()
        refreshTime()
    }

    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onPause() {
        pause()
        super.onPause()
    }

    // ---------- layout ----------

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false) = ux.tv(s, size, color, bold)

    private fun build() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF0A0D11.toInt())
        root.setPadding(0, 0, 0, 0)

        // top bar
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setBackgroundColor(0xFF0E141B.toInt())
        top.setPadding(dp(8f), dp(3f), dp(8f), dp(3f))
        val back = PButton(this, "Back", 1, 36f)
        back.onClick = { onBackPressed() }
        top.addView(back, LinearLayout.LayoutParams(dp(74f), -2))
        nameView = tv(work.name, 15f, 0xFFFFFFFF.toInt(), true)
        nameView.setPadding(dp(14f), 0, dp(8f), 0)
        nameView.setOnClickListener {
            ux.ask("Name", work.name) { s -> if (s.isNotEmpty()) { work.name = s; nameView.text = s; dirty = true } }
        }
        top.addView(nameView, LinearLayout.LayoutParams(0, -2, 1f))
        timeView = tv("", 12f, P.DIM)
        timeView.setPadding(0, 0, dp(10f), 0)
        top.addView(timeView)
        playBtn = PButton(this, "Play", 1, 36f)
        playBtn.onClick = { if (playing) pause() else play() }
        top.addView(playBtn, LinearLayout.LayoutParams(dp(78f), -2))
        val save = PButton(this, "Save", 0, 36f)
        save.onClick = { save() }
        val sl = LinearLayout.LayoutParams(dp(84f), -2)
        sl.leftMargin = dp(8f)
        top.addView(save, sl)
        root.addView(top, LinearLayout.LayoutParams(-1, dp(46f)))

        // middle: preview + settings
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.HORIZONTAL
        val holder = FrameLayout(this)
        stage = FxStage(this)
        stage.fit = true
        stage.editorMode = true
        stage.anim = work
        stage.onLayerSelect = { i -> select(2, i) }
        stage.onLayerMoved = { dirty = true; sync.forEach { it() }; tl.invalidate() }
        val stl = FrameLayout.LayoutParams(-1, -1)
        stl.gravity = Gravity.CENTER
        stl.setMargins(dp(8f), dp(6f), dp(8f), dp(6f))
        holder.addView(stage, stl)
        mid.addView(holder, LinearLayout.LayoutParams(0, -1, 1f))

        val side = ScrollView(this)
        side.overScrollMode = View.OVER_SCROLL_NEVER
        side.setBackgroundColor(0xFF0E141B.toInt())
        inspector = LinearLayout(this)
        inspector.orientation = LinearLayout.VERTICAL
        inspector.setPadding(dp(14f), dp(8f), dp(14f), dp(14f))
        side.addView(inspector, FrameLayout.LayoutParams(-1, -2))
        mid.addView(side, LinearLayout.LayoutParams(dp(320f), -1))
        root.addView(mid, LinearLayout.LayoutParams(-1, 0, 1f))

        // timeline
        tl = TimelineView(this, this)
        val tsv = ScrollView(this)
        tsv.overScrollMode = View.OVER_SCROLL_NEVER
        tsv.addView(tl, FrameLayout.LayoutParams(-1, -2))
        root.addView(tsv, LinearLayout.LayoutParams(-1, dp(128f)))

        // bottom tools
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(0xFF0E141B.toInt())
        bar.setPadding(dp(8f), dp(3f), dp(8f), dp(3f))
        fun tool(label: String, kind: Int, f: () -> Unit): PButton {
            val bb = PButton(this, label, kind, 36f)
            bb.onClick = f
            return bb
        }
        val tools = ux.buttons(
            tool("+ Picture", 0) { pickImage() },
            tool("+ Effect", 0) { addEffectDialog() },
            tool("+ Text", 0) { addText() },
            tool("+ Sound", 0) { pickAudio() },
            tool("Copy", 1) { copySel() },
            tool("Delete", 2) { deleteSel() }
        )
        bar.addView(tools, LinearLayout.LayoutParams(-1, -2))
        root.addView(bar, LinearLayout.LayoutParams(-1, dp(46f)))
        setContentView(root)
    }

    // ---------- playback ----------

    private val frame = object : Runnable {
        override fun run() {
            if (!playing) return
            head = (SystemClock.uptimeMillis() - t0).toInt()
            if (head > work.totalMs() + 300) {
                pause()
                head = 0
            }
            stage.headMs = head
            stage.invalidate()
            tl.invalidate()
            refreshTime()
            if (playing) ui.postDelayed(this, 16)
        }
    }

    fun play() {
        if (playing) return
        if (head >= work.totalMs()) head = 0
        playing = true
        t0 = SystemClock.uptimeMillis() - head
        playBtn.set("Pause", 0)
        if (head < 150 && work.audio.isNotEmpty()) FxAudio.play(work.audio, work.volume)
        ui.post(frame)
    }

    fun pause() {
        if (!playing) return
        playing = false
        FxAudio.stop()
        ui.removeCallbacks(frame)
        if (::playBtn.isInitialized) playBtn.set("Play", 1)
    }

    fun seek(ms: Int) {
        head = ms
        stage.headMs = ms
        stage.invalidate()
        tl.invalidate()
        refreshTime()
    }

    private fun refreshTime() {
        timeView.text = String.format(Locale.US, "%.1f / %.1f s", head / 1000f, work.totalMs() / 1000f)
    }

    // ---------- selection and changes ----------

    fun select(kind: Int, idx: Int) {
        if (kind == selKind && idx == selIdx) { tl.invalidate(); return }
        selKind = kind
        selIdx = idx
        stage.selLayer = if (kind == 2) idx else -1
        stage.invalidate()
        tl.invalidate()
        renderInspector()
    }

    /** Called while a bar is dragged on the timeline. */
    fun timesChanged() {
        dirty = true
        sync.forEach { it() }
        stage.invalidate()
        tl.requestLayout()
        tl.invalidate()
        refreshTime()
    }

    /** Called after a slider or choice changed something. */
    private fun changed(rebuildTl: Boolean = false) {
        dirty = true
        stage.invalidate()
        if (rebuildTl) tl.rebuild() else tl.invalidate()
        refreshTime()
    }

    private fun secs(ms: Int) = String.format(Locale.US, "%.2f s", ms / 1000f)

    // ---------- inspector ----------

    private fun slider(title: (Int) -> String, lo: Int, hi: Int, get: () -> Int, put: (Int) -> Unit) {
        val lab = ux.label(title(get()))
        inspector.addView(lab)
        val s = PSlider(this, lo, hi)
        s.setValue(get())
        s.onValue = { x -> put(x); lab.text = title(x); changed() }
        sync.add { s.setValue(get()); lab.text = title(get()) }
        inspector.addView(s, LinearLayout.LayoutParams(-1, -2))
    }

    private fun choice(title: String, names: Array<String>, get: () -> Int, put: (Int) -> Unit) {
        inspector.addView(ux.label(title))
        val bs = ArrayList<PButton>()
        val paint = { for ((i, bb) in bs.withIndex()) bb.set(names[i], if (get() == i) 0 else 1) }
        for ((i, n) in names.withIndex()) {
            val bb = PButton(this, n, 1, 36f)
            bb.onClick = { put(i); paint(); changed() }
            bs.add(bb)
        }
        paint()
        inspector.addView(ux.buttons(*bs.toTypedArray()))
    }

    private fun header(s: String) {
        inspector.addView(tv(s, 15f, 0xFFFFFFFF.toInt(), true))
    }

    private fun renderInspector() {
        inspector.removeAllViews()
        sync.clear()
        val a = work
        when (selKind) {
            2 -> {
                val l = a.layers.getOrNull(selIdx) ?: return
                header("Picture " + (selIdx + 1))
                slider({ "Size  $it %" }, 10, 400, { (l.scale * 100).toInt() }) { l.scale = it / 100f }
                slider({ "Rotate  $it deg" }, -180, 180, { l.rot.toInt() }) { l.rot = it.toFloat() }
                slider({ "Opacity  $it %" }, 5, 100, { (l.alpha * 100).toInt() }) { l.alpha = it / 100f }
                slider({ "Starts at  " + secs(it * 50) }, 0, 200, { l.startMs / 50 }) { l.startMs = it * 50; tl.invalidate() }
                slider({ "Lasts  " + secs(it * 50) }, 2, 200, { (l.durMs / 50).coerceIn(2, 200) }) { l.durMs = it * 50; changed(true) }
                choice("Enter", arrayOf("None", "Fade", "Pop", "Slide"), { l.intro }) { l.intro = it }
                choice("Exit", arrayOf("None", "Fade", "Shrink"), { l.outro }) { l.outro = it }
                val bc = PButton(this, "Centre on stage", 1, 36f)
                bc.onClick = { l.x = 0.5f; l.y = 0.5f; changed() }
                inspector.addView(bc, ux.top(bc, 10f))
                inspector.addView(tv("Tip: drag the picture on the preview to move it, pinch to resize and turn it.", 11f, P.DIM).also { it.setPadding(0, dp(8f), 0, 0) })
            }
            1 -> {
                val e = a.effects.getOrNull(selIdx) ?: return
                header("Effect")
                val tr = LinearLayout(this)
                tr.orientation = LinearLayout.HORIZONTAL
                tr.gravity = Gravity.CENTER_VERTICAL
                val prev = PButton(this, "<", 1, 36f)
                val next = PButton(this, ">", 1, 36f)
                val tn = tv(FxType.names[e.type], 15f, 0xFFFFFFFF.toInt(), true)
                tn.gravity = Gravity.CENTER
                val cycle = { dir: Int ->
                    val n = FxType.names.size
                    e.type = ((e.type + dir) % n + n) % n
                    if (e.type == FxType.TEXT && e.text.isEmpty()) e.text = "WIN"
                    changed(true)
                    renderInspector()
                }
                prev.onClick = { cycle(-1) }
                next.onClick = { cycle(1) }
                tr.addView(prev, LinearLayout.LayoutParams(dp(48f), -2))
                tr.addView(tn, LinearLayout.LayoutParams(0, -2, 1f))
                tr.addView(next, LinearLayout.LayoutParams(dp(48f), -2))
                inspector.addView(tr, ux.top(tr, 6f))
                val hint = tv(FxType.hints[e.type], 11f, P.DIM)
                hint.gravity = Gravity.CENTER
                inspector.addView(hint, LinearLayout.LayoutParams(-1, -2))
                if (e.type != FxType.SHAKE) {
                    inspector.addView(ux.label("Colour"))
                    val sw = SwatchRow(this)
                    sw.selected = FxStore.swatches.indexOfFirst { it == e.color }
                    sw.onPick = { cc -> e.color = cc; changed(true) }
                    inspector.addView(sw, LinearLayout.LayoutParams(-1, -2))
                }
                if (e.type == FxType.TEXT) {
                    val tl2 = tv("Word:  " + e.text, 14f, P.TEXT)
                    val tb = PButton(this, "Change", 1, 36f)
                    tb.onClick = { ux.ask("Word to show", e.text) { s -> if (s.isNotEmpty()) { e.text = s.take(16); tl2.text = "Word:  " + e.text; changed(true) } } }
                    val wr = LinearLayout(this)
                    wr.orientation = LinearLayout.HORIZONTAL
                    wr.gravity = Gravity.CENTER_VERTICAL
                    wr.setPadding(0, dp(8f), 0, 0)
                    wr.addView(tl2, LinearLayout.LayoutParams(0, -2, 1f))
                    wr.addView(tb, LinearLayout.LayoutParams(dp(100f), -2))
                    inspector.addView(wr)
                }
                val pn = when (e.type) {
                    FxType.SHAKE -> "Shake strength"
                    FxType.TEXT -> "Size"
                    FxType.FLASH -> "Brightness"
                    else -> "Power"
                }
                slider({ "$pn  $it" }, 0, 100, { e.power }) { e.power = it }
                slider({ "Speed  $it" }, 0, 100, { e.speed }) { e.speed = it }
                slider({ "Starts at  " + secs(it * 50) }, 0, 200, { e.startMs / 50 }) { e.startMs = it * 50; tl.invalidate() }
                slider({ "Lasts  " + secs(it * 50) }, 2, 200, { (e.durMs / 50).coerceIn(2, 200) }) { e.durMs = it * 50; changed(true) }
            }
            3 -> {
                header("Sound")
                slider({ "Volume  $it %" }, 0, 100, { work.volume }) { work.volume = it }
                val bt = PButton(this, "Test", 1, 36f)
                bt.onClick = { FxAudio.play(work.audio, work.volume) }
                val bs = PButton(this, "Stop", 1, 36f)
                bs.onClick = { FxAudio.stop() }
                val br = PButton(this, "Replace", 1, 36f)
                br.onClick = { pickAudio() }
                inspector.addView(ux.buttons(bt, bs, br), ux.top(bt, 10f))
                inspector.addView(tv("The sound starts when the animation starts.", 11f, P.DIM).also { it.setPadding(0, dp(8f), 0, 0) })
            }
            else -> {
                header("Nothing selected")
                inspector.addView(tv("Tap a bar on the timeline, or tap a picture on the preview, to change it.\n\nAdd things with the buttons at the bottom. Drag a bar to move it in time, and drag its ends to make it shorter or longer. Drag along the numbers to move the playhead.", 12.5f, P.MID).also { it.setPadding(0, dp(6f), 0, 0) })
            }
        }
    }

    // ---------- adding things ----------

    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
        try { startActivityForResult(i, 73) } catch (t: Throwable) { ux.toast("No picker found") }
    }

    private fun pickAudio() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*")
        try { startActivityForResult(i, 74) } catch (t: Throwable) { ux.toast("No picker found") }
    }

    private fun copyIn(uri: android.net.Uri, prefix: String): File? {
        return try {
            val dir = File(filesDir, "fx")
            dir.mkdirs()
            val f = File(dir, prefix + System.currentTimeMillis().toString(36))
            contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } } ?: return null
            if (f.length() == 0L) null else f
        } catch (t: Throwable) { null }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(code: Int, res: Int, data: Intent?) {
        super.onActivityResult(code, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        if (code == 73) {
            val f = copyIn(uri, "img_")
            if (f == null) { ux.toast("Could not read that picture"); return }
            val l = FxLayer(f.absolutePath, 0.5f, 0.5f, 1f)
            l.startMs = head
            l.durMs = 2000
            work.layers.add(l)
            dirty = true
            tl.rebuild()
            select(2, work.layers.size - 1)
            stage.invalidate()
        } else if (code == 74) {
            val f = copyIn(uri, "a_")
            if (f == null) { ux.toast("Could not read that audio"); return }
            work.audio = f.absolutePath
            dirty = true
            tl.rebuild()
            selKind = -1
            select(3, 0)
        }
    }

    private fun addEffectDialog() {
        AlertDialog.Builder(this).setTitle("Add effect")
            .setItems(FxType.names.toTypedArray()) { _, which ->
                val e = FxEffect(which, FxStore.CYAN, 70, 50, head, 1500)
                if (which == FxType.TEXT) e.text = "WIN"
                work.effects.add(e)
                dirty = true
                tl.rebuild()
                select(1, work.effects.size - 1)
                stage.invalidate()
            }.show()
    }

    private fun addText() {
        ux.ask("Word to show", "WIN") { s ->
            if (s.isNotEmpty()) {
                val e = FxEffect(FxType.TEXT, FxStore.GOLD, 80, 50, head, 1800, s.take(16))
                work.effects.add(e)
                dirty = true
                tl.rebuild()
                select(1, work.effects.size - 1)
                stage.invalidate()
            }
        }
    }

    private fun copySel() {
        if (selKind == 1) {
            val e = work.effects.getOrNull(selIdx) ?: return
            val c = e.copy(); c.startMs += 200
            work.effects.add(c)
            dirty = true
            tl.rebuild()
            select(1, work.effects.size - 1)
        } else if (selKind == 2) {
            val l = work.layers.getOrNull(selIdx) ?: return
            val c = l.copy(); c.startMs += 200; c.x = (c.x + 0.05f).coerceAtMost(1f); c.y = (c.y + 0.05f).coerceAtMost(1f)
            work.layers.add(c)
            dirty = true
            tl.rebuild()
            select(2, work.layers.size - 1)
        } else {
            ux.toast("Select a picture or an effect first")
        }
        stage.invalidate()
    }

    private fun deleteSel() {
        when (selKind) {
            1 -> if (selIdx in work.effects.indices) work.effects.removeAt(selIdx) else return
            2 -> if (selIdx in work.layers.indices) work.layers.removeAt(selIdx) else return
            3 -> work.audio = ""
            else -> { ux.toast("Select something first"); return }
        }
        dirty = true
        selKind = -1
        tl.rebuild()
        select(0, -1)
        stage.invalidate()
        refreshTime()
    }

    // ---------- save / leave ----------

    private fun save() {
        pause()
        val orig = FxStore.get(this, animId)
        if (orig == null) {
            FxStore.add(this, work)
        } else {
            orig.name = work.name
            orig.effects.clear()
            orig.effects.addAll(work.effects)
            orig.layers.clear()
            orig.layers.addAll(work.layers)
            orig.audio = work.audio
            orig.volume = work.volume
            FxStore.save(this)
        }
        setResult(RESULT_OK, Intent().putExtra(EX_ID, animId))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        pause()
        if (!dirty) { finish(); return }
        AlertDialog.Builder(this).setTitle("Leave without saving?")
            .setMessage("Your changes to this animation will be lost.")
            .setPositiveButton("Save") { _, _ -> save() }
            .setNegativeButton("Discard") { _, _ -> finish() }
            .setNeutralButton("Keep editing", null).show()
    }
}

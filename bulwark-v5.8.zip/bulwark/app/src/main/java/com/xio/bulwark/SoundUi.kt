package com.xio.bulwark

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Plays a piece of recorded sound through the speaker, with a moving position. */
object PcmPlayer {
    private var track: AudioTrack? = null
    private var poll: Runnable? = null
    private val ui = Handler(Looper.getMainLooper())

    fun play(pcm: ShortArray, s: Int, e: Int, onPos: ((Float) -> Unit)?, onEnd: (() -> Unit)?) {
        stop()
        val n = e - s
        if (n <= 0) return
        try {
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(Wav.RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(n * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(pcm, s, n)
            t.play()
            track = t
            val r = object : Runnable {
                override fun run() {
                    val pos = t.playbackHeadPosition
                    onPos?.invoke(pos.toFloat() / n)
                    if (pos >= n - 64 || t.playState != AudioTrack.PLAYSTATE_PLAYING) {
                        stop()
                        onEnd?.invoke()
                    } else {
                        ui.postDelayed(this, 40)
                    }
                }
            }
            poll = r
            ui.post(r)
        } catch (t: Throwable) {
            track = null
        }
    }

    fun stop() {
        poll?.let { ui.removeCallbacks(it) }
        poll = null
        try { track?.stop() } catch (t: Throwable) { }
        try { track?.release() } catch (t: Throwable) { }
        track = null
    }
}

/** Waveform of a recording with two handles to mark the part you want to keep. */
class ClipView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private var peaks = FloatArray(0)
    var startF = 0f
    var endF = 1f
    var playF = -1f
    var onChange: (() -> Unit)? = null
    private var drag = 0

    fun setData(pcm: ShortArray) {
        val cols = 360
        peaks = FloatArray(cols)
        val per = max(1, pcm.size / cols)
        for (c in 0 until cols) {
            var m = 0
            val from = c * per
            val to = min(pcm.size, from + per)
            for (i in from until to) {
                val a = abs(pcm[i].toInt())
                if (a > m) m = a
            }
            peaks[c] = sqrt(m / 32768f)
        }
        startF = 0f
        endF = 1f
        playF = -1f
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 130f))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        val f = (e.x / max(1, width)).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> drag = if (abs(f - startF) <= abs(f - endF)) 1 else 2
        }
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            if (drag == 1) startF = f.coerceAtMost(endF - 0.01f)
            else if (drag == 2) endF = f.coerceAtLeast(startF + 0.01f)
            invalidate()
            onChange?.invoke()
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = 0xFF080E14.toInt()
        r.set(0f, 0f, w, h)
        c.drawRoundRect(r, 10 * d, 10 * d, p)
        val n = peaks.size
        if (n == 0) return
        val cw = w / n
        val mid = h / 2f
        for (i in 0 until n) {
            val f = i.toFloat() / n
            val on = f >= startF && f <= endF
            p.color = if (on) Cy.a(Cy.CYAN, 0.9f) else Cy.a(0xFF8B96A3.toInt(), 0.35f)
            val bh = max(1.5f * d, peaks[i] * (h - 24 * d))
            c.drawRect(i * cw, mid - bh / 2f, i * cw + max(1f, cw - 1f), mid + bh / 2f, p)
        }
        if (playF >= 0f) {
            p.color = 0xFFFFFFFF.toInt()
            val x = (startF + (endF - startF) * playF) * w
            c.drawRect(x - 1f * d, 0f, x + 1f * d, h, p)
        }
        for (hf in floatArrayOf(startF, endF)) {
            val x = hf * w
            p.color = Cy.PINK
            c.drawRect(x - 1.5f * d, 0f, x + 1.5f * d, h, p)
            r.set(x - 6 * d, mid - 14 * d, x + 6 * d, mid + 14 * d)
            c.drawRoundRect(r, 3 * d, 3 * d, p)
        }
    }
}

/** Thin bar showing how closely the live sound matches one saved sound. The line marks the needed level. */
class ScoreBar(ctx: Context, private val t: Trigger) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 14f))
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = 0x22FFFFFF
        c.drawRoundRect(0f, 4 * d, w, h - 4 * d, 3 * d, 3 * d, p)
        val s = if (CaptureBus.running) (MatchBus.scores[t.id] ?: 0f).coerceIn(0f, 1f) else 0f
        val thr = t.threshold()
        p.color = if (s >= thr) Cy.PINK else Cy.CYAN
        c.drawRoundRect(0f, 4 * d, w * s, h - 4 * d, 3 * d, 3 * d, p)
        p.color = 0xFFFFFFFF.toInt()
        c.drawRect(w * thr - 1f * d, 0f, w * thr + 1f * d, h, p)
        postInvalidateDelayed(80)
    }
}

/** Live level bar for the listening check. */
class LevelMeter(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 48f))
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val w = width.toFloat()
        val h = height.toFloat()
        val n = 28
        val cw = w / n
        val lv = if (CaptureBus.running) CaptureBus.level else 0f
        val pk = if (CaptureBus.running) CaptureBus.peak else 0f
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            val f = i.toFloat() / n
            val on = f < lv
            val base = if (f < 0.6f) Cy.CYAN else if (f < 0.85f) CyUi.YELLOW else 0xFFFF5A4D.toInt()
            p.color = Cy.a(base, if (on) 0.95f else 0.12f)
            c.drawRect(i * cw + 1.5f * d, 10 * d, (i + 1) * cw - 1.5f * d, h - 10 * d, p)
        }
        if (pk > 0f) {
            p.color = 0xFFFFFFFF.toInt()
            val px = (pk * n).toInt().coerceIn(0, n - 1) * cw
            c.drawRect(px + 1.5f * d, 5 * d, px + cw - 1.5f * d, 9 * d, p)
        }
        postInvalidateDelayed(60)
    }
}

/**
 * The "Sounds" half of the Triggers tab: listening, saved recordings, the trimmer and the sound triggers.
 */
class SoundSection(private val ux: FxUi, into: LinearLayout) {
    private val act = ux.act
    private val ui = Handler(Looper.getMainLooper())
    private val timeFmt = SimpleDateFormat("d MMM HH:mm:ss", Locale.US)

    private val recBox: LinearLayout
    private val trimBox: LinearLayout
    private val trigBox: LinearLayout
    private val capStatus: TextView
    private val lastMatch: TextView
    private var pendingMode = 0

    // trimmer state
    private var trimFile: File? = null
    private var trimOrig: ShortArray? = null
    private var trimPcm: ShortArray? = null
    private var trimTitle = ""
    private var trimAnim = ""
    private var openTrig = ""
    private val saveRun = Runnable { TriggerStore.save(act) }

    init {
        // --- listening ---
        val lc = ux.card("Listening", into)
        lc.addView(ux.tv("Start listening, play your game, and Frameline keeps the last " + CaptureService.KEEP_SECONDS + " seconds of sound. Allow the prompt (pick \"Entire screen\" if asked).", 13f, P.MID))
        val bGame = PButton(act, "Game audio", 0, 44f)
        bGame.onClick = { startCapture(1) }
        val bMic = PButton(act, "Microphone", 1, 44f)
        bMic.onClick = { startCapture(2) }
        val bOff = PButton(act, "Stop", 2, 44f)
        bOff.onClick = { CaptureService.stop(act); ux.toast("Stopped") }
        lc.addView(ux.buttons(bGame, bMic, bOff), ux.top(View(act), 12f))
        lc.addView(LevelMeter(act), ux.top(View(act), 10f))
        capStatus = ux.tv("", 12.5f, P.DIM)
        capStatus.setPadding(0, ux.dp(6f), 0, 0)
        lc.addView(capStatus)
        lc.addView(ux.tv("If the bar moves while the game plays, Frameline can hear it. If it stays flat, that app may block capture. The microphone is the fallback (phone speaker, no headphones).", 11.5f, P.DIM).also { it.setPadding(0, ux.dp(8f), 0, 0) })

        // --- recordings ---
        val rc = ux.card("Recordings", into)
        rc.addView(ux.tv("When you hear the sound in the game, pull down the notification and tap Save clip. Or come back here and tap the button.", 13f, P.MID))
        val bSave = PButton(act, "Save last " + CaptureService.KEEP_SECONDS + " seconds", 0, 46f)
        bSave.onClick = {
            if (!CaptureBus.running) ux.toast("Start listening first")
            else { CaptureService.save(act); ui.postDelayed({ renderRecordings() }, 700) }
        }
        rc.addView(bSave, ux.top(View(act), 12f))
        recBox = LinearLayout(act)
        recBox.orientation = LinearLayout.VERTICAL
        rc.addView(recBox)
        trimBox = LinearLayout(act)
        trimBox.orientation = LinearLayout.VERTICAL
        rc.addView(trimBox)

        // --- triggers ---
        val tc = ux.card("Sound triggers", into)
        tc.addView(ux.tv("Each trigger listens for one saved sound and plays an animation when it hears it. The line on each bar is the score it needs.", 13f, P.MID))
        trigBox = LinearLayout(act)
        trigBox.orientation = LinearLayout.VERTICAL
        tc.addView(trigBox)
        lastMatch = ux.tv("", 12.5f, P.DIM)
        lastMatch.setPadding(0, ux.dp(10f), 0, 0)
        tc.addView(lastMatch)
    }

    fun refresh() {
        renderRecordings()
        renderTriggers()
        tick()
    }

    // ---------- listening ----------

    private fun startCapture(mode: Int) {
        if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingMode = mode
            act.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 72)
            return
        }
        if (mode == 1) {
            if (Build.VERSION.SDK_INT < 29) {
                ux.toast("Game audio needs Android 10 or newer. Try the microphone.")
                return
            }
            val mpm = act.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            act.startActivityForResult(mpm.createScreenCaptureIntent(), 71)
        } else {
            act.startForegroundService(
                Intent(act, CaptureService::class.java).setAction(CaptureService.ACT_START).putExtra(CaptureService.EX_MODE, 2)
            )
            ux.toast("Listening with the microphone")
        }
    }

    fun onResult(code: Int, res: Int, data: Intent?): Boolean {
        if (code != 71) return false
        if (res == Activity.RESULT_OK && data != null) {
            act.startForegroundService(
                Intent(act, CaptureService::class.java).setAction(CaptureService.ACT_START)
                    .putExtra(CaptureService.EX_MODE, 1)
                    .putExtra(CaptureService.EX_CODE, res)
                    .putExtra(CaptureService.EX_DATA, data)
            )
            ux.toast("Listening to game audio")
        } else {
            ux.toast("No permission was given")
        }
        return true
    }

    fun onPermission(granted: Boolean) {
        val m = pendingMode
        pendingMode = 0
        if (granted && m != 0) startCapture(m)
        else if (!granted) ux.toast("Allow the microphone permission so Frameline can listen")
    }

    /** Called a few times a second while the tab is open. */
    fun tick() {
        val now = SystemClock.uptimeMillis()
        capStatus.text = when {
            !CaptureBus.running && CaptureBus.error.isNotEmpty() -> "Could not start: " + CaptureBus.error
            !CaptureBus.running -> "Not listening. Tap a source above."
            else -> {
                val src = if (CaptureBus.mode == 1) "game audio" else "the microphone"
                val since = (now - CaptureBus.startedMs) / 1000
                if (CaptureBus.lastLoudMs == 0L)
                    "Listening to $src for $since s. Nothing heard yet." + (if (since > 15) " If something was playing, this source may be blocked." else "")
                else
                    "Listening to $src. Heard sound " + (now - CaptureBus.lastLoudMs) / 1000 + " s ago."
            }
        }
        val id = MatchBus.lastId
        if (id.isEmpty()) {
            lastMatch.text = "No match yet."
        } else {
            val t = TriggerStore.get(act, id)
            lastMatch.text = "Last match: " + (t?.title ?: "?") + "  " + (MatchBus.lastScore * 100).toInt() + "%  -  " +
                (System.currentTimeMillis() - MatchBus.lastMs) / 1000 + " s ago  (" + MatchBus.count + " in total)"
        }
    }

    // ---------- recordings and trimmer ----------

    private fun renderRecordings() {
        recBox.removeAllViews()
        val list = Recordings.list(act)
        if (list.isEmpty()) {
            val t = ux.tv("No recordings yet.", 12.5f, P.DIM)
            t.setPadding(0, ux.dp(10f), 0, 0)
            recBox.addView(t)
            return
        }
        recBox.addView(ux.label("Saved clips"))
        for (f in list) {
            val r = LinearLayout(act)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.background = CutDrawable(0x0FFFFFFF, 0x33FFFFFF, ux.dp(1f).toFloat(), ux.dp(10f).toFloat())
            r.setPadding(ux.dp(14f), ux.dp(8f), ux.dp(8f), ux.dp(8f))
            r.layoutParams = ux.top(r, 6f)
            val c = LinearLayout(act)
            c.orientation = LinearLayout.VERTICAL
            c.addView(ux.tv(timeFmt.format(Date(f.lastModified())), 14f, P.TEXT))
            c.addView(ux.tv(String.format(Locale.US, "%.0f s", Recordings.seconds(f)), 11.5f, P.DIM))
            r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
            val bt = PButton(act, "Trim", 0, 38f)
            bt.onClick = { openTrimmer(f) }
            val bd = PButton(act, "Delete", 2, 38f)
            bd.onClick = {
                if (trimFile == f) closeTrimmer()
                f.delete()
                renderRecordings()
            }
            val l1 = LinearLayout.LayoutParams(ux.dp(74f), -2)
            l1.rightMargin = ux.dp(6f)
            r.addView(bt, l1)
            r.addView(bd, LinearLayout.LayoutParams(ux.dp(84f), -2))
            recBox.addView(r)
        }
    }

    private fun closeTrimmer() {
        PcmPlayer.stop()
        trimFile = null
        trimOrig = null
        trimPcm = null
        trimBox.removeAllViews()
    }

    private fun openTrimmer(f: File) {
        closeTrimmer()
        val pcm = Wav.read(f)
        if (pcm == null || pcm.size < Wav.RATE / 2) { ux.toast("This clip could not be opened"); return }
        trimFile = f
        trimOrig = pcm
        trimPcm = pcm
        val all = TriggerStore.all(act)
        var n = all.size + 1
        while (all.any { it.title == "Sound $n" }) n++
        trimTitle = "Sound $n"
        trimAnim = FxStore.all(act).firstOrNull()?.id ?: ""

        trimBox.addView(ux.label("Move the two pink handles around the sound you want (just the announcer's word works best)."), ux.top(View(act), 8f))
        val cv = ClipView(act)
        cv.setData(pcm)
        trimBox.addView(cv, LinearLayout.LayoutParams(-1, -2))
        val info = ux.tv("", 12f, P.DIM)
        trimBox.addView(info)
        val upd = {
            val p = trimPcm
            if (p != null) info.text = String.format(Locale.US, "Selected %.2f s of %.1f s", (cv.endF - cv.startF) * p.size / Wav.RATE, p.size.toFloat() / Wav.RATE)
        }
        upd()
        cv.onChange = { upd() }

        val bPlay = PButton(act, "Play", 0, 40f)
        bPlay.onClick = {
            val p = trimPcm
            if (p != null) {
                val s = (cv.startF * p.size).toInt()
                val e = (cv.endF * p.size).toInt()
                PcmPlayer.play(p, s, e, { pos -> cv.playF = pos; cv.invalidate() }, { cv.playF = -1f; cv.invalidate() })
            }
        }
        val bStop = PButton(act, "Stop", 1, 40f)
        bStop.onClick = { PcmPlayer.stop(); cv.playF = -1f; cv.invalidate() }
        val bCrop = PButton(act, "Zoom in", 1, 40f)
        bCrop.onClick = {
            val p = trimPcm
            if (p != null) {
                val s = (cv.startF * p.size).toInt()
                val e = (cv.endF * p.size).toInt()
                if (e - s > Wav.RATE / 4) {
                    PcmPlayer.stop()
                    val q = p.copyOfRange(s, e)
                    trimPcm = q
                    cv.setData(q)
                    upd()
                }
            }
        }
        val bReset = PButton(act, "Reset", 1, 40f)
        bReset.onClick = {
            val o = trimOrig
            if (o != null) { PcmPlayer.stop(); trimPcm = o; cv.setData(o); upd() }
        }
        trimBox.addView(ux.buttons(bPlay, bStop, bCrop, bReset), ux.top(View(act), 8f))

        // title
        val tl = ux.tv("Title:  $trimTitle", 14f, P.TEXT)
        val tb = PButton(act, "Change", 1, 38f)
        tb.onClick = { ux.ask("Title", trimTitle) { s -> if (s.isNotEmpty()) { trimTitle = s; tl.text = "Title:  $s" } } }
        val tr = LinearLayout(act)
        tr.orientation = LinearLayout.HORIZONTAL
        tr.gravity = Gravity.CENTER_VERTICAL
        tr.addView(tl, LinearLayout.LayoutParams(0, -2, 1f))
        tr.addView(tb, LinearLayout.LayoutParams(ux.dp(110f), -2))
        trimBox.addView(tr, ux.top(View(act), 12f))

        // animation to play
        trimBox.addView(animPicker({ trimAnim }, { trimAnim = it }), ux.top(View(act), 6f))

        val bOk = PButton(act, "Save as trigger", 0, 46f)
        bOk.onClick = {
            val p = trimPcm
            if (p != null) {
                val s = (cv.startF * p.size).toInt()
                val e = (cv.endF * p.size).toInt()
                if (e - s < Wav.RATE * 3 / 10) {
                    ux.toast("Select at least 0.3 seconds")
                } else {
                    PcmPlayer.stop()
                    val id = FxStore.newId()
                    val file = File(act.filesDir, "fx/clip_$id.wav")
                    Wav.write(file, p.copyOfRange(s, e), e - s)
                    val t = Trigger("t$id", trimTitle, file.absolutePath, trimAnim)
                    TriggerStore.add(act, t)
                    closeTrimmer()
                    openTrig = t.id
                    renderTriggers()
                    ux.toast("Saved. Keep listening on, and it will watch for this sound.")
                }
            }
        }
        val bClose = PButton(act, "Close", 1, 46f)
        bClose.onClick = { closeTrimmer() }
        trimBox.addView(ux.buttons(bOk, bClose), ux.top(View(act), 14f))
    }

    /** < animation name > picker. */
    private fun animPicker(get: () -> String, put: (String) -> Unit): LinearLayout {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val prev = PButton(act, "<", 1, 40f)
        val next = PButton(act, ">", 1, 40f)
        val nm = ux.tv("", 14f, 0xFFFFFFFF.toInt(), true)
        nm.gravity = Gravity.CENTER
        val show = {
            val a = FxStore.get(act, get())
            nm.text = "Plays:  " + (a?.name ?: "(none)")
        }
        val go = { dir: Int ->
            val all = FxStore.all(act)
            if (all.isNotEmpty()) {
                val i = all.indexOfFirst { it.id == get() }
                val j = ((if (i < 0) 0 else i) + dir + all.size) % all.size
                put(all[j].id)
                show()
            }
        }
        prev.onClick = { go(-1) }
        next.onClick = { go(1) }
        show()
        r.addView(prev, LinearLayout.LayoutParams(ux.dp(52f), -2))
        r.addView(nm, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(next, LinearLayout.LayoutParams(ux.dp(52f), -2))
        return r
    }

    // ---------- triggers ----------

    private fun renderTriggers() {
        trigBox.removeAllViews()
        val list = TriggerStore.all(act)
        if (list.isEmpty()) {
            val t = ux.tv("No triggers yet. Save a clip above, trim it and tap Save as trigger.", 12.5f, P.DIM)
            t.setPadding(0, ux.dp(10f), 0, ux.dp(4f))
            trigBox.addView(t)
            return
        }
        for (t in list) trigBox.addView(triggerRow(t))
    }

    private fun triggerRow(t: Trigger): View {
        val open = t.id == openTrig
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.background = CutDrawable(
            if (open) 0x3319E6F2 else 0x0FFFFFFF,
            if (open) 0xCC19E6F2.toInt() else 0x33FFFFFF,
            ux.dp(1f).toFloat(), ux.dp(10f).toFloat()
        )
        box.setPadding(ux.dp(14f), ux.dp(10f), ux.dp(14f), ux.dp(10f))
        box.layoutParams = ux.top(box, 8f)

        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.addView(ux.tv(t.title, 15f, if (open) 0xFFFFFFFF.toInt() else P.TEXT, open))
        val an = FxStore.get(act, t.animId)
        c.addView(ux.tv("Plays " + (an?.name ?: "(no animation)") + "  -  needs " + (t.threshold() * 100).toInt() + "%", 11.5f, P.DIM))
        head.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = PSwitch(act)
        sw.setChecked(t.enabled)
        sw.onChange = { v -> t.enabled = v; TriggerStore.save(act, true) }
        head.addView(sw, LinearLayout.LayoutParams(-2, -2))
        head.setOnClickListener { openTrig = if (open) "" else t.id; renderTriggers() }
        box.addView(head)
        box.addView(ScoreBar(act, t), ux.top(View(act), 8f))

        if (open) {
            val line = View(act)
            line.setBackgroundColor(0x2219E6F2)
            box.addView(line, ux.top(line, 12f, -1, 1))

            val rn = PButton(act, "Rename", 1, 38f)
            rn.onClick = { ux.ask("Title", t.title) { s -> if (s.isNotEmpty()) { t.title = s; TriggerStore.save(act); renderTriggers() } } }
            box.addView(rn, ux.top(rn, 10f, ux.dp(120f)))

            box.addView(animPicker({ t.animId }, { t.animId = it; TriggerStore.save(act) }), ux.top(View(act), 8f))

            val sensLab = ux.label("Sensitivity  " + t.sens)
            box.addView(sensLab)
            val s1 = PSlider(act, 0, 100)
            s1.setValue(t.sens)
            s1.onValue = { v ->
                t.sens = v
                sensLab.text = "Sensitivity  $v   (needs " + (t.threshold() * 100).toInt() + "%)"
                ui.removeCallbacks(saveRun)
                ui.postDelayed(saveRun, 500)
            }
            box.addView(s1, LinearLayout.LayoutParams(-1, -2))
            box.addView(ux.tv("Higher sensitivity triggers more easily, but may fire on other sounds. Lower is stricter.", 11f, P.DIM))

            val cdLab = ux.label("Wait between plays  " + t.cooldown + " s")
            box.addView(cdLab)
            val s2 = PSlider(act, 1, 30)
            s2.setValue(t.cooldown)
            s2.onValue = { v ->
                t.cooldown = v
                cdLab.text = "Wait between plays  $v s"
                ui.removeCallbacks(saveRun)
                ui.postDelayed(saveRun, 500)
            }
            box.addView(s2, LinearLayout.LayoutParams(-1, -2))

            val bClip = PButton(act, "Play sound", 1, 40f)
            bClip.onClick = {
                val p = Wav.read(File(t.clip))
                if (p != null) PcmPlayer.play(p, 0, p.size, null, null) else ux.toast("The saved sound is missing")
            }
            val bTest = PButton(act, "Test animation", 0, 40f)
            bTest.onClick = {
                val a = FxStore.get(act, t.animId)
                if (a != null) FxOverlay.play(act, a) else ux.toast("Pick an animation first")
            }
            val bDel = PButton(act, "Delete", 2, 40f)
            bDel.onClick = {
                AlertDialog.Builder(act).setTitle("Delete \"" + t.title + "\"?")
                    .setPositiveButton("Delete") { _, _ -> TriggerStore.remove(act, t.id); openTrig = ""; renderTriggers() }
                    .setNegativeButton("Cancel", null).show()
            }
            box.addView(ux.buttons(bClip, bTest, bDel), ux.top(View(act), 14f))
        }
        return box
    }
}
